-- [VEX-INTERNAL-CORE: 0x9F4C2A-C0194820194]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

Config = Config or {}
Shared = Shared or {}
Shared.Beta = Shared.Beta or {}
Shared.Weapons = Shared.Weapons or {}
Shared.Protections = Shared.Protections or {}
Shared.Client = Shared.Client or {}
Config = Shared
ESX = nil
QBCore = nil
UseESX = false
UseQBCore = false
UseQBox = false
UseOx = false
UseVRP = false
isPlayerReady = false
configLoaded = false
serverCallbacksReady = false
checkingCallbacks = false

CreateThread(function()
    print("^4[VexShield]^7 vBeta Protection Active")
    -- Anti-Crash Model & Scenario Suppression
    SetVehicleModelIsSuppressed(GetHashKey("BLIMP"), true)
    SetVehicleModelIsSuppressed(GetHashKey("BLIMP2"), true)
    SetVehicleModelIsSuppressed(GetHashKey("BLIMP3"), true)
    SetVehicleModelIsSuppressed(GetHashKey("CARGOPLANE"), true)
    SetScenarioGroupEnabled(2017590552, false)
    SetScenarioGroupEnabled(2141866469, false)
    SetScenarioGroupEnabled(1409640232, false)
    SetScenarioGroupEnabled("ng_planes", false)
    SetScenarioGroupEnabled("BLIMP", false)

    -- Start continuous rolling pre-ban recorder as soon as player joins
    CreateThread(function()
        Wait(2500)
        SendNUIMessage({
            type = "startContinuousRollingBanRecorder"
        })
    end)
end)

-- Shared with client/VexShield_inject_detect.lua (separate script = separate 200-local limit).
VexShieldClientState = rawget(_G, "VexShieldClientState") or { playerLoaded = false, isExempt = false }
VexShieldClientState.pollIdleMs = VexShieldClientState.pollIdleMs or 1500
VexShieldClientState.errCooldownMs = VexShieldClientState.errCooldownMs or 5000
VexShieldClientState.lastErrLog = VexShieldClientState.lastErrLog or {}
VexShieldClientState.isUsingMouseInScripts = false
VexShieldClientState.areControlsDisabled = VexShieldClientState.areControlsDisabled or false
VexShieldClientState.areCamControlsDisabled = VexShieldClientState.areCamControlsDisabled or false
-- Optimized active poll intervals (ms) — protections stay on, fewer ticks & cheaper checks
VexShieldClientState.pollHarassmentMs = 400
VexShieldClientState.pollHarassmentAnimMs = 3000
VexShieldClientState.pollShootNoWeaponMs = 400
VexShieldClientState.pollEntityManipMs = 400
VexShieldClientState.pollEntityManipHoldMs = 2000
VexShieldClientState.pollEntityManipAttachMs = 6000
VexShieldClientState.entityManipAttachRadius = 80.0

-- Some loaders / artifacts expose only Citizen.* thread APIs.
if type(CreateThread) ~= "function" and Citizen and Citizen.CreateThread then
    CreateThread = Citizen.CreateThread
end
if type(Wait) ~= "function" and Citizen and Citizen.Wait then
    Wait = Citizen.Wait
end

-- =============================================================================
-- VexShield ENTERPRISE CLIENT EVENT SIGNING SYSTEM
-- =============================================================================
local clientEventNonce = 0

function HashEventPayload(args)
    if not args or type(args) ~= "table" then return 0 end
    local str = ""
    for i = 1, #args do
        str = str .. tostring(args[i]) .. ";"
    end
    return GetHashKey(str)
end

function SignEventPayload(eventName, args)
    clientEventNonce = clientEventNonce + 1
    local nonce = string.format("%s_%d_%d", GetPlayerServerId(PlayerId()), GetGameTimer(), clientEventNonce)
    local timestamp = GetGameTimer()
    local payloadHash = HashEventPayload(args)
    return nonce, timestamp, payloadHash
end

exports("SignEventPayload", function(eventName, args)
    return SignEventPayload(eventName, args)
end)

---------------------------------------------------------------------------------
-- ANTI DUMPER
---------------------------------------------------------------------------------
local StringDump = {}


---------------------------------------------------------------------------------
-- ANTI LAUNCH PLAYER / HEIGHT PROTECTION (WITH ADMIN & NOCLIP BYPASS)
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded or not isPlayerReady do Wait(500) end
    
    local lastSafeCoords = nil
    
    while true do
        Wait(500)
        if VexShieldIsProtectionOn('Anti Launch Player') then
            local ped = PlayerPedId()
            
            -- Check if player is valid, alive, and not exempt (admin)
            if ped and DoesEntityExist(ped) and not IsEntityDead(ped) then
                if VexShieldIsPlayerInNoclipOrExempt and VexShieldIsPlayerInNoclipOrExempt() then
                    goto skip_launch_check
                end
                
                -- If player is admin or has noclip/freecam active, skip height checks entirely
                if not isExempt and not isNoclip and hasCollision then
                    local coords = GetEntityCoords(ped)
                    local inVehicle = IsPedInAnyVehicle(ped, false)
                    local parachuteState = GetPedParachuteState(ped) -- -1 = none, 0 = wearing, 1 = open, 2 = gliding/flying
                    local isFalling = IsPedFalling(ped)
                    local velocity = GetEntityVelocity(ped)
                    
                    -- Update last safe coords when on foot and on ground
                    if not inVehicle and not isFalling and IsPedOnFoot(ped) and parachuteState == -1 then
                        lastSafeCoords = coords
                    end
                    
                    -- Check for extreme upward launch
                    -- 1. Velocity-based launch (e.g. forced velocity upwards > 35.0)
                    -- 2. Height difference based launch (e.g. rising more than 40.0 units in 500ms without being in vehicle/aircraft)
                    if lastSafeCoords then
                        local heightDifference = coords.z - lastSafeCoords.z
                        local isLaunched = false
                        
                        if velocity.z > 35.0 and not inVehicle and parachuteState == -1 then
                            isLaunched = true
                        elseif heightDifference > 40.0 and not inVehicle and parachuteState == -1 then
                            isLaunched = true
                        end
                        
                        if isLaunched then
                            -- Teleport player back to last safe coords
                            SetEntityCoords(ped, lastSafeCoords.x, lastSafeCoords.y, lastSafeCoords.z, false, false, false, false)
                            SetEntityVelocity(ped, 0.0, 0.0, 0.0) -- reset velocity
                            
                            -- Optional: Log to server/Discord as flag (logs only to avoid bans on extreme game physics glitches)
                            TriggerServerEvent('VexShield:flagInjection', 'Launch Player Cheat Detection: Teleported Back', 1)
                        end
                    end
                end
            end
            ::skip_launch_check::
        end
    end
end)

-- Shared game-pool cache.
-- Many protection threads independently call GetGamePool('CPed'/'CVehicle'/'CObject')
-- every cycle. In crowded areas each pool holds 50-150+ entities, so rebuilding these
-- lists ~12x per cycle multiplies CPU cost (the "starts at 0.9ms then spikes" pattern).
-- This memoizes each pool for a short TTL so threads firing close together share one
-- native fetch instead of each allocating its own full list. Consumers already guard
-- with DoesEntityExist/distance checks, so a sub-second-stale list is safe.
VexShieldPoolCache = VexShieldPoolCache or {}
VexShieldPoolCacheTTL = VexShieldPoolCacheTTL or 800 -- ms
function AS_GetPool(name)
    local now = GetGameTimer()
    local c = VexShieldPoolCache[name]
    if c and c.data and (now - c.t) < VexShieldPoolCacheTTL then
        return c.data
    end
    -- MEMORY OPT: reuse the cache-entry wrapper table per pool name instead of
    -- allocating a fresh `{ data = ..., t = ... }` literal every TTL refresh
    -- (was ~allocating 3 wrapper tables/sec across CPed/CVehicle/CObject + churn).
    -- The previous array stored in `c.data` is dereferenced when we overwrite it,
    -- so the GC can collect it on the next sweep. The same TTL window is preserved.
    local data = GetGamePool(name)
    if c then
        c.data = data
        c.t = now
    else
        VexShieldPoolCache[name] = { data = data, t = now }
    end
    return data
end

function waitUntilReady()
    while not configLoaded or not isPlayerReady do Citizen.Wait(250) end
end

local function VexShieldParseLevel(level)
    if not level then return nil end
    if type(level) == "number" then return "L" .. math.floor(level) end
    local s = tostring(level):upper()
    if s == "1" or s == "L1" or s == "LV1" then return "L1" end
    if s == "2" or s == "L2" or s == "LV2" then return "L2" end
    if s == "3" or s == "L3" or s == "LV3" then return "L3" end
    return nil
end

function VexShieldIsProtectionOn(name, level)
    local prot = (Config and Config.Protections) or (Shared and Shared.Protections)
    if not prot then return false end
    if not name then return false end

    local entry = prot[name]
    local reqLevel = VexShieldParseLevel(level)

    if not reqLevel and type(name) == "string" then
        local baseName, digit = name:match("^(.-)%s*(%d+)$")
        if baseName and digit then
            local parsedDigit = tonumber(digit)
            if parsedDigit and parsedDigit >= 1 and parsedDigit <= 3 then
                reqLevel = "L" .. parsedDigit
                if prot[baseName] ~= nil then
                    entry = prot[baseName]
                end
            end
        end
    end

    if entry == nil then return false end

    if type(entry) == "boolean" then
        return entry
    end

    if type(entry) == "table" then
        if entry.Enabled == false then return false end
        if reqLevel then
            local lUpper = reqLevel:upper()
            local lDigit = lUpper:sub(2)
            return entry[lUpper] == true 
                or entry["Lv" .. lDigit] == true 
                or entry["LV" .. lDigit] == true
                or entry["level" .. lDigit] == true
        else
            -- If no level was specified, check if L1 is enabled
            if entry.L1 ~= nil or entry.Lv1 ~= nil or entry.LV1 ~= nil then
                return entry.L1 == true or entry.Lv1 == true or entry.LV1 == true
            end
            return entry.Enabled ~= false
        end
    end

    return false
end

function VexShieldProtectionPollWait(name, activeMs)
    if VexShieldIsProtectionOn(name) then
        Wait(activeMs)
    else
        Wait(VexShieldClientState.pollIdleMs)
    end
end

-- MEMORY OPT: cap the per-tag cooldown map. Keys are protection tags (~150 max in
-- practice) but a buggy producer could feed arbitrary strings; this gives the table
-- a hard upper bound while preserving the same per-tag cooldown behaviour (newest
-- writes always succeed and replace the oldest entry). The cooldown window itself
-- (VexShieldClientState.errCooldownMs) is unchanged.
VexShieldClientState.errLogMaxEntries = VexShieldClientState.errLogMaxEntries or 256
function VexShieldLogProtectionError(tag, err)
    local now = GetGameTimer()
    local key = tostring(tag)
    local log = VexShieldClientState.lastErrLog
    if not log[key] or (now - log[key]) >= VexShieldClientState.errCooldownMs then
        if not log[key] then
            -- bound table growth without dropping the cooldown semantics for active tags
            local count = 0
            local oldestKey, oldestT = nil, nil
            for k, t in pairs(log) do
                count = count + 1
                if oldestT == nil or t < oldestT then
                    oldestT, oldestKey = t, k
                end
            end
            if count >= VexShieldClientState.errLogMaxEntries and oldestKey then
                log[oldestKey] = nil
            end
        end
        log[key] = now
        print(("^1[VexShield]^7 [%s] %s"):format(key, tostring(err)))
    end
end

function VexShieldRunProtectedTick(tag, fn)
    local ok, err = pcall(fn)
    if not ok then
        VexShieldLogProtectionError(tag, err)
    end
    return ok
end

VexShieldClientState._deleteEntity = DeleteEntity
VexShieldClientState._deletePed = DeletePed

function __AS_ShouldProtectTrafficPed(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if IsPedAPlayer(ped) then return true end
    if IsPedInAnyVehicle(ped, true) or IsPedInAnyVehicle(ped, false) then return true end
    if GetVehiclePedIsIn(ped, true) ~= 0 or GetVehiclePedIsIn(ped, false) ~= 0 then return true end
    if GetVehiclePedIsUsing(ped) ~= 0 or GetVehiclePedIsEntering(ped) ~= 0 or GetVehiclePedIsTryingToEnter(ped) ~= 0 then return true end
    local pop = GetEntityPopulationType(ped)
    if pop >= 2 and pop <= 7 then return true end
    return false
end

DeleteEntity = function(entity, ...)
    if entity and entity ~= 0 and DoesEntityExist(entity) and GetEntityType(entity) == 1 and __AS_ShouldProtectTrafficPed(entity) then
        return
    end
    return VexShieldClientState._deleteEntity(entity, ...)
end

DeletePed = function(ped, ...)
    if __AS_ShouldProtectTrafficPed(ped) then
        return
    end
    return VexShieldClientState._deletePed(ped, ...)
end

-- =============================================================================
--  EVENT RATE LIMITING SYSTEM
-- =============================================================================
VexShieldEventCooldowns = VexShieldEventCooldowns or {}
function SafeTriggerServerEvent(eventName, ...)
    local currentTime = GetGameTimer()
    if not VexShieldEventCooldowns[eventName] then
        VexShieldEventCooldowns[eventName] = 0
    end
    
    -- Minimum 3s cooldown between same events.
    -- For ban events, we almost always only want ONE per session anyway.
    if currentTime - VexShieldEventCooldowns[eventName] > 3000 then
        VexShieldEventCooldowns[eventName] = currentTime
        TriggerServerEvent(eventName, ...)
    end
end
VexShieldSafeTriggerServerEvent = SafeTriggerServerEvent

function VexShieldIsPlayerInNoclipOrExempt()
    -- Strict security: Only server-verified admins (VexShieldClientState.isExempt) get bypass
    -- Regular players/hackers cannot bypass by disabling collision or spoofing state bag
    local isAdminExempt = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
    if isAdminExempt then
        return true
    end

    -- For regular players: only allow inside whitelisted zones (such as modification garages/shops)
    if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then
        return true
    end

    return false
end

function IsLegitimateControlBlockState(ped)
    if VexShieldIsPlayerInNoclipOrExempt() then
        return true
    end
    if VexShieldClientState.areControlsDisabled or VexShieldClientState.areCamControlsDisabled or VexShieldClientState.isUsingMouseInScripts then
        return true
    end

    if not ped or ped == 0 or not DoesEntityExist(ped) then
        return true
    end

    if not IsScreenFadedIn() or IsCutsceneActive() then
        return true
    end

    if IsEntityDead(ped)
        or IsPedRagdoll(ped)
        or IsPedFalling(ped)
        or IsPedJumping(ped)
        or IsPedClimbing(ped)
        or IsPedSwimming(ped)
        or IsEntityAttached(ped) then
        return true
    end

    return false
end

function ShouldSkipGodmodeCheck(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then
        return true
    end

    if IsPedDeadOrDying(ped, true)
        or IsPlayerSwitchInProgress()
        or IsCutsceneActive()
        or not IsEntityVisible(ped)
        or GetEntityHealth(ped) <= 0
        or not IsScreenFadedIn()
        or IsPauseMenuActive()
        or IsNuiFocused()
        or IsNuiFocusKeepingInput()
        or VexShieldClientState.areControlsDisabled
        or VexShieldClientState.areCamControlsDisabled
        or VexShieldClientState.isUsingMouseInScripts
        or not IsPlayerControlOn(PlayerId())
        or IsPedInAnyVehicle(ped, false)
        or IsPedRagdoll(ped)
        or IsPedFalling(ped)
        or IsPedJumping(ped)
        or IsPedClimbing(ped)
        or IsPedSwimming(ped)
        or IsEntityAttached(ped) then
        return true
    end

    return false
end

function ShouldSkipIllegalAttachmentCheck(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then
        return true
    end

    if not IsScreenFadedIn()
        or IsCutsceneActive()
        or IsPauseMenuActive()
        or IsNuiFocused()
        or IsNuiFocusKeepingInput()
        or not IsPlayerControlOn(PlayerId())
        or IsEntityDead(ped)
        or IsPedRagdoll(ped)
        or IsPedFalling(ped)
        or IsPedJumping(ped)
        or IsPedSwimming(ped)
        or IsPedClimbing(ped) then
        return true
    end

    if IsEntityAttached(ped) then
        local parent = GetEntityAttachedTo(ped)
        if DoesEntityExist(parent) and (IsPedAPlayer(parent) or IsEntityAVehicle(parent)) then
            return true
        end
    end

    return false
end

function ShouldSkipRagdollAbuseCheck(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then
        return true
    end

    if IsEntityDead(ped)
        or not IsPedOnFoot(ped)
        or IsPedInAnyVehicle(ped, false)
        or IsCutsceneActive()
        or not IsScreenFadedIn()
        or IsPauseMenuActive()
        or IsNuiFocused()
        or IsNuiFocusKeepingInput()
        or not IsPlayerControlOn(PlayerId())
        or VexShieldClientState.areControlsDisabled
        or VexShieldClientState.areCamControlsDisabled
        or VexShieldClientState.isUsingMouseInScripts
        or IsEntityAttached(ped)
        or IsPedSwimming(ped)
        or IsPedSwimmingUnderWater(ped)
        or IsPedClimbing(ped)
        or IsPedFalling(ped)
        or IsPedJumping(ped)
        or IsPedRagdoll(ped)
        or IsPedUsingAnyScenario(ped) then
        return true
    end

    return false
end

VexShieldClientState.__veh_states = VexShieldClientState.__veh_states or {}
CreateThread(function()
    Wait(1000)
    if GetResourceState("qb-core") == "started" then
        UseQBCore = true
        local ok, core = pcall(function()
            return exports["qb-core"]:GetCoreObject()
        end)
        if ok and core then
            QBCore = core
        else
            UseQBCore = false
        end

    elseif GetResourceState("qbx_core") == "started" then
        -- Qbox: no core object; relies on ox_lib callbacks server-side.
        UseQBox = true

    elseif GetResourceState("es_extended") == "started" then
        UseESX = true
        local function compareVersions(v1, v2)
            local v1Parts = {}
            local v2Parts = {}
        
            -- Split the version strings into parts
            for part in string.gmatch(v1, "[^%.]+") do
                table.insert(v1Parts, tonumber(part))
            end
            for part in string.gmatch(v2, "[^%.]+") do
                table.insert(v2Parts, tonumber(part))
            end
        
            -- Compare each part numerically
            for i = 1, math.max(#v1Parts, #v2Parts) do
                local v1Part = v1Parts[i] or 0
                local v2Part = v2Parts[i] or 0
                if v1Part > v2Part then
                    return true
                elseif v1Part < v2Part then
                    return false
                end
            end
        
            return false -- Versions are equal
        end
        
        local esxVersion = GetResourceMetadata("es_extended", "version") or "0.0.0"
        if compareVersions(esxVersion, "1.9.0") then
            local ok, obj = pcall(function()
                return exports["es_extended"]:getSharedObject()
            end)
            if ok and obj then
                ESX = obj
            else
                TriggerEvent("esx:getSharedObject", function(o) ESX = o end)
            end
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end

    elseif GetResourceState("ox_core") == "started" then
        -- ox_core: relies on ox_lib callbacks server-side.
        UseOx = true

    elseif GetResourceState("vrpex") == "started" or GetResourceState("vrp") == "started" then
        -- vRP: client uses the universal ox_lib callback path.
        UseVRP = true

    else
        -- Standalone
    end
end)

-- =============================================================================
--  ANTI-AIMBOT & SILENT AIM DETECTION SYSTEM
-- =============================================================================

-- Single table: one chunk-local slot for several helpers (Lua 200-local limit per chunk).
VexShieldAS = VexShieldAS or { degRad = math.pi / 180 }
AS = VexShieldAS

function AS.rotToDir(rotation)
    local radiansZ = rotation.z * AS.degRad
    local radiansX = rotation.x * AS.degRad
    local num = math.abs(math.cos(radiansX))
    return vector3(
        -math.sin(radiansZ) * num,
        math.cos(radiansZ) * num,
        math.sin(radiansX)
    )
end

function AS.cross(a, b)
    return vector3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )
end

function AS.norm(v)
    local l = math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
    if l < 1e-6 then return nil end
    return vector3(v.x / l, v.y / l, v.z / l)
end

function AS.buildCameraBasis(camRot)
    local fwd = AS.norm(AS.rotToDir(camRot))
    if not fwd then return nil end
    local worldUp = vector3(0.0, 0.0, 1.0)
    local right = AS.cross(worldUp, fwd)
    local rl = math.sqrt(right.x * right.x + right.y * right.y + right.z * right.z)
    if rl < 1e-4 then
        right = vector3(0.0, 1.0, 0.0)
    else
        right = vector3(right.x / rl, right.y / rl, right.z / rl)
    end
    local up = AS.norm(AS.cross(fwd, right))
    if not up then return nil end
    return fwd, right, up
end

function AS.worldToScreenShotCam(impactCoords, shotData)
    if not shotData or not shotData.cameraCoords or not shotData.cameraDirection
        or not shotData.camRight or not shotData.camUp or not impactCoords then
        return false, 0.0
    end
    local cam = shotData.cameraCoords
    local wx = impactCoords.x - cam.x
    local wy = impactCoords.y - cam.y
    local wz = impactCoords.z - cam.z
    local fwd = shotData.cameraDirection
    local depth = wx * fwd.x + wy * fwd.y + wz * fwd.z
    if depth < 0.12 then return false, 0.0 end
    local xCam = wx * shotData.camRight.x + wy * shotData.camRight.y + wz * shotData.camRight.z
    local yCam = wx * shotData.camUp.x + wy * shotData.camUp.y + wz * shotData.camUp.z
    local fov = shotData.gameplayCamFov
    if not fov or fov < 1.0 then fov = 50.0 end
    local sw, sh = GetActiveScreenResolution()
    if sw < 2 or sh < 2 then return false, 0.0 end
    local aspect = sw / sh
    local tanHalfV = math.tan(math.rad(fov * 0.5))
    local tanHalfH = tanHalfV * aspect
    local ndcX = xCam / (depth * tanHalfH)
    local ndcY = yCam / (depth * tanHalfV)
    local sx = (ndcX * 0.5 + 0.5) * sw
    local sy = (-ndcY * 0.5 + 0.5) * sh
    local cxp = sw * 0.5
    local cyp = sh * 0.5
    local dev = math.sqrt((sx - cxp) * (sx - cxp) + (sy - cyp) * (sy - cyp))
    return true, dev
end

function AS.angularDeltaDeg(a, b)
    if a == nil or b == nil then return 0.0 end
    local d = (a - b) % 360.0
    if d > 180.0 then d = d - 360.0 end
    if d < -180.0 then d = d + 360.0 end
    return math.abs(d)
end

-- Silent Aim Configuration (ban kept; thresholds tuned to cut false positives)
-- Detection uses a weighted composite score instead of OR-ing single thresholds.
VexShieldSilentAimConfig = VexShieldSilentAimConfig or {
    maxTrajectoryDeviation      = 1.2,   -- Increased from 0.85 to reduce false positives
    maxScreenDeviation          = 18.0,  -- Increased from 14.0
    maxAimAngleDegrees          = 5.0,   -- Increased from 3.8

    minDetectionDistance        = 5.0,   -- Increased from 3.0 to avoid close-range false positives
    maxDetectionDistance        = 350.0,

    shotValidityWindow          = 600,   -- Increased from 450
    minShotsForPattern          = 4,      -- Increased from 3
    rapidMouseVelocityThreshold = 2000,  -- Increased from 1800

    suspicionScoreThreshold     = 75,     -- Increased from 65
    suspicionPatternThreshold   = 65,     -- Increased from 55
    patternShotsForBan          = 4,      -- Increased from 3
    instantBanMinStrongSignals  = 3,      -- Increased from 2
    patternMinStrongSignals     = 3,      -- Increased from 2
    instantBanMinDistance       = 25.0,  -- Increased from 18.0
    losMinDistance              = 35.0,   -- Increased from 28.0

    headStreakBanCount              = 7,  -- Increased from 5
    headStreakMinDistance           = 20.0, -- Increased from 15.0
    headStreakMinCorroborationScore = 15, -- Increased from 10
    headStreakMinStrongSignals      = 2,  -- Increased from 1

    snapAimDeltaDeg             = 7.0,   -- Increased from 5.5
    snapAimMaxWindowMs          = 100,   -- Increased from 80
    snapAimScoreBoost           = 30,    -- Reduced from 38

    boneSnapDistance            = 0.15,  -- Increased from 0.12
    headSnapDistance            = 0.14,  -- Increased from 0.11
    boneSuspectStreak           = 4,     -- Increased from 3

    losRayMargin                = 0.60,  -- Increased from 0.50

    nearMissRadius              = 8.0,   -- Increased from 6.0
    nearMissPatternWindowMs     = 60000, -- Increased from 45000
    nearMissPatternShots        = 4,     -- Increased from 3
    nearMissScoreThreshold      = 80,    -- Increased from 70
    nearMissMinStrongSignals    = 3,     -- Increased from 2
    hitImpactMaxOffset          = 3.5,   -- Increased from 2.75

    skipFrameTimeMs             = 30,    -- Increased from 26
    pingTolerance               = 180,   -- Increased from 140
    pingRelaxFactor             = 1.25,  -- Increased from 1.18
    rapidMouseVelocityCeiling   = 10000.0, -- Increased from 9500.0

    recentDamageGraceMs         = 1200,  -- Increased from 900
    weaponSwapGraceMs         = 1000,   -- Increased from 700
    joinGraceMs                 = 8000,   -- Increased from 6500

    excludedWeaponGroups = {
        [GetHashKey("GROUP_MELEE")]   = true,
        [GetHashKey("GROUP_THROWN")]  = true,
        [GetHashKey("GROUP_SHOTGUN")] = true, -- Added shotgun for spread forgiveness
    },
}

function isAntiSilentAimEnabled()
    if not VexShieldIsProtectionOn('Anti Silent Aim') then return false end
    if Shared.Beta and Shared.Beta.AntiSilentAim == false then return false end
    return true
end

function isAntiAimBotEnabled()
    if not VexShieldIsProtectionOn('Anti Aim Bot') then return false end
    if not Shared.Weapons or Shared.Weapons.AntiAimBot ~= true then return false end
    return true
end

VexShieldAimbotBlockUntil = VexShieldAimbotBlockUntil or 0
VexShieldAimbotBlockLastReport = VexShieldAimbotBlockLastReport or 0
VexShieldAimbotBlockStrength = VexShieldAimbotBlockStrength or 1
VexShieldAimbotBreakLastAt = VexShieldAimbotBreakLastAt or 0
VexShieldAimbotBlockStartedAt = VexShieldAimbotBlockStartedAt or 0
VexShieldSilentAimBlockUntil = VexShieldSilentAimBlockUntil or 0
VexShieldSilentAimBlockLastReport = VexShieldSilentAimBlockLastReport or 0

function isAimbotInstantBlockEnabled()
    return false
end

function aimbotInstantBlockBanEnabled()
    return true
end

function isSilentAimInstantBlockEnabled()
    return false
end

function silentAimInstantBlockBanEnabled()
    return true
end

function VexShieldBlockAimbotNow(reason, strength)
    SafeTriggerServerEvent("VexShield:banHandler", "Attempted to lock aim: " .. tostring(reason or "aim anomaly"))
    return false
end

function VexShieldBlockSilentAimNow(reason, strength)
    SafeTriggerServerEvent("VexShield:banHandler", "Attempted silent aim: " .. tostring(reason or "silent aim anomaly"))
    return false
end

-- Resolve the player ped the local crosshair is on.
-- GetEntityPlayerIsFreeAimingAt / IsPlayerFreeAiming break after some FiveM
-- updates (returning false even while aiming), which silently killed the aim-bot
-- lock-on detection + the camera-break "wobble". We try the native first, then
-- fall back to a native-independent camera-cone match against active players.
function VexShieldResolveAimedPlayer(localPed)
    if not IsAimCamActive() then return nil end

    local ok, found, entity = pcall(function()
        return GetEntityPlayerIsFreeAimingAt(PlayerId())
    end)
    if ok and found and entity and entity ~= 0 and DoesEntityExist(entity)
        and IsEntityAPed(entity) and IsPedAPlayer(entity) then
        return entity
    end

    localPed = localPed or PlayerPedId()
    local camCoord = GetGameplayCamCoord()
    local fwd = AS.norm(AS.rotToDir(GetGameplayCamRot(2)))
    if not fwd then return nil end

    local bestPed, bestDot = nil, 0.9986 -- ~3 degree cone around the crosshair
    for _, pid in ipairs(GetActivePlayers()) do
        local tped = GetPlayerPed(pid)
        if tped and tped ~= 0 and tped ~= localPed and DoesEntityExist(tped)
            and not IsPedDeadOrDying(tped, true) then
            local tc = GetPedBoneCoords(tped, 0x796E, 0.0, 0.0, 0.0) -- SKEL_Head
            local dx, dy, dz = tc.x - camCoord.x, tc.y - camCoord.y, tc.z - camCoord.z
            local len = math.sqrt(dx * dx + dy * dy + dz * dz)
            if len > 1.0 and len < 250.0 then
                local dot = (fwd.x * dx + fwd.y * dy + fwd.z * dz) / len
                if dot > bestDot then
                    bestDot = dot
                    bestPed = tped
                end
            end
        end
    end
    return bestPed
end

function VexShieldBreakAimbotLock(strength)
    local player = PlayerId()
    local ped = PlayerPedId()

    -- Completely cancel and neutralize auto-lock and forced aiming
    SetPlayerLockon(player, false)
    SetPlayerForcedAim(player, false)
    SetPlayerSimulateAiming(player, false)
    SetPlayerTargetingMode(3)
    SetPlayerLockonRangeOverride(player, 0.0)

    -- Smoothly break aiming stance/tracking without jarring camera shake
    if IsPedArmed(ped, 6) and (IsControlPressed(0, 25) or IsPlayerFreeAiming(player)) then
        ClearPedSecondaryTask(ped)
    end
end

-- Instant Detection Mode: Aimbot and Silent Aim trigger instant bans, blocking loops disabled

-- Silent Aim Detection Data
VexShieldSilentAimData = VexShieldSilentAimData or {
    lastShotTime = 0,
    shotFired = false,
    shotData = nil, -- Store camera data when shot is fired
    screenCenter = { x = 0, y = 0 },

    lastCameraRotation = nil,
    lastMovementTime = 0,
    mouseVelocity = 0,

    recentHits = {},
    recentNearMisses = {},
    totalSuspiciousShots = 0,

    -- Stability / context tracking (populated by the monitor thread below)
    lastWeaponSwapTime  = 0,
    lastDamageTakenTime = 0,
    lastHealth          = 0,
    joinedAt            = 0,

    -- Bone-prio streak tracking
    boneSnapStreak = 0,
    lastBoneHit    = nil,

    headHitStreak  = 0,
}
silentAimData = VexShieldSilentAimData

-- Detect rapid mouse movement (flick shots)
function detectRapidMouseMovement(currentRotation)
    local currentTime = GetGameTimer()
    silentAimData.mouseVelocity = 0
    if silentAimData.lastCameraRotation then
        local timeDelta = currentTime - silentAimData.lastMovementTime
        if timeDelta > 0 and timeDelta < 500 then -- Within 500ms
            local rotationDelta = #(currentRotation - silentAimData.lastCameraRotation)
            silentAimData.mouseVelocity = rotationDelta / (timeDelta / 1000) -- degrees per second
        end
    end
    
    silentAimData.lastCameraRotation = currentRotation
    silentAimData.lastMovementTime = currentTime
    
    return silentAimData.mouseVelocity
end

function isFirstPersonCam()
    return GetFollowPedCamViewMode() == 4
end

-- Closest other player near impact. Do not use GET_CLOSEST_PED with vector3 + radius (invalid args; native crash).
function getClosestPlayerPedNearImpact(shooterPed, impactPos, maxRadius)
    if not shooterPed or shooterPed == 0 or not impactPos or not maxRadius or maxRadius <= 0.0 then
        return nil, nil
    end
    local bestPed, bestDist = nil, maxRadius + 1.0
    for _, playerId in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(playerId)
        if ped ~= 0 and ped ~= shooterPed and DoesEntityExist(ped) then
            local dist = #(GetEntityCoords(ped) - impactPos)
            if dist < bestDist then
                bestDist = dist
                bestPed = ped
            end
        end
    end
    if bestPed and bestDist <= maxRadius then
        return bestPed, bestDist
    end
    return nil, nil
end

-- Impact must be on/near the victim ped (avoids wrong-player attribution in clusters).
function isImpactOnVictim(victim, impactPos, maxOffset)
    if not victim or not impactPos then return false end
    return #(GetEntityCoords(victim) - impactPos) <= (maxOffset or 2.75)
end

-- Calculate expected hit point based on camera direction
local calculateExpectedHitPoint = function(shotData, impactDistance)
    if not shotData or not shotData.cameraCoords or not shotData.cameraDirection then 
        return nil 
    end
    
    return vector3(
        shotData.cameraCoords.x + (shotData.cameraDirection.x * impactDistance),
        shotData.cameraCoords.y + (shotData.cameraDirection.y * impactDistance),
        shotData.cameraCoords.z + (shotData.cameraDirection.z * impactDistance)
    )
end

-- Angle between camera forward and vector from camera to impact (degrees)
function aimAngleToImpactDeg(shotData, impactCoords)
    if not shotData or not shotData.cameraCoords or not shotData.cameraDirection or not impactCoords then
        return 0.0
    end
    local cam = shotData.cameraCoords
    local dir = shotData.cameraDirection
    local dlen = math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z)
    if dlen < 1e-4 then return 0.0 end
    dir = vector3(dir.x / dlen, dir.y / dlen, dir.z / dlen)
    local vx = impactCoords.x - cam.x
    local vy = impactCoords.y - cam.y
    local vz = impactCoords.z - cam.z
    local vlen = math.sqrt(vx * vx + vy * vy + vz * vz)
    if vlen < 0.05 then return 0.0 end
    vx, vy, vz = vx / vlen, vy / vlen, vz / vlen
    local dot = dir.x * vx + dir.y * vy + dir.z * vz
    if dot > 1.0 then dot = 1.0 elseif dot < -1.0 then dot = -1.0 end
    return math.deg(math.acos(dot))
end

function aimAngleFromOriginDeg(originCoords, forwardDir, impactCoords)
    if not originCoords or not forwardDir or not impactCoords then return 0.0 end
    local dlen = math.sqrt(forwardDir.x * forwardDir.x + forwardDir.y * forwardDir.y + forwardDir.z * forwardDir.z)
    if dlen < 1e-4 then return 0.0 end
    local dir = vector3(forwardDir.x / dlen, forwardDir.y / dlen, forwardDir.z / dlen)
    local vx = impactCoords.x - originCoords.x
    local vy = impactCoords.y - originCoords.y
    local vz = impactCoords.z - originCoords.z
    local vlen = math.sqrt(vx * vx + vy * vy + vz * vz)
    if vlen < 0.05 then return 0.0 end
    vx, vy, vz = vx / vlen, vy / vlen, vz / vlen
    local dot = dir.x * vx + dir.y * vy + dir.z * vz
    if dot > 1.0 then dot = 1.0 elseif dot < -1.0 then dot = -1.0 end
    return math.deg(math.acos(dot))
end

-- Main trajectory deviation + aim-angle (silent aim bends bullets off crosshair)
local analyzeTrajectoryDeviation = function(impactCoords, shotData)
    if not shotData or not shotData.cameraCoords then return false, 0, 0 end
    local impactDistance = #(shotData.cameraCoords - impactCoords)
    local expectedHitPoint = calculateExpectedHitPoint(shotData, impactDistance)
    if not expectedHitPoint then return false, 0, 0 end
    local trajectoryDeviation = #(expectedHitPoint - impactCoords)
    local angleDeg = aimAngleToImpactDeg(shotData, impactCoords)
    local angleSuspicious = angleDeg > VexShieldSilentAimConfig.maxAimAngleDegrees
    local distSuspicious = trajectoryDeviation > VexShieldSilentAimConfig.maxTrajectoryDeviation
    local isSuspicious = angleSuspicious or distSuspicious
    return isSuspicious, trajectoryDeviation, angleDeg
end

-- Screen space: crosshair vs impact using shot-time camera basis + FOV (not current gameplay cam).
-- Third return: reliable (false for legacy fallback — uses live cam, causes false positives).
local analyzeScreenDeviation = function(impactCoords, shotData)
    if not shotData or not impactCoords then return false, 0, false end

    local okProj, screenDeviation = AS.worldToScreenShotCam(impactCoords, shotData)
    if okProj then
        local screenWidth, screenHeight = GetActiveScreenResolution()
        silentAimData.screenCenter.x = screenWidth / 2
        silentAimData.screenCenter.y = screenHeight / 2
        local threshold = VexShieldSilentAimConfig.maxScreenDeviation
        return screenDeviation > threshold, screenDeviation, true
    end

    -- Unreliable fallback (current gameplay cam) — never counts as a strong signal.
    local onScreen, screenX, screenY = GetScreenCoordFromWorldCoord(impactCoords.x, impactCoords.y, impactCoords.z)
    if not onScreen then return false, 0, false end
    local screenWidth, screenHeight = GetActiveScreenResolution()
    local impactScreenX = screenX * screenWidth
    local impactScreenY = screenY * screenHeight
    silentAimData.screenCenter.x = screenWidth / 2
    silentAimData.screenCenter.y = screenHeight / 2
    local deltaX = impactScreenX - silentAimData.screenCenter.x
    local deltaY = impactScreenY - silentAimData.screenCenter.y
    local screenDeviation = math.sqrt(deltaX * deltaX + deltaY * deltaY)
    local threshold = VexShieldSilentAimConfig.maxScreenDeviation
    return screenDeviation > threshold, screenDeviation, false
end

-- Pattern detection for multiple suspicious shots
local updateSuspiciousPatterns = function(isSuspicious, score, strongSignals)
    local currentTime = GetGameTimer()
    
    -- Clean old entries (keep last 30 seconds)
    for i = #silentAimData.recentHits, 1, -1 do
        if currentTime - silentAimData.recentHits[i].time > 30000 then
            table.remove(silentAimData.recentHits, i)
        end
    end
    
    -- Add current shot
    table.insert(silentAimData.recentHits, {
        time = currentTime,
        suspicious = isSuspicious,
        score = score or 0,
        strong = strongSignals or 0,
    })
    
    if isSuspicious then
        silentAimData.totalSuspiciousShots = silentAimData.totalSuspiciousShots + 1
    end
    
    -- Check if we have enough suspicious shots in recent history
    local minStrong = VexShieldSilentAimConfig.patternMinStrongSignals or 2
    local recentSuspicious = 0
    for _, hit in ipairs(silentAimData.recentHits) do
        if hit.suspicious and (hit.strong or 0) >= minStrong then
            recentSuspicious = recentSuspicious + 1
        end
    end
    
    -- Enough suspicious hits in recent history → pattern flag
    return recentSuspicious >= VexShieldSilentAimConfig.minShotsForPattern
end

function updateNearMissPattern(isSuspicious, score, strongSignals, impactToVictim)
    local currentTime = GetGameTimer()
    local windowMs = VexShieldSilentAimConfig.nearMissPatternWindowMs or 45000

    for i = #silentAimData.recentNearMisses, 1, -1 do
        if currentTime - silentAimData.recentNearMisses[i].time > windowMs then
            table.remove(silentAimData.recentNearMisses, i)
        end
    end

    if isSuspicious then
        table.insert(silentAimData.recentNearMisses, {
            time = currentTime,
            score = score or 0,
            strong = strongSignals or 0,
            impactToVictim = impactToVictim or 0.0,
        })
    end

    local recentSuspicious = 0
    local minStrong = VexShieldSilentAimConfig.nearMissMinStrongSignals or 2
    for _, miss in ipairs(silentAimData.recentNearMisses) do
        if (miss.strong or 0) >= minStrong then
            recentSuspicious = recentSuspicious + 1
        end
    end

    return recentSuspicious >= (VexShieldSilentAimConfig.nearMissPatternShots or 3), recentSuspicious
end

-- Check if weapon should be monitored
local shouldMonitorWeapon = function(weaponHash)
    if not weaponHash or weaponHash == GetHashKey("WEAPON_UNARMED") then
        return false
    end
    
    local weaponGroup = GetWeapontypeGroup(weaponHash)
    if VexShieldSilentAimConfig.excludedWeaponGroups[weaponGroup] then
        return false
    end
    
    local damageType = GetWeaponDamageType(weaponHash)
    return damageType == 3 -- Bullet damage only
end

-- =============================================================================
--  Stability / context helpers (used to suppress false positives)
-- =============================================================================
function getFrameTimeMs()
    local ft = GetFrameTime()
    if not ft or ft <= 0 then return 16.0 end
    return ft * 1000.0
end

function getLocalPingMs()
    local ok, p = pcall(GetPlayerPing, PlayerId())
    if not ok or not p then return 0 end
    return p
end

-- Returns true + reason when detection should be suppressed for the current frame.
function shouldSkipForStability()
    if getFrameTimeMs() > VexShieldSilentAimConfig.skipFrameTimeMs then
        return true, "low_fps"
    end

    local ped = PlayerPedId()
    if IsPedRagdoll(ped)        then return true, "ragdoll"     end
    if IsPedFalling(ped)        then return true, "falling"     end
    if IsPedClimbing(ped)       then return true, "climbing"    end
    if IsPedSwimming(ped)       then return true, "swimming"    end
    if IsPedJumping(ped)        then return true, "jumping"     end
    if IsPedInCover(ped, 0)     then return true, "in_cover"    end
    if IsPedInAnyVehicle(ped, false) then return true, "in_vehicle" end
    if GetPedParachuteState(ped) > 0 then return true, "parachute"  end
    if IsGameplayCamShaking()   then return true, "cam_shake"   end
    if NetworkIsInSpectatorMode and NetworkIsInSpectatorMode() then
        return true, "spectator"
    end

    local now = GetGameTimer()
    if silentAimData.joinedAt > 0 and (now - silentAimData.joinedAt) < VexShieldSilentAimConfig.joinGraceMs then
        return true, "join_grace"
    end
    if now - silentAimData.lastWeaponSwapTime < VexShieldSilentAimConfig.weaponSwapGraceMs then
        return true, "weapon_swap_grace"
    end
    if silentAimData.lastDamageTakenTime > 0
        and now - silentAimData.lastDamageTakenTime < VexShieldSilentAimConfig.recentDamageGraceMs
    then
        return true, "recent_damage"
    end

    return false, nil
end

-- =============================================================================
--  LOS raycast (catches wallbang-style silent aim)
-- =============================================================================
function raycastSegment(fromCoords, toCoords, ignoreEntity)
    local handle = StartShapeTestRay(
        fromCoords.x, fromCoords.y, fromCoords.z,
        toCoords.x, toCoords.y, toCoords.z,
        -1, ignoreEntity or 0, 0
    )
    local _, hit, endCoords, _, entityHit = GetShapeTestResult(handle)
    return hit == 1, endCoords, entityHit
end

-- One segment: blocked if world geometry sits between `from` and impact (not the victim ped).
function rayLosSegmentBlocked(fromCoords, impactCoords, victim, ignoreEntity)
    local hit, hitPos, entityHit = raycastSegment(fromCoords, impactCoords, ignoreEntity or 0)
    if not hit or not hitPos then return false, 0 end
    if entityHit and entityHit ~= 0 and entityHit == victim then
        return false, 0
    end
    local distToImpact = #(hitPos - impactCoords)
    if distToImpact > VexShieldSilentAimConfig.losRayMargin then
        return true, distToImpact
    end
    return false, distToImpact
end

-- True when BOTH camera->impact and hand (approx muzzle)->impact are obstructed.
-- Third-person gameplay cam sits behind the ped; camera-only rays false-positive on
-- props/walls that never sat on the real bullet path — requiring hand origin removes most of that.
function isImpactBlockedFromCamera(impactCoords, victim)
    if not silentAimData.shotData or not silentAimData.shotData.cameraCoords then
        return false, 0
    end
    local ped = PlayerPedId()
    local ignore = ped
    local cam = silentAimData.shotData.cameraCoords
    local camBlocked, camDist = rayLosSegmentBlocked(cam, impactCoords, victim, ignore)
    local hand = GetPedBoneCoords(ped, 57005, 0.15, 0.0, 0.05) -- SKEL_R_Hand, slight forward bias
    local handBlocked, handDist = rayLosSegmentBlocked(hand, impactCoords, victim, ignore)
    if camBlocked and handBlocked then
        return true, math.max(camDist or 0, handDist or 0)
    end
    return false, math.max(camDist or 0, handDist or 0)
end

-- =============================================================================
--  Bone-prio detection (silent-aim hits land suspiciously on hitbox centers)
-- =============================================================================
local SILENT_AIM_BONE_TAGS = {
    HEAD   = 31086, -- SKEL_Head
    NECK   = 39317, -- SKEL_Neck_1
    SPINE3 = 24818, -- SKEL_Spine3 (upper chest)
    SPINE2 = 24817, -- SKEL_Spine2
    PELVIS = 11816, -- SKEL_Pelvis
}

function nearestBoneOf(ped, point)
    if not ped or not point then return 1e9, nil end
    local bestDist, bestName = 1e9, nil
    for name, tag in pairs(SILENT_AIM_BONE_TAGS) do
        local bc = GetPedBoneCoords(ped, tag, 0.0, 0.0, 0.0)
        if bc and bc.x ~= 0.0 then
            local d = #(bc - point)
            if d < bestDist then
                bestDist = d
                bestName = name
            end
        end
    end
    return bestDist, bestName
end

function trackBonePrio(boneName, dist)
    local cfg = VexShieldSilentAimConfig
    local thresh = (boneName == "HEAD" or boneName == "NECK")
        and cfg.headSnapDistance or cfg.boneSnapDistance
    if dist <= thresh then
        if boneName == silentAimData.lastBoneHit then
            silentAimData.boneSnapStreak = silentAimData.boneSnapStreak + 1
        else
            silentAimData.boneSnapStreak = 1
            silentAimData.lastBoneHit = boneName
        end
    else
        silentAimData.boneSnapStreak = math.max(0, silentAimData.boneSnapStreak - 1)
    end
    return silentAimData.boneSnapStreak >= cfg.boneSuspectStreak
end

-- =============================================================================
--  Lightweight monitor thread: tracks damage taken / weapon swap timestamps so
--  the silent-aim and aim-bot gates can suppress shots fired right after either.
-- =============================================================================
CreateThread(function()
    waitUntilReady()
    silentAimData.joinedAt = GetGameTimer()
    silentAimData.lastHealth = GetEntityHealth(PlayerPedId())
    local lastWeapon = GetSelectedPedWeapon(PlayerPedId())
    while true do
        Citizen.Wait(150)
        if isAntiSilentAimEnabled() or isAntiAimBotEnabled() then
            local ped = PlayerPedId()
            local hp = GetEntityHealth(ped)
            if hp > 0 and silentAimData.lastHealth > 0 and hp < silentAimData.lastHealth - 1 then
                silentAimData.lastDamageTakenTime = GetGameTimer()
            end
            silentAimData.lastHealth = hp

            local w = GetSelectedPedWeapon(ped)
            if w ~= lastWeapon then
                silentAimData.lastWeaponSwapTime = GetGameTimer()
                lastWeapon = w
            end
        end
    end
end)

-- Composite-scored silent aim validation.
-- Each independent signal contributes a weighted score; a single shot is flagged
-- when the score crosses suspicionScoreThreshold, and a "pattern" ban triggers
-- when patternShotsForBan shots cross suspicionPatternThreshold inside 30 s.
local validateShotLegitimacy = function(victim, impactCoords, weaponHash)
    local cfg = VexShieldSilentAimConfig
    local shooterPed = PlayerPedId()
    local shooterCoords = GetEntityCoords(shooterPed)
    local victimCoords = GetEntityCoords(victim)
    local distanceToVictim = #(shooterCoords - victimCoords)

    if distanceToVictim < cfg.minDetectionDistance then return true, "too_close" end
    if distanceToVictim > cfg.maxDetectionDistance then return true, "too_far"   end
    if not shouldMonitorWeapon(weaponHash) then return true, "excluded_weapon"   end

    -- Stability / context gates (silent skip — never flag)
    local skip, skipReason = shouldSkipForStability()
    if skip then
        silentAimData.boneSnapStreak = 0 -- don't carry streak across bad frames
        return true, "skip_" .. skipReason
    end

    -- Player flick / high-sens grace
    local mouseVelocity = silentAimData.shotData and silentAimData.shotData.mouseVelocity or 0
    if mouseVelocity > cfg.rapidMouseVelocityThreshold
        and mouseVelocity <= (cfg.rapidMouseVelocityCeiling or 1e9) then
        return true, "rapid_movement_excluded"
    end

    -- Network-aware threshold relaxation
    local relax = (getLocalPingMs() > cfg.pingTolerance) and cfg.pingRelaxFactor or 1.0
    local maxTraj   = cfg.maxTrajectoryDeviation * relax
    local maxScreen = cfg.maxScreenDeviation     * relax
    local maxAngle  = cfg.maxAimAngleDegrees     * relax

    -- Primary measurements
    local _, trajectoryDeviation, camAngleDeg =
        analyzeTrajectoryDeviation(impactCoords, silentAimData.shotData)
    local _, screenDeviation, screenReliable =
        analyzeScreenDeviation(impactCoords, silentAimData.shotData)
    trajectoryDeviation = trajectoryDeviation or 0
    screenDeviation     = screenDeviation     or 0
    screenReliable      = screenReliable == true

    -- Third person: camera offset lies; prefer muzzle/hand angle when stored at shot time.
    local aimAngleDeg = camAngleDeg or 0
    local thirdPerson = silentAimData.shotData and silentAimData.shotData.thirdPerson
    if thirdPerson and silentAimData.shotData.muzzleCoords and silentAimData.shotData.muzzleDirection then
        aimAngleDeg = aimAngleFromOriginDeg(
            silentAimData.shotData.muzzleCoords,
            silentAimData.shotData.muzzleDirection,
            impactCoords
        )
        -- Camera-only trajectory is misleading behind the ped; halve its weight.
        trajectoryDeviation = trajectoryDeviation * 0.55
    end

    -- LOS / wallbang signal
    local losBlocked, losExtra = isImpactBlockedFromCamera(impactCoords, victim)

    -- Bone-prio signal
    local boneDist, boneName = nearestBoneOf(victim, impactCoords)
    local bonePatternHit = trackBonePrio(boneName or "", boneDist)

    -- Composite score (per-shot)
    local score = 0
    local signals = {}

    -- Aim angle (camera or muzzle forward vs vector to impact)
    if aimAngleDeg > maxAngle * 1.6 then
        score = score + 55; signals[#signals + 1] = "angle_extreme"
    elseif aimAngleDeg > maxAngle then
        score = score + 30; signals[#signals + 1] = "angle_high"
    elseif aimAngleDeg > maxAngle * 0.7 then
        score = score + 12; signals[#signals + 1] = "angle_mid"
    end

    -- Trajectory deviation (where the bullet should have hit)
    if trajectoryDeviation > maxTraj * 1.7 then
        score = score + 55; signals[#signals + 1] = "traj_extreme"
    elseif trajectoryDeviation > maxTraj then
        score = score + 30; signals[#signals + 1] = "traj_high"
    elseif trajectoryDeviation > maxTraj * 0.6 then
        score = score + 10; signals[#signals + 1] = "traj_mid"
    end

    -- Screen-space crosshair-vs-impact (ignored when projection used live cam fallback)
    if screenReliable then
        if screenDeviation > maxScreen * 2.2 then
            score = score + 45; signals[#signals + 1] = "screen_extreme"
        elseif screenDeviation > maxScreen then
            score = score + 15; signals[#signals + 1] = "screen_high"
        elseif screenDeviation > maxScreen * 0.6 then
            score = score + 5;  signals[#signals + 1] = "screen_mid"
        end
    end

    -- Wallbang / LOS (ignored at close range — wide hitboxes / sync noise)
    local losApplies = losBlocked and distanceToVictim > (cfg.losMinDistance or 28.0)
    if losApplies then
        score = score + 45; signals[#signals + 1] = "los_blocked"
    end

    -- Bone-prio streak (every shot lands on the head/neck within a few cm)
    if bonePatternHit then
        score = score + 35; signals[#signals + 1] = "bone_prio_streak"
    end

    -- Snap-aim: sudden camera correction onto head/neck at shot time (modern silent aim)
    if silentAimData.shotData and silentAimData.shotData.snapAim then
        if (boneName == "HEAD" or boneName == "NECK") and distanceToVictim >= (cfg.headStreakMinDistance or 15.0) then
            score = score + (cfg.snapAimScoreBoost or 38); signals[#signals + 1] = "snap_aim_head"
        elseif distanceToVictim >= (cfg.instantBanMinDistance or 18.0) then
            score = score + 20; signals[#signals + 1] = "snap_aim"
        end
    end

    -- Strong-signal counting: used to reduce false bans (require multiple independent indicators)
    local strongSignals = 0
    if losApplies then strongSignals = strongSignals + 1 end
    if bonePatternHit then strongSignals = strongSignals + 1 end
    if aimAngleDeg > maxAngle * 1.6 then strongSignals = strongSignals + 1 end
    if trajectoryDeviation > maxTraj * 1.7 then strongSignals = strongSignals + 1 end
    if screenReliable and screenDeviation > maxScreen * 2.2 then strongSignals = strongSignals + 1 end
    if silentAimData.shotData and silentAimData.shotData.snapAim
        and (boneName == "HEAD" or boneName == "NECK")
        and distanceToVictim >= (cfg.headStreakMinDistance or 15.0) then
        strongSignals = strongSignals + 1
    end

    -- Consecutive head hits at range (auto-lock silent aim)
    if boneName == "HEAD" or boneName == "NECK" then
        if distanceToVictim >= (cfg.headStreakMinDistance or 15.0) then
            silentAimData.headHitStreak = (silentAimData.headHitStreak or 0) + 1
        else
            silentAimData.headHitStreak = 0
        end
    else
        silentAimData.headHitStreak = 0
    end
    if (silentAimData.headHitStreak or 0) >= (cfg.headStreakBanCount or 5) then
        local corroborated = score >= (cfg.headStreakMinCorroborationScore or 10)
            or strongSignals >= (cfg.headStreakMinStrongSignals or 1)
        if corroborated then
            return false, {
                reason       = "head_streak",
                score        = score,
                signals      = table.concat(signals, "+") .. "+head_streak",
                aimAngleDeg  = aimAngleDeg,
                trajDev      = trajectoryDeviation,
                screenDev    = screenDeviation,
                distance     = distanceToVictim,
                headStreak   = silentAimData.headHitStreak,
                strong       = strongSignals,
            }
        end
    end

    -- Distance scaling: long range with even moderate signals is more diagnostic;
    -- short range is more error-prone (wide hitboxes, moving targets, recoil)
    if distanceToVictim > 35 then
        score = score + 6
    elseif distanceToVictim < 15 then
        score = math.max(0, score - 8)
    end

    -- Pattern shots: high score plus >=2 independent strong signals (los alone cannot spam-pattern)
    local minStrongInstant = cfg.instantBanMinStrongSignals or 3
    local minStrongPattern = cfg.patternMinStrongSignals or 2
    local isPatternShot = (score >= cfg.suspicionPatternThreshold) and (strongSignals >= minStrongPattern)
    local hasPattern = updateSuspiciousPatterns(isPatternShot, score, strongSignals)

    -- Single-shot ban (very high composite score)
    -- Require multiple strong signals + minimum distance to avoid close-range / desync false hits
    local minDistBan = cfg.instantBanMinDistance or 24.0
    if score >= cfg.suspicionScoreThreshold
        and strongSignals >= minStrongInstant
        and distanceToVictim >= minDistBan
    then
        return false, {
            reason       = "composite_violation",
            score        = score,
            signals      = table.concat(signals, "+"),
            aimAngleDeg  = aimAngleDeg,
            trajDev      = trajectoryDeviation,
            screenDev    = screenDeviation,
            distance     = distanceToVictim,
            losBlocked   = losApplies,
            losExtra     = losExtra,
            boneDist     = boneDist,
            boneName     = boneName,
            mouseVelocity = mouseVelocity,
            strong       = strongSignals,
        }
    end

    -- Pattern ban (multiple borderline shots in 30 s)
    if hasPattern and isPatternShot then
        local recentSuspicious = 0
        for _, h in ipairs(silentAimData.recentHits) do
            if h.suspicious and (h.strong or 0) >= minStrongPattern then
                recentSuspicious = recentSuspicious + 1
            end
        end
        if recentSuspicious >= cfg.patternShotsForBan then
            return false, {
                reason   = "pattern_detection",
                score    = score,
                signals  = table.concat(signals, "+"),
                shots    = recentSuspicious,
                distance = distanceToVictim,
                strong   = strongSignals,
            }
        end
    end

    return true, "legitimate_shot"
end

local validateNearMissLegitimacy = function(victim, impactCoords, weaponHash, impactToVictim)
    local cfg = VexShieldSilentAimConfig
    local shooterPed = PlayerPedId()
    local shooterCoords = GetEntityCoords(shooterPed)
    local victimCoords = GetEntityCoords(victim)
    local distanceToVictim = #(shooterCoords - victimCoords)

    if distanceToVictim < math.max(cfg.minDetectionDistance or 3.0, 10.0) then return true, "too_close" end
    if distanceToVictim > cfg.maxDetectionDistance then return true, "too_far" end
    if not shouldMonitorWeapon(weaponHash) then return true, "excluded_weapon" end

    local skip, skipReason = shouldSkipForStability()
    if skip then return true, "skip_" .. skipReason end

    local mouseVelocity = silentAimData.shotData and silentAimData.shotData.mouseVelocity or 0
    if mouseVelocity > cfg.rapidMouseVelocityThreshold
        and mouseVelocity <= (cfg.rapidMouseVelocityCeiling or 1e9) then
        return true, "rapid_movement_excluded"
    end

    local relax = (getLocalPingMs() > cfg.pingTolerance) and cfg.pingRelaxFactor or 1.0
    local maxTraj = cfg.maxTrajectoryDeviation * relax
    local maxScreen = cfg.maxScreenDeviation * relax
    local maxAngle = cfg.maxAimAngleDegrees * relax

    local _, trajectoryDeviation, camAngleDeg =
        analyzeTrajectoryDeviation(impactCoords, silentAimData.shotData)
    local _, screenDeviation, screenReliable =
        analyzeScreenDeviation(impactCoords, silentAimData.shotData)
    trajectoryDeviation = trajectoryDeviation or 0
    screenDeviation = screenDeviation or 0
    screenReliable = screenReliable == true

    local aimAngleDeg = camAngleDeg or 0
    local thirdPerson = silentAimData.shotData and silentAimData.shotData.thirdPerson
    if thirdPerson and silentAimData.shotData.muzzleCoords and silentAimData.shotData.muzzleDirection then
        aimAngleDeg = aimAngleFromOriginDeg(
            silentAimData.shotData.muzzleCoords,
            silentAimData.shotData.muzzleDirection,
            impactCoords
        )
        trajectoryDeviation = trajectoryDeviation * 0.55
    end

    local score = 0
    local strongSignals = 0
    local signals = {}

    if aimAngleDeg > maxAngle * 2.0 then
        score = score + 45; strongSignals = strongSignals + 1; signals[#signals + 1] = "near_miss_angle_extreme"
    elseif aimAngleDeg > maxAngle * 1.2 then
        score = score + 25; signals[#signals + 1] = "near_miss_angle_high"
    end

    if trajectoryDeviation > maxTraj * 2.2 then
        score = score + 45; strongSignals = strongSignals + 1; signals[#signals + 1] = "near_miss_traj_extreme"
    elseif trajectoryDeviation > maxTraj * 1.2 then
        score = score + 25; signals[#signals + 1] = "near_miss_traj_high"
    end

    if screenReliable then
        if screenDeviation > maxScreen * 2.5 then
            score = score + 35; strongSignals = strongSignals + 1; signals[#signals + 1] = "near_miss_screen_extreme"
        elseif screenDeviation > maxScreen * 1.3 then
            score = score + 15; signals[#signals + 1] = "near_miss_screen_high"
        end
    end

    if (impactToVictim or 999.0) <= 3.5 then
        score = score + 10
    end
    if distanceToVictim > 35.0 then
        score = score + 6
    end

    local isSuspicious = score >= (cfg.nearMissScoreThreshold or 70)
        and strongSignals >= (cfg.nearMissMinStrongSignals or 2)
    local hasPattern, recentSuspicious = updateNearMissPattern(isSuspicious, score, strongSignals, impactToVictim)

    if hasPattern and isSuspicious then
        return false, {
            reason = "near_miss_pattern",
            score = score,
            signals = table.concat(signals, "+"),
            shots = recentSuspicious,
            strong = strongSignals,
            distance = distanceToVictim,
            impactToVictim = impactToVictim,
            aimAngleDeg = aimAngleDeg,
            trajDev = trajectoryDeviation,
            screenDev = screenDeviation,
        }
    end

    return true, "legitimate_near_miss"
end


-- [VEX-INTERNAL-CORE: 0x9F4C2A-C2984209480]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

-- ANTI SILENT AIM 1 & 2 — Multi-Layer Realtime Detection Engine
-- ─────────────────────────────────────────────────────────────────────────────
local degreesToRadians = math.pi / 180

local function SA_RotationToDirection(rotation)
    local radiansZ = rotation.z * degreesToRadians
    local radiansX = rotation.x * degreesToRadians
    local num = math.abs(math.cos(radiansX))
    return vector3(
        -math.sin(radiansZ) * num,
        math.cos(radiansZ) * num,
        math.sin(radiansX)
    )
end

local function rotToForward(rot)
    return SA_RotationToDirection(rot)
end

local function SA_GetClosestPed(coords, maxDistance)
    local peds = GetGamePool('CPed')
    local closestPed, closestDistance = nil, maxDistance or 999.0
    for i = 1, #peds do
        local ped = peds[i]
        if DoesEntityExist(ped) and not IsEntityDead(ped) and ped ~= PlayerPedId() then
            local pedCoords = GetEntityCoords(ped)
            local distance = #(coords - pedCoords)
            if distance < closestDistance then
                closestDistance = distance
                closestPed = ped
            end
        end
    end
    return closestPed, closestDistance
end

local function SA_ShouldMonitorWeapon(weaponHash)
    if not weaponHash or weaponHash == GetHashKey("WEAPON_UNARMED") then return false end
    local weaponGroup = GetWeapontypeGroup(weaponHash)
    local excludedGroups = {
        [GetHashKey("GROUP_MELEE")] = true,
        [GetHashKey("GROUP_THROWN")] = true,
    }
    if excludedGroups[weaponGroup] then return false end
    local damageType = GetWeaponDamageType(weaponHash)
    return damageType == 3
end

local function SA_ComputeAngle(v1, v2)
    local dot = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
    local len1 = math.sqrt(v1.x * v1.x + v1.y * v1.y + v1.z * v1.z)
    local len2 = math.sqrt(v2.x * v2.x + v2.y * v2.y + v2.z * v2.z)
    if len1 == 0 or len2 == 0 then return 0 end
    local clamped = math.max(-1.0, math.min(1.0, dot / (len1 * len2)))
    return math.acos(clamped) * (180.0 / math.pi)
end

local saConfig = {
    angleThreshold = 15.0,
    trajectoryThreshold = 5.0,
    screenDeviationThreshold = 180,
    minDistance = 3.0,
    maxDistance = 350.0,
    shotValidityWindow = 800,
    flickAngleThreshold = 25.0,
    patternWindow = 3500,
    patternMinHits = 5,
}

local saState = {
    lastShotTime = 0,
    shotFired = false,
    shotData = nil,
    previousAngles = {},
    recentShots = {},
    flickDetections = 0,
    zeroHits = 0,
    saConfirmCount = 0,
}

local _saDamageState = {
    recentShots = {},
    damageConfirm = {},
    cooldowns = {},
}

local _saCooldown = {}

local function SA_DetectFlick(currentAngle, currentTime)
    table.insert(saState.previousAngles, { angle = currentAngle, time = currentTime })
    for i = #saState.previousAngles, 1, -1 do
        if currentTime - saState.previousAngles[i].time > 300 then
            table.remove(saState.previousAngles, i)
        end
    end
    if #saState.previousAngles >= 2 then
        local oldest = saState.previousAngles[1]
        local timeDelta = currentTime - oldest.time
        if timeDelta > 0 and timeDelta < 300 then
            local angleDelta = math.abs(currentAngle - oldest.angle)
            if angleDelta > saConfig.flickAngleThreshold then
                return true
            end
        end
    end
    return false
end

local function SA_TrackPattern(isSuspicious, currentTime)
    table.insert(saState.recentShots, { time = currentTime, suspicious = isSuspicious })
    for i = #saState.recentShots, 1, -1 do
        if currentTime - saState.recentShots[i].time > saConfig.patternWindow then
            table.remove(saState.recentShots, i)
        end
    end
    local count = 0
    for _, s in ipairs(saState.recentShots) do
        if s.suspicious then count = count + 1 end
    end
    return count >= saConfig.patternMinHits
end

local function SA_ValidateShot(victim, impactCoords, weaponHash, shotData)
    if not shotData then return true, "no_shot_data" end
    local myPed = PlayerPedId()
    if IsPedInAnyVehicle(myPed, false) or IsPedInCover(myPed, false) or IsPedDoingDriveby(myPed) then
        return true, "vehicle_or_cover"
    end

    local shooterCoords = GetEntityCoords(myPed)
    local victimCoords = GetEntityCoords(victim)
    local distance = #(shooterCoords - victimCoords)
    if distance < saConfig.minDistance then return true, "too_close" end
    if distance > saConfig.maxDistance then return true, "too_far" end
    if not SA_ShouldMonitorWeapon(weaponHash) then return true, "excluded_weapon" end

    local impactDistance = #(shotData.cameraCoords - impactCoords)
    local expectedHit = vector3(
        shotData.cameraCoords.x + shotData.cameraDirection.x * impactDistance,
        shotData.cameraCoords.y + shotData.cameraDirection.y * impactDistance,
        shotData.cameraCoords.z + shotData.cameraDirection.z * impactDistance
    )
    local trajectoryDeviation = #(expectedHit - impactCoords)
    local impactDirection = vector3(
        impactCoords.x - shotData.cameraCoords.x,
        impactCoords.y - shotData.cameraCoords.y,
        impactCoords.z - shotData.cameraCoords.z
    )
    local angleDeviation = SA_ComputeAngle(shotData.cameraDirection, impactDirection)

    local onScreen, screenX, screenY = GetScreenCoordFromWorldCoord(impactCoords.x, impactCoords.y, impactCoords.z)
    local screenDeviation = 0
    if onScreen then
        local sw, sh = GetActiveScreenResolution()
        local dx = screenX * sw - sw / 2
        local dy = screenY * sh - sh / 2
        screenDeviation = math.sqrt(dx * dx + dy * dy)
    end

    local currentTime = GetGameTimer()
    local isFlick = SA_DetectFlick(angleDeviation, currentTime)

    if angleDeviation > saConfig.angleThreshold * 2.0 then
        return false, {
            reason = "extreme_angle_discrepancy",
            angleDeviation = angleDeviation,
            trajectoryDeviation = trajectoryDeviation,
            screenDeviation = screenDeviation,
            distance = distance,
        }
    end

    if trajectoryDeviation > saConfig.trajectoryThreshold * 2.0 then
        return false, {
            reason = "extreme_trajectory_deviation",
            trajectoryDeviation = trajectoryDeviation,
            angleDeviation = angleDeviation,
            screenDeviation = screenDeviation,
            distance = distance,
        }
    end

    if screenDeviation > saConfig.screenDeviationThreshold * 1.5 then
        return false, {
            reason = "extreme_screen_deviation",
            screenDeviation = screenDeviation,
            angleDeviation = angleDeviation,
            trajectoryDeviation = trajectoryDeviation,
            distance = distance,
        }
    end

    if isFlick and angleDeviation > saConfig.angleThreshold then
        return false, {
            reason = "flick_pattern_detected",
            angleDeviation = angleDeviation,
            distance = distance,
        }
    end

    local victimDir = vector3(victimCoords.x - shotData.cameraCoords.x,
                              victimCoords.y - shotData.cameraCoords.y,
                              victimCoords.z - shotData.cameraCoords.z)
    local crosshairDeviation = SA_ComputeAngle(shotData.cameraDirection, victimDir)

    -- Relaxed crosshair deviation to account for headshots, limb shots, recoil, and spread
    if crosshairDeviation > 25.0 then
        return false, {
            reason = "crosshair_miss",
            crosshairDeviation = crosshairDeviation,
            angleDeviation = angleDeviation,
            trajectoryDeviation = trajectoryDeviation,
            screenDeviation = screenDeviation,
            distance = distance,
        }
    end

    local isSuspicious = (angleDeviation > saConfig.angleThreshold) or
                         (trajectoryDeviation > saConfig.trajectoryThreshold) or
                         (screenDeviation > saConfig.screenDeviationThreshold)
    if isSuspicious then
        if SA_TrackPattern(true, currentTime) then
            return false, {
                reason = "pattern_detection",
                angleDeviation = angleDeviation,
                trajectoryDeviation = trajectoryDeviation,
                screenDeviation = screenDeviation,
                distance = distance,
            }
        end
    end

    return true, "legitimate"
end

AddEventHandler("CEventGunShot", function(witnesses, shooter)
    if not isAntiSilentAimEnabled() then return end
    if shooter ~= PlayerPedId() then return end
    if IsEntityDead(shooter) then return end
    if GetPedParachuteState(shooter) > 0 then return end
    if GetRenderingCam() ~= -1 then return end
    if IsPedInAnyVehicle(shooter, false) or IsPedInCover(shooter, false) or IsPedDoingDriveby(shooter) then return end

    local timer = GetGameTimer()
    if timer - saState.lastShotTime == 0 then return end

    local hold, weaponHash = GetCurrentPedWeapon(PlayerPedId(), true)
    if not SA_ShouldMonitorWeapon(weaponHash) then return end

    saState.lastShotTime = timer
    saState.shotFired = true

    local camCoord = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local camDir = SA_RotationToDirection(camRot)
    saState.shotData = {
        cameraCoords = camCoord,
        cameraRotation = camRot,
        cameraDirection = camDir,
        time = timer,
    }

    table.insert(_saDamageState.recentShots, {
        camCoords = camCoord,
        camDir = camDir,
        time = timer,
    })
    if #_saDamageState.recentShots > 30 then
        table.remove(_saDamageState.recentShots, 1)
    end
end)

AddEventHandler("CEventGunShotBulletImpact", function(witnesses, shooter)
    if not isAntiSilentAimEnabled() then return end
    if shooter ~= PlayerPedId() then return end
    if not saState.shotFired then return end
    if GetPedParachuteState(shooter) > 0 then return end
    if GetRenderingCam() ~= -1 then return end
    if IsPedInAnyVehicle(shooter, false) or IsPedInCover(shooter, false) or IsPedDoingDriveby(shooter) then
        saState.shotFired = false
        return
    end

    local currentTime = GetGameTimer()
    if currentTime - saState.lastShotTime >= saConfig.shotValidityWindow then
        saState.shotFired = false
        return
    end

    if IsPedDeadOrDying(shooter, true) or IsPedRagdoll(shooter) then
        saState.shotFired = false
        return
    end

    local hold, weaponHash = GetCurrentPedWeapon(PlayerPedId(), true)
    if not hold then
        saState.shotFired = false
        return
    end

    local success, impactCoords = GetPedLastWeaponImpactCoord(shooter)
    if not success or impactCoords == vector3(0.0, 0.0, 0.0) then
        -- Fallback to player target coords if last impact is 0
        local players = GetActivePlayers()
        local shooterCoords = GetEntityCoords(shooter)
        for i = 1, #players do
            local targetPlayer = players[i]
            if targetPlayer ~= PlayerId() then
                local targetPed = GetPlayerPed(targetPlayer)
                if DoesEntityExist(targetPed) and HasEntityBeenDamagedByWeapon(targetPed, weaponHash, 0) then
                    impactCoords = GetPedBoneCoords(targetPed, 31086, 0.0, 0.0, 0.0)
                    success = true
                    break
                end
            end
        end
    end

    if not success or impactCoords == vector3(0.0, 0.0, 0.0) then
        saState.zeroHits = (saState.zeroHits or 0) + 1
        if saState.zeroHits >= 6 then
            if not _saCooldown["zero"] or currentTime - _saCooldown["zero"] > 10000 then
                _saCooldown["zero"] = currentTime
                SafeTriggerServerEvent("VexShield:banHandler", "Attempted to bypass hit validation (zero impact angle)")
            end
            saState.zeroHits = 0
        end
        saState.shotFired = false
        return
    else
        saState.zeroHits = 0
    end

    local victim, victimDistance = SA_GetClosestPed(impactCoords, 5.0)
    if not victim then
        saState.shotFired = false
        return
    end

    -- Strictly check: ONLY monitor player vs player hits to completely eliminate false bans on NPCs
    if not IsPedAPlayer(victim) then
        saState.shotFired = false
        return
    end

    if not HasEntityBeenDamagedByWeapon(victim, weaponHash, 0) then
        saState.shotFired = false
        return
    end

    local lastDamagedTime = GetTimeOfLastPedWeaponDamage(victim, weaponHash)
    if currentTime - lastDamagedTime > saConfig.shotValidityWindow then
        saState.shotFired = false
        return
    end

    ClearPedLastWeaponDamage(victim)
    ClearEntityLastWeaponDamage(victim)

    local isLegitimate, detectionData = SA_ValidateShot(victim, impactCoords, weaponHash, saState.shotData)

    if not isLegitimate then
        saState.saConfirmCount = (saState.saConfirmCount or 0) + 1
        if saState.saConfirmCount >= 6 then -- Increased from 3 to 6 to require consistent abuse
            local kClientId = NetworkGetPlayerIndexFromPed(victim)
            if kClientId and NetworkIsPlayerActive(kClientId) then
                local kSrvId = GetPlayerServerId(kClientId)
                if not _saCooldown[kSrvId] or currentTime - _saCooldown[kSrvId] > 8000 then
                    _saCooldown[kSrvId] = currentTime
                    SafeTriggerServerEvent("VexShield:banHandler", "Attempted to manipulate aim direction")
                end
            end
            saState.saConfirmCount = 0
        end
    else
        saState.saConfirmCount = 0
    end

    saState.shotFired = false
end)

---------------------------------------------------------------------------------
-- ANTI SILENT AIM — Damage-Based Detection (CEventNetworkEntityDamage)
---------------------------------------------------------------------------------
AddEventHandler("gameEventTriggered", function(event, data)
    if not isAntiSilentAimEnabled() then return end
    if event ~= "CEventNetworkEntityDamage" then return end

    local victim = data[1]
    local attacker = data[2]
    if not victim or not attacker then return end
    local ped = PlayerPedId()
    if attacker ~= ped then return end
    if not IsPedAPlayer(victim) then return end
    if IsPedInAnyVehicle(ped, false) or IsPedInCover(ped, false) or IsPedDoingDriveby(ped) then return end

    local victimCoords = GetEntityCoords(victim)
    local myCoords = GetEntityCoords(ped)
    local dist = #(myCoords - victimCoords)
    if dist < 3.0 or dist > 350.0 then return end

    local now = GetGameTimer()

    local bestShot = nil
    local bestDiff = 999999
    for i = #_saDamageState.recentShots, 1, -1 do
        local s = _saDamageState.recentShots[i]
        if now - s.time > 800 then
            table.remove(_saDamageState.recentShots, i)
        else
            local toVictim = vector3(victimCoords.x - s.camCoords.x, victimCoords.y - s.camCoords.y, victimCoords.z - s.camCoords.z)
            local len = #toVictim
            if len > 0.01 then
                toVictim = vector3(toVictim.x / len, toVictim.y / len, toVictim.z / len)
            end
            local angleBetween = SA_ComputeAngle(s.camDir, toVictim)
            if angleBetween < bestDiff then
                bestDiff = angleBetween
                bestShot = s
            end
        end
    end

    if not bestShot then return end
    if bestDiff < 8.0 then return end

    local victimId = NetworkGetPlayerIndexFromPed(victim)
    if not victimId or not NetworkIsPlayerActive(victimId) then return end
    local victimSrvId = GetPlayerServerId(victimId)

    -- Obvious 180 / 90 degree silent aim (blatant abuse)
    if bestDiff > 45.0 then
        if not _saCooldown[victimSrvId] or now - _saCooldown[victimSrvId] > 8000 then
            _saCooldown[victimSrvId] = now
            _saDamageState.cooldown = now
            SafeTriggerServerEvent("VexShield:banHandler", "Attempted to manipulate aim direction")
        end
        return
    end

    -- Consistent suspicious deviation (e.g. angle > 25.0 degrees across 5 consecutive hits)
    if bestDiff > 25.0 then
        if not _saDamageState.damageConfirm[victimSrvId] then
            _saDamageState.damageConfirm[victimSrvId] = { count = 0, lastTime = 0 }
        end
        local dc = _saDamageState.damageConfirm[victimSrvId]
        if now - dc.lastTime > 3000 then
            dc.count = 0
        end
        dc.count = dc.count + 1
        dc.lastTime = now
        if dc.count >= 5 then
            if not _saCooldown[victimSrvId] or now - _saCooldown[victimSrvId] > 8000 then
                _saCooldown[victimSrvId] = now
                SafeTriggerServerEvent("VexShield:banHandler", "Attempted to manipulate aim direction")
            end
            dc.count = 0
        end
    else
        local victimId2 = NetworkGetPlayerIndexFromPed(victim)
        if victimId2 then
            local sid = GetPlayerServerId(victimId2)
            if _saDamageState.damageConfirm[sid] then
                _saDamageState.damageConfirm[sid].count = 0
            end
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI-SILENT AIM 2 — Realtime Aim Direction vs Hit Direction
---------------------------------------------------------------------------------
local _sa2LastReport = 0

CreateThread(function()
    while not configLoaded do Wait(250) end
    while true do
        Wait(100)
        if not isAntiSilentAimEnabled() then
            Wait(2000)
            goto sa2End
        end

        local myPed = PlayerPedId()
        if IsPedDeadOrDying(myPed, true) then goto sa2End end
        if not IsPedShooting(myPed) then goto sa2End end

        local hold, weaponHash = GetCurrentPedWeapon(myPed, true)
        if not hold then goto sa2End end
        if not SA_ShouldMonitorWeapon(weaponHash) then goto sa2End end

        local success, impactCoords = GetPedLastWeaponImpactCoord(myPed)
        local camCoord = GetGameplayCamCoord()
        local camRot = GetGameplayCamRot(2)
        local camFwd = SA_RotationToDirection(camRot)

        if not success or impactCoords == vector3(0.0, 0.0, 0.0) then
            -- Fallback to player target coords if last impact is 0
            local players = GetActivePlayers()
            for i = 1, #players do
                local p = players[i]
                if p ~= PlayerId() then
                    local targetPed = GetPlayerPed(p)
                    if DoesEntityExist(targetPed) and HasEntityBeenDamagedByWeapon(targetPed, weaponHash, 0) then
                        impactCoords = GetPedBoneCoords(targetPed, 31086, 0.0, 0.0, 0.0)
                        success = true
                        break
                    end
                end
            end
        end

        if not success or impactCoords == vector3(0.0, 0.0, 0.0) then goto sa2End end

        local victim, victimDist = SA_GetClosestPed(impactCoords, 5.0)
        if not victim then goto sa2End end

        local victimCoords = GetEntityCoords(victim)
        local toVictim = vector3(victimCoords.x - camCoord.x, victimCoords.y - camCoord.y, victimCoords.z - camCoord.z)
        local len = #toVictim
        if len < 0.001 then goto sa2End end
        toVictim = vector3(toVictim.x / len, toVictim.y / len, toVictim.z / len)

        local aimHitAngle = SA_ComputeAngle(camFwd, toVictim)

        local toImpact = vector3(impactCoords.x - camCoord.x, impactCoords.y - camCoord.y, impactCoords.z - camCoord.z)
        local impactLen = #toImpact
        if impactLen > 0.001 then
            toImpact = vector3(toImpact.x / impactLen, toImpact.y / impactLen, toImpact.z / impactLen)
        end
        local aimImpactAngle = SA_ComputeAngle(camFwd, toImpact)

        local now = GetGameTimer()
        if now - _sa2LastReport > 500 then
            _sa2LastReport = now

            local suspicious = false
            if aimHitAngle > 20.0 and HasEntityBeenDamagedByAnyPed(myPed) then -- Increased from 15.0
                suspicious = true
            end
            if aimImpactAngle > 25.0 then -- Increased from 20.0
                suspicious = true
            end

            if suspicious then
                -- Add a cooldown to prevent rapid false bans
                if not _saCooldown["angle"] or now - _saCooldown["angle"] > 8000 then
                    _saCooldown["angle"] = now
                    SafeTriggerServerEvent("VexShield:banHandler", "Attempted to manipulate aim direction")
                end
            end
        end

        ::sa2End::
    end
end)

-- Weapons to skip for aim-snap heuristics (optional: Shared.Client.AimbotIgnoredWeapons = { "WEAPON_STUNGUN", ... })
function isWeaponWhitelisted(weaponHash)
    if not weaponHash or weaponHash == joaat("WEAPON_UNARMED") then
        return true
    end
    local list = Shared and Shared.Client and Shared.Client['AimbotIgnoredWeapons']
    if type(list) ~= "table" then
        return false
    end
    for _, entry in ipairs(list) do
        local h = type(entry) == "string" and joaat(entry) or entry
        if h == weaponHash then return true end
    end
    return false
end

-- =============================================================================
--  Anti-AimBot Detection Thread
--  Signals:
--    1) "smooth aim without input" — camera yaw moves while raw input is zero
--    2) "snap aim" — sudden large yaw delta with no input
--    3) "smooth-tracking jitter signature" — yaw is moving but variance across
--       the last N samples is suspiciously low (real humans micro-tremor;
--       aimbot tracking is eerily smooth even when sweeping a target)
--  Gates (silent skip): low FPS, high ping, ragdoll/cover/vehicle/falling/etc,
--  recent damage taken, recent weapon swap, gameplay-cam shake, scope FOV.
-- =============================================================================
Citizen.CreateThread(function()
    local cfg = {
        minDeltaToTrigger    = 0.040,      
        snapYawDelta         = 25.0,       
        snapInputEps         = 0.0050,     
        headingEps           = 0.006,      
        smoothStrikesNeeded  = 5,
        snapStrikesNeeded    = 4,
        jitterStrikesNeeded  = 6,
        finalStrikesNeeded   = 5,
        strikeDecayMs        = 8000,       
        sampleStaleMs        = 100,        
        jitterSamples        = 12,         
        jitterVarMin         = 0.000030,   
        jitterMinAvgYaw      = 0.25,       
        snapHugeYawDeg       = 75.0,
        skipFrameTimeMs      = 90,        
        skipPingMs           = 350,
    }

    local previousCamRot      = GetGameplayCamRot(2)
    local previousCamHeading  = GetGameplayCamRelativeHeading()
    local lastFov             = GetGameplayCamFov()
    local lastInput           = 0
    local previousSampleTime  = GetGameTimer()
    local steadyFrames        = 0
    local strikeCount         = 0
    local snapStrikeCount     = 0
    local jitterStrikeCount   = 0
    local lastYawDelta        = 0.0
    local lastWeaponBlocked   = 0
    local lastInCollision     = 0
    local lastChangedWeapon   = 0
    local lastWeapon          = GetHashKey("WEAPON_UNARMED")
    local yawDeltaWindow      = {}
    local aimbotStrikeCount   = 0
    local aimbotStrikeTime    = 0

    local function pushYaw(d)
        yawDeltaWindow[#yawDeltaWindow + 1] = d
        if #yawDeltaWindow > cfg.jitterSamples then
            table.remove(yawDeltaWindow, 1)
        end
    end

    local function yawStats()
        local n = #yawDeltaWindow
        if n < cfg.jitterSamples then return nil, nil end
        local sum = 0
        for i = 1, n do sum = sum + yawDeltaWindow[i] end
        local mean = sum / n
        local sumSq = 0
        for i = 1, n do
            local d = yawDeltaWindow[i] - mean
            sumSq = sumSq + d * d
        end
        return mean, sumSq / n
    end

    local function resetStrikes()
        strikeCount       = 0
        snapStrikeCount   = 0
        jitterStrikeCount = 0
        lastYawDelta      = 0.0
        lastInput         = 0
        yawDeltaWindow    = {}
    end

    waitUntilReady()
    while true do
        if isAntiAimBotEnabled() then
            local ped        = PlayerPedId()
            local weaponHash = GetSelectedPedWeapon(ped)
            local timer      = GetGameTimer()
            local wait       = 250

            -- Hard skip: any condition where the cam/input correlation can't be trusted
            local frameMs = getFrameTimeMs()
            local pingMs  = getLocalPingMs()
            local hardSkip =
                IsPedDeadOrDying(ped, true)
                or IsPedInAnyVehicle(ped, false)
                or IsPedRagdoll(ped)
                or IsPedFalling(ped)
                or IsPedClimbing(ped)
                or IsPedSwimming(ped)
                or IsEntityInAir(ped)
                or IsPedInCover(ped, 0)
                or IsPedJumping(ped)
                or GetPedParachuteState(ped) > 0
                or frameMs > cfg.skipFrameTimeMs
                or pingMs  > cfg.skipPingMs
                or (silentAimData.lastDamageTakenTime > 0
                    and timer - silentAimData.lastDamageTakenTime < VexShieldSilentAimConfig.recentDamageGraceMs)
                or (timer - silentAimData.lastWeaponSwapTime < VexShieldSilentAimConfig.weaponSwapGraceMs)
                or (NetworkIsInSpectatorMode and NetworkIsInSpectatorMode())

            if hardSkip then
                resetStrikes()
                wait = 250
                goto continue
            end

            if IsAimCamActive() and GetPedConfigFlag(ped, 78, true) and not isWeaponWhitelisted(weaponHash) then
                wait = 25
            end

            if IsAimCamActive() and GetPedConfigFlag(ped, 78, true)
                and timer - lastWeaponBlocked > 1000
                and timer - lastChangedWeapon > 1000
                and timer - lastInCollision > 1000
                and not (IsGameplayCamShaking() and IsPedInAnyVehicle(ped, false))
                and (not IsGameplayCamShaking()
                    or (GetFollowPedCamViewMode() ~= 4 or not IsPlayerFreeAiming(PlayerId())))
                and IsUsingKeyboard(0)
            then
                local weaponGroup = GetWeapontypeGroup(weaponHash)
                if weaponGroup ~= -1212426201 and weaponGroup ~= -1569042529 then
                    local camRot      = GetGameplayCamRot(2)
                    local camHeading  = GetGameplayCamRelativeHeading()
                    local ix          = GetControlNormal(0, 1)
                    local iy          = GetControlNormal(0, 2)
                    local currentFov  = GetGameplayCamFov()
                    local fovDiff     = math.abs(currentFov - lastFov)

                    if fovDiff < 0.08 then
                        steadyFrames = steadyFrames + 1
                    else
                        steadyFrames = 0
                    end

                    local sampleDt = timer - previousSampleTime
                    previousSampleTime = timer

                    if sampleDt > cfg.sampleStaleMs then
                        resetStrikes()
                        previousCamRot     = camRot
                        previousCamHeading = camHeading
                    elseif previousCamRot and steadyFrames > 2 then
                        local yawDelta        = AS.angularDeltaDeg(camRot.z, previousCamRot.z)
                        local pitchDelta      = math.abs(camRot.x - previousCamRot.x)
                        local camHeadingDelta = AS.angularDeltaDeg(camHeading, previousCamHeading)
                        local input           = math.abs(ix) + math.abs(iy)

                        local noInput        = input < cfg.snapInputEps and lastInput < cfg.snapInputEps
                        local noHeadingStick = camHeadingDelta < cfg.headingEps

                        -- Smooth aim without input (camera moves while input is zero)
                        if yawDelta > cfg.minDeltaToTrigger and noHeadingStick and noInput then
                            strikeCount = strikeCount + 1
                        else
                            strikeCount = math.max(0, strikeCount - 1) -- soft decay (was hard reset)
                        end

                        -- Snap aim (idle -> sudden large yaw with no input)
                        if lastYawDelta < 0.35 and yawDelta > cfg.snapYawDelta and noInput and pitchDelta < 1.5 then
                            snapStrikeCount = snapStrikeCount + 1
                        elseif snapStrikeCount > 0 then
                            snapStrikeCount = math.max(0, snapStrikeCount - 0.5)
                        end

                        -- Superhuman one-frame snap
                        if yawDelta > cfg.snapHugeYawDeg and noInput then
                            snapStrikeCount = snapStrikeCount + 2
                        end

                        local aimingAtPlayer = VexShieldResolveAimedPlayer(ped) ~= nil
                        if aimingAtPlayer and (yawDelta > cfg.snapHugeYawDeg and noInput or (yawDelta > cfg.snapYawDelta and noInput)) then
                            VexShieldBlockAimbotNow("snap lock on player", 3)
                            snapStrikeCount = snapStrikeCount + 2
                        end

                        -- Tracking-jitter signature: real humans micro-tremor; aimbot
                        -- tracking shows abnormally low variance even while sweeping.
                        pushYaw(yawDelta)
                        local mean, var = yawStats()
                        if mean and var
                            and mean > cfg.jitterMinAvgYaw
                            and var  < cfg.jitterVarMin
                            and noInput
                        then
                            jitterStrikeCount = jitterStrikeCount + 1
                        else
                            jitterStrikeCount = math.max(0, jitterStrikeCount - 1)
                        end

                        lastYawDelta = yawDelta
                        lastInput    = input
                    else
                        strikeCount = 0
                    end

                    local triggered =
                        strikeCount       >= cfg.smoothStrikesNeeded
                        or snapStrikeCount   >= cfg.snapStrikesNeeded
                        or jitterStrikeCount >= cfg.jitterStrikesNeeded

                    if triggered then
                        if timer - aimbotStrikeTime > cfg.strikeDecayMs then
                            aimbotStrikeCount = 1
                            aimbotStrikeTime  = timer
                        else
                            aimbotStrikeCount = aimbotStrikeCount + 1
                        end

                        if aimbotStrikeCount >= cfg.finalStrikesNeeded then
                            local reason
                            if jitterStrikeCount >= cfg.jitterStrikesNeeded then
                                reason = "smooth-tracking jitter signature"
                            elseif strikeCount >= cfg.smoothStrikesNeeded then
                                reason = "smooth aim without input"
                            else
                                reason = "snap aim"
                            end
                            SafeTriggerServerEvent("VexShield:banHandler",
                                "Attempted to lock aim: " .. reason .. " (strikes " .. aimbotStrikeCount .. ")")
                            aimbotStrikeCount = 0
                            resetStrikes()
                        end
                    end

                    lastFov            = currentFov
                    previousCamRot     = camRot
                    previousCamHeading = camHeading
                    wait = 20
                else
                    wait = 1000
                end
            end

            if GetIsTaskActive(ped, 299) then
                lastWeaponBlocked = timer
            end

            if #GetCollisionNormalOfLastHitForEntity(ped) > 0 then
                lastInCollision = timer
            end

            if lastWeapon ~= weaponHash then
                lastChangedWeapon = timer
            end
            lastWeapon = weaponHash

            ::continue::
            Citizen.Wait(wait)
        else
            Citizen.Wait(10000)
        end
    end
end)

-- [Unified Protection Thread] - Combined multiple small threads for better performance
Citizen.CreateThread(function()
    waitUntilReady()
    
    local weaponComponents = {
        joaat("COMPONENT_COMBATPISTOL_CLIP_01"), joaat("COMPONENT_COMBATPISTOL_CLIP_02"),
        joaat("COMPONENT_APPISTOL_CLIP_01"), joaat("COMPONENT_APPISTOL_CLIP_02"),
        joaat("COMPONENT_MICROSMG_CLIP_01"), joaat("COMPONENT_MICROSMG_CLIP_02"),
        joaat("COMPONENT_SMG_CLIP_01"), joaat("COMPONENT_SMG_CLIP_02"),
        joaat("COMPONENT_ASSAULTRIFLE_CLIP_01"), joaat("COMPONENT_ASSAULTRIFLE_CLIP_02"),
        joaat("COMPONENT_CARBINERIFLE_CLIP_01"), joaat("COMPONENT_CARBINERIFLE_CLIP_02"),
        joaat("COMPONENT_ADVANCEDRIFLE_CLIP_01"), joaat("COMPONENT_ADVANCEDRIFLE_CLIP_02"),
        joaat("COMPONENT_MG_CLIP_01"), joaat("COMPONENT_MG_CLIP_02"),
        joaat("COMPONENT_COMBATMG_CLIP_01"), joaat("COMPONENT_COMBATMG_CLIP_02"),
        joaat("COMPONENT_PUMPSHOTGUN_CLIP_01"), joaat("COMPONENT_SAWNOFFSHOTGUN_CLIP_01"),
        joaat("COMPONENT_ASSAULTSHOTGUN_CLIP_01"), joaat("COMPONENT_ASSAULTSHOTGUN_CLIP_02"),
        joaat("COMPONENT_PISTOL50_CLIP_01"), joaat("COMPONENT_PISTOL50_CLIP_02"),
        joaat("COMPONENT_ASSAULTSMG_CLIP_01"), joaat("COMPONENT_ASSAULTSMG_CLIP_02"),
        joaat("COMPONENT_AT_RAILCOVER_01"), joaat("COMPONENT_AT_AR_AFGRIP"),
        joaat("COMPONENT_AT_PI_FLSH"), joaat("COMPONENT_AT_AR_FLSH"),
        joaat("COMPONENT_AT_SCOPE_MACRO"), joaat("COMPONENT_AT_SCOPE_SMALL"),
        joaat("COMPONENT_AT_SCOPE_MEDIUM"), joaat("COMPONENT_AT_SCOPE_LARGE"),
        joaat("COMPONENT_AT_SCOPE_MAX"), joaat("COMPONENT_AT_PI_SUPP")
    }
    
    local lastLicenseCheck = 0
    local lastNoHeadshotCheck = 0
    local lastWeaponComponentsCheck = 0
    local lastInjectorCheck = 0
    local lastInfiniteStaminaCheck = 0
    local lastLookAroundCheck = 0
    local lookAroundFlags = 0
    local infiniteStaminaFlags = 0
    
    local sprintStart = 0
    local staminaStart = 0.0
    
    while true do
        Citizen.Wait(500)
        
        if not Shared or not Shared.Protections then
            goto continue
        end
        
        local now = GetGameTimer()
        local ped = PlayerPedId()
        
        -- [Anti License Clear] - Every 10 seconds
        if VexShieldIsProtectionOn('Anti License Clear') and now - lastLicenseCheck >= 10000 then
            lastLicenseCheck = now
            if ForceSocialClubUpdate == nil then
                SafeTriggerServerEvent("VexShield:banHandler", "Attempted to tamper with Social Club license")
            end
            if ShutdownAndLaunchSinglePlayerGame == nil then
                SafeTriggerServerEvent("VexShield:banHandler", "Attempted to tamper with Single Player license")
            end
            if ActivateRockstarEditor == nil then
                SafeTriggerServerEvent("VexShield:banHandler", "Attempted to tamper with Rockstar Editor license")
            end
        end
        

        
        -- [Anti Weapon Components / Folder] - Every 10 seconds
        if VexShieldIsProtectionOn('Anti Weapon Components') and now - lastWeaponComponentsCheck >= 10000 then
            lastWeaponComponentsCheck = now
            for i = 1, #weaponComponents do
                local damageModifier = GetWeaponComponentDamageModifier(weaponComponents[i])
                local accuracyModifier = GetWeaponComponentAccuracyModifier(weaponComponents[i])
                if damageModifier > 1.1 or accuracyModifier > 1.2 then
                    SafeTriggerServerEvent("VexShield:banHandler", "Attempted to modify weapon components")
                    break
                end
            end
        end
        
        -- [Anti Horn Boost] - Every second
        if VexShieldIsProtectionOn('Anti Horn Boost') then
            if IsPedInAnyVehicle(ped) then
                local vehicle = GetVehiclePedIsUsing(ped)
                local vehicleModel = GetEntityModel(vehicle)
                -- Allowed boost vehicles: Voltic2 (989294410), Scramjet (884483972), Vigilante (-638562243), Oppressor2 (2069146067)
                if GetHasRocketBoost(vehicle) and vehicleModel ~= 989294410 and vehicleModel ~= 884483972 and vehicleModel ~= -638562243 and vehicleModel ~= 2069146067 then
                    if IsVehicleRocketBoostActive(vehicle) then
                        SafeTriggerServerEvent("VexShield:banHandler", "Attempted to use illegal rocket boost")
                    end
                end
            end
        end
        
        -- [Anti Infinite Stamina] - Every second
        if VexShieldIsProtectionOn('Anti Infinite Stamina') and now - lastInfiniteStaminaCheck >= 1000 then
            lastInfiniteStaminaCheck = now
            local validState = DoesEntityExist(ped)
                and IsPedOnFoot(ped)
                and not IsPedInAnyVehicle(ped, false)
                and not IsEntityDead(ped)
                and not IsPedRagdoll(ped)
                and not IsPedFalling(ped)
                and not IsPedJumping(ped)
                and not IsPedClimbing(ped)
                and not IsPedSwimming(ped)
                and not IsEntityAttached(ped)
                and not IsPauseMenuActive()
                and not IsNuiFocused()
                and not IsNuiFocusKeepingInput()
                and not IsCutsceneActive()
                and IsScreenFadedIn()
                and IsPlayerControlOn(PlayerId())

            if validState then
                local sprinting = IsPedSprinting(ped) and GetEntitySpeed(ped) >= 5.0
                local stamina = GetPlayerSprintStaminaRemaining(PlayerId())
                if sprinting then
                    if sprintStart == 0 then
                        sprintStart = now
                        staminaStart = stamina
                    else
                        local dt = now - sprintStart
                        if dt >= 7000 and staminaStart >= 85.0 then
                            local delta = staminaStart - stamina
                            local staminaStillHigh = stamina >= 80.0
                            if delta <= 4.0 and staminaStillHigh then
                                infiniteStaminaFlags = infiniteStaminaFlags + 1
                            else
                                infiniteStaminaFlags = 0
                            end

                            if infiniteStaminaFlags >= 3 then
                                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass stamina limit')
                                infiniteStaminaFlags = 0
                                sprintStart = 0
                                staminaStart = 0.0
                            else
                                sprintStart = 0
                                staminaStart = 0.0
                            end
                        end
                    end
                else
                    infiniteStaminaFlags = 0
                    sprintStart = 0
                    staminaStart = 0.0
                end
            else
                infiniteStaminaFlags = 0
                sprintStart = 0
                staminaStart = 0.0
            end
        end
        
        -- [Anti Look Around] - Every second
        if VexShieldIsProtectionOn('Anti Look Around') and now - lastLookAroundCheck >= 1000 then
            lastLookAroundCheck = now
            if DoesEntityExist(ped) then
                local pedCoords = GetEntityCoords(ped, false)
                local camCoordsFinal = GetFinalRenderedCamCoord()
                local camCoordsGame = GetGameplayCamCoord()
                local maxDistance = math.max(#(camCoordsFinal - pedCoords), #(camCoordsGame - pedCoords))
                local inVehicle = IsPedInAnyVehicle(ped, false)
                local inHeliPlane = IsPedInAnyHeli(ped) or IsPedInAnyPlane(ped)
                local natural = inVehicle
                    or inHeliPlane
                    or IsPedFalling(ped)
                    or IsPedJumping(ped)
                    or IsPedSwimming(ped)
                    or IsPedClimbing(ped)
                    or IsEntityAttached(ped)
                    or IsEntityDead(ped)
                    or not IsScreenFadedIn()
                    or IsCutsceneActive()
                    or IsPauseMenuActive()
                    or IsNuiFocused()
                    or IsNuiFocusKeepingInput()
                    or VexShieldClientState.areControlsDisabled
                    or VexShieldClientState.areCamControlsDisabled
                    or VexShieldClientState.isUsingMouseInScripts
                    or not IsPlayerControlOn(PlayerId())
                    or GetRenderingCam() ~= -1

                if natural then
                    lookAroundFlags = 0
                elseif maxDistance > 12.0 then
                    local pedInterior = GetInteriorFromEntity(ped)
                    local camInterior = GetInteriorAtCoords(camCoordsFinal.x, camCoordsFinal.y, camCoordsFinal.z)
                    local rayHandle = StartShapeTestRay(camCoordsFinal.x, camCoordsFinal.y, camCoordsFinal.z, pedCoords.x, pedCoords.y, pedCoords.z, -1, ped, 0)
                    local _, didHit = GetShapeTestResult(rayHandle)
                    local interiorMismatch = pedInterior ~= 0 and camInterior ~= 0 and pedInterior ~= camInterior
                    local noLineOfSight = didHit == 0 and maxDistance > 14.0
                    local suspiciousDistance = maxDistance > 18.0

                    if (interiorMismatch and noLineOfSight) or (noLineOfSight and suspiciousDistance) then
                        lookAroundFlags = lookAroundFlags + 1
                    else
                        lookAroundFlags = 0
                    end

                    if lookAroundFlags >= 3 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit camera manipulation')
                        lookAroundFlags = 0
                    end
                else
                    lookAroundFlags = 0
                end
            else
                lookAroundFlags = 0
            end
        end
        
        ::continue::
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end

    local taskClearCount = 0
    local taskClearTimer = GetGameTimer()
    local wasAnimActive = false

    while true do
        VexShieldProtectionPollWait('Anti Task Clear Loop', 200)
        if VexShieldIsProtectionOn('Anti Task Clear Loop') then
            local ped = PlayerPedId()
            if DoesEntityExist(ped) and not IsEntityDead(ped) and not IsPedInAnyVehicle(ped, false) then
                local isAnimActive = GetIsTaskActive(ped, 1) or GetIsTaskActive(ped, 12) or IsEntityPlayingAnim(ped, "mp_arresting", "idle", 3) or IsEntityPlayingAnim(ped, "random@mugging3", "handsup_standing_base", 3)

                if wasAnimActive and not isAnimActive then
                    local now = GetGameTimer()
                    if now - taskClearTimer < 2000 then
                        taskClearCount = taskClearCount + 1
                    else
                        taskClearCount = 1
                        taskClearTimer = now
                    end

                    if taskClearCount > 8 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to spam task clearing')
                        taskClearCount = 0
                    end
                elseif isAnimActive then
                    wasAnimActive = true
                else
                    wasAnimActive = false
                end
            end
        end
        Wait(10000)
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    local flags = 0
    local controls = {30,31,32,33,34,35,21,22,24,25,14,15}
    local minDisabledControls = 10
    local minConsecutiveFlags = 5
    while true do
        Citizen.Wait(1000)
        if not VexShieldIsProtectionOn('Anti Block Input') then break end
        local ped = PlayerPedId()
        if IsPauseMenuActive() or IsNuiFocused() or IsNuiFocusKeepingInput() or IsLegitimateControlBlockState(ped) then
            flags = 0
        else
            if IsPlayerControlOn(PlayerId()) then
                local disabled = 0
                for i=1,#controls do
                    if not IsControlEnabled(0, controls[i]) then
                        disabled = disabled + 1
                    end
                end
                if disabled >= minDisabledControls then
                    flags = flags + 1
                    if flags >= minConsecutiveFlags then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to block player input')
                        flags = 0
                    end
                else
                    flags = 0
                end
            else
                flags = 0
            end
        end
    end
end)

local __luaMenuDetections = {}
RegisterNetEvent("VexShield:checkLuaMenuInjection")
AddEventHandler("VexShield:checkLuaMenuInjection", function(category, value)
    if not configLoaded or not VexShieldIsProtectionOn('Anti Lua Menu') then return end
    local key = tostring(category) .. ":" .. tostring(value)
    if __luaMenuDetections[key] then return end
    local detected = false
    if category == "Sprites" or category == "FilesReady" then
        detected = HasStreamedTextureDictLoaded(value)
    elseif category == "Emotes" then
        detected = HasAnimDictLoaded(value)
    elseif category == "Tables" then
        detected = type(rawget(_G, value)) == "table"
    elseif category == "Functions" then
        detected = type(rawget(_G, value)) == "function"
    end
    if detected then
        __luaMenuDetections[key] = true
        local sid = GetPlayerServerId(PlayerId())
        SafeTriggerServerEvent("VexShield:luaMenuDetected", sid, "Lua Menu Injection (" .. tostring(category) .. "): " .. tostring(value))
    end
end)

function isProtectedTrafficPed(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if IsPedAPlayer(ped) then return true end
    if IsPedInAnyVehicle(ped, true) or IsPedInAnyVehicle(ped, false) then return true end
    if GetVehiclePedIsIn(ped, true) ~= 0 or GetVehiclePedIsIn(ped, false) ~= 0 then return true end
    if GetVehiclePedIsUsing(ped) ~= 0 or GetVehiclePedIsEntering(ped) ~= 0 or GetVehiclePedIsTryingToEnter(ped) ~= 0 then return true end
    local pop = GetEntityPopulationType(ped)
    if pop >= 2 and pop <= 7 then return true end
    return false
end


CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Clone Player') then return end
    while not configLoaded do Wait(250) end
    local lastBanAt = 0
    local deletedPeds = {}
    while true do
        Wait(2000)
        local now = GetGameTimer()
        local me = PlayerPedId()
        if not DoesEntityExist(me) then goto continue end
        local myModel = GetEntityModel(me)
        local myCoords = GetEntityCoords(me)
        local pid = PlayerId()
        local peds = AS_GetPool('CPed')
        for i = 1, #peds do
            local ped = peds[i]
            if ped ~= me and DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                local model = GetEntityModel(ped)
                if model == myModel then
                    local dist = #(GetEntityCoords(ped) - myCoords)
                    if dist < 25.0 then
                        local net = NetworkGetEntityIsNetworked(ped)
                        local owner = net and NetworkGetEntityOwner(ped) or -1
                        local attached = IsEntityAttached(ped) and GetEntityAttachedTo(ped) == me
                        local combat = IsPedInCombat(ped, me)
                        
                        -- Check if ped should be deleted (cloned ped detection)
                        local shouldDelete = false
                        
                        -- If owned by current player and attached/combat, it's likely a clone
                        if attached or combat or (net and owner == pid) then
                            shouldDelete = true
                        end
                        
                        -- If not networked but close proximity, suspicious
                        if not net and dist < 5.0 then
                            shouldDelete = true
                        end
                        
                        -- If networked but owner is different player, could be another player's ped
                        if net and owner ~= -1 and owner ~= pid then
                            shouldDelete = false
                        end
                        
                        if shouldDelete then
                            if now - lastBanAt > 2500 then
                                SetEntityAsMissionEntity(ped, true, true)
                                DeleteEntity(ped)
                                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to duplicate player entity')
                                lastBanAt = now
                                break
                            end
                        end
                    end
                end
            end
        end
        ::continue::
    end
end)

-- [Anti Player Harassment] — single thread; player scan only on E / anim dict loaded
Citizen.CreateThread(function()
    waitUntilReady()
    local E_KEY = 38
    local HARASS_ANIM = "missminuteman_1ig_2"
    local HARASS_ANIM_CLIP = "handsup_base"
    local lastForcedAnimation = 0
    local forcedAnimationCount = 0
    local lastAnimScanMs = 0
    local lastHarassTarget = -1
    local harassAnimFlags = 0

    while true do
        if not VexShieldIsProtectionOn('Anti Player Harassment') then
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end

        Wait(VexShieldClientState.pollHarassmentMs)

        if IsPauseMenuActive() then
            goto continue
        end

        local now = GetGameTimer()
        local playerPed = PlayerPedId()

        if IsControlJustPressed(0, E_KEY)
            and not IsPedInAnyVehicle(playerPed, false)
            and not IsEntityDead(playerPed)
            and not IsPauseMenuActive()
            and not IsNuiFocused()
            and not IsNuiFocusKeepingInput()
            and IsPlayerControlOn(PlayerId()) then
            local playerCoords = GetEntityCoords(playerPed)
            local closestDist = 1.35
            local closestTarget = -1
            for _, playerId in ipairs(GetActivePlayers()) do
                if playerId ~= PlayerId() then
                    local targetPed = GetPlayerPed(playerId)
                    if targetPed ~= playerPed
                        and DoesEntityExist(targetPed)
                        and not IsPedInAnyVehicle(targetPed, false)
                        and not IsEntityDead(targetPed) then
                        local dist = #(playerCoords - GetEntityCoords(targetPed))
                        if dist < closestDist then
                            closestDist = dist
                            closestTarget = GetPlayerServerId(playerId)
                        end
                    end
                end
            end

            if closestTarget ~= -1 then
                if closestTarget == lastHarassTarget and (now - lastForcedAnimation) <= 3000 then
                    forcedAnimationCount = forcedAnimationCount + 1
                else
                    forcedAnimationCount = 1
                    harassAnimFlags = 0
                    lastHarassTarget = closestTarget
                end
                lastForcedAnimation = now
            else
                forcedAnimationCount = 0
                harassAnimFlags = 0
                lastHarassTarget = -1
            end
        end

        if now - lastForcedAnimation > 5000 then
            forcedAnimationCount = 0
            harassAnimFlags = 0
            lastHarassTarget = -1
        end

        if now - lastAnimScanMs >= VexShieldClientState.pollHarassmentAnimMs then
            lastAnimScanMs = now
            if HasAnimDictLoaded(HARASS_ANIM) and lastHarassTarget ~= -1 and forcedAnimationCount >= 3 then
                local playerCoords = GetEntityCoords(playerPed)
                for _, playerId in ipairs(GetActivePlayers()) do
                    if playerId ~= PlayerId() and GetPlayerServerId(playerId) == lastHarassTarget then
                        local targetPed = GetPlayerPed(playerId)
                        if targetPed ~= playerPed and DoesEntityExist(targetPed) then
                            if #(playerCoords - GetEntityCoords(targetPed)) <= 2.0
                                and not IsPedInAnyVehicle(targetPed, false)
                                and not IsEntityDead(targetPed) then
                                if IsEntityPlayingAnim(targetPed, HARASS_ANIM, HARASS_ANIM_CLIP, 3) then
                                    harassAnimFlags = harassAnimFlags + 1
                                    if harassAnimFlags >= 2 then
                                        SafeTriggerServerEvent("VexShield:banHandler", "Attempted to force animation on other player")
                                        forcedAnimationCount = 0
                                        harassAnimFlags = 0
                                        lastHarassTarget = -1
                                    end
                                else
                                    harassAnimFlags = 0
                                end
                            end
                        end
                    end
                end
            end
        end

        ::continue::
    end
end)

-- [Anti AC Scanner]
Citizen.CreateThread(function()
    local scanDetectionThreshold = 5
    local resourceLoadCount = 0
    local lastResourceLoadTime = 0
    local scanStartTime = 0
    
    local originalLoadResourceFile = LoadResourceFile
    
    _G.LoadResourceFile = function(resourceName, fileName)
        if Config and Config.Protections and Config.Protections['Anti AC Scanner'] then
            local currentTime = GetGameTimer()
            
            if currentTime - lastResourceLoadTime > 2000 then
                resourceLoadCount = 0
                scanStartTime = currentTime
            end
            
            resourceLoadCount = resourceLoadCount + 1
            lastResourceLoadTime = currentTime
            
            if resourceLoadCount > scanDetectionThreshold and (currentTime - scanStartTime) < 10000 then
                SafeTriggerServerEvent("VexShield:banHandler", "Attempted to scan anticheat files: " .. resourceName)
                resourceLoadCount = 0
            end
            
            local suspiciousFiles = {
                "shared_fg-obfuscated.lua", "waveshield.lua", "fire-config.lua", "secureserve.key",
                "ac_config.lua", "anticheat.lua", "screenshot.lua", "banlist.json", "whitelist.lua"
            }
            
            for _, suspiciousFile in ipairs(suspiciousFiles) do
                if fileName == suspiciousFile then
                    SafeTriggerServerEvent("VexShield:banHandler", "Attempted targeted file scan: " .. fileName)
                    break
                end
            end
        end
        
        return originalLoadResourceFile(resourceName, fileName)
    end
end)

-- [Anti Unauthorized Admin]
Citizen.CreateThread(function()
    local adminEvents = {
        "qb-admin:server:checkPerm", "qb-admin:server:vehicleFound", "qb-admin:server:setWpCoords",
        "qb-admin:server:getradiolist", "qb-admin:server:platelookup", "qb-admin:server:setPermissions",
        "qb-admin:server:kick", "qb-admin:server:ban", "qb-admin:server:toggleNoClip",
        "qb-admin:client:setWpCoords", "qb-admin:server:playerstash", "qb-admin:server:playerstash2",
        "QBCore:CallCommand", "qb-weathersync:server:setWeather", "qb-weathersync:server:setTime",
        "inventory:server:OpenInventory", "qb-inventory:server:OpenInventory", "police:server:RobPlayer",
        "qb-personalstash:server:OpenStash", "weapons:server:UpdateWeaponAmmo", "InteractSound_SV:PlayOnSource",
        "raid_clothes:get_character_face", "raid_clothes:get_character_current", "qb-log:server:CreateLog"
    }
    
    local originalTriggerServerEvent = TriggerServerEvent
    
    _G.TriggerServerEvent = function(eventName, ...)
        if Config and Config.Protections and Config.Protections['Anti Unauthorized Admin'] then
            for _, adminEvent in ipairs(adminEvents) do
                if eventName == adminEvent then
                    originalSafeTriggerServerEvent("VexShield:UnauthorizedAdminDetected", eventName, "Triggered by client")
                    break
                end
            end
        end
        return originalTriggerServerEvent(eventName, ...)
    end
end)




VexShieldClientState.killAllWindowStart = VexShieldClientState.killAllWindowStart or 0
VexShieldClientState.killAllCount = VexShieldClientState.killAllCount or 0
VexShieldClientState.killAllVictims = VexShieldClientState.killAllVictims or {}

function VexShieldResetKillAllTracker()
    VexShieldClientState.killAllWindowStart = 0
    VexShieldClientState.killAllCount = 0
    VexShieldClientState.killAllVictims = {}
end

AddEventHandler('gameEventTriggered', function(event, data)
    if not VexShieldIsProtectionOn('Anti Kill All') then return end
    if event ~= 'CEventNetworkEntityDamage' then return end
    local victim = data[1]
    local victimDied = data[4]
    local attacker = data[2]
    if not victimDied then return end
    local playerPed = PlayerPedId()
    if not DoesEntityExist(playerPed)
        or IsEntityDead(playerPed)
        or IsPedInAnyVehicle(playerPed, false)
        or IsPauseMenuActive()
        or IsNuiFocused()
        or IsNuiFocusKeepingInput()
        or IsCutsceneActive()
        or not IsScreenFadedIn()
        or not IsPlayerControlOn(PlayerId()) then
        VexShieldResetKillAllTracker()
        return
    end
    if not IsPedAPlayer(victim) then return end
    if victim == playerPed then return end
    if attacker ~= playerPed then return end

    -- Keep this extremely conservative: only treat rapid multi-kill bursts as suspicious
    -- when the attacker is not using a firearm at all.
    local currentWeapon = GetSelectedPedWeapon(playerPed)
    if IsPedArmed(playerPed, 6) or currentWeapon ~= GetHashKey('WEAPON_UNARMED') then
        VexShieldResetKillAllTracker()
        return
    end

    local now = GetGameTimer()
    if VexShieldClientState.killAllWindowStart == 0 or (now - VexShieldClientState.killAllWindowStart) > 1500 then
        VexShieldClientState.killAllWindowStart = now
        VexShieldClientState.killAllCount = 0
        VexShieldClientState.killAllVictims = {}
    end

    local victimKey = tostring(victim)
    if VexShieldClientState.killAllVictims[victimKey] then
        return
    end

    VexShieldClientState.killAllVictims[victimKey] = now
    VexShieldClientState.killAllCount = VexShieldClientState.killAllCount + 1

    if VexShieldClientState.killAllCount >= 6 then
        SafeTriggerServerEvent('VexShield:banHandler','Attempted mass elimination')
        VexShieldResetKillAllTracker()
    elseif now - VexShieldClientState.killAllWindowStart > 1500 then
        VexShieldResetKillAllTracker()
    else
        VexShieldClientState.killAllWindowStart = math.min(VexShieldClientState.killAllWindowStart, now)
    end
end)

-- ================================= VEHICLE SPAM DETECTION (conservative heuristic) =================================
VexShieldClientState.vehicleSpamLastCount = VexShieldClientState.vehicleSpamLastCount or nil
VexShieldClientState.vehicleSpamStrikes = VexShieldClientState.vehicleSpamStrikes or 0
VexShieldClientState.vehicleSpamLastStrikeAt = VexShieldClientState.vehicleSpamLastStrikeAt or 0
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Wait(Config.VehicleSpamCheckMs or 5000)

        if VexShieldIsProtectionOn('Anti Vehicle Spam') then
            local ped = PlayerPedId()
            local skipVehicleSpamCheck = not DoesEntityExist(ped)
                or IsEntityDead(ped)
                or IsPedInAnyVehicle(ped, false)
                or IsPauseMenuActive()
                or GetInteriorFromEntity(ped) ~= 0

            if skipVehicleSpamCheck then
                VexShieldClientState.vehicleSpamLastCount = nil
                VexShieldClientState.vehicleSpamStrikes = 0
            else
                local playerPos = GetEntityCoords(ped)
                local count = 0
                local radius = tonumber(Config.VehicleSpamRadius) or 15.0

                local vehicles = AS_GetPool('CVehicle')
                for _, veh in ipairs(vehicles) do
                    if DoesEntityExist(veh) then
                        local vehPos = GetEntityCoords(veh)
                        if #(playerPos - vehPos) < radius then
                            count = count + 1
                        end
                    end
                end

                local lastCount = VexShieldClientState.vehicleSpamLastCount
                if lastCount ~= nil then
                    local diff = count - lastCount
                    local threshold = tonumber(Config.VehicleSpamIncreaseThreshold) or 8
                    local minNearby = tonumber(Config.VehicleSpamMinNearbyVehicles) or 10
                    if diff >= threshold and count >= minNearby then
                        local now = GetGameTimer()
                        if now - (VexShieldClientState.vehicleSpamLastStrikeAt or 0) > (Config.VehicleSpamStrikeWindowMs or 20000) then
                            VexShieldClientState.vehicleSpamStrikes = 0
                        end
                        VexShieldClientState.vehicleSpamLastStrikeAt = now
                        VexShieldClientState.vehicleSpamStrikes = (VexShieldClientState.vehicleSpamStrikes or 0) + 1

                        if VexShieldClientState.vehicleSpamStrikes >= (Config.VehicleSpamRequiredStrikes or 3) then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to spam vehicle spawning')
                            VexShieldClientState.vehicleSpamStrikes = 0
                        end
                    elseif diff <= 0 then
                        VexShieldClientState.vehicleSpamStrikes = 0
                    end
                end

                VexShieldClientState.vehicleSpamLastCount = count
            end
        end
    end
end)

-- [VEX-INTERNAL-CORE: 0x9F4C2A-C3849102948]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    local freezeFlags = 0
    local ragdollFlags = 0
    local taskClearFlags = 0
    local lastTaskStatus = 0
    
    while true do
        Citizen.Wait(1000)
        
        if Shared and Shared.Protections then
            local ped = PlayerPedId()
             -- Anti Freeze Player
            if VexShieldIsProtectionOn('Anti Freeze Player') then
                if DoesEntityExist(ped) and not IsEntityDead(ped) then
                    if IsEntityStatic(ped) and not IsPedInAnyVehicle(ped, false) and not IsPauseMenuActive() and not IsNuiFocused() then
                        -- If the player is static but should be moving or is forced frozen
                        if IsEntityPositionFrozen(ped) then
                            freezeFlags = freezeFlags + 1
                            if freezeFlags >= 5 then
                                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to freeze player position')
                                freezeFlags = 0
                            end
                        else
                            freezeFlags = 0
                        end
                    else
                        freezeFlags = 0
                    end
                end
            end

            -- Anti Ragdoll Abuse
            if VexShieldIsProtectionOn('Anti Ragdoll Abuse') then
                if not ShouldSkipRagdollAbuseCheck(ped) then
                    -- Detect if ragdoll is disabled via native CanPedRagdoll or CPED_CONFIG_FLAG_DisableRagdoll (58)
                    local cannotRagdoll = (not CanPedRagdoll(ped)) or GetPedConfigFlag(ped, 58, true) or GetPedConfigFlag(ped, 58, false)
                    if cannotRagdoll then
                        ragdollFlags = ragdollFlags + 1
                        if ragdollFlags >= 5 then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to abuse ragdoll state')
                            ragdollFlags = 0
                        end
                    else
                        ragdollFlags = math.max(0, ragdollFlags - 1)
                    end
                else
                    ragdollFlags = math.max(0, ragdollFlags - 1)
                end
            end

            -- Anti Task Clear Loop
            -- (Handled in separate thread)
        end
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Wait(2000)
        if not VexShieldIsProtectionOn('Anti Ped Scale') then break end

        local ped = PlayerPedId()
        if DoesEntityExist(ped) then
            -- Check for Tiny Ped (Flag 223)
            if GetPedConfigFlag(ped, 223, true) then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to shrink player model')
            end
            
            -- Check for Giant Ped (Height Mismatch)
            if not IsPedRagdoll(ped) and not IsPedInAnyVehicle(ped, false) and not IsPedSwimming(ped) and not IsPedClimbing(ped) then
                local min, max = GetModelDimensions(GetEntityModel(ped))
                local expectedHeight = max.z - min.z
                
                local headCoords = GetPedBoneCoords(ped, 31086, 0, 0, 0)
                local rootCoords = GetEntityCoords(ped)
                local actualHeight = headCoords.z - rootCoords.z
                
                -- If actual height is significantly larger than model height (allow 1.5x buffer)
                if actualHeight > expectedHeight * 1.5 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to enlarge player model')
                end
            end
        end
    end
end)

local camRotFlags = 0
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while true do
        Wait(1000)
        if not VexShieldIsProtectionOn('Anti Camera Rotation') then break end
        if isExempt or (VexShieldClientState and VexShieldClientState.isExempt) then
            camRotFlags = 0
            goto continue
        end
        
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then
            camRotFlags = 0
            goto continue
        end

        local state = LocalPlayer.state
        local isNoclipOrFreecam = state and (state.VexShield_noclip or state.VexShield_freecam or state.noclip or state.freecam or state.isSpectating) or false
        if isNoclipOrFreecam then
            camRotFlags = 0
            goto continue
        end

        -- Skip check when player is in vehicle, ragdoll, dead, falling, climbing, tazed/stunned, being carried, using scenarios, in cutscene, or camera shake/drunk/effects active
        if IsPedInAnyVehicle(ped, false)
            or IsPedRagdoll(ped)
            or IsEntityDead(ped)
            or IsPedDeadOrDying(ped)
            or IsPedBeingStunned(ped)
            or IsPedFalling(ped)
            or IsPedJumping(ped)
            or IsPedClimbing(ped)
            or IsPedInCover(ped)
            or IsPedUsingAnyScenario(ped)
            or IsEntityAttached(ped)
            or IsPauseMenuActive()
            or IsNuiFocused()
            or IsNuiFocusKeepingInput()
            or NetworkIsInSpectatorMode()
            or IsCutsceneActive()
            or GetRenderingCam() ~= -1
            or IsGameplayCamShaking()
            or not IsScreenFadedIn()
        then
            camRotFlags = 0
            goto continue
        end

        local camRot = GetGameplayCamRot(2)
        local pitch = camRot.x
        local roll = camRot.y

        -- Real camera rotation hacks lock roll/pitch at unnatural extreme angles (e.g. roll > 160° or pitch > 115°)
        if math.abs(roll) > 160.0 or math.abs(pitch) > 115.0 then
            camRotFlags = camRotFlags + 1
            if camRotFlags >= 5 then
                if math.abs(roll) > 160.0 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted camera manipulation (roll: ' .. math.floor(roll) .. ')')
                else
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted camera manipulation (pitch: ' .. math.floor(pitch) .. ')')
                end
                camRotFlags = 0
            end
        else
            if camRotFlags > 0 then
                camRotFlags = camRotFlags - 1
            end
        end

        ::continue::
    end
end)

function IsPlayerInWhitelistedAreaRepair()
    local playerCoords = GetEntityCoords(PlayerPedId())
    if not (Shared.Client and Shared.Client['Vehicle Repair']) then
        return false
    end
    for _, area in ipairs(Shared.Client['Vehicle Repair']['Whitelisted Areas']) do
        if #(playerCoords - area.coords) <= area.radius then 
            return true
        end
    end
    return false
end

function ShouldSkipRepairVehicleCheck(ped, veh, enterGraceUntil)
    if not ped or ped == 0 or not veh or veh == 0 then
        return true
    end

    if not DoesEntityExist(ped) or not DoesEntityExist(veh) then
        return true
    end

    if IsEntityDead(ped) or not IsScreenFadedIn() or IsCutsceneActive() then
        return true
    end

    if IsPlayerInWhitelistedAreaRepair() then
        return true
    end

    if GetPedInVehicleSeat(veh, -1) ~= ped then
        return true
    end

    if enterGraceUntil and GetGameTimer() < enterGraceUntil then
        return true
    end

    if NetworkGetEntityIsNetworked(veh) and NetworkGetEntityOwner(veh) ~= PlayerId() then
        return true
    end

    return false
end

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    local lastEngine = 0.0
    local lastBody = 0.0
    local lastTime = 0
    local lastVehicle = 0
    local enterGraceUntil = 0
    while true do
        Wait(500)
        if not VexShieldIsProtectionOn('Anti Repair Vehicle') then
            break
        end
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and DoesEntityExist(veh) then
            local now = GetGameTimer()
            if veh ~= lastVehicle then
                lastVehicle = veh
                enterGraceUntil = now + 4000
                lastEngine = 0.0
                lastBody = 0.0
                lastTime = now
            end

            local eng = GetVehicleEngineHealth(veh)
            local body = GetVehicleBodyHealth(veh)
            if ShouldSkipRepairVehicleCheck(ped, veh, enterGraceUntil) then
                lastEngine = eng
                lastBody = body
                lastTime = now
            elseif lastEngine == 0.0 then
                lastEngine = eng
                lastBody = body
                lastTime = now
            else
                local dEng = eng - lastEngine
                local dBody = body - lastBody
                local dt = now - lastTime
                local wasClearlyDamaged = (lastEngine <= 700.0) or (lastBody <= 850.0)
                local repairedToHealthy = (eng >= 900.0) and (body >= 900.0)
                local suspiciousRepairJump = (dEng >= 450.0) and (dBody >= 300.0)
                if dt <= 1500 and wasClearlyDamaged and repairedToHealthy and suspiciousRepairJump then
                    SafeTriggerServerEvent('VexShield:banHandler','Attempted to repair vehicle remotely')
                    break
                end
                lastEngine = eng
                lastBody = body
                lastTime = now
            end
        else
            lastVehicle = 0
            enterGraceUntil = 0
            lastEngine = 0.0
            lastBody = 0.0
            lastTime = GetGameTimer()
        end
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    local prevSet = {}
    local prevTime = 0
    while true do
        Wait(2000)
        if not VexShieldIsProtectionOn('Anti Delete Vehicle') then
            break
        end
        local myPed = PlayerPedId()
        local myCoords = GetEntityCoords(myPed)
        local now = GetGameTimer()
        local setNow = {}
        local pool = AS_GetPool('CVehicle')
        for i = 1, #pool do
            local veh = pool[i]
            if DoesEntityExist(veh) then
                local vpos = GetEntityCoords(veh)
                if #(vpos - myCoords) <= 60.0 then
                    setNow[veh] = true
                end
            end
        end
        local removals = 0
        for v,_ in pairs(prevSet) do
            if not setNow[v] and (now - prevTime) <= 2000 then
                removals = removals + 1
            end
        end
        -- Increased threshold from 3 to 8 to reduce false bans
        if removals >= 8 then
            SafeTriggerServerEvent('VexShield:banHandler','Attempted to delete vehicle remotely')
            break
        end
        prevSet = setNow
        prevTime = now
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Wait(400)
        if not VexShieldIsProtectionOn('Anti Bug Vehicle') then
            break
        end
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and DoesEntityExist(veh) then
            local alpha = GetEntityAlpha(veh)
            local canDamaged = GetEntityCanBeDamaged(veh)
            local frozen = IsEntityPositionFrozen(veh)
            if (alpha < 200 or not canDamaged or frozen) and not IsPedInAnyPlane(ped) and not IsPedInAnyHeli(ped) then
                SafeTriggerServerEvent('VexShield:banHandler','Attempted to corrupt vehicle state')
                break
            end
        end
    end
end)

CreateThread(function()
    checkingCallbacks = true
    local callbacksProbeResult = nil

    local function onCallbacksReady()
        callbacksProbeResult = true
    end
    local function onCallbacksNotReady()
        callbacksProbeResult = false
    end

    RegisterNetEvent("VexShield:CallbacksReady", onCallbacksReady)
    RegisterNetEvent("VexShield:CallbacksNotReady", onCallbacksNotReady)

    while not serverCallbacksReady do
        callbacksProbeResult = nil
        SafeTriggerServerEvent("VexShield:AreCallbacksReady")

        local deadline = GetGameTimer() + 8000
        while callbacksProbeResult == nil and GetGameTimer() < deadline do
            -- Waiting on a server round-trip (tens of ms); polling every frame was a pure
            -- busy-wait. 50ms is well within tolerance for a readiness probe and removes the spin.
            Wait(50)
        end

        if callbacksProbeResult == true then
            serverCallbacksReady = true
        else
            Wait(2000)
        end
    end
    checkingCallbacks = false
end)

-- print("here clientjajaj1")

CreateThread(function()
    Wait(2000) -- wacht even tot speler volledig geladen is
    SafeTriggerServerEvent("VexShield:MarkPlayerJoined")
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        if not VexShieldIsProtectionOn('Attempted to fire without weapon') then
            Wait(VexShieldClientState.pollIdleMs)
        else
            Wait(VexShieldClientState.pollShootNoWeaponMs)
            -- Skip natives unless attack input (saves IsPedShooting every tick)
            if IsControlPressed(0, 24) or IsControlPressed(0, 257) then
                local ped = PlayerPedId()
                if IsPedShooting(ped) and not IsPedArmed(ped, 6) then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to fire without weapon')
                end
            end
        end
    end
end)

-------------------------------------------
-- WAIT FOR FRAMEWORK IN SERVER CALLBACK --
-------------------------------------------
function FrameworkTriggerServerCallback(name, cb, ...)
    -- Wait for a framework OR ox_lib (Qbox/ox_core/standalone use the ox_lib path).
    local waited = 0
    while (not UseESX and not UseQBCore) and not (lib and lib.callback) and waited < 20000 do
        Wait(500)
        waited = waited + 500
    end

    -- Wacht totdat server callbacks klaar zijn
    
    while (not serverCallbacksReady) do
        -- print("^1[VexShield-Client] Waiting for server callbacks to be ready...^0")
        Wait(100)
    end

    -- Roep de juiste callback aan
    if UseESX and ESX then
        ESX.TriggerServerCallback(name, cb, ...)
    elseif UseQBCore and QBCore then
        QBCore.Functions.TriggerCallback(name, cb, ...)
    elseif lib and lib.callback then
        -- Universal ox_lib path (Qbox / ox_core / standalone). Server registers these names via lib.callback.
        local args = { ... }
        CreateThread(function()
            local res = lib.callback.await(name, false, table.unpack(args))
            cb(res)
        end)
    else
        print("[VexShield] Error: Server callback failed (No framework/ox_lib active).")
    end
end
----------------------------------
-- SIMPLE NOTIFICATION WRAPPER  --
----------------------------------
function ShowNotification(msg)
    if UseESX then
        TriggerEvent("esx:showNotification", msg)
    elseif UseQBCore then
        QBCore.Functions.Notify(msg, "inform", 5000)
    else
        print("Notification: "..msg)
    end
end

--------------------------------
-- LOAD CONFIG LOGIC
-- NOTE: Do not declare local Shared / local configLoaded here — they shadow globals
-- used by waitUntilReady(), CEvent handlers, and AntiSilentAim / AntiAimBot checks.
--------------------------------

function detectInventorySystem()
    -- Auto-detect which inventory system is available
    local detectedInventory = {
        ['esx'] = false,
        ['qb'] = false,
        ['ox'] = false,
        ['ps'] = false,
        ['quasar'] = false,
        ['custom'] = false
    }
    
    -- Use the already detected framework to determine base system
    if UseESX then
        detectedInventory['esx'] = true
    elseif UseQBCore then
        detectedInventory['qb'] = true
    end
    
    -- Check for specific inventory systems regardless of framework
    -- Check for ox_inventory
    if GetResourceState('ox_inventory') == 'started' then
        detectedInventory['ox'] = true
        detectedInventory['qb'] = false
        detectedInventory['esx'] = false
    end
    
    -- Check for ps-inventory
    if GetResourceState('ps-inventory') == 'started' then
        detectedInventory['ps'] = true
        detectedInventory['qb'] = false
    end
    
    -- Check for Quasar Inventory
    if GetResourceState('quasar_inventory') == 'started' then
        detectedInventory['quasar'] = true
        detectedInventory['qb'] = false
        detectedInventory['esx'] = false
    end
    
    return detectedInventory
end

function applyClientConfig(config)
    Shared = config or {}
    Config = Shared
    Shared.Inventory = Shared.Inventory or {}
    
    -- Override inventory settings with auto-detected values, but preserve custom config for custom inventory
    local autoDetected = detectInventorySystem()
    for inventoryType, isEnabled in pairs(autoDetected) do
        if inventoryType ~= 'custom' and isEnabled then  -- Don't auto-enable custom inventory
            Shared.Inventory[inventoryType] = true
            print("^2VexShield: Auto-detected " .. inventoryType .. " inventory system^7")
        elseif not isEnabled and inventoryType ~= 'custom' then  -- Only disable non-custom if not detected
            -- Only disable if it wasn't manually enabled in config
            if not Shared.Inventory[inventoryType] then
                Shared.Inventory[inventoryType] = false
            end
        end
    end
    
    configLoaded = true
end

RegisterNetEvent('VexShield:ClientSyncConfig', function(newConfig)
    applyClientConfig(newConfig)
end)

function loadConfig()
    FrameworkTriggerServerCallback('VexShield:get:config', function(config)
        if not config then
            print("[VexShield] Error: Configuration sync failed.")
            return
        end
        applyClientConfig(config)
    end)
end

-- QB / PS-Inventory: tolerate DB rows without WEAPON_ prefix (e.g. PISTOL_MK2) and avoid errors on bad types.
local function compareWeaponHashes(hash1, hash2)
    if not hash1 or not hash2 then return false end
    if hash1 == hash2 then return true end
    local h1_num = tonumber(hash1)
    local h2_num = tonumber(hash2)
    if not h1_num or not h2_num then return false end
    if h1_num == h2_num then return true end
    
    local un1 = h1_num < 0 and (4294967296 + h1_num) or h1_num
    local un2 = h2_num < 0 and (4294967296 + h2_num) or h2_num
    if un1 == un2 then return true end

    local sig1 = h1_num > 2147483647 and (h1_num - 4294967296) or h1_num
    local sig2 = h2_num > 2147483647 and (h2_num - 4294967296) or h2_num
    if sig1 == sig2 then return true end

    return false
end

function qbPsItemNameForWeaponHash(itemName, weaponHash)
    if itemName == nil or weaponHash == nil or weaponHash == -1569615261 then return nil end
    local s = tostring(itemName):match("^%s*(.-)%s*$") or ""
    if s == "" then return nil end
    local u = string.upper(s)
    
    if compareWeaponHashes(GetHashKey(u), weaponHash) then return u end
    if compareWeaponHashes(GetHashKey(s), weaponHash) then return s end

    local prefixed = u
    if not prefixed:find("WEAPON_", 1, true) then
        prefixed = "WEAPON_" .. prefixed
    end
    if compareWeaponHashes(GetHashKey(prefixed), weaponHash) then return prefixed end

    local lowerPrefixed = "weapon_" .. s:lower():gsub("^weapon_", "")
    if compareWeaponHashes(GetHashKey(lowerPrefixed), weaponHash) then return lowerPrefixed end

    return nil
end

VexShieldAllowedWeapons = VexShieldAllowedWeapons or {}

local function VexShieldSignedToUnsigned(num)
    if not num or type(num) ~= "number" then return nil end
    if num >= 0 then return num end
    return 4294967296 + num
end

function isWeaponInVexShieldAllowedList(hash)
    if not hash then return false end
    if type(hash) == "string" then hash = GetHashKey(hash) end
    if VexShieldAllowedWeapons[hash] then return true end
    local un = VexShieldSignedToUnsigned(hash)
    if un and VexShieldAllowedWeapons[un] then return true end
    return false
end

exports('giveWeapon', function(weaponHash)
    if type(weaponHash) == "string" then weaponHash = GetHashKey(weaponHash) end
    if type(weaponHash) == "number" then
        VexShieldAllowedWeapons[weaponHash] = true
        local un = VexShieldSignedToUnsigned(weaponHash)
        if un then VexShieldAllowedWeapons[un] = true end
    end
end)

exports('removeWeapon', function(weaponHash)
    if not weaponHash then return end
    if type(weaponHash) == "string" then weaponHash = GetHashKey(weaponHash) end
    if type(weaponHash) == "number" then
        VexShieldAllowedWeapons[weaponHash] = nil
        local un = VexShieldSignedToUnsigned(weaponHash)
        if un then VexShieldAllowedWeapons[un] = nil end
    end
end)

exports('removeAllWeapons', function()
    VexShieldAllowedWeapons = {}
end)

RegisterNetEvent('VexShield:giveWeapon', function(weaponHash)
    if type(weaponHash) == "string" then weaponHash = GetHashKey(weaponHash) end
    if type(weaponHash) == "number" then
        VexShieldAllowedWeapons[weaponHash] = true
        local un = VexShieldSignedToUnsigned(weaponHash)
        if un then VexShieldAllowedWeapons[un] = true end
    end
end)

RegisterNetEvent('VexShield:removeWeapon', function(weaponHash)
    if not weaponHash then return end
    if type(weaponHash) == "string" then weaponHash = GetHashKey(weaponHash) end
    if type(weaponHash) == "number" then
        VexShieldAllowedWeapons[weaponHash] = nil
        local un = VexShieldSignedToUnsigned(weaponHash)
        if un then VexShieldAllowedWeapons[un] = nil end
    end
end)

RegisterNetEvent('VexShield:removeAllWeapons', function()
    VexShieldAllowedWeapons = {}
end)

AddEventHandler('gameEventTriggered', function(name, args)
    if name == "CEventNetworkPlayerCollectedAmbientPickup" or name == "CEventNetworkPlayerCollectedPortablePickup" then
        if args and args[1] then
            local wHash = args[1]
            if type(wHash) == "string" then wHash = GetHashKey(wHash) end
            if type(wHash) == "number" then
                VexShieldAllowedWeapons[wHash] = true
                local un = VexShieldSignedToUnsigned(wHash)
                if un then VexShieldAllowedWeapons[un] = true end
            end
        end
    end
end)

function hasWeaponInInventoryByHash(hash)
    if not hash or hash == -1569615261 then return true end
    if isWeaponInVexShieldAllowedList(hash) then
        return true
    end

    -- 1. Check ox_inventory
    if GetResourceState('ox_inventory') == 'started' then
        local ok, w = pcall(function() return exports.ox_inventory:getCurrentWeapon() end)
        if ok and w and compareWeaponHashes(w.hash, hash) then
            VexShieldAllowedWeapons[hash] = true
            local un = VexShieldSignedToUnsigned(hash)
            if un then VexShieldAllowedWeapons[un] = true end
            return true
        end
    end

    -- 2. Check quasar_inventory
    if GetResourceState('quasar_inventory') == 'started' then
        local ok, w = pcall(function() return exports.quasar_inventory:getCurrentWeapon() end)
        if ok and w and compareWeaponHashes(w.hash, hash) then
            VexShieldAllowedWeapons[hash] = true
            local un = VexShieldSignedToUnsigned(hash)
            if un then VexShieldAllowedWeapons[un] = true end
            return true
        end
    end

    -- 3. Check QBCore / ps-inventory / qb-inventory
    local qbData = nil
    if QBCore and QBCore.Functions and QBCore.Functions.GetPlayerData then
        local ok, pd = pcall(function() return QBCore.Functions.GetPlayerData() end)
        if ok and pd then qbData = pd end
    end
    if not qbData and LocalPlayer and LocalPlayer.state and LocalPlayer.state.qbPlayerData then
        qbData = LocalPlayer.state.qbPlayerData
    end

    if qbData and qbData.items then
        for _, item in pairs(qbData.items) do
            if item and item.name and qbPsItemNameForWeaponHash(item.name, hash) then
                VexShieldAllowedWeapons[hash] = true
                local un = VexShieldSignedToUnsigned(hash)
                if un then VexShieldAllowedWeapons[un] = true end
                return true
            end
        end
    end

    -- 4. Check ESX
    if ESX and ESX.GetPlayerData then
        local ok, x = pcall(function() return ESX.GetPlayerData() end)
        if ok and x and x.inventory then
            for _, item in pairs(x.inventory) do
                if item and item.name and (string.find(item.name:upper(), 'WEAPON_') or qbPsItemNameForWeaponHash(item.name, hash)) then
                    if compareWeaponHashes(GetHashKey(item.name), hash) or qbPsItemNameForWeaponHash(item.name, hash) then
                        VexShieldAllowedWeapons[hash] = true
                        local un = VexShieldSignedToUnsigned(hash)
                        if un then VexShieldAllowedWeapons[un] = true end
                        return true
                    end
                end
            end
        end
    end

    -- 5. Custom inventory fallback export
    if Shared and Shared.CustomInventory and Shared.CustomInventory.getWeapon then
        local w = Shared.CustomInventory.getWeapon()
        if w and compareWeaponHashes(w.hash, hash) then
            VexShieldAllowedWeapons[hash] = true
            local un = VexShieldSignedToUnsigned(hash)
            if un then VexShieldAllowedWeapons[un] = true end
            return true
        end
    end

    return false
end


--------------------------------
-- RESOURCE WHITELIST CHECK
--------------------------------
-- Function to check if a resource is in the whitelist
-- If resource is whitelisted, it bypasses ALL anti-cheat protections
function isResourceWhitelisted(resource)
    if not resource or resource == "" or resource == "unknown" then
        return false
    end
    
    -- Get whitelisted resources from config
    local whitelistedResources = (Shared and Shared.WhitelistedResources) or (Config and Config.WhitelistedResources) or {}
    
    -- Check if resource is in whitelist
    for _, whitelistedResource in ipairs(whitelistedResources) do
        if resource == whitelistedResource then
            return true
        end
    end
    
    return false
end

-- Full Whitelist Resources Check Function (like admin bypass)
function isResourceFullWhitelisted(resource)
    if not resource or resource == "" or resource == "unknown" then
        return false
    end
    
    -- Get full whitelisted resources from config
    local fullWhitelistResources = (Shared and Shared.FullWhitelistResources) or (Config and Config.FullWhitelistResources) or {}
    
    -- Check if resource is in full whitelist
    for _, fullWhitelistedResource in ipairs(fullWhitelistResources) do
        if resource == fullWhitelistedResource then
            return true
        end
    end
    
    return false
end

CreateThread(function()
    while not serverCallbacksReady do
        Wait(100)
    end
    loadConfig()
end)

-- print("here clientjajaj2")

-------------------------------------------
-- EXAMPLE: Some non-protection thread
-------------------------------------------
local clientUUID = tostring(GetPlayerServerId(PlayerId())) .. "-" .. tostring(math.random(100000, 999999))
local resourceName = GetCurrentResourceName()
local secretKey = math.random(100000, 999999)
local lastHeartbeat = 0
local lastStealthCheck = 0
function WaitForPlayerToLoad()
    while not NetworkIsSessionStarted() or not NetworkIsPlayerActive(PlayerId()) or not DoesEntityExist(PlayerPedId()) do
        Citizen.Wait(100)
    end
end

-- Registreer volledig zodra speler is geladen
Citizen.CreateThread(function()
    WaitForPlayerToLoad()
    Citizen.Wait(2000)
    SafeTriggerServerEvent('VexShield:registerUUID', clientUUID, secretKey, false)
end)

-- Heartbeat loop
Citizen.CreateThread(function()
    WaitForPlayerToLoad()
    while true do
        Citizen.Wait(math.random(4500, 6000))
        if GetCurrentResourceName() ~= resourceName then
            SafeTriggerServerEvent('VexShield:kickPlayer', 'Anticheat gemanipuleerd of gestopt!')
            return
        end
        local token = math.random(100000, 999999)
        lastHeartbeat = GetGameTimer()
        SafeTriggerServerEvent('VexShield:heartbeat', resourceName, clientUUID, secretKey, token)
    end
end)

-- Stealth check loop
Citizen.CreateThread(function()
    WaitForPlayerToLoad()
    while true do
        Citizen.Wait(math.random(8500, 12500))
        -- Fixed: Removed return that could stop the loop forever
        lastStealthCheck = GetGameTimer()
        local token = math.random(100000, 999999)
        SafeTriggerServerEvent('VexShield:stealthCheck', clientUUID, secretKey, token)
    end
end)

AddEventHandler('onClientResourceStop', function(stoppedResource)
    if stoppedResource == GetCurrentResourceName() then
        if VexShieldIsProtectionOn('Anti Stop Resource') then
            SafeTriggerServerEvent('VexShield:stopResourceDetected')
        else
            SafeTriggerServerEvent('VexShield:kickPlayer', 'You tried to stop the Anticheat!')
        end
        ExecuteCommand("ensure " .. GetCurrentResourceName())
    else
        -- Detect attempts to stop ANY resource (not just VexShield)
        if VexShieldIsProtectionOn('Anti Stop Resource') then
            SafeTriggerServerEvent('VexShield:stopResourceDetected', stoppedResource)
        end
    end
end)

AddEventHandler("onClientResourceStart", function(startedResource)
    if startedResource == resourceName and not clientUUID then
        SafeTriggerServerEvent('VexShield:kickPlayer', 'Anticheat herstartte zonder registratie!')
    end
end)

---------------------------------------------------------------------------------
-- TELEPORT DETECTION
---------------------------------------------------------------------------------
local teleportDetectionTime = 5000
local maxTeleportSpeed = 400
local lastPosition = vector3(0, 0, 0)
local lastCheckTime = 0
local isTeleportingByScript = false
local teleportCooldown = 1000
local TeleportIgnoreUntil = 0
local wasInVehicle = false

function getPlayerPosition()
    return GetEntityCoords(PlayerPedId())
end

function checkForTeleportation()
    local currentTime = GetGameTimer()
    if lastPosition == vector3(0, 0, 0) then
        lastPosition = getPlayerPosition()
        return 
    end

    if currentTime - lastCheckTime >= teleportDetectionTime then
        local currentPosition = getPlayerPosition()
        local distance = #(currentPosition - lastPosition)
        -- Make sure we check if Shared.Client['Max Distance Telelporting'] exists
        local maxDist = (Shared.Client and Shared.Client['Max Distance Telelporting']) or 200.0

        local ped = PlayerPedId()
        local inVeh = IsPedInAnyVehicle(ped)
        if inVeh then
            wasInVehicle = true
            lastPosition = currentPosition
            lastCheckTime = currentTime
            TeleportIgnoreUntil = GetGameTimer() + 3000
            return
        elseif wasInVehicle then
            wasInVehicle = false
            TeleportIgnoreUntil = GetGameTimer() + 3000
            lastPosition = currentPosition
            lastCheckTime = currentTime
            return
        end

        -- Check if teleport came from whitelisted resource before banning
        local invokingResource = GetInvokingResource()
        if distance > maxDist and not isTeleportingByScript and GetGameTimer() > TeleportIgnoreUntil then
            -- Allow whitelisted resources to teleport
            -- Also allow full whitelisted resources (like admin)
            if not (invokingResource and (isResourceWhitelisted(invokingResource) or isResourceFullWhitelisted(invokingResource))) then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to teleport')
            end
        end
        lastPosition = currentPosition
        lastCheckTime = currentTime
    end
end

function setEntityCoordsSafely(entity, x, y, z)
    -- Check if resource is whitelisted before marking as safe teleport
    -- Also check for full whitelisted resources (like admin)
    local invokingResource = GetInvokingResource()
    if invokingResource and (isResourceWhitelisted(invokingResource) or isResourceFullWhitelisted(invokingResource)) then
        isTeleportingByScript = true
        Wait(101)
        SetEntityCoords(entity, x, y, z, false, false, false, false)
        Wait(teleportCooldown)
        isTeleportingByScript = false
        lastPosition = vector3(x, y, z)
        return
    end
    
    -- For non-whitelisted resources, use normal safe teleport logic
    isTeleportingByScript = true
    Wait(101)
    SetEntityCoords(entity, x, y, z, false, false, false, false)
    Wait(teleportCooldown)
    isTeleportingByScript = false
    lastPosition = vector3(x, y, z)
end

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end

    while true do
        Citizen.Wait(1000)
        if not VexShieldIsProtectionOn('Anti Teleport') then
            break
        end
        checkForTeleportation()
    end
end)


-- [VEX-INTERNAL-CORE: 0x9F4C2A-C4920194820]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

---------------------------------------------------------------------------------
-- ANTI PLATE CHANGER
---------------------------------------------------------------------------------
function IsPlayerInWhitelistedAreePlateChanging()
    local playerCoords = GetEntityCoords(PlayerPedId())
    if not (Shared.Client and Shared.Client['Plate Changing']) then
        return false
    end
    for _, area in ipairs(Shared.Client['Plate Changing']['Whitelisted Areas']) do
        if #(playerCoords - area.coords) <= area.radius then 
            return true
        end
    end
    return false
end

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    local VEH = nil
    local PLATE = nil

    while true do
        Citizen.Wait(1000)
        if not VexShieldIsProtectionOn('Anti Plate Changer') then
            break
        end

        if IsPedInAnyVehicle(PlayerPedId(), false) then
            local vehicle = GetVehiclePedIsIn(PlayerPedId())
            local plate = GetVehicleNumberPlateText(vehicle)

            -- Only flag when the SAME vehicle's plate actually changed.
            -- Comparing across different vehicles (e.g. switching cars) or against an
            -- empty plate string (temporary during streaming/respawn) caused false bans.
            if VEH and PLATE and vehicle == VEH and plate ~= '' and PLATE ~= '' and plate ~= PLATE then
                if not IsPlayerInWhitelistedAreePlateChanging() then
                    -- Verification window to prevent transient false flags
                    Wait(2000)

                    -- Confirm persistence of state
                    local ped = PlayerPedId()
                    if IsPedInAnyVehicle(ped, false)
                        and GetVehiclePedIsIn(ped, false) == VEH
                        and DoesEntityExist(VEH) then
                        local newPlate = GetVehicleNumberPlateText(VEH)
                        if newPlate ~= '' and newPlate ~= PLATE then
                            DeleteVehicle(VEH)
                            Wait(500) -- Async entity cleanup window
                            
                            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to change vehicle plate')
                        end
                    end
                end
            end

            VEH = vehicle
            PLATE = plate
        else
            VEH = nil
            PLATE = nil
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI MODEL CHANGER (Multicharacter & Clothing Shop Safe)
---------------------------------------------------------------------------------
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not isPlayerReady do Wait(250) end

    while true do
        Citizen.Wait(1500)
        if not VexShieldIsProtectionOn('Anti Model Changer') then
            goto continue
        end

        -- Skip check if player is in Multicharacter, not logged in, or in character creation/preview
        if LocalPlayer and LocalPlayer.state then
            if LocalPlayer.state.isLoggedIn == false or LocalPlayer.state.chooseChar == true or LocalPlayer.state.inCharSelect == true then
                goto continue
            end
        end

        if not NetworkIsPlayerActive(PlayerId()) or IsScreenFadedOut() then
            goto continue
        end

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto continue end

        local myModel = GetEntityModel(ped)

        -- Check if ped model is a blacklisted cheat ped
        local isBlacklisted = false
        if Shared and Shared.BlacklistedPeds then
            for i = 1, #Shared.BlacklistedPeds do
                local v = Shared.BlacklistedPeds[i]
                local h = type(v) == 'number' and v or GetHashKey(v)
                if myModel == h then
                    isBlacklisted = true
                    break
                end
            end
        end

        if isBlacklisted then
            print('VexShield:banHandler', 'Blacklisted Ped Model Detected: ' .. myModel)
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to use blacklisted ped model')
        end

        ::continue::
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        SafeTriggerServerEvent('VexShield:flagPlayer', 'Tried to stop the anticheat script')
    end
end)

---------------------------------------------------------------------------------
-- ANTI INVISIBLE2
---------------------------------------------------------------------------------
local playerInvisible = false
local lastWarningTime = 0

local function IsPlayerUnderground()
    local ped = PlayerPedId()
    if not ped or ped == 0 then return false end
    local pCoords = GetEntityCoords(ped)
    local ground, posZ = GetGroundZFor_3dCoord(pCoords.x, pCoords.y, pCoords.z + 1.0, false)
    if not ground then
        ground, posZ = GetGroundZFor_3dCoord(pCoords.x, pCoords.y, pCoords.z + 999.0, false)
    end
    if ground then
        local distFromGround = pCoords.z - posZ
        return distFromGround < 0, math.abs(distFromGround)
    end
    return false
end

local function HasPlayerSpawned()
    local ped = PlayerPedId()
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    local model = GetEntityModel(ped)
    local coords = GetEntityCoords(ped)

    if model == 0 then return false end
    if model == GetHashKey("player_zero") then return false end
    if model == GetHashKey("player_one") then return false end
    if model == GetHashKey("player_two") then return false end
    if #(vector3(0.0, 0.0, 0.0) - coords) < 10.0 then return false end
    if IsScreenFadingOut() or IsScreenFadingIn() then return false end
    if #(GetGameplayCamCoord() - coords) > 10.0 then return false end
    if not NetworkIsSessionActive() or not NetworkIsSessionStarted() then return false end
    if IsNuiFocused() then return false end
    if not HasCollisionLoadedAroundEntity(ped) then return false end
    if IsPlayerSwitchInProgress() then return false end
    if not IsEntityOnScreen(ped) then return false end
    if IsPlayerUnderground() then return false end
    if not IsEntityVisibleToScript(ped) then return false end
    if not IsEntityVisible(ped) then return false end
    return true
end

local isCharacterLoaded = false
isPlayerReady = false

local function OnCharacterFullyReady()
    if isCharacterLoaded then return end
    isCharacterLoaded = true

    Citizen.CreateThread(function()
        -- Wait 8 seconds post-character load to allow apartment/interior/clothes/props to fully sync and settle
        Wait(8000)

        VexShieldClientState.playerLoaded = true
        isPlayerReady = true
        SafeTriggerServerEvent('VexShield:characterFullyLoaded')
        SafeTriggerServerEvent('VexShield:playerReady')
        SafeTriggerServerEvent('VexShield:isExempt')
    end)
end

-- Framework Ready Detection: QBCore / ESX / QBX / Ox
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    OnCharacterFullyReady()
end)

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    OnCharacterFullyReady()
end)

RegisterNetEvent('qbx_core:client:playerLoaded', function()
    OnCharacterFullyReady()
end)

RegisterNetEvent('ox:playerLoaded', function()
    OnCharacterFullyReady()
end)

AddEventHandler("playerSpawned", function()
    VexShieldClientState.playerLoaded = true
    SafeTriggerServerEvent('VexShield:isExempt')
    -- If no framework is installed (pure standalone), start timer after playerSpawned
    local hasFramework = GetResourceState('qb-core') == 'started'
        or GetResourceState('qbx_core') == 'started'
        or GetResourceState('es_extended') == 'started'
        or GetResourceState('ox_core') == 'started'
    if not hasFramework then
        OnCharacterFullyReady()
    end
end)

-- Character Load Verification Loop
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end

    while not isCharacterLoaded do
        Wait(1000)

        -- Check QBCore statebag (in case resource restarted mid-session or event missed)
        if LocalPlayer and LocalPlayer.state and LocalPlayer.state.isLoggedIn then
            OnCharacterFullyReady()
            break
        end

        -- Check ESX loaded state
        if type(ESX) == 'table' and type(ESX.IsPlayerLoaded) == 'function' and ESX.IsPlayerLoaded() then
            OnCharacterFullyReady()
            break
        end

        -- Standalone fallback: wait until player is spawned, valid coordinates, not in black screen
        local hasFramework = GetResourceState('qb-core') == 'started'
            or GetResourceState('qbx_core') == 'started'
            or GetResourceState('es_extended') == 'started'
            or GetResourceState('ox_core') == 'started'

        if not hasFramework and HasPlayerSpawned() then
            local ped = PlayerPedId()
            if DoesEntityExist(ped) and not IsScreenFadedOut() and not IsScreenFadingOut() then
                local coords = GetEntityCoords(ped)
                if coords.z > 0.5 or coords.z < -0.5 then
                    Wait(15000)
                    OnCharacterFullyReady()
                    break
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

   while not VexShieldClientState.playerLoaded or VexShieldClientState.isExempt == nil do
        Citizen.Wait(500)
   end

    while true do
        Citizen.Wait(1000)
        if not VexShieldIsProtectionOn('Anti invisible2') then
            break
        end

        local playerPed = PlayerPedId()
        if not DoesEntityExist(playerPed) or IsEntityDead(playerPed) then
            Citizen.Wait(1100)
        else
            local entityAlpha = GetEntityAlpha(playerPed)
            local isVisible = IsEntityVisible(playerPed)
            local hasCollision = not IsEntityOccluded(playerPed)

            if not VexShieldIsPlayerInNoclipOrExempt() and ((not isVisible) or entityAlpha <= 150 or not hasCollision) then
                SetEntityVisible(playerPed, true, false)
                SetEntityAlpha(playerPed, 255, false)
                Citizen.Wait(1100)

                if GetEntityAlpha(playerPed) < 255 or not IsEntityVisible(playerPed) then
                    local currentTime = GetGameTimer()
                    if playerInvisible then
                        if currentTime - lastWarningTime > 1200 then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to become invisible')
                            -- SafeTriggerServerEvent('VexShield:Log', "^1[Anti Invisible] Player was invisible again")
                            lastWarningTime = currentTime
                        end
                    else
                        playerInvisible = true
                        -- SafeTriggerServerEvent('VexShield:Log', "^1[Anti Invisible] Player was invisible and is now visible.")
                        lastWarningTime = currentTime
                    end
                end
            else
                if playerInvisible and isVisible and entityAlpha == 255 and hasCollision then
                    playerInvisible = false
                end
            end
        end
    end
end)

RegisterNetEvent('VexShield:returnExemptStatus', function(status)
    VexShieldClientState.isExempt = status
end)

-- print("CLIENT CHECK 5")

---------------------------------------------------------------------------------
-- ANTI SPAWN VEHICLE2
---------------------------------------------------------------------------------
-- ADVANCED ANTI VEHICLE SPAWN v5
-- Zero False Ban + Full Stealth Detection + Deep Ownership Validation

local entityEnumerator = {
    __gc = function(enum)
        if enum.destructor and enum.handle then
            enum.destructor(enum.handle)
        end
        enum.destructor = nil
        enum.handle = nil
    end
}

function EnumerateEntities(initFunc, moveFunc, disposeFunc)
    return coroutine.wrap(function()
        local iter, id = initFunc()
        if not id or id == 0 then
            disposeFunc(iter)
            return
        end

        local enum = { handle = iter, destructor = disposeFunc }
        setmetatable(enum, entityEnumerator)

        repeat
            coroutine.yield(id)
        until not select(1, moveFunc(iter))

        enum.destructor, enum.handle = nil, nil
        disposeFunc(iter)
    end)
end

function EnumerateVehicles()
    return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
end

function EnumerateObjects()
    return EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject)
end

function EnumeratePeds()
    return EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed)
end

-------------------------------------------
-- CONFIG
-------------------------------------------

local allowedScripts = {
    ["qb-core"] = true,
    ["ox_inventory"] = true,
    ["boblife_vehicles"] = true,
    ["esx_vehicleshop"] = true,
    ["kq_outfitbag"] = true,
}

function isValidModel(model)
    return IsModelAVehicle(model) and IsModelInCdimage(model)
end

function isNaturalSpawn(pop)
    return pop == 4 or pop == 5 or pop == 6 or pop == 7
end

---------------------------------------------------------------------------------
-- ANTI SPAWN VEHICLE
---------------------------------------------------------------------------------
-- ============================================================
-- ANTI VEHICLE SPAWN V7 - ULTRA ADVANCED VexShield VERSION
-- Zero False Ban / Detect Stealth / Detect Injection / Pre-Spawn
-- ============================================================

local naturalPop = {
    [4] = true, -- Cops
    [5] = true, -- Gangs
    [6] = true, -- Civ cars
    [7] = true  -- Parked vehicles
}

local allowedScripts = {
    ["qb-core"] = true,
    ["es_extended"] = true,
    ["ox_inventory"] = true,
    ["vehicleshop"] = true,
    ["kq_outfitbag"] = true,
}

local entitySignature = {}

-- Generate a unique safe signature for every legitimate vehicle
function markEntity(ent)
    local sig = GetGameTimer() .. math.random(1111,9999)
    entitySignature[ent] = sig
end

-- Check if vehicle is signed properly
function isSigned(ent)
    return entitySignature[ent] ~= nil
end

-- Validate if model exists and is a real GTA V model
function isModelValid(model)
    return IsModelInCdimage(model) and IsModelAVehicle(model)
end

-- ============================================================
-- PRE-SPAWN CHECK (Before the vehicle actually exists)
-- ============================================================
-- Removed Anti Spawn Vehicle V7 as per user request

-- ============================================================
-- ANTI ENTITY SPAWN (Objects & Peds)
-- ============================================================

AddEventHandler("entityCreating", function(entity)
    if not VexShieldIsProtectionOn('Anti Spawn Entity') then 
        return 
    end

    if not DoesEntityExist(entity) then return end
    local eType = GetEntityType(entity)
    -- 1 = Ped, 3 = Object
    if eType ~= 1 and eType ~= 3 then return end
    if eType == 1 then
        -- Prevent false positives: ped pre-create filtering can strip traffic drivers.
        return
    end

    local popType = GetEntityPopulationType(entity)
    local invoking = GetInvokingResource()
    local isNet = NetworkGetEntityIsNetworked(entity)

    local owner = -1
    if isNet then
        owner = NetworkGetEntityOwner(entity)
    end

    -----------------------------------------
    -- 0. CHECK RESOURCE WHITELIST
    -----------------------------------------
    if invoking and isResourceWhitelisted(invoking) then
        return 
    end
    
    if invoking and isResourceFullWhitelisted(invoking) then
        return
    end

    -----------------------------------------
    -- 1. SCRIPT VALIDATION
    -----------------------------------------
    if invoking and not allowedScripts[invoking] then
        if not naturalPop[popType] then
            SafeTriggerServerEvent("VexShield:banHandler", "Attempted unauthorized entity spawn (Type " .. eType .. ") | " .. tostring(invoking))
            CancelEvent()
            return
        end
    end

    -----------------------------------------
    -- 2. STEALTH SPAWN DETECTION
    -----------------------------------------
    if isNet and (owner == -1 or owner == nil) then
        if popType == 0 then
             SafeTriggerServerEvent("VexShield:banHandler", "Attempted stealth entity spawn (Type " .. eType .. ")")
             CancelEvent()
             return
        end
    end

    -----------------------------------------
    -- 3. POPULATION VALIDATION
    -----------------------------------------
    if not naturalPop[popType] and not invoking then
        SafeTriggerServerEvent("VexShield:banHandler", "Attempted manual entity injection (Type " .. eType .. ")")
        CancelEvent()
        return
    end
end)

-- ============================================================
-- POST-SPAWN CHECK (After vehicle exists)
-- Extra protection against menu cloning & invisible spawn
-- ============================================================
-- Removed Anti Spawn Vehicle V7 Post-Spawn Check as per user request
-- FIXED: removed orphaned V7 post-spawn fragment that referenced undefined `owner` at file scope.

    -- print("CLIENT CHECK 6")

-- print("here clientjajaj7")

-- print("here clientjajaj8")

-- local camdisthres = 7.26
-- local raydisthres = 10.0
-- local collcheckintv = 3000
-- local maxdetect = 3

-- local dectcount = 0
-- local lastcolcheck = 0
-- local spawnTime = 0
-- local waitAfterSpawn = 70000 -- 30 seconden wachttijd na spawn

-- AddEventHandler('playerSpawned', function()
--     spawnTime = GetGameTimer()
-- end)

-- local function CheckCameraDistance(pedCoords)
--     local camCoordsFinal = GetFinalRenderedCamCoord()
--     local distFinal = #(camCoordsFinal - pedCoords)
--     local camCoordsGame = GetGameplayCamCoord()
--     local distGameplay = #(camCoordsGame - pedCoords)
--     return math.max(distFinal, distGameplay)
-- end

-- local function CheckRaycast(pedCoords, camCoords)
--     local rayHandle = StartShapeTestRay(
--         camCoords.x, camCoords.y, camCoords.z,
--         pedCoords.x, pedCoords.y, pedCoords.z,
--         -1,
--         PlayerPedId(),
--         0
--     )
--     local _, didHit = GetShapeTestResult(rayHandle)
--     local dist = #(camCoords - pedCoords)
--     if dist > raydisthres and not didHit then
--         return true
--     end
--     return false
-- end

-- Citizen.CreateThread(function()
--     while not configLoaded do Wait(250) end
--     while not configLoaded or not isPlayerReady do Wait(250) end

--     while true do
--         Citizen.Wait(1000)
--         if not Shared.Protections or not Shared.Protections['Anti Freecam'] then
--             break
--         end

--         if (GetGameTimer() - spawnTime) < waitAfterSpawn then
--             goto continue
--         end

--         local playerPed = PlayerPedId()
--         if DoesEntityExist(playerPed) then
--             local pedCoords = GetEntityCoords(playerPed, false)
--             local maxDistance = CheckCameraDistance(pedCoords)
--             if maxDistance > camdisthres then
--                 dectcount = dectcount + 1
--             else
--                 if dectcount > 0 then
--                     dectcount = dectcount - 1
--                 end
--             end

--             local pedInterior = GetInteriorFromEntity(playerPed)
--             local camCoordsFinal = GetFinalRenderedCamCoord()
--             local camInterior = GetInteriorAtCoords(camCoordsFinal.x, camCoordsFinal.y, camCoordsFinal.z)

--             if pedInterior ~= camInterior then
--                 dectcount = dectcount + 1
--             end

--             local suspiciousRay = CheckRaycast(pedCoords, camCoordsFinal)
--             if suspiciousRay then
--                 dectcount = dectcount + 1
--             end

--             if (GetGameTimer() - lastcolcheck) > collcheckintv then
--                 lastcolcheck = GetGameTimer()
--                 if not IsEntityVisible(playerPed) then
--                     dectcount = dectcount + 2
--                 end
--             end

--             if dectcount >= maxdetect then
--                 if GetVehiclePedIsIn(playerPed, false) == 0 then
--                     SafeTriggerServerEvent('VexShield:banHandler', 'FreeCam Detected')
--                 end
--                 dectcount = 0
--             end
--         end
--         ::continue::
--     end
-- end)

-- print("here clientjajaj9")
---------------------------------------------------------------------------------
-- ANTI ENTITY MANIPULATION
---------------------------------------------------------------------------------

-- Track entity manipulation attempts
local holdingEntity = false
local holdingCarEntity = false
local holdingPed = false
local heldEntity = nil

---------------------------------------------------------------------------------
-- ANTI NIGHT / THERMAL VISION
---------------------------------------------------------------------------------
CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Wait(1000)
        if not VexShieldIsProtectionOn('Anti Night/ThermalVision') then
            break
        end

        if IsNightvisionActive() and not IsPedInAnyHeli(PlayerPedId()) then
            SetNightvision(false)
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to enable night vision')
        end

        if IsSeethroughActive() and not IsPedInAnyHeli(PlayerPedId()) then
            SetSeethrough(false)
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to enable thermal vision')
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI SPECTATE
---------------------------------------------------------------------------------
Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(math.random(500, 1500))
        if not VexShieldIsProtectionOn('Anti Spectate') then
            break
        end

        if NetworkIsInSpectatorMode() then
            SafeTriggerServerEvent('VexShield:checkSpectateStatus', true)
        end

        local playerPed = PlayerPedId()
        local health = GetEntityHealth(playerPed)
        if health < 0 then
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to spectate players')
        end
    end
end)


local __lastOnFootPos = nil
local __lastOnFootTime = 0
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    while true do
        Wait(250)
        if not VexShieldIsProtectionOn('Anti Teleport2') then
            break
        end
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto continue end
        local inVeh = IsPedInAnyVehicle(ped, false)
        if not inVeh then
            __lastOnFootPos = GetEntityCoords(ped)
            __lastOnFootTime = GetGameTimer()
        else
            if __lastOnFootPos then
                local veh = GetVehiclePedIsIn(ped, false)
                if veh ~= 0 and DoesEntityExist(veh) then
                    local vpos = GetEntityCoords(veh)
                    local dist = #(vpos - __lastOnFootPos)
                    local limit = (Shared.Client and (Shared.Client['Max Distance Teleporting'] or Shared.Client['Max Distance Telelporting'])) or 200.0
                    if dist > (limit * 0.5) and (GetGameTimer() - __lastOnFootTime) <= 2000 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to warp to vehicle')
                    end
                end
                __lastOnFootPos = nil
                __lastOnFootTime = 0
            end
        end
        ::continue::
    end
end)

local __lastDamageAt = 0
AddEventHandler('gameEventTriggered', function(event, data)
    if event ~= 'CEventNetworkEntityDamage' then return end
    local victim = data[1]
    if victim == PlayerPedId() then
        __lastDamageAt = GetGameTimer()
    end
end)
AddEventHandler('gameEventTriggered', function(event, data)
    if event ~= 'CEventNetworkEntityDamage' then return end
    
end)



Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    local checknames = {"cipher","Cipher","CipherMenu","CIPHERMENU","CipherUI"}
    while true do
        Citizen.Wait(1500)
        if not VexShieldIsProtectionOn('Anti Cipher') then break end
        for i=1,#checknames do
            local n = checknames[i]
            if HasStreamedTextureDictLoaded(n) then
                SafeTriggerServerEvent('VexShield:banHandler', 'Detected unauthorized software: Cipher Menu')
                break
            end
        end
    end
end)
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    local lastRotZ = 0.0
    local spike = 0
    local windowStart = 0
    while true do
        if not VexShieldIsProtectionOn('Anti Aimlock') then
            Wait(VexShieldClientState.pollIdleMs)
        else
        Wait(150)
        local ped = PlayerPedId()
        if IsPlayerFreeAiming(PlayerId()) and IsPedArmed(ped, 6) then
            local rot = GetGameplayCamRot(2)
            local dz = math.abs((rot.z or 0.0) - (lastRotZ or 0.0))
            if dz > 8.0 then
                local now = GetGameTimer()
                if now - windowStart <= 800 then
                    spike = spike + 1
                else
                    windowStart = now
                    spike = 1
                end
            end
            if IsPedShooting(ped) and spike >= 3 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to lock aim')
                spike = 0
                windowStart = 0
            end
            lastRotZ = rot.z or 0.0
        else
            spike = 0
            windowStart = 0
        end
        end
    end
end)




    -- print("CLIENT CHECK 7")

    -- print("here clientjajaj10")
---------------------------------------------------------------------------------
-- ANTI SPEEDHACK
---------------------------------------------------------------------------------
local fallStartTime = nil
local lastCoords = nil
local distanceThreshold = 5
local vehicleExitTime = nil
local wasInVehicle = false
local WHITELIST_DURATION = 7000 -- 7 seconden whitelist

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(500)

        if not VexShieldIsProtectionOn('Anti Speedhack') then
            break
        end

        if VexShieldIsPlayerInNoclipOrExempt() then
            Citizen.Wait(1000)
            goto continue
        end

        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local heightAboveGround = GetEntityHeightAboveGround(playerPed)
        local isOnFoot = IsPedOnFoot(playerPed)
        local isFalling = IsPedFalling(playerPed)
        local onGround = isOnFoot and not isFalling and heightAboveGround < 1.5
        local inVehicle = IsPedInAnyVehicle(playerPed, false)

        -- Detectie: speler was net in voertuig maar nu niet meer â†’ start whitelist timer
        if not inVehicle and wasInVehicle and not vehicleExitTime then
            vehicleExitTime = GetGameTimer()
        elseif inVehicle then
            vehicleExitTime = nil
        end
        wasInVehicle = inVehicle

        -- Valdetectie
        if isFalling and not fallStartTime then
            fallStartTime = GetGameTimer()
        end

        if onGround and fallStartTime then
            local fallTime = GetGameTimer() - fallStartTime
            fallStartTime = nil
            if fallTime > 2000 then
                inVehicle = false
            end
        end

        -- Afstand controleren
        if lastCoords then
            local distance = #(coords - lastCoords)
            if distance < distanceThreshold then
                lastCoords = coords
                goto continue
            end
        end
        lastCoords = coords

        local now = GetGameTimer()
        if vehicleExitTime and (now - vehicleExitTime) <= WHITELIST_DURATION then
            SafeTriggerServerEvent('VexShield:checkSpeed', { x = coords.x, y = coords.y, z = coords.z }, inVehicle, onGround, true)
            goto continue
        end

        -- Check if player is in whitelisted area for speed hack
        if IsPlayerInWhitelistedAreaSpeedhack() then
            SafeTriggerServerEvent('VexShield:checkSpeed', { x = coords.x, y = coords.y, z = coords.z }, inVehicle, onGround, true)
            goto continue
        end

        -- Normale snelheid check
        SafeTriggerServerEvent('VexShield:checkSpeed', { x = coords.x, y = coords.y, z = coords.z }, inVehicle, onGround)

        ::continue::
    end
end)

---------------------------------------------------------------------------------
-- HELPER FOR WHITELISTED AREAS
---------------------------------------------------------------------------------
function IsPlayerInWhitelistedAreaInvisible()
    local playerCoords = GetEntityCoords(PlayerPedId())
    if not (Shared.Client and Shared.Client['Anti invisible']) then
        return false
    end
    for _, area in ipairs(Shared.Client['Anti invisible']['Whitelisted Areas']) do
        if #(playerCoords - area.coords) <= area.radius then 
            return true
        end
    end
    return false
end

function IsPlayerInWhitelistedAreaSpeedhack()
    local playerCoords = GetEntityCoords(PlayerPedId())
    if not (Shared.Client and Shared.Client['Anti Speedhack']) then
        return false
    end
    if not Shared.Client['Anti Speedhack']['Whitelisted Areas'] then
        return false
    end
    for _, area in ipairs(Shared.Client['Anti Speedhack']['Whitelisted Areas']) do
        if #(playerCoords - area.coords) <= area.radius then 
            return true
        end
    end
    return false
end

---------------------------------------------------------------------------------
-- EXPORTED FUNCTION
---------------------------------------------------------------------------------
exports('tpsafely', function(entity, coords)
    setEntityCoordsSafely(entity, coords.x, coords.y, coords.z)
end)

-- Anti Executor Exports
VexShieldClientState.expiresAntiExec = VexShieldClientState.expiresAntiExec or 0
VexShieldClientState.expiresAntiExec2 = VexShieldClientState.expiresAntiExec2 or 0
VexShieldClientState.expiresAntiExec3 = VexShieldClientState.expiresAntiExec3 or 0

exports('disableE2', function()
    local timer = GetGameTimer()
    if timer > VexShieldClientState.expiresAntiExec - 2000 then
        VexShieldClientState.expiresAntiExec = timer + 5000
        if not VexShieldClientState.isUsingMouseInScripts then
            VexShieldClientState.isUsingMouseInScripts = true
            CreateThread(function()
                while GetGameTimer() < VexShieldClientState.expiresAntiExec do Wait(100) end
                VexShieldClientState.isUsingMouseInScripts = false
            end)
        end
    end
end)

exports('disableCamControls', function()
    local timer = GetGameTimer()
    if timer > VexShieldClientState.expiresAntiExec2 - 2000 then
        VexShieldClientState.expiresAntiExec2 = timer + 5000
        if not VexShieldClientState.areCamControlsDisabled then
            VexShieldClientState.areCamControlsDisabled = true
            CreateThread(function()
                while GetGameTimer() < VexShieldClientState.expiresAntiExec2 do Wait(100) end
                VexShieldClientState.areCamControlsDisabled = false
            end)
        end
    end
end)

exports('disableAllControls', function()
    local timer = GetGameTimer()
    if timer > VexShieldClientState.expiresAntiExec3 - 2000 then
        VexShieldClientState.expiresAntiExec3 = timer + 5000
        if not VexShieldClientState.areControlsDisabled then
            VexShieldClientState.areControlsDisabled = true
            CreateThread(function()
                while GetGameTimer() < VexShieldClientState.expiresAntiExec3 do Wait(100) end
                VexShieldClientState.areControlsDisabled = false
            end)
        end
    end
end)

-- print("here client12")
---------------------------------------------------------------------------------
-- Spawn-weapon bypass: trusted resource names from whitelist.json "resources" (server → Config.WhitelistedJobs)
---------------------------------------------------------------------------------
local VexShieldWeaponSpawnBypassUntil = 0

RegisterNetEvent('VexShield:weaponSpawnBypass', function(ms)
    ms = tonumber(ms) or 8000
    if ms < 500 then ms = 500 end
    if ms > 120000 then ms = 120000 end
    VexShieldWeaponSpawnBypassUntil = GetGameTimer() + ms
end)

function isVexShieldWeaponSpawnBypassActive()
    return GetGameTimer() < VexShieldWeaponSpawnBypassUntil
end

RegisterNetEvent('VexShield:ForceDeleteEntityByNetId', function(netId, coords, model)
    CreateThread(function()
        local ent = nil
        if netId and netId > 0 and NetworkDoesNetworkIdExist(netId) then
            ent = NetToObj(netId)
            if not ent or ent == 0 or not DoesEntityExist(ent) then
                ent = NetToEnt(netId)
            end
        end

        if (not ent or ent == 0 or not DoesEntityExist(ent)) and coords and model then
            ent = GetClosestObjectOfType(coords.x, coords.y, coords.z, 5.0, model, false, false, false)
        end

        if ent and ent ~= 0 and DoesEntityExist(ent) then
            SetEntityAsMissionEntity(ent, true, true)
            NetworkRequestControlOfEntity(ent)
            local timeout = 0
            while timeout < 10 and not NetworkHasControlOfEntity(ent) do
                Wait(10)
                NetworkRequestControlOfEntity(ent)
                timeout = timeout + 1
            end
            DeleteEntity(ent)
            if DoesEntityExist(ent) then
                SetEntityCoords(ent, 0.0, 0.0, -1000.0, false, false, false, false)
                DeleteObject(ent)
            end
        end
    end)
end)

---------------------------------------------------------------------------------
-- ANTI SPOOF/ SPAWN WEAPON2
---------------------------------------------------------------------------------
local asw2_warningCount = 0

CreateThread(function()
    while true do
        Wait(9500)
        asw2_warningCount = 0
    end
end)

function antispawnweapon2()
    if not VexShieldIsProtectionOn('Anti Spawn Weapon2') then
        return
    end

    if GetResourceState('ox_inventory') ~= 'started' then
        return
    end

    local playerPed = PlayerPedId()
    local nativeWeapon = GetSelectedPedWeapon(playerPed)

    if nativeWeapon ~= -1569615261 then
        local weapon = exports.ox_inventory:getCurrentWeapon()

        if weapon and weapon.name then
            local weaponHash = GetHashKey(weapon.name)

            if weaponHash ~= nativeWeapon then
                asw2_warningCount = asw2_warningCount + 1

                if asw2_warningCount > 4 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to spawn weapon (V2)')
                    asw2_warningCount = 0
                end
            end
        else
            asw2_warningCount = asw2_warningCount + 1

            if asw2_warningCount > 4 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to spawn weapon (V2)')
                asw2_warningCount = 0
            end
        end
    end
end

CreateThread(function()
    while not configLoaded do Wait(250) end
    while true do
        Wait(1500)
        antispawnweapon2()
    end
end)

CreateThread(function()
    while true do
        Wait(25000)
        asw2_warningCount = 0
    end
end)

-- print("CLIENT CHECK 8")
---------------------------------------------------------------------------------
-- ANTI SPOOF / SPAWN WEAPON3 (Native Memory Spoof & Whitelist Architecture)
---------------------------------------------------------------------------------

local warningCount = 0
local asw3MismatchStreak = 0

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end

    while true do
        Wait(1500)

        if not VexShieldIsProtectionOn('Anti Spawn Weapon3') then
            Wait(2500)
        else
            if isVexShieldWeaponSpawnBypassActive() then
                goto asw3_end
            end

            local playerPed = PlayerPedId()
            if not playerPed or playerPed == 0 or IsEntityDead(playerPed) then
                goto asw3_end
            end

            local isInVehicle = IsPedInAnyVehicle(playerPed, false)
            local isArmed = IsPedArmed(playerPed, 4) or IsPedArmed(playerPed, 1) or IsPedArmed(playerPed, 2)
            local isHoldingWeapon, currentWeapon = GetCurrentPedWeapon(playerPed, true)
            local selectedWeapon = GetSelectedPedWeapon(playerPed)

            -- Native Memory Spoof Checks (Spoof #1 to #8)
            if isHoldingWeapon and currentWeapon == -1569615261 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted weapon spoofing (variant #1)')
                goto asw3_end
            end

            if isHoldingWeapon and not HasPedGotWeapon(playerPed, currentWeapon, false)
                and not isInVehicle and not isVexShieldWeaponSpawnBypassActive()
                and isArmed then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted weapon spoofing (variant #2)')
                goto asw3_end
            end

            if not isHoldingWeapon and currentWeapon == -1569615261 and isArmed and not isInVehicle then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted weapon spoofing (variant #3)')
                goto asw3_end
            end

            if not isHoldingWeapon and currentWeapon == -1569615261 then
                local weaponObject = GetWeaponObjectFromPed(playerPed, false)
                if weaponObject and weaponObject > 0 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted weapon spoofing (variant #5)')
                    goto asw3_end
                end
            end

            if isHoldingWeapon and selectedWeapon == -1569615261 and currentWeapon ~= 0
                and currentWeapon ~= selectedWeapon and not HasPedGotWeapon(playerPed, currentWeapon, false) then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted weapon spoofing (variant #8)')
                goto asw3_end
            end

            -- Unarmed / fists: reset state
            if selectedWeapon == nil or selectedWeapon == -1569615261 then
                warningCount = 0
                asw3MismatchStreak = 0
                goto asw3_end
            end

            -- Whitelist & Inventory verification
            if isWeaponInVexShieldAllowedList(selectedWeapon) or hasWeaponInInventoryByHash(selectedWeapon) then
                warningCount = 0
                asw3MismatchStreak = 0
                goto asw3_end
            end

            -- Grace Period check for network lag / drawing weapon
            Wait(700)
            if isVexShieldWeaponSpawnBypassActive() then
                goto asw3_end
            end

            local nativeWeapon2 = GetSelectedPedWeapon(PlayerPedId())
            if nativeWeapon2 == nil or nativeWeapon2 == -1569615261
                or nativeWeapon2 ~= selectedWeapon
                or isWeaponInVexShieldAllowedList(nativeWeapon2)
                or hasWeaponInInventoryByHash(nativeWeapon2) then
                warningCount = 0
                asw3MismatchStreak = 0
                goto asw3_end
            end

            -- Confirmed un-whitelisted weapon hold
            RemoveWeaponFromPed(playerPed, selectedWeapon)

            local warningLimit = isInVehicle and 12 or 8
            asw3MismatchStreak = asw3MismatchStreak + 1
            if asw3MismatchStreak >= 2 then
                asw3MismatchStreak = 0
                warningCount = warningCount + 1
                if warningCount > warningLimit then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to spawn weapon (V3)')
                    warningCount = 0
                end
            end
            ::asw3_end::
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(30000)
        warningCount = 0
        asw3MismatchStreak = 0
    end
end)


-- print("here clientjajaj12")


-- [VEX-INTERNAL-CORE: 0x9F4C2A-C5820194821]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

---------------------------------------------------------------------------------
-- ANTI NOCLIP
---------------------------------------------------------------------------------
function isInFreecamNoclipWhitelist()
    local pedCoords = GetEntityCoords(PlayerPedId())
    local whitelist = Shared.Client['Noclip/Freecam Whitelist'] and Shared.Client['Noclip/Freecam Whitelist']['Whitelisted Areas'] or {}
    
    for _, area in pairs(whitelist) do
        if #(pedCoords - area.coords) <= area.radius then
            return true
        end
    end

    return false
end

-- Sea / rivers: height-above-ground and Z checks false-flag as noclip; skip detections in or near water.
function VexShieldShouldSkipNoclipWater(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if IsEntityInWater(ped) then return true end
    if IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped) then return true end
    local c = GetEntityCoords(ped)
    local pcallOk, found, waterZ = pcall(GetWaterHeightNoWaves, c.x, c.y, c.z + 1.0)
    if pcallOk and found and type(waterZ) == 'number' and (c.z - waterZ) < 18.0 and (c.z - waterZ) > -10.0 then
        return true
    end
    return false
end

local wasDead = false
local noclipProtectionActive = false

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
end)
---------------------------------------------------------------------------------
-- ANTI NOCLIP (ENHANCED ENGINE)
---------------------------------------------------------------------------------
local VexShieldStrikes = {}
local VexShieldFirstStrikeTimes = {}

local function CreateVexShieldStrikeSystem(detectionName, strikesNeeded, onFlag, timeWindowMs)
    timeWindowMs = timeWindowMs or 10000
    VexShieldStrikes[detectionName] = VexShieldStrikes[detectionName] or 0
    VexShieldFirstStrikeTimes[detectionName] = VexShieldFirstStrikeTimes[detectionName] or 0

    return function(extraParam)
        local now = GetGameTimer()
        if VexShieldFirstStrikeTimes[detectionName] == 0 or (now - VexShieldFirstStrikeTimes[detectionName]) > timeWindowMs then
            VexShieldStrikes[detectionName] = 1
            VexShieldFirstStrikeTimes[detectionName] = now
        else
            VexShieldStrikes[detectionName] = VexShieldStrikes[detectionName] + 1
        end

        if VexShieldStrikes[detectionName] >= strikesNeeded then
            VexShieldStrikes[detectionName] = 0
            VexShieldFirstStrikeTimes[detectionName] = 0
            if type(onFlag) == "function" then
                onFlag(extraParam)
            end
        end
    end
end

local NC_oldCoords, NC_oldSpeed, NC_oldStateValid = vector3(0, 0, 0), 0.0, false

local noclipHeightBypassStrike = CreateVexShieldStrikeSystem(
    "AntiNoClipHeightBypass",
    3,
    function(diffHeight)
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
    end,
    10000
)

local noclipVehicleBypassStrike = CreateVexShieldStrikeSystem(
    "AntiNoClipVehicleBypass",
    2,
    function()
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
    end,
    10000
)

local noclipFallBypassStrike = CreateVexShieldStrikeSystem(
    "AntiNoClipFallBypass",
    3,
    function()
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
    end,
    10000
)

local function isVexShieldValidNoclipState(ped)
    local coords = GetEntityCoords(ped)
    local speed = GetEntitySpeed(ped)
    local inVeh = IsPedInAnyVehicle(ped, false)
    local veh = inVeh and GetVehiclePedIsIn(ped, false) or 0
    local isDriver = inVeh and (GetPedInVehicleSeat(veh, -1) == ped)
    local isDead = IsPedDeadOrDying(ped, true)
    local height = GetEntityHeightAboveGround(ped)

    local vehValid = (not inVeh) or (isDriver and inVeh and not isDead and GetEntitySpeed(veh) < 3.0 and IsVehicleStopped(veh) and (not IsVehicleOnAllWheels(veh) or IsEntityPositionFrozen(veh) or GetEntityCollisionDisabled(veh)))

    return vehValid and
        not IsPedOnVehicle(ped) and
        (not IsPedFalling(ped) or (IsPedFalling(ped) and speed == 0.0)) and
        not (IsEntityAttached(ped) and not inVeh) and
        not IsPedAPlayer(GetEntityAttachedTo(ped)) and
        not IsCutsceneActive() and
        GetPedType(ped) ~= 28 and
        (IsEntityPositionFrozen(ped) or GetEntityCollisionDisabled(ped) or (height > 4.0 and speed < 1.0)) and
        (GetVehiclePedIsEntering(ped) == 0) and
        not IsPedInParachuteFreeFall(ped) and
        not IsPedJumpingOutOfVehicle(ped) and
        #(coords - vector3(0, 0, 0)) > 100.0
end

CreateThread(function()
    while not configLoaded or not isPlayerReady do Wait(250) end

    while true do
        if not VexShieldIsProtectionOn('Anti Noclip') then
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Wait(2000)

        local playerPed = PlayerPedId()
        if not DoesEntityExist(playerPed) then goto continue end

        local isDead = IsPlayerDead(playerPed)
        if wasDead and not isDead then
            noclipProtectionActive = true
            CreateThread(function()
                Wait(5000)
                noclipProtectionActive = false
            end)
        end
        wasDead = isDead

        if noclipProtectionActive or (VexShieldIsPlayerInNoclipOrExempt and VexShieldIsPlayerInNoclipOrExempt()) then
            goto continue
        end

        local coords = GetEntityCoords(playerPed)
        local height = GetEntityHeightAboveGround(playerPed)
        local speed = GetEntitySpeed(playerPed)
        local inVeh = IsPedInAnyVehicle(playerPed, false)

        -- 1. Ground Z Height Bypass Check (0.002 accuracy threshold)
        local success, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, false)
        if success then
            local calcHeight = coords.z - groundZ
            local diffHeight = math.abs(height - calcHeight)
            -- Threshold raised 0.002→0.5 (avoid terrain-loading false bans).
            -- Added collision-loaded + swimming guards to reduce false positives.
            local isBypassingHeight = (diffHeight > 0.5)
                and not inVeh
                and not isDead
                and not IsPedOnVehicle(playerPed)
                and not IsEntityAttached(playerPed)
                and not IsPedJumping(playerPed)
                and not IsPedClimbing(playerPed)
                and not IsPedSwimming(playerPed)
                and not IsPedSwimmingUnderWater(playerPed)
                and HasCollisionLoadedAroundEntity(playerPed)
            if isBypassingHeight then
                noclipHeightBypassStrike(diffHeight)
            end
        end

        -- 2. Vehicle Bypass Check
        if inVeh then
            local currentVehicle = GetVehiclePedIsIn(playerPed, false)
            if currentVehicle ~= 0 and not DoesEntityExist(currentVehicle) and not GetPedConfigFlag(playerPed, 62, true) then
                noclipVehicleBypassStrike()
            end
        end

        -- 3. Fall Bypass Check
        if IsPedFalling(playerPed) and not GetIsTaskActive(playerPed, 423) and not IsPedRagdoll(playerPed) then
            noclipFallBypassStrike()
        end

        -- 4. Phaze Noclip Check (Self-Attachment & Frozen Entity)
        local entityAttached = GetEntityAttachedTo(playerPed)
        if entityAttached > 0 and IsEntityPositionFrozen(playerPed) and (#(coords - GetEntityCoords(entityAttached)) == 0) and (NetworkGetNetworkIdFromEntity(entityAttached) == NetworkGetNetworkIdFromEntity(playerPed)) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
            goto continue
        end

        -- 5. Main Movement & Validity Check
        local currentStateValid = isVexShieldValidNoclipState(playerPed)
        if NC_oldStateValid and currentStateValid and
            (NC_oldSpeed == speed or (speed < 1.2 and NC_oldSpeed < 1.2)) and
            #(NC_oldCoords - coords) > 15.0
        then
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
        end

        NC_oldCoords = coords
        NC_oldSpeed = speed
        NC_oldStateValid = currentStateValid

        ::continue::
    end
end)

---------------------------------------------------------------------------------
-- ANTI NOCLIP V3 (UPGRADED ENGINE)
---------------------------------------------------------------------------------

Citizen.CreateThread(function()
    while not configLoaded or not isPlayerReady do Wait(250) end

    local suspiciousFlags = 0

    while true do
        if not VexShieldIsProtectionOn('ANTI NOCLIP V3') then
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Wait(1000)

        if VexShieldIsPlayerInNoclipOrExempt() then
            suspiciousFlags = 0
            goto continue
        end

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then 
            suspiciousFlags = 0
            goto continue
        end

        local coords = GetEntityCoords(ped)
        local speed = GetEntitySpeed(ped)
        local height = GetEntityHeightAboveGround(ped)

        local isInVehicle = IsPedInAnyVehicle(ped, false)
        local isInHeli = IsPedInAnyHeli(ped)
        local isInPlane = IsPedInAnyPlane(ped)
        local isFalling = IsPedFalling(ped)
        local isParachuting = GetPedParachuteState(ped) >= 0 and GetPedParachuteState(ped) <= 2
        local isFreefall = IsPedInParachuteFreeFall(ped)
        local isSwimming = IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped)
        local inWater = IsEntityInWater(ped)
        local isRagdoll = IsPedRagdoll(ped)
        local isJumping = IsPedJumping(ped)
        local isClimbing = IsPedClimbing(ped)
        local isAttached = IsEntityAttached(ped)
        local isDead = IsEntityDead(ped)
        local isInAir = IsEntityInAir(ped)

        local legitMovement = (
            isInVehicle or isInHeli or isInPlane or
            isFalling or isParachuting or isFreefall or
            isSwimming or inWater or VexShieldShouldSkipNoclipWater(ped) or
            isRagdoll or isJumping or isClimbing or isAttached or isDead or
            noclipProtectionActive or
            not IsScreenFadedIn() or IsCutsceneActive() or IsPauseMenuActive() or
            IsNuiFocused() or IsNuiFocusKeepingInput() or
            not IsPlayerControlOn(PlayerId())
        )

        local hoveringInAir = isInAir and math.abs(GetEntityVelocity(ped).z) < 0.1 and speed < 0.2 and height > 4.0
        local movingInAirNoCollision = isInAir and height > 3.5 and speed > 1.2 and not isFalling and not isJumping
        local collisionDisabledInAir = isInAir and height > 3.5 and GetEntityCollisionDisabled(ped)

        if not legitMovement and (hoveringInAir or movingInAirNoCollision or collisionDisabledInAir) then
            suspiciousFlags = suspiciousFlags + 1
            if suspiciousFlags >= 3 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
                suspiciousFlags = 0
            end
        else
            suspiciousFlags = math.max(0, suspiciousFlags - 1)
        end

        ::continue::
    end
end)

-- Citizen.CreateThread(function()
--     while true do
--         Citizen.Wait(1000) -- elke seconde

--         local ped = PlayerPedId()
--         if not DoesEntityExist(ped) then return end

--         local inPlaneOrHeli = IsPedInAnyPlane(ped) or IsPedInAnyHeli(ped)
--         local inVehicle = IsPedInAnyVehicle(ped, false)
--         local isFalling = IsPedFalling(ped)
--         local isJumping = IsPedJumping(ped)
--         local isSwimming = IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped)
--         local isClimbing = IsPedClimbing(ped)
--         local isRagdoll = IsPedRagdoll(ped)
--         local isParachuting = GetPedParachuteState(ped) >= 0 and GetPedParachuteState(ped) <= 2
--         local isFreefall = IsPedInParachuteFreeFall(ped)
--         local isDead = IsEntityDead(ped)
--         local isAttached = IsEntityAttached(ped)
--         local alpha = GetEntityAlpha(ped)

--         local vx, vy, vz = table.unpack(GetEntityVelocity(ped))
--         local speed = math.sqrt(vx*vx + vy*vy + vz*vz)
--         local height = GetEntityHeightAboveGround(ped)
--         local coords = GetEntityCoords(ped)

--         local suspiciousReasons = {}

--         local naturalState = (
--             inPlaneOrHeli or inVehicle or isFalling or isJumping or isSwimming or
--             isClimbing or isRagdoll or isParachuting or isFreefall or isAttached or isDead
--         )

--         -- Check op verdachte situaties
--         if not naturalState then
--             if height > 3.0 and speed < 1.0 then
--                 table.insert(suspiciousReasons, "zweeft boven grond zonder beweging")
--             end

--             if speed > 15.0 and height > 2.5 then
--                 table.insert(suspiciousReasons, "beweegt te snel op hoogte")
--             end

--             if alpha < 100 then
--                 table.insert(suspiciousReasons, "lage alpha (mogelijk onzichtbaar)")
--             end
--         end

--         -- Debug output
--         print("^5[VexShield DEBUG]^7")
--         print("  Hoogte:", string.format("%.2f", height))
--         print("  Snelheid:", string.format("%.2f", speed))
--         print("  Alpha:", alpha)
--         print("  In voertuig:", inVehicle)
--         print("  In vliegtuig/heli:", inPlaneOrHeli)
--         print("  Vallen:", isFalling)
--         print("  Zwemmen:", isSwimming)
--         print("  Klimmen:", isClimbing)
--         print("  Parachute:", isParachuting)
--         print("  Attached:", isAttached)
--         print("  Dood:", isDead)

--         if #suspiciousReasons > 0 then
--             print("^1[VERDACHT GEDRAG GEDETECTEERD]^7 Redenen:")
--             for _, reason in ipairs(suspiciousReasons) do
--                 print("  -", reason)
--             end
--             print("-----------------------------------------")
--         end
--     end
-- end)

CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end

    local detectionTime = 0
    local requiredTime = 2500 -- 3 seconden

    while true do
        if not VexShieldIsProtectionOn('Anti Noclip2') then
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Citizen.Wait(1000)

        local ped = PlayerPedId()

        -- Ignore detection while the player is attached (e.g., being carried)
        if IsEntityAttached(ped) then
            detectionTime = 0
        elseif VexShieldShouldSkipNoclipWater(ped) then
            detectionTime = 0
        elseif IsPedFalling(ped) then
            local coords = GetEntityCoords(ped)
            local speed = GetEntitySpeed(ped)

            if coords.z > 35 and speed < 0.1 then
                detectionTime = detectionTime + 200
                if detectionTime >= requiredTime then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
                    break
                end
            else
                detectionTime = 0
            end
        else
            detectionTime = 0
        end
        ::continue::
    end
end)

---------------------------------------------------------------------------------
-- ANTI NOCLIP3
---------------------------------------------------------------------------------

local wasFalling = false
local lastHeight = 0.0
local zeroSpeedStart = 0

CreateThread(function()
    while true do
        if not VexShieldIsProtectionOn('Anti Noclip3') then
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Wait(400)

        local ped = PlayerPedId()
        if VexShieldShouldSkipNoclipWater(ped) then
            wasFalling = false
            zeroSpeedStart = 0
            lastHeight = 0.0
            goto continue
        end
        local isFalling = IsPedFalling(ped)
        -- Skip when attached to another entity (carry/drag scenarios)
        if IsEntityAttached(ped) then
            goto continue
        end
        local z = GetEntityCoords(ped).z
        local speed = GetEntitySpeed(ped)

        -- Bereken tijd zonder snelheid
        local timeNoSpeed = zeroSpeedStart ~= 0 and (GetGameTimer() - zeroSpeedStart) or 0
        local heightDiff = lastHeight ~= 0.0 and (z - lastHeight) or 0.0

        -- Debug
        -- print("^5[VexShield DEBUG]^7")
        -- print("  Hoogte:\t" .. string.format("%.2f", z))
        -- print("  Snelheid:\t" .. string.format("%.2f", speed))
        -- print("  Vallen:\t" .. tostring(isFalling))
        -- print("  Tijd zonder speed:\t" .. timeNoSpeed)
        -- print("  Hoogteverschil:\t" .. string.format("%.2f", heightDiff))

        if isFalling then
            -- ðŸ”º Plotselinge stijging
            if lastHeight ~= 0.0 and z - lastHeight > 26.0 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
                -- print("^1[VexShield]^7 Speler gebanned: Noclip (Falling omhoog)")
                return
            end

            -- ðŸŸ¥ Valt met 0 snelheid
            if speed < 0.05 then
                if zeroSpeedStart == 0 then
                    zeroSpeedStart = GetGameTimer()
                elseif GetGameTimer() - zeroSpeedStart > 5500 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
                    -- print("^1[VexShield]^7 Speler gebanned: Noclip (Falling met 0 speed)")
                    return
                end
            else
                zeroSpeedStart = 0
            end

            -- Under-map cheat can report z ~ 0; ocean / coast desync can too — never flag in/near water.
            -- Guard against false bans when map collision is still loading
            if z <= 0.01 and not IsEntityInWater(ped) and not VexShieldShouldSkipNoclipWater(ped) and HasCollisionLoadedAroundEntity(ped) then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to bypass collision')
                -- print("^1[VexShield]^7 Speler gebanned: Noclip (Falling met hoogte 0.00)")
                return
            end

            lastHeight = z
            wasFalling = true
        else
            wasFalling = false
            zeroSpeedStart = 0
            lastHeight = 0.0
        end

        ::continue::
    end
end)

---------------------------------------------------------------------------------
-- ANTI PARACHUTE NOCLIP
---------------------------------------------------------------------------------
local ncfix = false
local lastTimeChecked = GetGameTimer()

AddEventHandler('playerSpawned', function()
    if not ncfix then
        ncfix = true
        Wait(2500)
        ncfix = false
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end

    local prevCoords = GetEntityCoords(PlayerPedId())  -- Houd de vorige coÃ¶rdinaten bij

    while true do
        if not VexShieldIsProtectionOn('Anti Parachute Noclip') then
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Wait(500)

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) or IsEntityDead(ped) then goto continue end

        local coords = GetEntityCoords(ped)
        local height = GetEntityHeightAboveGround(ped)
        local vx, vy, vz = table.unpack(GetEntityVelocity(ped))

        local isParachuting = false
        local isMovingTooFast = false
        local isMovingUpwards = false

        -- Uitsluiten van legitieme situaties
        local allow = 
            IsPedInAnyVehicle(ped, false) or 
            IsPedInAnyPlane(ped) or 
            IsPedInAnyHeli(ped) or
            IsPedJumping(ped) or 
            IsPedFalling(ped) or 
            IsPedSwimming(ped) or 
            IsPedSwimmingUnderWater(ped) or
            IsEntityInWater(ped) or
            VexShieldShouldSkipNoclipWater(ped) or
            IsPedClimbing(ped) or 
            IsEntityAttached(ped) or 
            IsPauseMenuActive() or
            IsPlayerDead(PlayerId()) or
            not HasPedGotWeapon(ped, GetHashKey("GADGET_PARACHUTE"), false)  -- Controleer of de speler geen parachute heeft

        -- Controleer of de speler omhoog gaat met de parachute
        if not allow and height > 1.5 then
            if vz > 0.1 then  -- Positieve verticale snelheid betekent omhoog gaan
                isMovingUpwards = true
            end

            -- Controleer of de speler te snel naar links of rechts beweegt (abnormaal snel)
            local speedLimit = 10.0  -- Stel een limiet in voor horizontale snelheid, bijvoorbeeld 10 m/s
            if math.abs(vx) > speedLimit or math.abs(vy) > speedLimit then
                isMovingTooFast = true
            end
        end

        -- Als er verdacht omhoog bewegen of te snel bewegen naar links/rechts met parachute wordt gedetecteerd
        if isMovingUpwards or isMovingTooFast then
            SafeTriggerServerEvent('VexShield:checkParachuteMovement', {
                coords = coords,
                height = height,
                velocity = {vx, vy, vz},
                isMovingTooFast = isMovingTooFast,
                isMovingUpwards = isMovingUpwards
            })
        end

        -- Update de vorige coÃ¶rdinaten voor de volgende check
        prevCoords = coords
        lastTimeChecked = GetGameTimer()

        ::continue::
    end
end)
-- print("CLIENT CHECK 10.1")

---------------------------------------------------------------------------------
-- ANTI FREECAM (ENHANCED ENGINE INTEGRATION)
---------------------------------------------------------------------------------
local createdCams = {}

local freecamStrike1 = CreateVexShieldStrikeSystem(
    "Freecam1",
    2,
    function(distanceFromCam)
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
    end,
    9000
)

local freecamStrike2 = CreateVexShieldStrikeSystem(
    "Freecam2",
    2,
    function(distanceFromCam)
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
    end,
    9000
)

local freecamStrike3 = CreateVexShieldStrikeSystem(
    "Freecam3",
    2,
    function(distanceFromCam)
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
    end,
    9000
)

local freecamStrike4 = CreateVexShieldStrikeSystem(
    "Freecam4",
    2,
    function(distanceFromCam)
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
    end,
    9000
)

local FC_camRot = vector3(0.0, 0.0, 0.0)

exports("createCam", function(cam)
    if cam then createdCams[cam] = true end
end)

exports("destroyCam", function(cam)
    if cam then createdCams[cam] = nil end
end)

CreateThread(function()
    while not configLoaded or not isPlayerReady do Wait(500) end

    while true do
        if not VexShieldIsProtectionOn('Anti Freecam') then
            Wait(VexShieldClientState.pollIdleMs)
            goto skip_freecam
        end
        Wait(3000)

        local ped = PlayerPedId()
        if not ped or not DoesEntityExist(ped) or IsPedDeadOrDying(ped, true) then
            goto skip_freecam
        end

        if VexShieldIsPlayerInNoclipOrExempt and VexShieldIsPlayerInNoclipOrExempt() then
            goto skip_freecam
        end

        local playerCoords = GetEntityCoords(ped)
        local renderingCam = GetRenderingCam()
        local renderedCamCoords = GetFinalRenderedCamCoord()
        local distanceFromCam = #(renderedCamCoords - playerCoords)
        local myHeadCoords = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
        local _, screenX, screenY = GetScreenCoordFromWorldCoord(myHeadCoords.x, myHeadCoords.y, myHeadCoords.z)
        local viewModeContext = GetCamActiveViewModeContext()
        local isCamFoot = viewModeContext == 0
        local isCamVehicle = viewModeContext == 1 or viewModeContext == 2
        local inVeh = IsPedInAnyVehicle(ped, false)
        local isFirstPersonCam = GetFollowPedCamViewMode() == 4
        local isDistanceFromCamLegit = distanceFromCam <= ((isCamVehicle or inVeh) and 50.0 or 25.0)
        local lastCamEaseTime = GetGameTimer() - (LocalPlayer.state and LocalPlayer.state["_WS:LastCamEaseTime"] or 0)
        local camRot = GetFinalRenderedCamRot(2)

        -- Phaze Freecam Check
        if screenX == 0 and screenY == 0 and IsEntityOnScreen(ped) and IsEntityOccluded(ped) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
            goto skip_freecam
        end

        -- Freecam 1: Unknown Rendering Cam Check
        if renderingCam ~= -1 and not createdCams[renderingCam] and not IsCinematicCamRendering() and not IsCinematicIdleCamRendering() and not IsPlayerSwitchInProgress() and not IsNuiFocused() and not IsCutscenePlaying() then
            freecamStrike1(distanceFromCam)
            goto skip_freecam

        -- Bypass 1: Off-screen unlegit cam distance
        elseif renderingCam == -1 and not IsEntityOnScreen(ped) and not IsCinematicIdleCamRendering() and not NetworkIsInSpectatorMode() and (IsCinematicCamRendering() and (isCamFoot or not isDistanceFromCamLegit)) and not IsCinematicCamInputActive() and (isCamFoot or (isCamVehicle and not isFirstPersonCam)) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
            goto skip_freecam

        -- Freecam 2: Camera Ease & Occluded Foot Check
        elseif renderingCam == -1 and isDistanceFromCamLegit and IsGameplayCamRendering() and not NetworkIsInSpectatorMode() and not IsPlayerSwitchInProgress() and not IsNuiFocused() and not IsCutscenePlaying() and not IsCinematicCamRendering()
            and not IsCinematicCamInputActive() and not IsCinematicIdleCamRendering() and not IsPlayerCamControlDisabled() and not IsFirstPersonAimCamActive() and isCamFoot
            and GetFollowPedCamViewMode() == 1 and IsFollowPedCamActive() and (screenX == -1.0 and screenY == -1.0) and IsEntityOnScreen(ped) and IsEntityOccluded(ped)
            and not IsCamInterpolating(renderingCam) and (lastCamEaseTime > 10000) and GetPedMovementClipset(ped) ~= GetHashKey("move_ped_crouched") and not IsPedDeadOrDying(ped, true) and not IsEntityPositionFrozen(ped) and FC_camRot == camRot and IsPlayerFreeForAmbientTask(PlayerId())
        then
            freecamStrike2(distanceFromCam)

        -- Freecam 3: Unnatural Cam Distance & Occluded Ped
        elseif renderingCam == -1 and ((screenX == -1.0 and screenY == -1.0) or IsEntityOccluded(ped)) and not IsEntityOnScreen(ped) and not IsCinematicIdleCamRendering() and not IsCinematicCamRendering() and not NetworkIsInSpectatorMode() and not IsPlayerSwitchInProgress() and not IsCutscenePlaying() and isDistanceFromCamLegit and not isFirstPersonCam and (not inVeh or (GetVehicleClass(GetVehiclePedIsIn(ped, false)) < 10)) and not IsPedDeadOrDying(ped, true) and not IsCamInterpolating(renderingCam) and (lastCamEaseTime > 10000) and IsPlayerFreeForAmbientTask(PlayerId()) and GetPedMovementClipset(ped) ~= GetHashKey("move_ped_crouched") and not IsPedAPlayer(GetEntityAttachedTo(ped)) and (not (IsEntityAttached(ped) and not inVeh)) and GetEntityAlpha(ped) == 255 then
            freecamStrike3(distanceFromCam)

        -- Freecam 4: Gameplay FOV Range & Unlegit Distance
        elseif renderingCam == -1 and GetCamActiveViewModeContext() <= 2 and not IsCinematicCamRendering() and not IsCinematicIdleCamRendering() and not IsPlayerSwitchInProgress() and not IsNuiFocused() and not IsCutscenePlaying() and not NetworkIsInSpectatorMode() and not IsPedDeadOrDying(ped, true) and not IsPedFalling(ped) and (GetGameplayCamFov() >= 50.0 and GetGameplayCamFov() <= 52.0) and not isDistanceFromCamLegit and (lastCamEaseTime > 10000) and
            not IsPedOnVehicle(ped) and not IsPedInParachuteFreeFall(ped) and (GetVehiclePedIsEntering(ped) == 0) and not IsPedJumpingOutOfVehicle(ped) and not (IsEntityAttached(ped) and not inVeh) and not IsPedAPlayer(GetEntityAttachedTo(ped)) then
            freecamStrike4(distanceFromCam)
        end

        FC_camRot = camRot

        ::skip_freecam::
    end
end)

---------------------------------------------------------------------------------
-- CHECK NOCLIP2 (OPTIMIZED & SAFE VERSION)
---------------------------------------------------------------------------------

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end

    while not NetworkIsPlayerActive(PlayerId()) or not PlayerPedId() do
        Citizen.Wait(860)
    end

    while true do
        if not VexShieldIsProtectionOn('Anti Noclip2') then
            Wait(VexShieldClientState.pollIdleMs)
            goto noclip2opt_end
        end
        Citizen.Wait(math.random(5000, 6500))
        do
            local ped = PlayerPedId()
            if VexShieldShouldSkipNoclipWater(ped) then
                goto noclip2opt_skip_send
            end
            local coords = GetEntityCoords(ped)
            local speed = GetEntitySpeed(ped)
            local vehicle = GetVehiclePedIsIn(ped, false)
            local inVehicle = (vehicle ~= 0)
            local isFalling = IsPedInParachuteFreeFall(ped)
            local isRagdoll = IsPedRagdoll(ped)
            -- These natives are client-only; server uses the flags below (see server/main.lua CheckNoclip2).
            local inWater = IsEntityInWater(ped)
            local isSwimming = IsPedSwimming(ped)
            local isSwimmingUnderWater = IsPedSwimmingUnderWater(ped)

            -- Ø­Ø³Ø§Ø¨ Ø§Ø±ØªÙØ§Ø¹ Ø§Ù„Ø£Ø±Ø¶ Ø§Ù„Ø­Ù‚ÙŠÙ‚ÙŠ
            local success, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z)
            if not success then groundZ = coords.z end
            local groundCheck = coords.z - groundZ

            SafeTriggerServerEvent('VexShield:CheckNoclip2', {
                coords = coords,
                speed = speed,
                inVehicle = inVehicle,
                isFalling = isFalling,
                isRagdoll = isRagdoll,
                groundCheck = groundCheck,
                inWater = inWater,
                isSwimming = isSwimming,
                isSwimmingUnderWater = isSwimmingUnderWater,
            })
            ::noclip2opt_skip_send::
        end
        ::noclip2opt_end::
    end
end)

---------------------------------------------------------------------------------
-- ADMIN LOG
---------------------------------------------------------------------------------
function notifyAdmins(message)
    print("[NotifyAdmins] " .. message)
end

---------------------------------------------------------------------------------
-- MAINTENANCE THREADS
---------------------------------------------------------------------------------
-- Reserved for future maintenance checks. Avoid idle forever-threads with no work.

---------------------------------------------------------------------------------
-- SPECTATE CHECK (CLIENT SAFE VERSION)
---------------------------------------------------------------------------------
RegisterNetEvent('VexShield:checkSpectateStatus', function(isSpectating)
    local ped = PlayerPedId()

    -- Ù„Ùˆ Ø§Ù„Ù„Ø§Ø¹Ø¨ Ø¯Ø§Ø®Ù„ Spectate Ø¨Ø·Ø±ÙŠÙ‚Ø© ØºØ±ÙŠØ¨Ø©
    if isSpectating then
        if IsPedInAnyVehicle(ped, false) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to manipulate spectate mode')
        end
    end
end)

---------------------------------------------------------------------------------
-- EXPLOSION CHECK
---------------------------------------------------------------------------------
RegisterNetEvent('VexShield:checkExplosion', function(data)
    if not data then return end

    local reason = data.reason or "Unknown"
    print("Explosion Check â€” Reason: " .. reason)

    if reason == "Suspicious Frequency" then
        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted unauthorized explosion')
    end
end)

-- print("here clientjajaj13")
---------------------------------------------------------------------------------
-- ANTI SUPER PUNCH
---------------------------------------------------------------------------------
local health = {}
CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    AddEventHandler('gameEventTriggered', function(eventName, eventData)
        if eventName ~= "CEventNetworkEntityDamage" then return end
        if not VexShieldIsProtectionOn('Anti Super Punch') then return end

        local ped2    = eventData[1]
        local attacker = eventData[2]
        local playerPed = PlayerPedId()
        if attacker ~= playerPed then return end

        -- Only flag hits on real player peds (not NPCs or objects)
        if not ped2 or not IsEntityAPed(ped2) or not IsPedAPlayer(ped2) then return end
        -- Skip if target is already dead before this hit (death-state desync)
        if not DoesEntityExist(ped2) then return end

        local ped2health   = GetEntityHealth(ped2)
        local maxHealth    = GetEntityMaxHealth(ped2)
        local previousHealth = health[ped2]   -- nil on first hit = no data yet, skip
        local invehicle    = IsPedInAnyVehicle(attacker, false)
        health[ped2] = ped2health

        -- Skip on first hit (no previous health baseline)
        if not previousHealth then return end
        -- Skip if attacker is shooting (gun death, not punch)
        if IsPedShooting(attacker) then return end
        -- Skip if target was already below 10 HP (nearly dead anyway)
        if previousHealth <= (maxHealth * 0.10) then return end

        -- Require > 70% health drop in a single unarmed hit to flag
        local healthDropPct = ((previousHealth - ped2health) / maxHealth) * 100
        if healthDropPct > 70
           and ped2health <= 0
           and GetSelectedPedWeapon(attacker) == GetHashKey("WEAPON_UNARMED")
           and not invehicle then
            SafeTriggerServerEvent('VexShield:banHandler', 'Super Punch Detected')
        end
    end)
end)

function IsPlayerHoldingHandsUp()
    return IsControlPressed(0, 323) -- Standaard "handen omhoog" control
end

CreateThread(function()
    while true do
        Wait(500)
        if IsPlayerHoldingHandsUp() then
            -- print("[DEBUG] Speler heeft handen omhoog!")
        end
    end
end)

-- print("CLIENT CHECK 10.2")
-- print("here clientjajaj13.5")

---------------------------------------------------------------------------------
-- ANTI CARRY VEHICLE
---------------------------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(1500)

        if not VexShieldIsProtectionOn('Anti Carry Vehicle') then
            break
        end

        local playerPed = PlayerPedId()

        if not IsPedInAnyVehicle(playerPed, false) and GetVehiclePedIsTryingToEnter(playerPed) == 0 then
            local playerCoords = GetEntityCoords(playerPed)
            local nearbyVehicles = GetNearbyEntities(playerCoords, 6.0)

            for _, vehicle in ipairs(nearbyVehicles) do
                if DoesEntityExist(vehicle) and IsEntityAVehicle(vehicle) then

                    local vehicleCoords = GetEntityCoords(vehicle)
                    local heightDiff = vehicleCoords.z - playerCoords.z

                    local isAttachedToPed = IsEntityAttachedToEntity(vehicle, playerPed)
                    local isAttachedToAnything = IsEntityAttached(vehicle)
                    local parentEntity = GetEntityAttachedTo(vehicle)

                    local vehicleSpeed = GetEntitySpeed(vehicle)

                    if (isAttachedToPed or (isAttachedToAnything and parentEntity == playerPed)) and
                       (heightDiff > 1.5 and heightDiff < 10.0) and
                       vehicleSpeed < 1.0 then

                        SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to carry vehicle')
                        DeleteEntity(vehicle)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        if not VexShieldIsProtectionOn('Anti Attach All Cars') then
            Wait(VexShieldClientState.pollIdleMs)
        else
            Wait(1200)
            VexShieldRunProtectedTick('Anti Attach All Cars', function()
                local ped = PlayerPedId()
                if not DoesEntityExist(ped) then return end
                local count = 0
                local pool = AS_GetPool('CVehicle')
                for i = 1, #pool do
                    local veh = pool[i]
                    if DoesEntityExist(veh) and IsEntityAttachedToEntity(veh, ped) then
                        count = count + 1
                        if count >= 4 then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to attach vehicles to player')
                            break
                        end
                    end
                end
            end)
        end
    end
end)

function GetNearbyEntities(coords, radius)
    local vehicles = {}
    local handle, vehicle = FindFirstVehicle()
    local success
    repeat
        if DoesEntityExist(vehicle) then
            local vehicleCoords = GetEntityCoords(vehicle)
            if #(vehicleCoords - coords) <= radius then
                table.insert(vehicles, vehicle)
            end
        end
        success, vehicle = FindNextVehicle(handle)
    until not success
    EndFindVehicle(handle)
    return vehicles
end

-- print("here clientjajaj13.6")

-- [VEX-INTERNAL-CORE: 0x9F4C2A-C6930194823]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

---------------------------------------------------------------------------------
-- ANTI INJECTION ENGINE
---------------------------------------------------------------------------------
Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        if not VexShieldIsProtectionOn('ANTI INJECTION ENGINE') then
            Wait(VexShieldClientState.pollIdleMs)
        else
            Wait(200)
            if IsControlJustPressed(0, 24) then
                local ped = PlayerPedId()
                local isStill = IsPedStill(ped)
                local x, y = GetNuiCursorPosition()
                if isStill then
                    SafeTriggerServerEvent("reportCursorPosition", x, y)
                end
            end
        end
    end
end)

RegisterNetEvent("Airsecure:notify")
AddEventHandler("Airsecure:notify", function(message, type)
    SendNUIMessage({
        action = "notify",
        message = message,
        type = type or "info"
    })
end)

function GetNearbyEntities(coords, radius)
    local entities = {}
    local handle, vehicle = FindFirstVehicle()
    local success

    repeat
        local vehicleCoords = GetEntityCoords(vehicle)
        if #(vehicleCoords - coords) <= radius then
            table.insert(entities, vehicle)
        end
        success, vehicle = FindNextVehicle(handle)
    until not success
    EndFindVehicle(handle)

    local handle2, object = FindFirstObject()
    repeat
        local objectCoords = GetEntityCoords(object)
        if #(objectCoords - coords) <= radius then
            table.insert(entities, object)
        end
        success, object = FindNextObject(handle2)
    until not success
    EndFindObject(handle2)

    return entities
end

-- print("CLIENT CHECK 10.3")
-- print("here clientjajaj13.7")

---------------------------------------------------------------------------------
-- ANTI SPOOFED DAMAGE/WEAPON
---------------------------------------------------------------------------------
-- Weak client-side unarmed shooting checks caused false bans during weapon
-- transition/desync frames. Authoritative checks are handled by the server
-- weaponDamageEvent logic and the stricter gameEventTriggered detector below.

-- print("here clientjajaj13.7.1")

---------------------------------------------------------------------------------
-- ANTI INJECTION
---------------------------------------------------------------------------------
 local checkInterval = 60
 local VexShieldLastInjectionScreenshotAt = 0
 Citizen.CreateThread(function()
     -- WAIT FOR FRAMEWORK & CONFIG
     while not configLoaded do Wait(250) end
     while not configLoaded do Wait(250) end

     while true do
         Citizen.Wait(checkInterval * 1000)
         if not VexShieldIsProtectionOn('Anti Injection') then
             break
        end
         if not IsNuiFocused() and not IsNuiFocusKeepingInput() and not IsPauseMenuActive() then
             TakeScreenshot()
         end
     end
 end)

 function TakeScreenshot()
     local now = GetGameTimer()
     if now - (VexShieldLastInjectionScreenshotAt or 0) < 55000 then return end
     VexShieldLastInjectionScreenshotAt = now
     if GetResourceState and GetResourceState("screenshot-basic") ~= "started" then return end
     local ok = pcall(function()
     exports["screenshot-basic"]:requestScreenshotUpload("files://", "files[]", function(data)
         local imageData = json.decode(data)
         if imageData and imageData.files and imageData.files[1] then
             local filePath = imageData.files[1].file
             SafeTriggerServerEvent("screenshot:save", filePath)
         end
     end)
     end)
     if not ok then
         VexShieldLastInjectionScreenshotAt = now + 30000
     end
 end

 function IsAltTabbed()
     local screenWidth, screenHeight = GetActiveScreenResolution()
     local x = GetDisabledControlNormal(2, 239)
     local y = GetDisabledControlNormal(2, 240)
    local mouseX, mouseY = screenWidth * x, screenHeight * y
     return mouseX == screenWidth / 2 and mouseY == screenHeight / 2
 end

---------------------------------------------------------------------------------
-- ANTI BOOST VEHICLE
---------------------------------------------------------------------------------
Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(100)
        if not VexShieldIsProtectionOn('Anti Boost vehicle') then
            break
        end  

        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        if vehicle ~= 0 then
            local model = GetEntityModel(vehicle)
            if GetHasRocketBoost(vehicle)
               and model ~= 989294410
               and model ~= 884483972
               and model ~= -638562243
               and model ~= 2069146067 then
                if IsVehicleRocketBoostActive(vehicle) then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Vehicle Boost Detected')
                end
            end
        end
    end
end)
-- print("CLIENT CHECK 10.4")

-- print("here clientjajaj13.7.3")

---------------------------------------------------------------------------------
-- ANTI SHIFTBOOST VEHICLE
---------------------------------------------------------------------------------
local lastShiftPress = 0
local doublePressThreshold = 470
local holdShiftThreshold = 2300

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(100)
        if not VexShieldIsProtectionOn('Anti ShiftBoost vehicle') then
            break
        end

        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)

        if DoesEntityExist(vehicle) and vehicle ~= 0 then
            if IsControlJustPressed(0, 21) then
                local currentTime = GetGameTimer()
                if currentTime - lastShiftPress <= doublePressThreshold then
                    SetEntityAsMissionEntity(vehicle, true, true)
                    Citizen.Wait(1000)
                    if DoesEntityExist(vehicle) then
                        DeleteEntity(vehicle)
                        ShowNotification('VexShield: You have used vehicle boost staff is aware of this')
                    end
                end
                lastShiftPress = currentTime
            end

            if IsControlPressed(0, 21) then
                local holdTime = GetGameTimer() - lastShiftPress
                if holdTime >= holdShiftThreshold then
                    SetEntityAsMissionEntity(vehicle, true, true)
                    Citizen.Wait(1000)
                    if DoesEntityExist(vehicle) then
                        DeleteEntity(vehicle)
                        ShowNotification('VexShield: You have used vehicle boost staff is aware of this')
                    end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI TAZE
---------------------------------------------------------------------------------
Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(500)
        if not VexShieldIsProtectionOn('Anti Taze') then
            break
        end

        local playerPed = PlayerPedId()
        local weapon = GetSelectedPedWeapon(playerPed)
        if Shared.Client and Shared.Client['AntiTaze'] then
            if weapon == Shared.Client['AntiTaze']['TazerWeaponHash'] then
                local targetPed = GetClosestPed(0.0, 0.0, 0.0, 5.0, 1, 1, 1, 0, 0, -1)
                if targetPed then
                    local playerCoords = GetEntityCoords(playerPed)
                    local targetCoords = GetEntityCoords(targetPed)
                    local distance = Vdist(
                        playerCoords.x, playerCoords.y, playerCoords.z,
                        targetCoords.x, targetCoords.y, targetCoords.z
                    )

                    if distance <= Shared.Client['AntiTaze']['MaxTazeDistance'] then
                        SafeTriggerServerEvent(
                            'VexShield:checkTaze',
                            GetPlayerServerId(PlayerId()),
                            GetPlayerServerId(NetworkGetPlayerIndexFromPed(targetPed)),
                            distance
                        )
                    end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI SUPERJUMP
---------------------------------------------------------------------------------
local ncfix = false
local superJumpSpawnGraceUntil = 0

AddEventHandler('playerSpawned', function()
    superJumpSpawnGraceUntil = GetGameTimer() + 15000
    if not ncfix then
        ncfix = true
        Wait(2500)
        ncfix = false
    end
end)

function superJumpNaturalMovement(ped)
    if not ped or ped == 0 then return true end
    if ncfix or GetGameTimer() < superJumpSpawnGraceUntil then return true end
    if IsPedInAnyVehicle(ped, false) then return true end
    if IsEntityDead(ped) then return true end
    if IsPedRagdoll(ped) then return true end
    if IsPedFalling(ped) or IsPedInParachuteFreeFall(ped) then return true end
    if IsPedJumping(ped) then return true end
    if IsPedClimbing(ped) then return true end
    if IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped) then return true end
    local chute = GetPedParachuteState(ped)
    if chute ~= nil and chute >= 0 and chute <= 2 then return true end
    if IsEntityAttached(ped) then return true end
    return false
end

Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    local lastCoords = vector3(0, 0, 0)
    local lastVehicleState = false

    while true do
        Citizen.Wait(500)

        if not VexShieldIsProtectionOn('Anti SuperJump') then
            break
        end

        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local isInVehicle = IsPedInAnyVehicle(playerPed, false)
        local moved = #(coords - lastCoords) > 0.35
        local vehicleChanged = isInVehicle ~= lastVehicleState

        if moved or vehicleChanged then
            lastCoords = coords
            lastVehicleState = isInVehicle
            local natural = superJumpNaturalMovement(playerPed)
            local _, _, velZ = table.unpack(GetEntityVelocity(playerPed))
            SafeTriggerServerEvent(
                "AirSecure:UpdatePlayerPosition",
                coords.x,
                coords.y,
                coords.z,
                isInVehicle,
                natural,
                velZ or 0.0
            )
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI VEHICLE WEAPON
---------------------------------------------------------------------------------
Citizen.CreateThread(function()
    -- WAIT FOR FRAMEWORK & CONFIG
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(1000) -- Check every 1s instead of 200ms
        if not VexShieldIsProtectionOn('Anti Vehicle Weapon') then
            break
        end

        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)

        if IsPedInAnyVehicle(ped, false) then
            if DoesVehicleHaveWeapons(vehicle) then
                for i, weaponHash in pairs({
                    2971687502, 1945616459, 3450622333, 3530961278,
                    1259576109, 4026335563, 1566990507, 1186503822,
                    2669318622, 3473446624, 4171469727, 1741783703,
                    2211086889
                }) do
                    DisableVehicleWeapon(true, weaponHash, vehicle, ped)
                end
            end
        end
    end
end)
-- print("here clientjajaj13.7.4")

-- print("here clientjajaj13.7.5")

--------------------------------------------------------
-- ANTI Infinite Ammo
--------------------------------------------------------

Citizen.CreateThread(function()
    -- Wacht op framework en configuratie
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(1000)
        if not VexShieldIsProtectionOn('Anti Infinite Ammo') then break end

        local playerPed = PlayerPedId()
        if not IsPedArmed(playerPed, 6) then goto continue end -- Alleen checken als speler een wapen heeft

        local weaponHash = GetSelectedPedWeapon(playerPed)

        -- Skip WEAPON_STUNGUN
        if weaponHash == GetHashKey("WEAPON_STUNGUN") then goto continue end

        local success, ammoInClip = GetAmmoInClip(playerPed, weaponHash)
        local maxAmmoSuccess, maxAmmo = GetMaxAmmo(playerPed, weaponHash)
        local totalAmmo = GetAmmoInPedWeapon(playerPed, weaponHash)
        local clipMax = ((Shared.Client and Shared.Client['InfiniteAmmoMax']) or 250)
        local ammoMin = ((Shared.Client and Shared.Client['InfiniteAmmoMin']) or 0)

        -- Zet Infinite Ammo uit
        SetPedInfiniteAmmoClip(playerPed, false)

        -- Check: Oneindige of abnormale ammo in clip
        if success and (ammoInClip > clipMax or ammoInClip < ammoMin) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Infinite Ammo Detection')
            return
        end

        -- Check: Oneindige of abnormale maximale munitie
        if maxAmmoSuccess and (maxAmmo > clipMax or maxAmmo < ammoMin) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Infinite Ammo Detection')
            return
        end

        -- Check: Totaal aantal kogels hoger dan toegestaan
        if totalAmmo > maxAmmo or totalAmmo < ammoMin or totalAmmo == -1 then
            SafeTriggerServerEvent('VexShield:banHandler', 'Infinite Ammo Detection')
            return
        end

        ::continue::
    end
end)

-- print("CLIENT CHECK 10.5")

--------------------------------------------------------
-- CHEAT AI DETECTION
--------------------------------------------------------

function isoutofgame()
    local x = GetControlNormal(0, 239)
    local y = GetControlNormal(0, 240)

    if x == 0.5 and  y == 0.5 then
        return true
    else
        return false
    end
end

local test = {1, 2, 3, 4}

CreateThread(function()
    if not VexShieldIsProtectionOn('Cheat Ai Detection') then return end
    local aiflags = 0
    while VexShieldIsProtectionOn('Cheat Ai Detection') do
        
        local ped = PlayerPedId()
        local oldX, oldY = GetNuiCursorPosition()
        local oldCamCoords = GetGameplayCamCoord()
        Wait(150)
        local newX, newY = GetNuiCursorPosition()
        local newCamCoords = GetGameplayCamCoord()
        if not IsNuiFocused() and isInGame() and IsMinimapRendering() and not IsPedInAnyVehicle(ped, false) and not IsPlayerCamControlDisabled() and not isoutofgame() and not IsPauseMenuActive() and not IsPedDeadOrDying(ped) and not IsHudComponentActive(19) and NetworkIsPlayerConnected(PlayerId()) and not NetworkIsPlayerFading(PlayerId()) and not LandingMenuIsActive() and not IsNuiFocusKeepingInput() then
            local cursorMoved = (oldX ~= newX or oldY ~= newY) and oldCamCoords == newCamCoords
            if cursorMoved then
                local x = GetControlNormal(0, 239)
                local y = GetControlNormal(0, 240)
                local camCoordsBefore = GetGameplayCamCoord()
                SetNuiFocusKeepInput(true)
                SetNuiFocus(true, false)
                for _, value in ipairs(test) do
                    EnableControlAction(2, value, true)
                end
                SetCursorLocation(0.5, 0.6)
                Wait(150)
                SetCursorLocation(0.5, 0.7)
                SetCursorLocation(x, y)
                SetNuiFocusKeepInput(false)
                SetNuiFocus(false, false)
                for _, value in ipairs(test) do
                    EnableControlAction(2, value, false) 
                end
                local camCoordsAfter = GetGameplayCamCoord()
                if camCoordsBefore == camCoordsAfter then
                    aiflags = aiflags + 1
                    if aiflags >= 4 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Internal Executor Detected (CheatAI)')
                        aiflags = 0
                    end
                    Wait(400)
                else
                    aiflags = 0
                    Wait(9000)
                end
            else
                aiflags = 0
            end
        else
            aiflags = 0
        end
    end
end)

-- print("here clientjajaj14")



--------------------------------------------------------
-- ANTI TELEPORT #2
--------------------------------------------------------

Citizen.CreateThread(function()
    while not VexShieldIsProtectionOn('Anti Teleport2') do
        Citizen.Wait(500)
    end

    local lastPosition = nil
    local teleportThreshold = 100.0
    local isTeleporting = false
    local isNoClipping = false

    RegisterNetEvent('esx:playerLoaded')
    AddEventHandler('esx:playerLoaded', function()
        isTeleporting = true
        TeleportIgnoreUntil = GetGameTimer() + 10000
    end)

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(1000)
            if VexShieldIsPlayerInNoclipOrExempt() then
                goto continue_tp2
            end
            local playerPed = PlayerPedId()
            local currentPosition = GetEntityCoords(playerPed)
            if lastPosition then
                local distance = #(currentPosition - lastPosition)
                if distance > teleportThreshold and GetGameTimer() > TeleportIgnoreUntil then
                    if not isNoClipping then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Teleport detected #2')
                    end
                end
            end
            lastPosition = currentPosition
            ::continue_tp2::
        end
    end)

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(100)
            isNoClipping = checkNoClipMode()
        end
    end)

    function checkNoClipMode()
        local playerPed = PlayerPedId()
        local isFlying = not IsPedOnFoot(playerPed) and IsEntityInAir(playerPed)
        local isInVehicle = IsPedInAnyVehicle(playerPed, false) and not IsVehicleOnAllWheels(GetVehiclePedIsIn(playerPed, false))
        return isFlying or isInVehicle
    end
end)

-- print("working client5")

-- print("CLIENT CHECK 10.7")

--------------------------------------------------------
-- ANTI RAPE PLAYER
--------------------------------------------------------

CreateThread(function()
        if not VexShieldIsProtectionOn('Anti Rape Player') then return end
    while true do
        for _, player in ipairs(GetActivePlayers()) do
            if IsEntityPlayingAnim(GetPlayerPed(player), "rcmpaparazzo_2", "shag_loop_poppy", 3) then
                ClearPedTasks(GetPlayerPed(player))
                SafeTriggerServerEvent('VexShield:banHandler', 'Rape Player detected')
            end
        end
        Wait(1000) 
    end
end)

--------------------------------------------------------
-- ANTI THROW VEHICLE
--------------------------------------------------------

---------------------------------------------------------------------------------
-- ANTI THROW VEHICLE (Vehicle Throw & Slingshot Detection)
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Throw Vehicle') then return end
    
    local __v_data = {}
    -- MEMORY OPT: deterministic eviction replaces the previous
    -- `if math.random(1,100) > 95 then __v_data = {} end` random reset (which
    -- on average wiped state ~every 30s but could let entries accumulate
    -- arbitrarily long in a bad-luck streak). Each tick we evict entries
    -- older than `__v_data_max_age_ms`. The retention window (60s) is
    -- comfortably longer than the original ~30s average, so no entry is
    -- forgotten sooner than before and the detection physics (accel from
    -- prev.t) is identical.
    local __v_data_max_age_ms = 60000
    
    while true do
        Wait(1500)
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) or IsEntityDead(ped) then goto continue end
        
        local p_coords = GetEntityCoords(ped)
        local vehicles = AS_GetPool('CVehicle')
        local now = GetGameTimer()

        for _, veh in ipairs(vehicles) do
            if DoesEntityExist(veh) then
                -- Check ownership to prevent false bans
                if NetworkGetEntityOwner(veh) ~= PlayerId() then
                    goto continue
                end

                local v_coords = GetEntityCoords(veh)
                local dist = #(v_coords - p_coords)
                
                -- Only check vehicles within a reasonable distance to save performance
                if dist < 60.0 then
                    local driver = GetPedInVehicleSeat(veh, -1)
                    local speed = GetEntitySpeed(veh)
                    local velocity = GetEntityVelocity(veh)
                    local attached = GetEntityAttachedTo(veh)
                    
                    -- 1. SLINGSHOT DETECTION: If a vehicle is attached to the player (common throw method)
                    if attached == ped and not IsPedInAnyVehicle(ped, false) then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Throw Vehicle: Slingshot Attempt')
                        DeleteEntity(veh)
                        goto continue
                    end

                    -- 2. UNNATURAL VELOCITY SPIKE (Velocity Spike Detection)
                    local v_id = tostring(veh)
                    local prev = __v_data[v_id]
                    
                    if not prev then
                        -- MEMORY OPT: allocate the per-vehicle state table ONCE; subsequent
                        -- ticks mutate it in place (was: `__v_data[v_id] = { v=..., s=..., t=...}`
                        -- on every touch, allocating a fresh table per vehicle per 1500ms tick).
                        __v_data[v_id] = { v = velocity, s = speed, t = now }
                    else
                        local accel = #(velocity - prev.v)
                        local dt = (now - prev.t) / 1000.0
                        
                        -- If speed is extreme and there is no driver
                        if speed > 45.0 and not DoesEntityExist(driver) and not IsEntityInWater(veh) then
                            -- Check if it was a sudden unnatural force
                            if accel > 25.0 then
                                SafeTriggerServerEvent('VexShield:banHandler', 'Throw Vehicle: Unnatural Impulse Detected (Speed: '..math.floor(speed)..')')
                                DeleteEntity(veh)
                                goto continue
                            end
                        end
                        
                        -- 3. SUSANO/KEYSER "VEHICLE RAIN" OR "LAUNCH" DETECTION
                        -- If vehicle is launched vertically without a driver
                        if math.abs(velocity.z) > 35.0 and not DoesEntityExist(driver) and dist < 15.0 then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Throw Vehicle: Vertical Launch Detected')
                            DeleteEntity(veh)
                            goto continue
                        end

                        -- MEMORY OPT: in-place mutation (was a fresh table allocation per call).
                        prev.v = velocity
                        prev.s = speed
                        prev.t = now
                    end
                end
            end
        end
        
        -- MEMORY OPT: deterministic eviction (was: random 5%-chance full wipe).
        -- Walks the bounded vehicle-state map ONCE per 1500ms tick and nils out
        -- entries older than __v_data_max_age_ms. Behaviour matches the previous
        -- intent (forget stale per-vehicle history) but is now predictable —
        -- nothing is retained for less time than the random version's avg.
        for vid, entry in pairs(__v_data) do
            if not entry or (now - (entry.t or 0)) > __v_data_max_age_ms then
                __v_data[vid] = nil
            end
        end
        
        ::continue::
    end
end)
-- print("working client laast4")

-- print("CLIENT CHECK 10.8")

-- print("working client laaste3")

--------------------------------------------------------
-- ANTI NoReload (Enhanced)
--------------------------------------------------------

local noReloadLastClip = {}
local noReloadFlags = {}
local noReloadLastShotTime = {}
local noReloadIgnoredWeapons = {
    [GetHashKey("WEAPON_MINIGUN")] = true,
    [GetHashKey("WEAPON_RAYMINIGUN")] = true,
    [GetHashKey("WEAPON_UNARMED")] = true,
    [GetHashKey("WEAPON_STUNGUN")] = true,
    [GetHashKey("WEAPON_FLAREGUN")] = true,
    [GetHashKey("WEAPON_FIREEXTINGUISHER")] = true,
    [GetHashKey("WEAPON_PETROLCAN")] = true,
    [GetHashKey("WEAPON_HAZARDCAN")] = true,
    [GetHashKey("WEAPON_FERTILIZERCAN")] = true,
}

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti NoReload') then return end
    
    while true do
        Citizen.Wait(100)
        
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) or IsEntityDead(ped) then
            Wait(500)
            goto continue
        end
        
        if IsPedShooting(ped) then
            local weapon = GetSelectedPedWeapon(ped)
            
            if noReloadIgnoredWeapons[weapon]
                or not IsPedArmed(ped, 6)
                or IsPedInAnyVehicle(ped, false)
                or IsPauseMenuActive()
                or IsNuiFocused()
                or IsNuiFocusKeepingInput()
                or not IsPlayerControlOn(PlayerId())
                or IsPedReloading(ped) then
                goto continue
            end
            
            local success, clip = GetAmmoInClip(ped, weapon)
            local currentTime = GetGameTimer()
            if not success then
                goto continue
            end
            
            if noReloadLastClip[weapon] ~= nil and noReloadLastShotTime[weapon] ~= nil then
                local timeSinceLastShot = currentTime - noReloadLastShotTime[weapon]
                
                -- Only flag repeated shots where clip never drops, with sane cadence and usable clip size.
                if clip >= noReloadLastClip[weapon]
                    and noReloadLastClip[weapon] > 1
                    and timeSinceLastShot >= 120
                    and timeSinceLastShot <= 1500 then
                    noReloadFlags[weapon] = (noReloadFlags[weapon] or 0) + 1
                    
                    if noReloadFlags[weapon] >= 5 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'NoReload Detected')
                        noReloadFlags[weapon] = 0
                    end
                else
                    noReloadFlags[weapon] = 0
                end
            end
            
            noReloadLastClip[weapon] = clip
            noReloadLastShotTime[weapon] = currentTime
        end
        
        ::continue::
    end
end)

-- print("working client laaste2")

--------------------------------------------------------
-- ANTI EXPLOSION BULLET
--------------------------------------------------------

CreateThread(function()

    if not VexShieldIsProtectionOn('Anti Explosion Bullet') then return end

    local weaponHash = GetSelectedPedWeapon(PlayerPedId())
    local validWeaponDamage = {4, 5, 6, 13}
    while true do
        Wait(500)
        local currentWeaponHash = GetSelectedPedWeapon(PlayerPedId())
        if currentWeaponHash ~= weaponHash then
            weaponHash = currentWeaponHash
        end
        local weapondamage = GetWeaponDamageType(weaponHash)
        for _, wp in pairs(validWeaponDamage) do
        if wp == weapondamage then
            SafeTriggerServerEvent('VexShield:banHandler', 'Explosive Bullets detected')
            -- print("bullets")
        end
    end
end
end)
-- print("working client1")

--------------------------------------------------------
-- ANTI CRASH INTEGRITY
--------------------------------------------------------

AddStateBagChangeHandler(nil, nil, function(bagName, key, value) 
    if #key > 131072 then
        sendScreenshot("Crash Server detected", "N/A")
        while true do
            Wait(1000)
        end
    end
end)

-- print("CLIENT CHECK 10.9")

--------------------------------------------------------
-- ANTI GLOBAL VOICE
--------------------------------------------------------
CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Global Voice') then return end
    local windows = 0
    while true do
        Wait(3000)
        local myPed = PlayerPedId()
        local myCoords = GetEntityCoords(myPed)
        local players = GetActivePlayers()
        local farTalkers = 0
        for i=1,#players do
            local pid = players[i]
            if pid ~= PlayerId() and NetworkIsPlayerTalking(pid) then
                local ped = GetPlayerPed(pid)
                local coords = GetEntityCoords(ped)
                if #(coords - myCoords) > 200.0 then
                    farTalkers = farTalkers + 1
                end
            end
        end
        if farTalkers >= 3 then
            windows = windows + 1
            if windows >= 3 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Global Voice Detected')
                windows = 0
            end
        else
            windows = 0
        end
        if MumbleIsConnected then
            pcall(function()
                MumbleSetAudioInputDistance(15.0)
                MumbleSetAudioOutputDistance(30.0)
            end)
        end
    end
end)

--------------------------------------------------------
-- ANTI LUA FREEZE
--------------------------------------------------------
CreateThread(function()
    while true do
        Wait(1000)
        if not VexShieldIsProtectionOn('Anti Lua Freeze') then
            return
        end
        local ped = PlayerPedId()
        if IsEntityPlayingAnim(ped, "reaction@shove", "shoved_back", 3) then
            FreezeEntityPosition(ped, false)
            StopAnimTask(ped, "reaction@shove", "shoved_back", 3)
            ClearPedTasks(ped)
        end
    end
end)

--------------------------------------------------------
-- ANTI LAUNCH/FLY VEHICLE (local player only — avoids GetActivePlayers every tick)
--------------------------------------------------------
local airTimeByNetId = {}
local airTimeLastMs = {}
local minimumFlyHeight = 100.0
local flyAirSecondsRequired = 2.8
local flyPollActiveMs = 1000
local flyAirPruneEveryMs = 30000
local flyAirLastPruneMs = 0

function pruneFlyAirTime(nowMs)
    for netId, startedMs in pairs(airTimeLastMs) do
        if nowMs - startedMs > 60000 then
            airTimeLastMs[netId] = nil
            airTimeByNetId[netId] = nil
        end
    end
end

function checkLocalFlyVehicle(nowMs)
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then
        return
    end
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 or not DoesEntityExist(veh) then
        return
    end
    local vehClass = GetVehicleClass(veh)
    if vehClass == 15 or vehClass == 16 then
        return
    end
    local netId = VehToNet(veh)
    if not netId or netId == 0 then
        return
    end
    local coords = GetEntityCoords(veh)
    if coords.z < minimumFlyHeight then
        airTimeByNetId[netId] = 0
        airTimeLastMs[netId] = nil
        return
    end
    if IsVehicleOnAllWheels(veh) then
        airTimeByNetId[netId] = 0
        airTimeLastMs[netId] = nil
        return
    end
    local startedMs = airTimeLastMs[netId]
    if not startedMs then
        airTimeLastMs[netId] = nowMs
        airTimeByNetId[netId] = 0
        startedMs = nowMs
    end
    airTimeByNetId[netId] = (nowMs - startedMs) / 1000.0
    if airTimeByNetId[netId] > flyAirSecondsRequired then
        local foundGround, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + 50.0, 0)
        if foundGround then
            SetEntityCoords(veh, coords.x, coords.y, groundZ + 1.0, false, false, false, false)
        end
        airTimeByNetId[netId] = 0
        airTimeLastMs[netId] = nil
    end
end

CreateThread(function()
    while true do
        if not VexShieldIsProtectionOn('Anti Launch/Fly Vehicle') then
            Wait(VexShieldClientState.pollIdleMs)
        else
            Wait(flyPollActiveMs)
            local nowMs = GetGameTimer()
            checkLocalFlyVehicle(nowMs)
            if nowMs - flyAirLastPruneMs >= flyAirPruneEveryMs then
                pruneFlyAirTime(nowMs)
                flyAirLastPruneMs = nowMs
            end
        end
    end
end)

--------------------------------------------------------
-- ANTI NPC HIJACK
--------------------------------------------------------

function isNPCInvisible(ped)
    local visible = IsEntityVisible(ped)
    local alpha = GetEntityAlpha(ped)

    -- Beschouw als verdacht als NPC niet zichtbaar is of volledig transparant
    return not visible or alpha == 0
end

-- Zoek voertuigen in een gebied rondom de speler
function GetVehiclesInArea(position, radius)
    local vehicles = {}
    local handle, vehicle = FindFirstVehicle()
    local success

    repeat
        if vehicle and Vdist(position, GetEntityCoords(vehicle)) < radius then
            table.insert(vehicles, vehicle)
        end
        success, vehicle = FindNextVehicle(handle)
    until not success

    EndFindVehicle(handle)
    return vehicles
end

function detectInvisibleNPCVehicleHijack()
    local playerPed = PlayerPedId()
    local playerPos = GetEntityCoords(playerPed)
    local vehicles = GetVehiclesInArea(playerPos, 100.0)

    for _, vehicle in ipairs(vehicles) do
        local driver = GetPedInVehicleSeat(vehicle, -1)

        if driver and not IsPedAPlayer(driver) then
            if isNPCInvisible(driver) then
                -- Disabled destructive behavior due repeated false positives on streamed traffic.
                -- Keep detection hook without removing driver entities.
            end
        end
    end
end

-- Laat dit elke 5 seconden lopen als bescherming aanstaat
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5000)

        if VexShieldIsProtectionOn('Anti Npc Hijack') then
            -- print("npc zooie")
            detectInvisibleNPCVehicleHijack()
        end
    end
end)

--------------------------------------------------------
-- ANTI AGGRESIVE PEDS
--------------------------------------------------------

CreateThread(function()
        if not VexShieldIsProtectionOn('Anti Aggresive Peds') then
        return
    end
    while true do
        Wait(5000) -- elke 5 seconden

        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        local peds = AS_GetPool('CPed')
        for _, ped in pairs(peds) do
            if DoesEntityExist(ped) and not IsPedAPlayer(ped) and not isProtectedTrafficPed(ped) and not IsPedInAnyVehicle(ped, true) and not IsPedInAnyVehicle(ped, false) then
                local pedCoords = GetEntityCoords(ped)
                local distance = #(playerCoords - pedCoords)

                if distance < 100.0 then -- alleen in de buurt van de speler
                    local rel = GetRelationshipBetweenGroups(GetPedRelationshipGroupHash(ped), GetPedRelationshipGroupHash(playerPed))
                    
                    if rel == 5 or rel == 4 then -- 5 = hostile, 4 = hate
                        DeleteEntity(ped)
                    end
                end
            end
        end
    end
end)

-- [VEX-INTERNAL-CORE: 0x9F4C2A-C8930194825]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

-- Anti Object Spawn / blacklisted props: handled server-side only (server/main.lua)

--------------------------------------------------------
-- ANTI SPOOFED DAMAGE (gameEventTriggered logic)
--   A "spoofed damage" is when the local player deals damage at range with
--   a weapon hash they don't / didn't recently equip while showing UNARMED.
--   Many legitimate situations look the same on the wire (in-flight bullets
--   after weapon swap, grenades exploding after switch, sticky bombs detonated
--   later, taser stuns, environmental damage). We filter all of these and
--   require a multi-event pattern + cooldown before banning.
--------------------------------------------------------

-- Hashes that are *projectile* / *explosive* / *area* damage. These naturally
-- generate damage events while the player is no longer holding the weapon.
local SPOOF_DMG_PROJECTILE_HASHES = {
    [GetHashKey("WEAPON_EXPLOSION")]            = true,
    [GetHashKey("WEAPON_GRENADE")]              = true,
    [GetHashKey("WEAPON_STICKYBOMB")]           = true,
    [GetHashKey("WEAPON_PROXMINE")]             = true,
    [GetHashKey("WEAPON_PIPEBOMB")]             = true,
    [GetHashKey("WEAPON_MOLOTOV")]              = true,
    [GetHashKey("WEAPON_BZGAS")]                = true,
    [GetHashKey("WEAPON_SMOKEGRENADE")]         = true,
    [GetHashKey("WEAPON_FLARE")]                = true,
    [GetHashKey("WEAPON_FIREEXTINGUISHER")]     = true,
    [GetHashKey("WEAPON_PETROLCAN")]            = true,
    [GetHashKey("WEAPON_HAZARDCAN")]            = true,
    [GetHashKey("WEAPON_FIREWORK")]             = true,
    [GetHashKey("WEAPON_BALL")]                 = true,
    [GetHashKey("WEAPON_SNOWBALL")]             = true,
    [GetHashKey("WEAPON_FLAREGUN")]             = true,
    [GetHashKey("WEAPON_RPG")]                  = true,
    [GetHashKey("WEAPON_GRENADELAUNCHER")]      = true,
    [GetHashKey("WEAPON_GRENADELAUNCHER_SMOKE")]= true,
    [GetHashKey("WEAPON_HOMINGLAUNCHER")]       = true,
    [GetHashKey("WEAPON_COMPACTLAUNCHER")]      = true,
    [GetHashKey("WEAPON_RAYMINIGUN")]           = true,
    [GetHashKey("WEAPON_STUNGUN")]              = true, -- darts in flight after swap
    [GetHashKey("WEAPON_FIRE")]                 = true,
    [GetHashKey("WEAPON_DROWNING")]             = true,
    [GetHashKey("WEAPON_DROWNING_IN_VEHICLE")]  = true,
    [GetHashKey("WEAPON_FALL")]                 = true,
    [GetHashKey("WEAPON_RAMMED_BY_CAR")]        = true,
    [GetHashKey("WEAPON_RUN_OVER_BY_CAR")]      = true,
    [GetHashKey("WEAPON_HELI_CRASH")]           = true,
}

local SPOOF_DMG_EXEMPT_GROUPS = {
    [GetHashKey("GROUP_THROWN")] = true,
    [GetHashKey("GROUP_HEAVY")]  = true,
}

function spoofDmgIsProjectileOrExempt(h)
    if not h or h == 0 then return true end -- invalid hash, skip
    if SPOOF_DMG_PROJECTILE_HASHES[h] then return true end
    local group = GetWeapontypeGroup(h)
    if group and SPOOF_DMG_EXEMPT_GROUPS[group] then return true end
    return false
end

-- Sliding-window state for the local player
local spoofDmgData = {
    lastWeaponSwapTime = 0,
    lastWeapon         = 0,
    weaponHistory      = {},  -- {hash, time} kept ~6 seconds
    lastShotTime       = 0,
    suspiciousEvents   = {},  -- {time, hash} kept ~10 seconds
    lastBanTime        = 0,
}

function spoofDmgPushWeapon(h)
    local now = GetGameTimer()
    spoofDmgData.weaponHistory[#spoofDmgData.weaponHistory + 1] = { hash = h, time = now }
    while #spoofDmgData.weaponHistory > 0
        and now - spoofDmgData.weaponHistory[1].time > 6000 do
        table.remove(spoofDmgData.weaponHistory, 1)
    end
end

function spoofDmgWasRecentlyEquipped(h)
    if not h then return false end
    for i = 1, #spoofDmgData.weaponHistory do
        if spoofDmgData.weaponHistory[i].hash == h then return true end
    end
    return false
end

-- Light tracker thread: weapon swaps + shot timestamps
CreateThread(function()
    waitUntilReady()
    local ped = PlayerPedId()
    spoofDmgData.lastWeapon = GetSelectedPedWeapon(ped)
    spoofDmgPushWeapon(spoofDmgData.lastWeapon)
    while true do
        Citizen.Wait(120)
        if VexShieldIsProtectionOn('Anti Spoofed Damage/Weapon') then
            ped = PlayerPedId()
            local w = GetSelectedPedWeapon(ped)
            if w ~= spoofDmgData.lastWeapon then
                spoofDmgData.lastWeaponSwapTime = GetGameTimer()
                spoofDmgPushWeapon(w)
                spoofDmgData.lastWeapon = w
            end
            if IsPedShooting(ped) then
                spoofDmgData.lastShotTime = GetGameTimer()
            end
        end
    end
end)

AddEventHandler("gameEventTriggered", function(name, data)
    if name ~= "CEventNetworkEntityDamage" then return end
    if not VexShieldIsProtectionOn('Anti Spoofed Damage/Weapon') then
        return
    end

    local victim   = data and data[1]
    local attacker = data and data[2]
    local hash     = data and data[5]

    if not attacker or attacker == 0 or not hash or hash == 0 then return end

    local ped = PlayerPedId()
    if attacker ~= ped then return end             -- only local outgoing damage
    if attacker == victim then return end          -- self-damage / fall / drown
    if not DoesEntityExist(victim) then return end -- stale / despawned

    -- Hard skip on contexts where the engine fires bogus damage events
    if IsPedInAnyVehicle(ped, false) then return end
    if IsPedRagdoll(ped) then return end
    if IsPedDeadOrDying(ped, true) then return end
    if IsEntityInWater(ped) then return end
    if GetPedParachuteState(ped) > 0 then return end
    if NetworkIsInSpectatorMode and NetworkIsInSpectatorMode() then return end

    local now = GetGameTimer()

    -- 1) Weapon-swap grace (in-flight bullets after holster / swap)
    if now - spoofDmgData.lastWeaponSwapTime < 2000 then return end

    -- 2) Projectile / explosive / environmental hashes are exempt: a grenade
    --    thrown earlier WILL detonate after we've switched to UNARMED.
    if spoofDmgIsProjectileOrExempt(hash) then return end

    -- 3) Local sanity: must be unarmed RIGHT NOW and not recently shooting,
    --    AND the damaging hash must NOT match any weapon we equipped recently.
    local currentWeapon = GetSelectedPedWeapon(ped)
    local unarmedHash   = GetHashKey('WEAPON_UNARMED')
    local isUnarmedNow  = (currentWeapon == unarmedHash) and not IsPedArmed(ped, 6)
    if not isUnarmedNow then return end
    if spoofDmgWasRecentlyEquipped(hash) then return end -- legit in-flight bullet
    if hash == unarmedHash then return end               -- punches are legit

    -- 4) Player must not be shooting / have shot in the last 1.5s
    --    (animations + fire-rate quirks can echo events for real shots)
    if now - spoofDmgData.lastShotTime < 1500 then return end

    -- 5) Distance: spoofed damage uses arbitrary range; keep a moderate floor
    --    to exclude melee glitches but not so high that we miss real abuse.
    local dist = #(GetEntityCoords(victim) - GetEntityCoords(ped))
    if dist < 8.0 then return end

    -- 6) Require pattern: 2 suspicious events within 10 s before banning
    spoofDmgData.suspiciousEvents[#spoofDmgData.suspiciousEvents + 1] = {
        time = now, hash = hash
    }
    for i = #spoofDmgData.suspiciousEvents, 1, -1 do
        if now - spoofDmgData.suspiciousEvents[i].time > 10000 then
            table.remove(spoofDmgData.suspiciousEvents, i)
        end
    end
    if #spoofDmgData.suspiciousEvents < 2 then return end

    -- 7) Ban cooldown so a multi-pellet / network-replay event cannot spam
    if now - spoofDmgData.lastBanTime < 30000 then return end
    spoofDmgData.lastBanTime = now
    spoofDmgData.suspiciousEvents = {}

    SafeTriggerServerEvent('VexShield:banHandler', 'Spoofed Damage Detected')
end)

 
RegisterNetEvent('clearAllProps')
AddEventHandler('clearAllProps', function()
    local handle, object = FindFirstObject()
    local finished = false

    repeat
        if DoesEntityExist(object) then
            local model = GetEntityModel(object)
            if IsEntityAnObject(object) and not IsPedAPlayer(object) then
                DeleteEntity(object)
            end
        end
        finished, object = FindNextObject(handle)
    until not finished

    EndFindObject(handle)
end)

--------------------------------------------------------
-- ANTI FREECAM
--------------------------------------------------------

MAX_FREECAM_FLAGS          = 4
FLAG_INTERVAL_MS           = 1000
FLAG_RESET_TIME_MS         = 12000
SPAWN_GRACE_PERIOD_MS      = 15000
MAX_FREECAM_DISTANCE       = 25.0
MAX_FREECAM_HARD_DISTANCE  = 120.0

blackscreenWhitelist = blackscreenWhitelist or false
VexShieldFreecamLastCamCoords = VexShieldFreecamLastCamCoords or nil
VexShieldFreecamLastPedCoords = VexShieldFreecamLastPedCoords or nil

function isFreecamProtectionEnabled()
    return VexShieldIsProtectionOn('Anti Freecam')
        or VexShieldIsProtectionOn('Anti Freecam2')
        or VexShieldIsProtectionOn('Anti Freecam3')
        or VexShieldIsProtectionOn('Anti Freecam #4')
end

function initializePlayerState()
    local state = LocalPlayer.state
    state.spawnTime = state.spawnTime or 0
    state.freecamFlags = state.freecamFlags or 0
    state.lastFreecamFlagTime = state.lastFreecamFlagTime or 0
end

AddEventHandler("onClientResourceStart", function(resource)
    if resource == GetCurrentResourceName() then
        initializePlayerState()
    end
end)

AddEventHandler('playerSpawned', function()
    local state = LocalPlayer.state
    state.spawnTime = GetGameTimer()
    state.freecamFlags = 0
    state.lastFreecamFlagTime = 0
end)

function spawnGraceExpired()
    local spawnTime = LocalPlayer.state.spawnTime or 0
    return (GetGameTimer() - spawnTime) > SPAWN_GRACE_PERIOD_MS
end

function resetFreecamFlags()
    local state = LocalPlayer.state
    state.freecamFlags = 0
    state.lastFreecamFlagTime = 0
end

function punishFreecam()
    if isExempt or (VexShieldClientState and VexShieldClientState.isExempt) then return end
    if not isFreecamProtectionEnabled() then return end
    if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then return end
    RenderScriptCams(false, true, 0, true, true)
    SetFollowPedCamViewMode(1)
    SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected")
    resetFreecamFlags()
end

---------------------------------------------------------------------------------
-- ADVANCED MULTI-SIGNAL ANTI FREECAM ENGINE (FREECAM 1 TO 6)
---------------------------------------------------------------------------------

local hasPlayerLoaded = false
CreateThread(function()
    while not NetworkIsSessionStarted() or (not IsPedInAnyVehicle(PlayerPedId(), false) and GetEntityModel(PlayerPedId()) == 0) or not IsScreenFadedIn() do
        Wait(1000)
    end
    hasPlayerLoaded = true
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #1: Zero Distance & Hard Distance Separation
-- ─────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while true do
        Wait(500)
        if not VexShieldIsProtectionOn('Anti Freecam') then
            Wait(2000)
            goto continue
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto continue end

        if hasPlayerLoaded then
            local ped = PlayerPedId()
            if DoesEntityExist(ped) then
                if IsPedInAnyVehicle(ped, false) or IsPedFalling(ped) or IsPedRagdoll(ped) or IsPedDeadOrDying(ped, true) or IsEntityAttached(ped) or IsCutsceneActive() or IsPauseMenuActive() then
                    goto continue
                end

                local camCoords = GetFinalRenderedCamCoord()
                local pedCoords = GetEntityCoords(ped)
                local distance = #(camCoords - pedCoords)
                if distance < 0.01 or distance > 120.0 then
                    if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then goto continue end
                    SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected")
                end
            end
        end
        ::continue::
    end
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #2: Camera Offset & Signature Detection
-- ─────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while true do
        Wait(1000)
        if not VexShieldIsProtectionOn('Anti Freecam2') then
            Wait(2000)
            goto continue
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto continue end

        if hasPlayerLoaded then
            local playerPed = PlayerPedId()
            if DoesEntityExist(playerPed) then
                if IsPedInAnyVehicle(playerPed, false) or IsPedFalling(playerPed) or IsPedRagdoll(playerPed) or IsPedDeadOrDying(playerPed, true) or IsEntityAttached(playerPed) or IsCutsceneActive() or IsPauseMenuActive() then
                    goto continue
                end

                local camCoords = GetGameplayCamCoord()
                local playerCoords = GetEntityCoords(playerPed)
                local distance = #(playerCoords - camCoords)
                if math.abs(distance - 0.71) < 0.01 or (GetRenderingCam() ~= -1 and distance > 25.0) then
                    if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then goto continue end
                    SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #2")
                end
            end
        end
        ::continue::
    end
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #3: Camera Distance + Raycast + Interior Mismatch + Invisibility
-- ─────────────────────────────────────────────────────────────────────────────
local camdisthres = 7.26
local raydisthres = 10.0
local collcheckintv = 3000
local maxdetect = 3

local dectcount = 0
local lastcolcheck = 0

local function CheckCameraDistance(pedCoords)
    local camCoordsFinal = GetFinalRenderedCamCoord()
    local distFinal = #(camCoordsFinal - pedCoords)
    local camCoordsGame = GetGameplayCamCoord()
    local distGameplay = #(camCoordsGame - pedCoords)
    return math.max(distFinal, distGameplay)
end

local function CheckRaycast(pedCoords, camCoords)
    local rayHandle = StartShapeTestRay(
        camCoords.x, camCoords.y, camCoords.z,
        pedCoords.x, pedCoords.y, pedCoords.z,
        -1,
        PlayerPedId(),
        0
    )
    local _, didHit = GetShapeTestResult(rayHandle)
    local dist = #(camCoords - pedCoords)
    if dist > raydisthres and not didHit then
        return true
    end
    return false
end

CreateThread(function()
    while not configLoaded do Wait(250) end

    while true do
        Wait(1000)
        if not VexShieldIsProtectionOn('Anti Freecam3') then
            Wait(2000)
            goto continue
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto continue end

        local playerPed = PlayerPedId()
        if DoesEntityExist(playerPed) then
            local pedCoords = GetEntityCoords(playerPed, false)
            local maxDistance = CheckCameraDistance(pedCoords)
            if maxDistance > camdisthres then
                dectcount = dectcount + 1
            else
                if dectcount > 0 then
                    dectcount = dectcount - 1
                end
            end

            local pedInterior = GetInteriorFromEntity(playerPed)
            local camCoordsFinal = GetFinalRenderedCamCoord()
            local camInterior = GetInteriorAtCoords(camCoordsFinal.x, camCoordsFinal.y, camCoordsFinal.z)

            if pedInterior ~= 0 and camInterior ~= 0 and pedInterior ~= camInterior then
                dectcount = dectcount + 1
            end

            local suspiciousRay = CheckRaycast(pedCoords, camCoordsFinal)
            if suspiciousRay then
                dectcount = dectcount + 1
            end

            if (GetGameTimer() - lastcolcheck) > collcheckintv then
                lastcolcheck = GetGameTimer()
                if not IsEntityVisible(playerPed) then
                    dectcount = dectcount + 2
                end
            end

            if dectcount >= maxdetect then
                if GetVehiclePedIsIn(playerPed, false) == 0 then
                    if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then goto continue end
                    SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to exploit freecam')
                end
                dectcount = 0
            end
        end

        ::continue::
    end
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #4: Script Cam & Cam/Ped Delta Motion Tracking
-- ─────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while not configLoaded do Wait(250) end

    local notRenderingTicks = 0
    local camMoveTicks      = 0
    local lastCamCoords     = nil
    local lastPedCoords     = nil
    local cooldown          = 0

    while true do
        Wait(500)
        if not VexShieldIsProtectionOn('Anti Freecam #4') and not VexShieldIsProtectionOn('Anti Freecam4') then
            Wait(2000)
            goto fc4cont
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto fc4cont end

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto fc4cont end
        if IsPedDeadOrDying(ped, true) then notRenderingTicks = 0; camMoveTicks = 0; goto fc4cont end
        if IsCutsceneActive() then notRenderingTicks = 0; camMoveTicks = 0; goto fc4cont end
        if IsPauseMenuActive() then goto fc4cont end
        if IsPlayerSwitchInProgress() then goto fc4cont end
        if not IsScreenFadedIn() then goto fc4cont end
        if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then goto fc4cont end

        -- SIGNAL A: IsGameplayCamRendering Check
        if not IsGameplayCamRendering() then
            notRenderingTicks = notRenderingTicks + 1
        else
            notRenderingTicks = math.max(0, notRenderingTicks - 1)
        end

        if notRenderingTicks >= 4 then
            notRenderingTicks = 0
            local now = GetGameTimer()
            if now - cooldown > 20000 then
                cooldown = now
                SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #4")
            end
            goto fc4cont
        end

        -- SIGNAL B: Camera moves while Ped remains stationary
        local camCoords = GetFinalRenderedCamCoord()
        local pedCoords = GetEntityCoords(ped)

        if lastCamCoords and lastPedCoords then
            local camDelta = #(camCoords - lastCamCoords)
            local pedDelta = #(pedCoords - lastPedCoords)

            local inVeh = IsPedInAnyVehicle(ped, false)
            local inParachute = GetPedParachuteState(ped) ~= -1

            if not inVeh and not inParachute then
                if camDelta > 3.0 and pedDelta < 0.3 then
                    camMoveTicks = camMoveTicks + 1
                else
                    camMoveTicks = math.max(0, camMoveTicks - 1)
                end

                if camMoveTicks >= 5 then
                    camMoveTicks = 0
                    local now = GetGameTimer()
                    if now - cooldown > 20000 then
                        cooldown = now
                        SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #4")
                    end
                end
            else
                camMoveTicks = 0
            end
        end

        lastCamCoords = camCoords
        lastPedCoords = pedCoords

        ::fc4cont::
    end
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #5: Follow-Cam Zoom Anomaly & Cam Facing Vector Angle
-- ─────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while not configLoaded do Wait(250) end

    local suspTicks = 0
    local cooldown  = 0

    while true do
        Wait(500)
        if not VexShieldIsProtectionOn('Anti Freecam #5') and not VexShieldIsProtectionOn('Anti Freecam5') then
            Wait(2000)
            goto fc5cont
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto fc5cont end

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto fc5cont end
        if IsPedDeadOrDying(ped, true) then suspTicks = 0; goto fc5cont end
        if IsCutsceneActive() then suspTicks = 0; goto fc5cont end
        if IsPauseMenuActive() then suspTicks = 0; goto fc5cont end
        if not IsScreenFadedIn() then suspTicks = 0; goto fc5cont end
        if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then suspTicks = 0; goto fc5cont end
        if IsPedInAnyVehicle(ped, false) then suspTicks = 0; goto fc5cont end
        if GetPedParachuteState(ped) ~= -1 then suspTicks = 0; goto fc5cont end

        local camCoords  = GetGameplayCamCoord()
        local pedCoords  = GetEntityCoords(ped)
        local camRot     = GetGameplayCamRot(2)

        local rx = math.rad(camRot.x)
        local rz = math.rad(camRot.z)
        local camFwd = vector3(
            -math.sin(rz) * math.cos(rx),
             math.cos(rz) * math.cos(rx),
             math.sin(rx)
        )

        local camToPed = vector3(
            pedCoords.x - camCoords.x,
            pedCoords.y - camCoords.y,
            pedCoords.z - camCoords.z
        )
        local ctpLen = #(camToPed)

        local suspicious = false

        if ctpLen > 1.0 then
            local normX, normY, normZ = camToPed.x / ctpLen, camToPed.y / ctpLen, camToPed.z / ctpLen
            local dot = camFwd.x * normX + camFwd.y * normY + camFwd.z * normZ
            if dot > 1.0 then dot = 1.0 end
            if dot < -1.0 then dot = -1.0 end
            local acosVal = math.acos(dot)
            if acosVal then
                local angle = math.deg(acosVal)
                if angle > 100.0 and ctpLen > 8.0 then
                    local ray = StartShapeTestRay(
                        camCoords.x, camCoords.y, camCoords.z,
                        pedCoords.x, pedCoords.y, pedCoords.z,
                        1, ped, 0
                    )
                    local _, hit = GetShapeTestResult(ray)
                    if hit == 1 then
                        suspicious = true
                    end
                end
            end
        end

        if suspicious then
            suspTicks = suspTicks + 1
        else
            suspTicks = math.max(0, suspTicks - 1)
        end

        if suspTicks >= 6 then
            suspTicks = 0
            local now = GetGameTimer()
            if now - cooldown > 20000 then
                cooldown = now
                SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #5")
            end
        end

        ::fc5cont::
    end
end)

-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #6: Multi-Layer Distance + Raycast + Facing Angle + Input Override
-- ─────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while not configLoaded do Wait(250) end

    local suspTicks    = 0
    local cooldown     = 0
    local prevCamRot   = nil
    local prevCamCoord = nil

    local MAX_CAM_DISTANCE   = 20.0
    local RAYCAST_THRESHOLD   = 3
    local FACING_ANGLE_THRESH = 100.0
    local INPUT_OVERRIDE_TICKS = 4
    local ROT_SPEED_THRESH    = 15.0
    local CONSECUTIVE_TICKS   = 5

    local wallPenCount = 0
    local inputOverrideCount = 0

    while true do
        Wait(100)
        if not VexShieldIsProtectionOn('Anti Freecam #6') and not VexShieldIsProtectionOn('Anti Freecam6') then
            Wait(2000)
            goto fc6cont
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto fc6cont end

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto fc6cont end
        if IsPedDeadOrDying(ped, true) then suspTicks = 0; goto fc6cont end
        if IsCutsceneActive() then suspTicks = 0; goto fc6cont end
        if IsPauseMenuActive() then suspTicks = 0; goto fc6cont end
        if not IsScreenFadedIn() then suspTicks = 0; goto fc6cont end
        if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then suspTicks = 0; goto fc6cont end
        if IsPedInAnyVehicle(ped, false) then suspTicks = 0; goto fc6cont end
        if GetPedParachuteState(ped) ~= -1 then suspTicks = 0; goto fc6cont end
        if IsPlayerSwitchInProgress() then suspTicks = 0; goto fc6cont end

        local camCoord = GetGameplayCamCoord()
        local camRot   = GetGameplayCamRot(2)
        local pedCoord = GetEntityCoords(ped)

        local rx = math.rad(camRot.x)
        local rz = math.rad(camRot.z)
        local camFwd = vector3(
            -math.sin(rz) * math.cos(rx),
             math.cos(rz) * math.cos(rx),
             math.sin(rx)
        )

        local suspicious = false

        -- LAYER 1 — Distance Separation
        local dist = #(pedCoord - camCoord)
        if dist > MAX_CAM_DISTANCE then
            suspicious = true
        end

        -- LAYER 2 — Raycast Wall Penetration
        local ray = StartShapeTestRay(
            pedCoord.x, pedCoord.y, pedCoord.z,
            camCoord.x, camCoord.y, camCoord.z,
            1 + 16,
            ped,
            7
        )
        local _, hit, _, _, _ = GetShapeTestResult(ray)
        if hit == 1 then
            wallPenCount = wallPenCount + 1
            if wallPenCount >= RAYCAST_THRESHOLD then
                suspicious = true
            end
        else
            wallPenCount = 0
        end

        -- LAYER 3 — Camera Facing Direction
        local camToPed = vector3(
            pedCoord.x - camCoord.x,
            pedCoord.y - camCoord.y,
            pedCoord.z - camCoord.z
        )
        local ctpLen = #(camToPed)
        if ctpLen > 1.0 then
            local normX, normY, normZ = camToPed.x / ctpLen, camToPed.y / ctpLen, camToPed.z / ctpLen
            local dot = camFwd.x * normX + camFwd.y * normY + camFwd.z * normZ
            if dot > 1.0 then dot = 1.0 end
            if dot < -1.0 then dot = -1.0 end
            local acosVal = math.acos(dot)
            if acosVal then
                local angle = math.deg(acosVal)
                if angle > FACING_ANGLE_THRESH and dist > 8.0 then
                    suspicious = true
                end
            end
        end

        -- LAYER 4 — Input Vector Anomaly
        if prevCamRot and prevCamCoord then
            local rotDeltaX = math.abs(camRot.x - prevCamRot.x)
            local rotDeltaZ = math.abs(camRot.z - prevCamRot.z)
            if rotDeltaX > 180 then rotDeltaX = 360 - rotDeltaX end
            if rotDeltaZ > 180 then rotDeltaZ = 360 - rotDeltaZ end
            local rotSpeed = math.max(rotDeltaX, rotDeltaZ)

            local coordDelta = #(camCoord - prevCamCoord)

            local lookDisabled = (not IsControlEnabled(0, 1)) or (not IsControlEnabled(0, 2))

            if lookDisabled and coordDelta > 0.5 then
                inputOverrideCount = inputOverrideCount + 1
                if inputOverrideCount >= INPUT_OVERRIDE_TICKS then
                    suspicious = true
                end
            elseif rotSpeed > ROT_SPEED_THRESH and dist > 5.0 then
                suspicious = true
            else
                inputOverrideCount = 0
            end
        end

        prevCamRot   = camRot
        prevCamCoord = camCoord

        if suspicious then
            suspTicks = suspTicks + 1
        else
            suspTicks = math.max(0, suspTicks - 1)
        end

        if suspTicks >= CONSECUTIVE_TICKS then
            suspTicks = 0
            local now = GetGameTimer()
            if now - cooldown > 20000 then
                cooldown = now
                SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #6")
            end
        end

        ::fc6cont::
    end
end)





-- ─────────────────────────────────────────────────────────────────────────────
-- ANTI FREECAM #4: Script Cam & Cam/Ped Delta Motion Tracking
-- ─────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while not configLoaded do Wait(250) end

    local notRenderingTicks = 0
    local camMoveTicks      = 0
    local lastCamCoords     = nil
    local lastPedCoords     = nil
    local cooldown          = 0

    while true do
        Wait(500)
        if not VexShieldIsProtectionOn('Anti Freecam #4') and not VexShieldIsProtectionOn('Anti Freecam4') then
            Wait(2000)
            goto fc4cont
        end
        local isAdmin = isExempt or (VexShieldClientState and VexShieldClientState.isExempt)
        if isAdmin or freeCamActive then goto fc4cont end

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto fc4cont end
        if IsPedDeadOrDying(ped, true) then notRenderingTicks = 0; camMoveTicks = 0; goto fc4cont end
        if IsCutsceneActive() then notRenderingTicks = 0; camMoveTicks = 0; goto fc4cont end
        if IsPauseMenuActive() then goto fc4cont end
        if IsPlayerSwitchInProgress() then goto fc4cont end
        if not IsScreenFadedIn() then goto fc4cont end
        if isInFreecamNoclipWhitelist and isInFreecamNoclipWhitelist() then goto fc4cont end

        -- SIGNAL A: IsGameplayCamRendering Check
        if not IsGameplayCamRendering() then
            notRenderingTicks = notRenderingTicks + 1
        else
            notRenderingTicks = math.max(0, notRenderingTicks - 1)
        end

        if notRenderingTicks >= 4 then
            notRenderingTicks = 0
            local now = GetGameTimer()
            if now - cooldown > 20000 then
                cooldown = now
                SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #4")
            end
            goto fc4cont
        end

        -- SIGNAL B: Camera moves while Ped remains stationary
        local camCoords = GetFinalRenderedCamCoord()
        local pedCoords = GetEntityCoords(ped)

        if lastCamCoords and lastPedCoords then
            local camDelta = #(camCoords - lastCamCoords)
            local pedDelta = #(pedCoords - lastPedCoords)

            local inVeh = IsPedInAnyVehicle(ped, false)
            local inParachute = GetPedParachuteState(ped) ~= -1

            if not inVeh and not inParachute then
                if camDelta > 3.0 and pedDelta < 0.3 then
                    camMoveTicks = camMoveTicks + 1
                else
                    camMoveTicks = math.max(0, camMoveTicks - 1)
                end

                if camMoveTicks >= 5 then
                    camMoveTicks = 0
                    local now = GetGameTimer()
                    if now - cooldown > 20000 then
                        cooldown = now
                        SafeTriggerServerEvent("VexShield:banHandler", "Freecam Detected #4")
                    end
                end
            else
                camMoveTicks = 0
            end
        end

        lastCamCoords = camCoords
        lastPedCoords = pedCoords

        ::fc4cont::
    end
end)


-- --- WAVE-SHIELD STYLE ANTI-SPOOF ---
RegisterNUICallback("tokens", function(data, cb)
    local tokens = data.tokens
    if not tokens then return cb({}) end
    
    local hwid, storageId, spooferDetected = tokens.a, tokens.b, tokens.c
    local uidKvp = GetResourceKvpString("__AS_KVP_UID")
    if not uidKvp then
        local chars = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz123456789"
        local randomString = ""
        for i = 1, 64 do
            local rndm = math.random(1, #chars)
            randomString = randomString .. chars:sub(rndm, rndm)
        end
        uidKvp = ("sid2:%s"):format(randomString)
        SetResourceKvp("__AS_KVP_UID", uidKvp)
    end

    if spooferDetected then
        SafeTriggerServerEvent("VexShield:banHandler", "Spoofer Detected (Anti-Spoof)")
    else
        TriggerServerEvent("VexShield:checkExtraIdentifiers", uidKvp, storageId, hwid)
    end
    cb({})
end)

CreateThread(function()
    while not configLoaded do Wait(250) end
    local sd = Shared and Shared.SpoofDetection
    if type(sd) ~= "table" or not sd.WaveNuiEnabled then
        return
    end
    Wait(10000)
    SendNUIMessage({
        action = "GET_TOKENS"
    })
end)
-- --- END OF ANTI-SPOOF ---

-- print("CLIENT CHECK 10 dubbel")

--------------------------------------------------------
-- Blacklisted Particles
--------------------------------------------------------

CreateThread(function()
    while true do
        Wait(1000)

        if not VexShieldIsProtectionOn('Blacklisted Particles') then
            return
        end

        for _, particleName in ipairs(Shared.Client['BlacklistedParticles']) do
            if UseParticleFxAsset(particleName) then
                print("Blacklist particle: " .. particleName)
                SafeTriggerServerEvent("VexShield:banHandler", "Blacklist particle")
                return -- Stop direct bij eerste detectie
            end
        end
    end
end)

-- print("CLIENT CHECK PARTICLE HIER")

local __fcv2_score = 0
local __fcv2_lastCam = nil


-- RegisterCommand("testscreenshot", function()
--     print("^5[DEBUG] /testscreenshot gestart^7")

--     if not exports['screenshot-basic'] then
--         print("^1[ERROR] screenshot-basic export bestaat niet^7")
--         return
--     end

--     exports['screenshot-basic']:requestScreenshot({
--         encoding = 'jpg',
--         upload = false
--     }, function(data)
--         print("^5[DEBUG] Screenshot callback bereikt^7")

--         if not data then
--             print("^1[ERROR] Geen data ontvangen^7")
--             return
--         end

--         if not data.data then
--             print("^1[ERROR] Screenshot mislukt (data.data is nil)^7")
--             return
--         end

--         print("^2[SUCCESS] Screenshot gelukt! Base64 lengte:", #data.data, "^7")
--     end)
-- end)

--------------------------------------------------------
-- Anti SoloSession
--------------------------------------------------------
Citizen.CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Solo Session') then
        return
    end

    while true do  -- Eine Schleife hinzufÃ¼gen, um die ÃœberprÃ¼fung kontinuierlich alle 3 Sekunden auszufÃ¼hren
        Citizen.Wait(3000)  -- Wartezeit auf 3000 Millisekunden (3 Sekunden) setzen
        if not NetworkIsSessionActive() then
            SafeTriggerServerEvent("anticheat:solo", "antisolosession")
        end
    end
end)

-- print("CLIENT CHECK SOLO SESSION HIER")

--------------------------------------------------------
-- Anti Car Speed Hack
--------------------------------------------------------

local maxSpeedBuffer = 80

function GetVehicleSpeedInKmh(vehicle)
    local speed = GetEntitySpeed(vehicle)
    return speed * 3.6
end

function GetVehicleMaxSpeedFromHandling(vehicle)
    return GetVehicleHandlingFloat(vehicle, "CHandlingData", "fInitialDriveMaxFlatVel")
end

Citizen.CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Car Speed Hack') then
        return
    end

    while true do
        Citizen.Wait(1000)
        local playerPed = PlayerPedId()
        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            local handlingMaxSpeed = GetVehicleMaxSpeedFromHandling(vehicle)
            local currentSpeed = GetVehicleSpeedInKmh(vehicle)
            if currentSpeed > (handlingMaxSpeed + maxSpeedBuffer) then
                SafeTriggerServerEvent('antiSpeedHack:kickPlayer', currentSpeed, handlingMaxSpeed)
            end
        end
    end
end)

-- print("CLIENT CHECK CAR HACK HIER")

--------------------------------------------------------
-- Anti Noclip4
--------------------------------------------------------

local noclip4LastCoords = nil
local noclip4Strikes = 0
-- Real noclip "glides": every 1s sample shows movement with ~0 engine speed,
-- sustained for several seconds. A single such sample is almost always a
-- legitimate teleport / respawn / interior or elevator warp / network position
-- correction, so we require consecutive strikes AND ignore single huge jumps.
local NOCLIP4_REQUIRED_STRIKES = 4   -- consecutive 1s samples before a ban
local NOCLIP4_MIN_MOVE = 3.0         -- m of unexplained movement per sample
local NOCLIP4_MAX_MOVE = 100.0       -- a bigger single jump = teleport, not noclip
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    while true do
        if not VexShieldIsProtectionOn('Anti Noclip4') then
            noclip4LastCoords = nil
            noclip4Strikes = 0
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Citizen.Wait(1000)
        if VexShieldIsPlayerInNoclipOrExempt() then
            noclip4Strikes = 0
            goto continue
        end
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local speed = GetEntitySpeed(ped)

        -- States where a position jump is legitimate: reset and re-baseline so the
        -- next sample is never compared across the gap.
        local skip = IsPedInAnyVehicle(ped, false)
            or IsPedFalling(ped)
            or IsPedRagdoll(ped)
            or IsPedJumpingOutOfVehicle(ped)
            or IsEntityAttached(ped)
            or IsPedDeadOrDying(ped, true)
            or IsPedGettingUp(ped)
            or (NetworkIsInSpectatorMode and NetworkIsInSpectatorMode())
            or VexShieldShouldSkipNoclipWater(ped)

        if skip then
            noclip4Strikes = 0
        elseif noclip4LastCoords then
            local movement = #(coords - noclip4LastCoords)
            if speed < 0.5 and movement > NOCLIP4_MIN_MOVE and movement < NOCLIP4_MAX_MOVE then
                noclip4Strikes = noclip4Strikes + 1
                if noclip4Strikes >= NOCLIP4_REQUIRED_STRIKES then
                    SafeTriggerServerEvent("VexShield:banHandler", "Noclip Detected #4")
                    noclip4Strikes = 0
                end
            else
                noclip4Strikes = 0
            end
        end
        noclip4LastCoords = coords
        ::continue::
    end
end)

--------------------------------------------------------
-- Anti Noclip5
--------------------------------------------------------

local noclip5LastCoords = nil
local suspiciousStartTime = nil
local requiredNoclipDuration = 3000 -- 5 seconden voor movement check
local bypassStartTime = nil
local requiredBypassDuration = 3000 -- 3 seconden voor fall bypass check
local susanoStartTime = nil
local requiredSusanoDuration = 2500 -- 3 seconden voor Susano climbing check

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    while true do
        if not VexShieldIsProtectionOn('Anti Noclip5') then
            noclip5LastCoords = nil
            suspiciousStartTime = nil
            bypassStartTime = nil
            susanoStartTime = nil
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end
        Citizen.Wait(1000)
        if VexShieldIsPlayerInNoclipOrExempt() then
            suspiciousStartTime = nil
            bypassStartTime = nil
            susanoStartTime = nil
            goto continue
        end

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local speed = GetEntitySpeed(ped)
        local isInVehicle = IsPedInAnyVehicle(ped, false)
        local heightAboveGround = GetEntityHeightAboveGround(ped)
        local isClimbing = IsPedClimbing(ped)
        local isAttached = IsEntityAttached(ped)

        if not isAttached and isClimbing and heightAboveGround > 0.98 and heightAboveGround < 1.01 and speed > 0.35 then
            if not susanoStartTime then
                susanoStartTime = GetGameTimer()
            elseif GetGameTimer() - susanoStartTime >= requiredSusanoDuration then
                SafeTriggerServerEvent("VexShield:banHandler", "Susano Noclip Detected #5")
                susanoStartTime = nil
            end
        else
            susanoStartTime = nil
        end

        if noclip5LastCoords and not isInVehicle then
            local movement = #(coords - noclip5LastCoords)
            local isSuspicious = not IsPedFalling(ped)
                and not IsPedRagdoll(ped)
                and not IsPedJumpingOutOfVehicle(ped)
                and not isAttached
                and not VexShieldShouldSkipNoclipWater(ped)
                and speed < 0.5
                and movement > 3.0

            if isSuspicious then
                if not suspiciousStartTime then
                    suspiciousStartTime = GetGameTimer()
                elseif GetGameTimer() - suspiciousStartTime >= requiredNoclipDuration then
                    SafeTriggerServerEvent("VexShield:banHandler", "Noclip Detected #5")
                    suspiciousStartTime = nil
                end
            else
                suspiciousStartTime = nil
            end
        else
            suspiciousStartTime = nil
        end
        noclip5LastCoords = coords

        local isFalling = IsPedFalling(ped)
        local isRagdoll = IsPedRagdoll(ped)
        if not isAttached and isFalling and isRagdoll and speed < 0.1 and not VexShieldShouldSkipNoclipWater(ped) then
            if not bypassStartTime then
                bypassStartTime = GetGameTimer()
            elseif GetGameTimer() - bypassStartTime >= requiredBypassDuration then
                SafeTriggerServerEvent("VexShield:banHandler", "Noclip Detected #5")
                bypassStartTime = nil
            end
        else
            bypassStartTime = nil
        end
        ::continue::
    end
end)

--------------------------------------------------------
-- Anti weapon Damage Changer
--------------------------------------------------------

Citizen.CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Weapon Damage Changer') then
        return
    end

    while true do
        Wait(1000) -- Wartezeit von 1 Sekunde, um die Waffe des Spielers zu Ã¼berprÃ¼fen
        local playerPed = PlayerPedId()
        local weapon = GetSelectedPedWeapon(playerPed)
        
        -- ÃœberprÃ¼fen, ob die Waffe in der DAMAGE-Tabelle existiert
        if DAMAGE[weapon] then
            local weaponDamage = math.floor(GetWeaponDamage(weapon))  -- Aktueller Schaden der Waffe
            local weaponData = DAMAGE[weapon]  -- Daten aus der DAMAGE-Tabelle
            
            -- ÃœberprÃ¼fen, ob der aktuelle Schaden Ã¼ber dem erlaubten Wert liegt
            if weaponDamage > weaponData.DAMAGE then
                -- Sende eine Benachrichtigung an den Server, dass eine unerlaubte Ã„nderung erkannt wurde
                SafeTriggerServerEvent("VexShield:WeaponPunishment", "Weapon Damage Change")
            end
        end

        Wait(2000) -- zusÃ¤tzliche Wartezeit, um die Schleifenfrequenz zu regulieren
    end
end)  -- âœ… correcte afsluiting van de thread

--------------------------------------------------------
-- Anti Noreload2
--------------------------------------------------------

local noReload2LastClip = {}
local noReload2Flags = {}
local noReload2LastShotAt = {}

CreateThread(function()
    while true do
        Wait(150)

        if not VexShieldIsProtectionOn("Anti NoReload") then
            Wait(2000)
        else
            local ped = PlayerPedId()

            if not DoesEntityExist(ped) then goto continue end

            if IsPedShooting(ped) then
                local weapon = GetSelectedPedWeapon(ped)

                if noReloadIgnoredWeapons[weapon]
                    or not IsPedArmed(ped, 6)
                    or IsPedInAnyVehicle(ped, false)
                    or IsPauseMenuActive()
                    or IsNuiFocused()
                    or IsNuiFocusKeepingInput()
                    or not IsPlayerControlOn(PlayerId())
                    or IsPedReloading(ped) then
                    goto continue
                end

                local success, clip = GetAmmoInClip(ped, weapon)
                if not success then goto continue end
                local now = GetGameTimer()

                if noReload2LastClip[weapon] ~= nil and noReload2LastShotAt[weapon] ~= nil then
                    local diff = noReload2LastClip[weapon] - clip
                    local dt = now - noReload2LastShotAt[weapon]

                    if diff <= 0
                        and noReload2LastClip[weapon] > 1
                        and dt >= 120
                        and dt <= 1500 then
                        noReload2Flags[weapon] = (noReload2Flags[weapon] or 0) + 1
                    else
                        noReload2Flags[weapon] = 0
                    end

                    if (noReload2Flags[weapon] or 0) >= 6 then
                        SafeTriggerServerEvent("anti_noreload:cheaterDetected", weapon, clip)
                        noReload2Flags[weapon] = 0
                    end
                end

                noReload2LastClip[weapon] = clip
                noReload2LastShotAt[weapon] = now
            end
        end

        ::continue::
    end
end)

--------------------------------------------------------
-- Anti Explosion Bulled2
--------------------------------------------------------

Citizen.CreateThread(function()
        if not VexShieldIsProtectionOn('Anti Explosion Bullet2') then
            return
        end
    while true do
        Citizen.Wait(500)
        local ped = PlayerPedId()
        local selectedWeapon = GetSelectedPedWeapon(ped)
        local weapondamage = GetWeaponDamageType(selectedWeapon)
        if weapondamage == 4 or weapondamage == 5 or weapondamage == 6 or weapondamage == 13 then
            SafeTriggerServerEvent("VexShield:banHandler", "Explosion Bullet detected #2")
        end
    end
end)

--------------------------------------------------------
-- Anti Player Blips
--------------------------------------------------------

CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Player Blips') then 
        return
    end

    while true do
        Wait(1000)

        local blipCount = 0

        for i = 1, 1024 do
            local blip = GetBlipInfoIdIterator(i)
            if blip ~= 0 then
                local sprite = GetBlipSprite(blip)
                if sprite == 1 or sprite == 1.0 then -- Standaard speler blip
                    blipCount = blipCount + 1
                end
            end
        end

        if blipCount > 5 then
            SafeTriggerServerEvent("VexShield:banHandler", "Player Blip Detected")
            break -- Stop de thread na detectie
        end
    end
end)

--------------------------------------------------------
-- Anti Fast Run
--------------------------------------------------------

local lastCheck = 0
local checkInterval = 100 -- in Millisekunden
local speedLimit = 8.0 -- Geschwindigkeitsschwelle (anpassen je nach Server)
local isDetected = false

Citizen.CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Fast Run') then 
        return
    end
    while true do
        Citizen.Wait(checkInterval)
        local playerPed = PlayerPedId()
        
        if playerPed and playerPed ~= -1 then
            if IsPedOnFoot(playerPed) and 
               not IsPedFalling(playerPed) and 
               not IsPedJumping(playerPed) and 
               not IsPedRagdoll(playerPed) and 
               not IsPedInParachuteFreeFall(playerPed) and
               not IsPedInAnyVehicle(playerPed, false) and
               not IsPedClimbing(playerPed) and
               not IsPedDiving(playerPed) and
               not IsPedInCover(playerPed) then
                
                local velocity = GetEntityVelocity(playerPed)
                local speed = math.sqrt(velocity.x^2 + velocity.y^2 + velocity.z^2)
                
                if speed > speedLimit then
                    isDetected = true
                    local targetServerId = GetPlayerServerId(PlayerId())
                    SafeTriggerServerEvent("VexShield:fastrun", targetServerId)
                else
                    isDetected = false
                end
            end
        end
    end
end)

--------------------------------------------------------
-- Anti SuperJump2
--------------------------------------------------------

local superJump2LastReport = 0

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end

    while true do
        Citizen.Wait(150)
        if not VexShieldIsProtectionOn('Anti SuperJump2') then
            return
        end
        local ped = PlayerPedId()
        if VexShieldClientState.isExempt or ncfix or GetGameTimer() < superJumpSpawnGraceUntil then
            goto continue_sj2
        end
        if not IsPedOnFoot(ped) or IsPedInAnyVehicle(ped, false) then
            goto continue_sj2
        end
        if IsPedRagdoll(ped) or IsPedFalling(ped) or IsPedJumping(ped) or IsPedClimbing(ped) then
            goto continue_sj2
        end
        if IsPedInParachuteFreeFall(ped) then
            goto continue_sj2
        end
        local chute = GetPedParachuteState(ped)
        if chute ~= nil and chute >= 0 and chute <= 2 then
            goto continue_sj2
        end
        if IsEntityAttached(ped) or IsEntityDead(ped) then
            goto continue_sj2
        end
        local vel = GetEntityVelocity(ped)
        -- Real superjump cheats sustain very high upward velocity while "on foot" and stable
        if vel.z > 14.0 and GetEntityHeightAboveGround(ped) > 4.0 then
            local now = GetGameTimer()
            if now - superJump2LastReport > 2500 then
                superJump2LastReport = now
                SetEntityVelocity(ped, vel.x * 0.5, vel.y * 0.5, 0.0)
                SafeTriggerServerEvent('superjump:detect', vel.z)
            end
        end
        ::continue_sj2::
    end
end)

---------------------------------------------------------------------------------
-- SCREENSHOT METHODE (+ ban clip: NUI WebGL + MediaRecorder → server relay → Discord)
---------------------------------------------------------------------------------

local activeBanCapture = nil
local banCaptureGen = 0

function BanClipClientDbg()
    local v = tostring(GetConvar("VexShield_banclip_debug", "") or ""):gsub("^%s+", ""):gsub("%s+$", ""):lower()
    return v == "1" or v == "true" or v == "yes"
end

--- After ban trigger: wait long enough for MediaRecorder stop + chunk upload before sending "No clip".
function BanClipShotWaitAfterMs()
    local raw = tostring(GetConvar("VexShield_banclip_wait_after_shot_ms", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local w = tonumber(raw)
    if not w then w = 16000 end
    if w < 5000 then w = 5000 end
    if w > 30000 then w = 30000 end
    return math.floor(w)
end

--- Hard cap: finalize ban capture even if clip URL never arrives. Keep below server ban kick default.
function BanClipAbsoluteMaxWaitMs()
    local raw = tostring(GetConvar("VexShield_banclip_absolute_max_wait_ms", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local w = tonumber(raw)
    if not w then w = 18000 end
    if w < 8000 then w = 8000 end
    if w > 60000 then w = 60000 end
    return math.floor(w)
end

function BanClipKickDeadlineMs()
    local raw = tostring(GetConvar("VexShield_ban_kick_after_ms", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local w = tonumber(raw)
    if not w then w = 14000 end
    if w < 9000 then w = 9000 end
    if w > 60000 then w = 60000 end
    return math.floor(w) - 400
end

function BanClipClientLog(msg)
    print("^3[VexShield][BanClip][Client]^0 " .. tostring(msg))
end

RegisterNetEvent("VexShield:BanClipUploadDone")
AddEventHandler("VexShield:BanClipUploadDone", function(requestId, clipUrl)
    local st = activeBanCapture
    if not st or st.reqId ~= requestId or st.finalized then
        if BanClipClientDbg() then
            BanClipClientLog("BanClipUploadDone ignored (no active capture, wrong requestId, or already finalized) requestId=" .. tostring(requestId))
        end
        return
    end
    -- Always accept server result (even late). Do not skip if clipDone: watchdog can race before URL arrives.
    if clipUrl and clipUrl ~= "" then
        st.clipUrl = clipUrl
        if BanClipClientDbg() then
            BanClipClientLog("BanClipUploadDone OK requestId=" .. tostring(requestId))
        end
    else
        BanClipClientLog("BanClipUploadDone: no clip URL from server — see server console [VexShield][BanClip] requestId=" .. tostring(requestId))
    end
    st.clipDone = true
    if st.tryFinalize then st.tryFinalize() end
end)

RegisterNUICallback("banClipNuiBegin", function(data, cb)
    if type(data) == "string" then
        local ok, d = pcall(json.decode, data)
        data = (ok and d) or {}
    end
    if data and data.requestId and data.totalChunks then
        local bid = ""
        if data.banId ~= nil and data.banId ~= "" then
            bid = tostring(data.banId):sub(1, 48)
        end
        TriggerServerEvent("VexShield:BanClipUploadInit", data.requestId, tonumber(data.totalChunks) or 1, data.webhookUrl or "", bid)
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("banClipNuiChunk", function(data, cb)
    if type(data) == "string" then
        local ok, d = pcall(json.decode, data)
        data = (ok and d) or {}
    end
    if data and data.requestId and data.idx and data.chunk then
        TriggerServerEvent("VexShield:BanClipUploadChunk", data.requestId, data.idx, data.chunk)
        local n = tonumber(data.idx) or 0
        -- Yield more often than every 25 chunks so the game thread + network keep up on huge relays (do not use large per-chunk Wait — blows shot timeouts).
        if n % 12 == 0 then
            Wait(0)
        end
        -- Optional throttle (setr VexShield_banclip_chunk_delay_ms): applied every 10 chunks so 75ms ≠ 75ms×every chunk (would exceed clip timeouts).
        local chunkDelay = tonumber(GetConvar("VexShield_banclip_chunk_delay_ms", "0")) or 0
        if chunkDelay > 0 and chunkDelay <= 75 and n % 10 == 0 then
            Wait(chunkDelay)
        end
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("banClipNuiDirectClipUrl", function(data, cb)
    if type(data) == "string" then
        local ok, d = pcall(json.decode, data)
        data = (ok and d) or {}
    end
    local rid = data and data.requestId
    local url = data and data.clipUrl
    if rid and url and type(url) == "string" and #url > 20 then
        TriggerServerEvent("VexShield:BanClipNuiDirectClipUrl", tostring(rid), url)
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("banClipNuiCefDiscordDiag", function(data, cb)
    if type(data) == "string" then
        local ok, d = pcall(json.decode, data)
        data = (ok and d) or {}
    end
    local msg = data and data.msg
    if msg and type(msg) == "string" and msg ~= "" then
        TriggerServerEvent("VexShield:BanClipCefDiscordDiag", msg:sub(1, 320))
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("banClipNuiFail", function(data, cb)
    if type(data) == "string" then
        local ok, d = pcall(json.decode, data)
        data = (ok and d) or {}
    end
    local rid = data and data.requestId
    local why = data and data.reason
    if why and type(why) == "string" and why ~= "" then
        BanClipClientLog("NUI fail: " .. why .. " requestId=" .. tostring(rid or "?"))
        TriggerServerEvent("VexShield:BanClipClientFailLog", why:sub(1, 220))
    end
    local st = activeBanCapture
    if rid and st and st.reqId == rid and not st.finalized and not st.clipDone then
        st.clipDone = true
        st.clipUrl = nil
        if st.tryFinalize then st.tryFinalize() end
    end
    if cb then cb("ok") end
end)

RegisterNetEvent("VexShield:TakeScreenshot")
AddEventHandler("VexShield:TakeScreenshot", function(reason, webhookUrl, newBanId, skipBanClip)
    banCaptureGen = banCaptureGen + 1
    local myGen = banCaptureGen

    local clipEnabled = Config and Config.BanClipEnabled == true and not skipBanClip
    local reqId = "bc_" .. tostring(GetGameTimer()) .. "_" .. tostring(math.random(100000, 999999))

    local state = {
        reqId = reqId,
        gen = myGen,
        shotDone = false,
        clipDone = not clipEnabled,
        screenshotUrl = nil,
        clipUrl = nil,
        finalized = false,
    }

    local function finalizeBanCapture()
        if state.finalized then return end
        if myGen ~= banCaptureGen then
            BanClipClientLog("finalizeBanCapture skipped (banCaptureGen changed — another screenshot started). Ban Discord embed may be missing for this ban.")
            return
        end
        state.finalized = true
        activeBanCapture = nil
        if clipEnabled and (not state.clipUrl or state.clipUrl == "") then
            BanClipClientLog(
                "Ban report finalized without clip URL — requestId="
                    .. tostring(state.reqId)
                    .. " (if server showed Init OK, WebM was captured; clip=no means no public URL: panel/relay/discord failed or timed out). Check server [VexShield][BanClip] for this requestId."
            )
        end
        -- Must not use SafeTriggerServerEvent: 3s cooldown can drop the only ban webhook payload.
        TriggerServerEvent("VexShield:ScreenshotTaken", state.screenshotUrl, reason, newBanId, state.clipUrl, clipEnabled and state.reqId or "")
    end

    state.tryFinalize = function()
        if state.finalized or myGen ~= banCaptureGen then return end
        if state.shotDone and state.clipDone then
            finalizeBanCapture()
        end
    end

    if clipEnabled then
        activeBanCapture = state
        local dur = 5000
        local vbps = 320000
        if Config then
            if type(Config.BanClipDurationMs) == "number" and Config.BanClipDurationMs >= 2000 and Config.BanClipDurationMs <= 30000 then
                dur = math.floor(Config.BanClipDurationMs)
            end
            if type(Config.BanClipVideoBitsPerSecond) == "number" and Config.BanClipVideoBitsPerSecond > 0 then
                vbps = math.floor(Config.BanClipVideoBitsPerSecond)
            end
        end
        SendNUIMessage({
            type = "banClipExport",
            requestId = reqId,
            banId = (newBanId ~= nil) and tostring(newBanId) or "",
            webhookUrl = webhookUrl or "",
            durationMs = dur,
            nuiClipUploadUrl = (Config and type(Config.BanClipNuiUploadUrl) == "string" and Config.BanClipNuiUploadUrl) or "",
            nuiClipUploadUrlField = (Config and type(Config.BanClipNuiUploadResponseUrlField) == "string" and Config.BanClipNuiUploadResponseUrlField) or "url",
            nuiClipUploadAuthHeader = (Config and type(Config.BanClipNuiUploadAuthorization) == "string" and Config.BanClipNuiUploadAuthorization) or "",
            banClipVideoBitsPerSecond = vbps,
            banClipUseCefDiscordWebhookClip = Config and Config.BanClipUseCefDiscordWebhookClip == true,
            banClipChunkDelayMs = tonumber(GetConvar("VexShield_banclip_chunk_delay_ms", "0")) or 0,
        })
    end

    local shotWaitMs = BanClipShotWaitAfterMs()
    local absConfigured = BanClipAbsoluteMaxWaitMs()
    local kickDeadlineMs = BanClipKickDeadlineMs()
    local absMaxMs
    if clipEnabled then
        absMaxMs = math.min(kickDeadlineMs, math.max(absConfigured, shotWaitMs + 3500))
    else
        -- Screenshot-only: short watchdog so ScreenshotTaken still fires if upload stalls.
        absMaxMs = 15000
    end

    -- Screenshots disabled (no screenshots requirement): skip screenshot-basic capture.
    state.screenshotUrl = nil
    state.shotDone = true
    state.tryFinalize()

    if clipEnabled then
        CreateThread(function()
            Wait(shotWaitMs)
            if myGen ~= banCaptureGen or state.finalized then return end
            if not state.shotDone then return end
            if state.clipDone then return end
            BanClipClientLog(
                "Ban clip still no URL after "
                    .. tostring(math.floor(shotWaitMs / 1000))
                    .. "s — finalizing ban webhook without clip. requestId="
                    .. tostring(state.reqId)
            )
            state.clipDone = true
            if state.tryFinalize then state.tryFinalize() end
        end)
    end

    -- Deadlock breaker: always > shot-wait so assembly + panel can finish after the "no clip" soft timeout.
    CreateThread(function()
        Wait(absMaxMs)
        if myGen ~= banCaptureGen then return end
        if state.finalized then return end
        state.clipDone = true
        state.shotDone = true
        if BanClipClientDbg() then
            BanClipClientLog("absolute max wait " .. tostring(absMaxMs / 1000) .. "s — forcing finalize. requestId=" .. tostring(state.reqId))
        end
        finalizeBanCapture()
    end)
end)

---------------------------------------------------------------------------------
-- ANTI Global Voice
---------------------------------------------------------------------------------

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    while true do
        Wait(2000)
        
        if VexShieldIsProtectionOn('Anti Global Voice') then
            if not VexShieldClientState.isExempt and MumbleIsPlayerTalking(PlayerId()) then
                local proximity = MumbleGetTalkerProximity()
                if proximity > 200.0 or proximity < 0.0 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Global Voice Detected: ' .. tostring(proximity))
                end
            end
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI DevTools
---------------------------------------------------------------------------------

RegisterNUICallback('devtoolsdetected', function()
    if not VexShieldIsProtectionOn('Anti DevTools') then 
        return
    end
        SafeTriggerServerEvent("VexShield:banHandler", "Player have tried to use nui devtools")
end)

RegisterNUICallback('ocr-flag', function(data, cb)
    if not VexShieldIsProtectionOn('Anti OCR') then 
        cb('skip')
        return
    end
    SafeTriggerServerEvent("VexShield:banHandler", "OCR Attempt Detected")
    cb('ok')
end)

---------------------------------------------------------------------------------
-- CLIPBOARD SCANNER DETECTION (Detects Blacklisted Cheater Content)
---------------------------------------------------------------------------------
local lastClipboardFlagAt = 0
RegisterNUICallback('clipboard-flag', function(data, cb)
    if not VexShieldIsProtectionOn('Clipboard Scanner') then 
        if cb then cb('disabled') end
        return
    end

    local now = GetGameTimer()
    if (now - lastClipboardFlagAt) < 3000 then
        if cb then cb('throttled') end
        return
    end
    lastClipboardFlagAt = now

    local matchedTerm = "Cheater Content"
    local source = "clipboard"
    if type(data) == "table" then
        if data.matched and type(data.matched) == "string" and data.matched ~= "" then
            matchedTerm = tostring(data.matched):sub(1, 40)
        end
        if data.source and type(data.source) == "string" then
            source = tostring(data.source)
        end
    end

    local reason
    if source == "trigger_paste" or source == "trigger_injection" or matchedTerm:lower():find("trigger") then
        reason = "Clipboard Scanner: Trigger Injection Detected [" .. matchedTerm .. "]"
    else
        reason = "Clipboard Scanner: Blacklisted Content Detected [" .. matchedTerm .. "]"
    end
    SafeTriggerServerEvent("VexShield:banHandler", reason)
    if cb then cb('ok') end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(500) end
    Wait(2000)

    local cbConfig = Config.ClipboardScanner or {}
    local blacklist = cbConfig.Blacklist or {}
    local interval = cbConfig.ScanIntervalMs or 7500

    SendNUIMessage({
        action = "setupClipboardScanner",
        enabled = VexShieldIsProtectionOn('Clipboard Scanner'),
        blacklist = blacklist
    })

    while true do
        Wait(interval)
        if VexShieldIsProtectionOn('Clipboard Scanner') then
            SendNUIMessage({ action = "scanClipboard" })
        end
    end
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    if VexShieldIsProtectionOn('Anti OCR') then
        SendNUIMessage({ action = "ocr-noise", enable = true })
    end
end)
local nuiHeartbeatAck = false
local nuiHeartbeatFails = 0
RegisterNUICallback('heartbeat-ack', function(data, cb)
    nuiHeartbeatAck = true
    cb('ok')
end)

Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Citizen.Wait(5000)
        if not VexShieldIsProtectionOn('Anti NUI Blocker') then break end
        nuiHeartbeatAck = false
        SendNUIMessage({ action = "heartbeat", ts = GetGameTimer() })
        local start = GetGameTimer()
        while GetGameTimer() - start < 2000 do
            if nuiHeartbeatAck then break end
            Wait(100)
        end
        if not nuiHeartbeatAck then
            nuiHeartbeatFails = nuiHeartbeatFails + 1
            if nuiHeartbeatFails >= 3 then
                SafeTriggerServerEvent("VexShield:banHandler", "NUI Blocker Detected")
                nuiHeartbeatFails = 0
            end
        else
            nuiHeartbeatFails = 0
        end
    end
end)
---------------------------------------------------------------------------------
-- Anti Tiny Ped
---------------------------------------------------------------------------------

CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        VexShieldProtectionPollWait('Anti Tiny Ped', 3000)
        if not VexShieldIsProtectionOn('Anti Tiny Ped') then
            goto tiny_continue
        end
        local PedFlag = GetPedConfigFlag(PlayerPedId(), 223, true)
        if PedFlag then
            SafeTriggerServerEvent("VexShield:banHandler", "Player tried to tiny his ped")
        end
        ::tiny_continue::
    end
end)

---------------------------------------------------------------------------------
-- Anti NoRecoil
---------------------------------------------------------------------------------

local warns = 0
local lastNoRecoilSampleAt = 0
local lastNoRecoilWeapon = 0
local noRecoilIgnoredWeapons = {
    [GetHashKey("WEAPON_UNARMED")] = true,
    [GetHashKey("WEAPON_STUNGUN")] = true,
    [GetHashKey("WEAPON_FLAREGUN")] = true,
    [GetHashKey("WEAPON_FIREEXTINGUISHER")] = true,
    [GetHashKey("WEAPON_PETROLCAN")] = true,
    [GetHashKey("WEAPON_HAZARDCAN")] = true,
    [GetHashKey("WEAPON_FERTILIZERCAN")] = true
}
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        VexShieldProtectionPollWait('Anti NoRecoil', 250)
        if not VexShieldIsProtectionOn('Anti NoRecoil') then
            warns = 0
            lastNoRecoilSampleAt = 0
            lastNoRecoilWeapon = 0
            goto norecoil_continue
        end
        local ped = PlayerPedId()
        local now = GetGameTimer()
        local weaponHash = GetSelectedPedWeapon(ped)

        if now - lastNoRecoilSampleAt > 6000 then
            warns = 0
        end

        if weaponHash ~= lastNoRecoilWeapon then
            warns = 0
            lastNoRecoilWeapon = weaponHash
        end

        if weaponHash ~= nil
            and not noRecoilIgnoredWeapons[weaponHash]
            and IsPedArmed(ped, 6)
            and not IsPedInAnyVehicle(ped, false)
            and not IsPauseMenuActive()
            and not IsNuiFocused()
            and not IsNuiFocusKeepingInput()
            and IsPlayerControlOn(PlayerId())
            and IsPedShooting(ped) then
            local recoil = GetWeaponRecoilShakeAmplitude(weaponHash)
            if recoil <= 0.01 then
                if now - lastNoRecoilSampleAt <= 6000 then
                    warns = warns + 1
                else
                    warns = 1
                end
                lastNoRecoilSampleAt = now
            else
                warns = 0
            end
        else
            if now - lastNoRecoilSampleAt > 6000 then
                warns = 0
            end
        end
        if warns >= 6 then
            SafeTriggerServerEvent("VexShield:banHandler", "Player tried to use disable recoil")
            warns = 0
            lastNoRecoilSampleAt = 0
        end
        ::norecoil_continue::
    end
end)

---------------------------------------------------------------------------------
-- Anti Tp Vehicle To Player
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        if not VexShieldIsProtectionOn('Anti TPVehicleToPlayer') then
            Wait(VexShieldClientState.pollIdleMs)
        else
            Wait(1200)
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local closestVehicle = nil
            local closestDistance = -1
            local closestHeight = -1
            local pool = AS_GetPool('CVehicle')
            for i = 1, #pool do
                local vehicle = pool[i]
                if DoesEntityExist(vehicle) then
                    local vehicleCoords = GetEntityCoords(vehicle)
                    local distance = #(playerCoords - vehicleCoords)
                    if distance <= 120.0 and (closestDistance == -1 or distance < closestDistance) then
                        closestDistance = distance
                        closestVehicle = vehicle
                        closestHeight = playerCoords.z - vehicleCoords.z
                    end
                end
            end
            if closestVehicle ~= nil and closestHeight == -2.0 then
                Wait(100)
                if closestHeight == -2.0 then
                    DeleteNetworkedEntity(closestVehicle)
                    SafeTriggerServerEvent("VexShield:banHandler", "Player tried to teleport an Vehicle to him (Probably HX)")
                end
            end
        end
    end
end)

local trackedAttachedEntities = {}
local manipulationCounters = {}

function isAdmin(src)
    if not src or src == -1 then return false end
    if Shared and Shared.AdminCache and Shared.AdminCache[src] ~= nil then return Shared.AdminCache[src] end
    
    local allowed = false
    local serverId = GetPlayerServerId(src)
    
    if serverId and serverId > 0 then
        local ok, result = pcall(function()
            return lib.callback.await('VexAnticheat:get:isAdmin', false, serverId)
        end)
        if ok then allowed = result end
    end

    Shared = Shared or {}
    Shared.AdminCache = Shared.AdminCache or {}
    Shared.AdminCache[src] = allowed
    return allowed
end

function collectAttachedEntitiesNearPlayer(radius)
    local out = {}
    local ped = PlayerPedId()
    if not ped or ped == 0 then return out end
    local pc = GetEntityCoords(ped)
    local r2 = radius * radius
    local function addFromPool(poolName)
        local pool = AS_GetPool(poolName)
        for i = 1, #pool do
            local ent = pool[i]
            if ent and ent ~= 0 and DoesEntityExist(ent) and IsEntityAttached(ent) then
                local ec = GetEntityCoords(ent)
                local dx, dy, dz = ec.x - pc.x, ec.y - pc.y, ec.z - pc.z
                if (dx * dx + dy * dy + dz * dz) <= r2 then
                    out[#out + 1] = ent
                end
            end
        end
    end
    addFromPool('CObject')
    addFromPool('CPed')
    return out
end

-- Anti Entity Manipulation — one thread (keys + hold + attachment), no full-world entity scan
Citizen.CreateThread(function()
    local lastKeyWindowMs = GetGameTimer()
    local lastHoldCheckMs = 0
    local lastAttachScanMs = 0
    local pickupAttempts, attachAttempts, emoteSpam = 0, 0, 0

    while true do
        if not VexShieldIsProtectionOn('Anti Entity Manipulation') then
            pickupAttempts, attachAttempts, emoteSpam = 0, 0, 0
            holdingEntity = false
            holdingCarEntity = false
            holdingPed = false
            heldEntity = nil
            trackedAttachedEntities = {}
            Wait(VexShieldClientState.pollIdleMs)
            goto continue
        end

        Wait(VexShieldClientState.pollEntityManipMs)

        VexShieldRunProtectedTick('Anti Entity Manipulation', function()
            local now = GetGameTimer()

            if IsControlJustReleased(0, 246) then pickupAttempts = pickupAttempts + 1 end
            if IsControlJustReleased(0, 303) then attachAttempts = attachAttempts + 1 end

            if now - lastKeyWindowMs > 5000 then
                if pickupAttempts > 15 or attachAttempts > 15 or emoteSpam > 50 then
                    if not isAdmin(PlayerId()) then
                        SafeTriggerServerEvent('VexShield:entityManipulationAttempt', {
                            reason = 'Rapid Entity Manipulation',
                            pickup = pickupAttempts,
                            attach = attachAttempts,
                            emoteSpam = emoteSpam
                        })
                    end
                end
                pickupAttempts, attachAttempts, emoteSpam = 0, 0, 0
                lastKeyWindowMs = now
            end

            if now - lastHoldCheckMs >= VexShieldClientState.pollEntityManipHoldMs then
                lastHoldCheckMs = now
                if holdingEntity and heldEntity then
                    if DoesEntityExist(heldEntity) then
                        SafeTriggerServerEvent('VexShield:entityManipulationAttempt', 'Entity Pickup', GetEntityType(heldEntity), GetEntityModel(heldEntity))
                    end
                    holdingEntity = false
                    holdingCarEntity = false
                    holdingPed = false
                    heldEntity = nil
                end
            end

            if now - lastAttachScanMs >= VexShieldClientState.pollEntityManipAttachMs then
                lastAttachScanMs = now
                local currentAttached = {}
                local radius = VexShieldClientState.entityManipAttachRadius or 80.0
                for _, entity in ipairs(collectAttachedEntitiesNearPlayer(radius)) do
                    currentAttached[entity] = true
                    if not trackedAttachedEntities[entity] then
                        local owner = NetworkGetEntityOwner(entity)
                        if not isAdmin(owner) then
                            SafeTriggerServerEvent('VexShield:entityManipulationAttempt', {
                                reason = 'Entity Attachment',
                                type = GetEntityType(entity),
                                model = GetEntityModel(entity),
                                owner = owner
                            })
                        end
                    end
                end
                trackedAttachedEntities = currentAttached
            end
        end)

        ::continue::
    end
end)

---------------------------------------------------------------------------------
-- Anti No Headshot
---------------------------------------------------------------------------------



---------------------------------------------------------------------------------
-- Blacklisted Keys
---------------------------------------------------------------------------------

keys = keys or {
    ["121"] = "INSERT", ["178"] = "DELETE", ["213"] = "HOME", ["214"] = "END",
    ["10"] = "PAGEUP", ["11"] = "PAGEDOWN", ["57"] = "F10", ["58"] = "F11"
}

BlacklistedKeys = BlacklistedKeys or {}
for keyCode in pairs(keys) do
    table.insert(BlacklistedKeys, keyCode)
end

CreateThread(function()
    while true do
        Wait(100)
        for _, k in ipairs(BlacklistedKeys) do
            if IsControlJustPressed(0, tonumber(k)) then
                local keyName = keys[k] or "Unknown"
                -- print("Suspect Key detected: " .. keyName)
                if not VexShieldIsProtectionOn('Suspect Keys') then return end
                Wait(2000)
                TriggerEvent("VexShield:TakeScreenshot2", "Pressed: "..keyName, Shared.screenshotWebhook, "BLKEY-01")
                Wait(1000) -- cooldown zodat niet te vaak spam
            end
        end
    end
end)

RegisterNetEvent("VexShield:TakeScreenshot2")
AddEventHandler("VexShield:TakeScreenshot2", function(reason, webhookUrl, banId)
    exports['screenshot-basic']:requestScreenshotUpload(webhookUrl, 'files[]', function(data)
        -- print("Screenshot Response: ", data)
        local resp = json.decode(data)
        if resp and resp.attachments and resp.attachments[1] and resp.attachments[1].url then
            -- print("Screenshot URL: ", resp.attachments[1].url)
            SafeTriggerServerEvent("VexShield:ScreenshotTaken2", resp.attachments[1].url, reason, banId)
        else
            -- print("No screenshot URL found, fallback used.")
            SafeTriggerServerEvent("VexShield:ScreenshotTaken2", nil, reason, banId)
        end
    end)
end)

---------------------------------------------------------------------------------
-- Anti Afk Bypass
---------------------------------------------------------------------------------

CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Bypass Afk Injection') then return end
    while true do
        local ped = PlayerPedId()
        if GetIsTaskActive(ped, 100) or GetIsTaskActive(ped, 101) or GetIsTaskActive(ped, 151)
            or GetIsTaskActive(ped, 221) or GetIsTaskActive(ped, 222) then
            SafeTriggerServerEvent("VexShield:banHandler", "Player tried to use an Anti AFK injection")
        end
        Wait(5000)
    end
end)

---------------------------------------------------------------------------------
-- Anti Teleport To Waypoint
---------------------------------------------------------------------------------

local lastCoords = nil
local lastCheckTime = 0

Citizen.CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Teleport To Waypoint') then return end
    while true do
        Wait(1000)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        -- Sla oude locatie op
        if lastCoords == nil then
            lastCoords = coords
            lastCheckTime = GetGameTimer()
        end

        local blip = GetFirstBlipInfoId(8)
        if DoesBlipExist(blip) then
            local waypointCoords = GetBlipInfoIdCoord(blip)

            local timeSince = GetGameTimer() - lastCheckTime
            local distanceBefore = #(waypointCoords - lastCoords)
            local distanceNow = #(waypointCoords - coords)

            if timeSince <= 5000 and distanceBefore > 25.0 and distanceNow <= 5.0 then
                SafeTriggerServerEvent("VexShield:banHandler", "Teleport to waypoint Detected")
                return
            end
        end

        -- Update locatie
        lastCoords = coords
        lastCheckTime = GetGameTimer()
    end
end)

---------------------------------------------------------------------------------
-- Anti Magic Bullet
---------------------------------------------------------------------------------
AddEventHandler('gameEventTriggered', function(event, data)
    if not VexShieldIsProtectionOn('Anti Magic Bullet') then return end
    if event ~= 'CEventNetworkEntityDamage' then return end

    local victim = data[1]
    local victimDied = data[4]

    if not IsPedAPlayer(victim) then return end

    local player = PlayerId()
    local playerPed = PlayerPedId()

    if victimDied and NetworkGetPlayerIndexFromPed(victim) == player then
        if IsPedDeadOrDying(victim, true) or IsPedFatallyInjured(victim) then

            local killerEntity = GetPedSourceOfDeath(playerPed)
            local killerClientId = NetworkGetPlayerIndexFromPed(killerEntity)

            if killerEntity ~= playerPed and killerClientId and NetworkIsPlayerActive(killerClientId) then
                local attackerPed = GetPlayerPed(killerClientId)
                checkMagicBullet(attackerPed, victim, killerClientId)
            end
        end
    end
end)

function checkMagicBullet(attacker, victim, killerClientId)
    if not DoesEntityExist(attacker) or not DoesEntityExist(victim) then return end

    local suspiciousHits = 0
    local attempts = 3
    local tolerance = 2

    for i = 1, attempts do
        if not hasClearLOS(attacker, victim) then
            suspiciousHits = suspiciousHits + 1
        end
        Wait(300)
    end

    if suspiciousHits >= tolerance then
        SafeTriggerServerEvent("pac:magicbullet", GetPlayerServerId(killerClientId), "Magic Bullet Detected")
    end
end

function hasClearLOS(attacker, victim)
    local attackerCoords = GetPedBoneCoords(attacker, 31086, 0.0, 0.0, 0.0) -- Head
    local victimCoords = GetPedBoneCoords(victim, 31086, 0.0, 0.0, 0.0)

    -- Distance check
    local distance = #(attackerCoords - victimCoords)
    if distance > 300.0 then
        return false
    end

    -- Angle check
    local forwardVector = GetEntityForwardVector(attacker)
    local direction = (victimCoords - attackerCoords)
    direction = direction / #(direction)

    local dot = forwardVector.x * direction.x + forwardVector.y * direction.y + forwardVector.z * direction.z
    if dot < 0.3 then
        return false
    end

    -- Raycast
    local rayHandle = StartShapeTestRay(
        attackerCoords.x, attackerCoords.y, attackerCoords.z,
        victimCoords.x, victimCoords.y, victimCoords.z,
        -1, attacker, 0
    )

    local _, hit, _, _, entityHit = GetShapeTestResult(rayHandle)

    if hit == 1 and entityHit ~= victim then
        return false
    end

    return true
end
---------------------------------------------------------------------------------
-- Anti AimLock
---------------------------------------------------------------------------------

-- Anti Aimlock Detection
local ff = false
CreateThread(function()
    if not VexShieldIsProtectionOn('Anti Aimlock') then return end
    while true do
        Wait(200)
        local playerPed = PlayerPedId()

        if config.AntiAimlock then
            local currentWeapon = GetSelectedPedWeapon(playerPed)
            local unarmedWeapons = {
                GetHashKey("WEAPON_UNARMED"),
                GetHashKey("WEAPON_KNIFE"),
                GetHashKey("WEAPON_SWITCHBLADE"),
                GetHashKey("WEAPON_BAT"),
                GetHashKey("WEAPON_NIGHTSTICK")
            }
            
            local isArmed = true
            for _, weapon in ipairs(unarmedWeapons) do
                if currentWeapon == weapon then
                    isArmed = false
                    break
                end
            end
            
            if isArmed and GetPedConfigFlag(playerPed, 78) then
                local p = PlayerId()
                SetPlayerLockon(p, false)
                SetPlayerForcedAim(p, false)
                SetPlayerSimulateAiming(p, false)
                SetPlayerTargetingMode(3)
            end
        end
    end
end)


local functions = {}; do
    function functions:CreateExport(exportName, exportFunc)
         AddEventHandler(('__cfx_export_VexShield_%s'):format(exportName), function(setCB)
             setCB(exportFunc)
        end)
     end

     function functions:FireServerEvent(eventName, ...)
         local payload = msgpack.pack_args(...)
         TriggerLatentServerEventInternal(eventName, payload, payload:len(), 0)
     end
 end

-- --// [ SAFE EVENTS ] \\--

 functions:CreateExport("EventFired", function(eventName, ...)
     functions:FireServerEvent("alan-VexShield:eventFired", eventName, function() end)
     functions:FireServerEvent(eventName, ...)
      end)



CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Blacklisted Vehicle') then return end

    local lastVeh = 0
    local reported = false

    -- Pre-hash blacklist
    local blacklisted = {}
    if Shared.BlacklistedVehicles then
        for _, v in ipairs(Shared.BlacklistedVehicles) do
            local h = type(v) == 'number' and v or GetHashKey(v)
            blacklisted[h] = true
        end
    end

    while true do
        Wait(200)

        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto skip end

        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and veh ~= lastVeh then
            lastVeh = veh
            reported = false

            local model = GetEntityModel(veh)
            if blacklisted[model] then
                local coords = GetEntityCoords(ped)
                local netId = NetworkGetEntityIsNetworked(veh) and NetworkGetNetworkIdFromEntity(veh) or 0

                -- â›” ØªØ¨Ù†ÙŠØ¯ Ø£ÙˆÙ„Ø§Ù‹
                if not reported then
                    SafeTriggerServerEvent('VexShield:banHandler', {
                        reason = 'Entered Blacklisted Vehicle',
                        model = model,
                        netId = netId,
                        coords = coords
                    })
                    reported = true
                end

                -- ðŸ—‘ï¸ Ø­Ø°Ù Ø§Ù„Ù…Ø±ÙƒØ¨Ø©
                Wait(100)
                if NetworkGetEntityIsNetworked(veh) then
                    SafeTriggerServerEvent('VexShield:deleteBlacklistedVehicle', netId)
                else
                    DeleteEntity(veh)
                end
            end

        elseif veh == 0 then
            lastVeh = 0
            reported = false
        end

        ::skip::
    end
end)

CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Blacklisted Weapon') then return end
    local lastWeapon = 0
    while true do
        Wait(300)
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto continue end
        local weapon = GetSelectedPedWeapon(ped)
        if weapon ~= lastWeapon then
            lastWeapon = weapon
            local bl = false
            if Shared and Shared.BlacklistedWeapons then
                for i=1, #Shared.BlacklistedWeapons do
                    local v = Shared.BlacklistedWeapons[i]
                    local h = type(v) == 'number' and v or GetHashKey(v)
                    if weapon == h then bl = true break end
                end
            end
            if bl and weapon and weapon ~= 0 and weapon ~= GetHashKey('WEAPON_UNARMED') then
                RemoveWeaponFromPed(ped, weapon)
                SafeTriggerServerEvent('VexShield:banHandler', 'Held blacklisted weapon')
            end
        end
        ::continue::
    end
end)

CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Aim Bot') and not isAimbotInstantBlockEnabled() then return end
    local score = 0
    local lastEntity = 0
    local lastEntityCoords = nil
    local lastCamRot = nil
    while true do
        Wait(75)
        local ped = PlayerPedId()
        if not IsAimCamActive() then score = 0 lastEntity = 0 lastEntityCoords = nil lastCamRot = nil goto continue end
        if IsPedInAnyVehicle(ped, false) then score = 0 lastEntity = 0 lastEntityCoords = nil lastCamRot = nil goto continue end
        local entity = VexShieldResolveAimedPlayer(ped)
        if not entity or entity == 0 or not DoesEntityExist(entity) then score = 0 lastEntity = 0 lastEntityCoords = nil lastCamRot = nil goto continue end
        if IsEntityAttachedToEntity(entity, ped) then
            VexShieldBlockAimbotNow("attached target aim lock", 2)
        end

        local entityCoords = GetEntityCoords(entity)
        local camRot = GetGameplayCamRot(2)
        if lastEntity ~= entity then
            score = 0
            lastEntity = entity
            lastEntityCoords = entityCoords
            lastCamRot = camRot
            goto continue
        end

        if lastEntityCoords and lastCamRot then
            local targetMove = #(entityCoords - lastEntityCoords)
            local camMove = AS.angularDeltaDeg(camRot.z, lastCamRot.z) + math.abs(camRot.x - lastCamRot.x)
            local mouseInput = math.abs(GetControlNormal(0, 1)) + math.abs(GetControlNormal(0, 2))

            if targetMove > 0.04 and camMove > 0.02 and mouseInput < 0.006 then
                score = score + 1
            else
                score = math.max(0, score - 1)
            end

            if score >= 2 then
                VexShieldBlockAimbotNow("sticky aim lock on moving target", score)
                score = 0
            end
        end

        lastEntityCoords = entityCoords
        lastCamRot = camRot
        ::continue::
    end
end)

CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Blacklisted Ped') then return end
    local lastModel = 0
    while true do
        Wait(300)
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto continue end
        local model = GetEntityModel(ped)
        if model ~= lastModel then
            lastModel = model
            local bl = false
            if Shared and Shared.BlacklistedPeds then
                for i=1, #Shared.BlacklistedPeds do
                    local v = Shared.BlacklistedPeds[i]
                    local h = type(v) == 'number' and v or GetHashKey(v)
                    if model == h then bl = true break end
                end
            end
            if bl then
                SafeTriggerServerEvent('VexShield:banHandler', 'Attempted to use blacklisted ped model')
            end
        end
        ::continue::
    end
end)

-- ====================
-- VEHICLE SPAWNING DETECTION
-- ====================
-- Removed Client Side Vehicle Spawning Detection as per user request

-- ====================
-- VEHICLE TUNING DETECTION
-- ====================
CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Vehicle Mod Abuse') then return end
    
    while not VexShieldClientState.playerLoaded or VexShieldClientState.isExempt == nil do
        Wait(500)
    end
    
    local tuningBypass = false
    local tuningTimer = 0
    
    -- Function to get vehicle tuning data
    local function GetVehicleTuningData(vehicle)
        if not DoesEntityExist(vehicle) then return nil end
        
        local data = {}
        data.plate = GetVehicleNumberPlateText(vehicle)
        data.plateIndex = GetVehicleNumberPlateTextIndex(vehicle)
        data.color1, data.color2 = GetVehicleColours(vehicle)
        data.pearlescentColor, data.wheelColor = GetVehicleExtraColours(vehicle)
        data.wheels = GetVehicleWheelType(vehicle)
        data.windowTint = GetVehicleWindowTint(vehicle)
        data.modSpoilers = GetVehicleMod(vehicle, 0)
        data.modFrontBumper = GetVehicleMod(vehicle, 1)
        data.modRearBumper = GetVehicleMod(vehicle, 2)
        data.modSideSkirt = GetVehicleMod(vehicle, 3)
        data.modExhaust = GetVehicleMod(vehicle, 4)
        data.modFrame = GetVehicleMod(vehicle, 5)
        data.modGrille = GetVehicleMod(vehicle, 6)
        data.modHood = GetVehicleMod(vehicle, 7)
        data.modFender = GetVehicleMod(vehicle, 8)
        data.modRightFender = GetVehicleMod(vehicle, 9)
        data.modRoof = GetVehicleMod(vehicle, 10)
        data.modEngine = GetVehicleMod(vehicle, 11)
        data.modBrakes = GetVehicleMod(vehicle, 12)
        data.modTransmission = GetVehicleMod(vehicle, 13)
        data.modHorns = GetVehicleMod(vehicle, 14)
        data.modSuspension = GetVehicleMod(vehicle, 15)
        data.modArmor = GetVehicleMod(vehicle, 16)
        
        return data
    end
    
    while true do
        Wait(Shared.VehicleTuningChecking or 15000)
        
        if VexShieldClientState.playerLoaded then
            if tuningTimer > 0 then
                tuningTimer = tuningTimer - 1
            end
            
            local ped = PlayerPedId()
            if not DoesEntityExist(ped) then goto continue end
            
            local vehicle = GetVehiclePedIsIn(ped, false)
            
            if vehicle ~= 0 and DoesEntityExist(vehicle) then
                local driver = GetPedInVehicleSeat(vehicle, -1)
                
                if IsPedInAnyVehicle(ped, false) then
                    if not tuningBypass and tuningTimer == 0 then
                        if driver == ped then
                            local oldTuning = GetVehicleTuningData(vehicle)
                            
                            if oldTuning then
                                Wait(1000)
                                
                                local newTuning = GetVehicleTuningData(vehicle)
                                
                                -- Compare tuning data
                                if oldTuning and newTuning and oldTuning.plate == newTuning.plate then
                                    -- Check for tuning modifications
                                    if oldTuning.color1 ~= newTuning.color1 or
                                       oldTuning.color2 ~= newTuning.color2 or
                                       oldTuning.pearlescentColor ~= newTuning.pearlescentColor or
                                       oldTuning.wheelColor ~= newTuning.wheelColor or
                                       oldTuning.modSpoilers ~= newTuning.modSpoilers or
                                       oldTuning.modFrontBumper ~= newTuning.modFrontBumper or
                                       oldTuning.modRearBumper ~= newTuning.modRearBumper or
                                       oldTuning.modEngine ~= newTuning.modEngine or
                                       oldTuning.modBrakes ~= newTuning.modBrakes or
                                       oldTuning.modTransmission ~= newTuning.modTransmission or
                                       oldTuning.modSuspension ~= newTuning.modSuspension then
                                        SafeTriggerServerEvent('VexShield:banHandler', 'Vehicle tuning modification detected')
                                        tuningTimer = 30 -- Reset timer after detection
                                    end
                                end
                            end
                        end
                    else
                        Wait(2500)
                    end
                end
            end
        end
        ::continue::
    end
end)

-- print("working client laaste")
-- Single table: chunk-local limit (200); avoids eight separate file-scope locals.
local __invSj = {
    inv_count = 0,
    inv_window = 0,
    sj_active = false,
    sj_startZ = 0.0,
    sj_peakZ = 0.0,
    sj_flag = 0,
}
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Citizen.Wait(1000)
        if not VexShieldIsProtectionOn('Anti Invisible') then break end
        local ped = PlayerPedId()
        local isAdminNC = (LocalPlayer and LocalPlayer.state and (LocalPlayer.state.VexShield_noclip or LocalPlayer.state.VexShield_freecam)) or false
        local invisible = (not IsEntityVisible(ped)) or (GetEntityAlpha(ped) < 255)
        local speed = GetEntitySpeed(ped)
        local now = GetGameTimer()
        if invisible and not isAdminNC and speed > 1.0 then
            if now - __invSj.inv_window <= 2500 then __invSj.inv_count = __invSj.inv_count + 1 else __invSj.inv_window = now __invSj.inv_count = 1 end
            if __invSj.inv_count >= 3 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Invisible detected')
                __invSj.inv_count = 0
                __invSj.inv_window = 0
            end
        end
    end
end)
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Citizen.Wait(100)
        if not VexShieldIsProtectionOn('Anti Super Jump') then break end
        local ped = PlayerPedId()
        local inVeh = IsPedInAnyVehicle(ped, false)
        if inVeh then goto cont end
        local jumping = IsPedJumping(ped)
        local vel = GetEntityVelocity(ped)
        local coords = GetEntityCoords(ped)
        if jumping and not __invSj.sj_active then
            __invSj.sj_active = true
            __invSj.sj_startZ = coords.z
            __invSj.sj_peakZ = __invSj.sj_startZ
        end
        if __invSj.sj_active then
            local z = coords.z
            if z > __invSj.sj_peakZ then __invSj.sj_peakZ = z end
            if vel.z > 10.0 then __invSj.sj_flag = __invSj.sj_flag + 1 end
            if not jumping and IsPedOnFoot(ped) then
                local delta = __invSj.sj_peakZ - __invSj.sj_startZ
                if delta > 5.0 or __invSj.sj_flag >= 3 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Super Jump detected')
                end
                __invSj.sj_active = false
                __invSj.sj_startZ = 0.0
                __invSj.sj_peakZ = 0.0
                __invSj.sj_flag = 0
            end
        end
        ::cont::
    end
end)
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    local ncWindow = 0
    local ncCount = 0
    while true do
        Citizen.Wait(500)
        if not VexShieldIsProtectionOn('Anti Noclip') then break end
        local ped = PlayerPedId()
        -- Check state bags AND collision disabled (txAdmin noclip instant indicator)
        local ncState = LocalPlayer and LocalPlayer.state
        local isAdminNC = (ncState and (ncState.VexShield_noclip or ncState.VexShield_freecam or ncState.noclip or ncState.freecam)) or false
        -- Instant check: collision disabled = txAdmin noclip active (no replication delay)
        if not isAdminNC and GetEntityCollisionDisabled(ped) then isAdminNC = true end
        if isAdminNC or VexShieldClientState.isExempt then goto nxt end
        if not IsPedInAnyVehicle(ped) then
            local inAir = IsEntityInAir(ped)
            local falling = IsPedFalling(ped)
            local ragdoll = IsPedRagdoll(ped)
            local speed = GetEntitySpeed(ped)
            local jumping = IsPedJumping(ped)
            local height = GetEntityHeightAboveGround(ped)
            local now = GetGameTimer()
            if inAir and not falling and not ragdoll and not jumping and speed > 4.0 and height > 5.0
                and not VexShieldShouldSkipNoclipWater(ped) then
                if now - ncWindow <= 2000 then
                    ncCount = ncCount + 1
                else
                    ncWindow = now
                    ncCount = 1
                end
                if ncCount >= 3 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'NoClip detected')
                    ncCount = 0
                    ncWindow = 0
                end
            else
                if now - ncWindow > 2500 then
                    ncCount = 0
                    ncWindow = 0
                end
            end
        end
        ::nxt::
    end
end)


---------------------------------------------------------------------------------
-- ANTI ATTACH OBJECT TO PLAYER (Enhanced Detection for Props)
---------------------------------------------------------------------------------
VexShieldClientState.attachObjectToPlayerStrikes = VexShieldClientState.attachObjectToPlayerStrikes or 0
VexShieldClientState.lastAttachObjectToPlayerReport = VexShieldClientState.lastAttachObjectToPlayerReport or 0

CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        VexShieldProtectionPollWait('Anti Attach Object to Player', 3000)
        VexShieldRunProtectedTick('Anti Attach Object to Player', function()
            if not VexShieldIsProtectionOn('Anti Attach Object to Player') then
                VexShieldClientState.attachObjectToPlayerStrikes = 0
                return
            end
            local playerPed = PlayerPedId()
            if not DoesEntityExist(playerPed) then return end
            local playerId = PlayerId()
            local suspiciousObjects = {}
            local objects = AS_GetPool('CObject')
            for i = 1, #objects do
                local obj = objects[i]
                if DoesEntityExist(obj) and NetworkGetEntityIsNetworked(obj) and IsEntityAttachedToEntity(obj, playerPed) then
                    local parentEntity = GetEntityAttachedTo(obj)
                    local owner = NetworkGetEntityOwner(obj)
                    if parentEntity == playerPed
                        and owner ~= playerId
                        and owner ~= -1
                        and not isAdmin(owner) then
                        suspiciousObjects[#suspiciousObjects + 1] = obj
                    end
                end
            end

            if #suspiciousObjects >= 2 then
                VexShieldClientState.attachObjectToPlayerStrikes = VexShieldClientState.attachObjectToPlayerStrikes + 1
            else
                VexShieldClientState.attachObjectToPlayerStrikes = math.max(0, VexShieldClientState.attachObjectToPlayerStrikes - 1)
            end

            local now = GetGameTimer()
            if VexShieldClientState.attachObjectToPlayerStrikes >= 3 and now - VexShieldClientState.lastAttachObjectToPlayerReport > 30000 then
                VexShieldClientState.lastAttachObjectToPlayerReport = now
                VexShieldClientState.attachObjectToPlayerStrikes = 0
                SafeTriggerServerEvent('VexShield:banHandler', 'Attach Object to Player Detected')
                for i = 1, #suspiciousObjects do
                    DeleteEntity(suspiciousObjects[i])
                end
            end
        end)
    end
end)

---------------------------------------------------------------------------------
-- ANTI TELEPORT VEHICLE OCEAN
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        Wait(1000)
        if not VexShieldIsProtectionOn('Anti Teleport Vehicle Ocean') then
            break
        end
        
        local playerPed = PlayerPedId()
        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            if DoesEntityExist(vehicle) then
                local vehicleCoords = GetEntityCoords(vehicle)
                local vehicleSpeed = GetEntitySpeed(vehicle)
                
                -- Check if vehicle is teleported to ocean coordinates (0.0, 0.0, 0.0) or very deep water
                if (vehicleCoords.x == 0.0 and vehicleCoords.y == 0.0 and vehicleCoords.z == 0.0) or
                   (vehicleCoords.z < -50.0 and vehicleSpeed < 1.0) then
                    local groundZ = GetHeightmapBottomZForPosition(vehicleCoords.x, vehicleCoords.y)
                    if vehicleCoords.z < groundZ - 10.0 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Teleport Vehicle Ocean Detected')
                        SetEntityCoords(vehicle, vehicleCoords.x, vehicleCoords.y, groundZ + 1.0)
                    end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI DELETE PED MANIPULATION
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    while true do
        VexShieldProtectionPollWait('Anti Delete Ped Manipulation', 800)
        if not VexShieldIsProtectionOn('Anti Delete Ped Manipulation') then
            goto continue
        end
        
        local playerPed = PlayerPedId()
        if not DoesEntityExist(playerPed) then
            SafeTriggerServerEvent('VexShield:banHandler', 'Delete Ped Manipulation Detected')
            goto continue
        end
        
        local playerCoords = GetEntityCoords(playerPed)
        local pool = AS_GetPool('CPed')
        local nearbyPeds = {}
        for i = 1, #pool do
            local ped = pool[i]
            if ped ~= playerPed and DoesEntityExist(ped) then
                local pedCoords = GetEntityCoords(ped)
                if #(playerCoords - pedCoords) < 5.0 then
                    nearbyPeds[#nearbyPeds + 1] = ped
                end
            end
        end

        if #nearbyPeds > 0 then
            Wait(100)
            for i = 1, #nearbyPeds do
                if not DoesEntityExist(nearbyPeds[i]) then
                    -- suspicious nearby ped deletion (logged only)
                end
            end
        end
        
        ::continue::
    end
end)

---------------------------------------------------------------------------------
-- ANTI CHEAT MENU - Comprehensive Protection
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    -- Cheat Menu Detection Variables
    local cheatMenuDetected = false
    local cheatFunctionCalls = {}
    local lastCheatCheck = GetGameTimer()
    
    -- Check for cheat menu global variables
    while true do
        VexShieldProtectionPollWait('Anti Cheat Menu', 2500)
        VexShieldRunProtectedTick('Anti Cheat Menu/globals', function()
            if not VexShieldIsProtectionOn('Anti Cheat Menu') then
                return
            end
            local cheatGlobals = {
                "hixaxtiondfdsvvcxvvdsfdsf", "kkkl", "menuName", "menulist",
                "HamMafia", "Ham", "dopamine", "Dopamine", "Lynx8", "LynxMenu", "Lynx",
                "eulen", "Eulen", "redengine", "RedEngine", "skript", "Skript",
                "desudo", "nexus", "Nexus", "fallout", "Fallout", "brutan", "Brutan",
                "PlaneMenu", "Absolute", "HydroMenu", "WarMenu_Setup", "TiagoMenu",
                "Tiago", "Mishun", "InSec", "ISMMENU", "AOG", "AlphaV", "Maestro",
                "Rena", "Hydro", "Oblivious", "CKgang", "Darkside", "Swagmenu",
                "Alikhan", "KoGuSz", "xse", "Crown", "Outsider", "Luxmenu", "Soviet",
                "FendinX", "NopixelMenu", "FantaMenu", "Extasy", "MMenu", "Chocohax",
                "HamHax", "SwagMenu", "DopamineMenu", "AlphaMenu"
            }
            for _, globalName in ipairs(cheatGlobals) do
                if _G[globalName] ~= nil then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Menu Detected: ' .. globalName)
                    cheatMenuDetected = true
                    break
                end
            end
            if not VexShieldIsProtectionOn('Anti Cheat Menu Functions') then
                return
            end
            local cheatFunctions = {
                "HamMafia.CreateMenu", "HamMafia.GetClosestPlayer",
                "dopamine.CreateMenu", "Lynx8.CreateMenu", "LynxMenu.CreateMenu",
                "PlaneMenu.CreateMenu", "WarMenu.CreateMenu", "WarMenu.IsMenuOpened",
                "TiagoMenu.CreateMenu", "Absolute.CreateMenu", "HydroMenu.CreateMenu",
                "Darkside.CreateMenu", "AlphaV.CreateMenu",
                "hixaxtiondfdsvvcxvvdsfdsf.CreateMenu",
                "hixaxtiondfdsvvcxvvdsfdsf.Button",
                "hixaxtiondfdsvvcxvvdsfdsf.Display",
                "kkkl.GetPlayers", "kkkl.GetClosestPlayer", "kkkl.TriggerCustomEvent"
            }
            for _, funcName in ipairs(cheatFunctions) do
                local parts = {}
                for part in funcName:gmatch("[^.]+") do
                    table.insert(parts, part)
                end
                local obj = _G
                for i = 1, #parts - 1 do
                    if obj[parts[i]] then
                        obj = obj[parts[i]]
                    else
                        obj = nil
                        break
                    end
                end
                if obj and obj[parts[#parts]] and type(obj[parts[#parts]]) == "function" then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Menu Functions Detected: ' .. funcName)
                end
            end
        end)
    end
end)



---------------------------------------------------------------------------------
-- ANTI CHEAT TELEPORT FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Teleport Functions') then return end
    
    local ped = PlayerPedId()
    local lastPosition = GetEntityCoords(ped)
    local teleportThreshold = 50.0
    
    while true do
        Wait(500)
        ped = PlayerPedId()
        local currentPosition = GetEntityCoords(ped)
        local distance = #(currentPosition - lastPosition)
        
        -- Check for suspicious teleportation patterns
        if distance > teleportThreshold then
            -- Check if player is in vehicle (legitimate teleport)
            if not IsPedInAnyVehicle(ped, false) then
                -- Check if teleport is to waypoint (legitimate)
                local waypoint = GetFirstBlipInfoId(8)
                if DoesBlipExist(waypoint) then
                    local wpCoords = GetBlipInfoIdCoord(waypoint)
                    local wpDistance = #(currentPosition - wpCoords)
                    if wpDistance > 10.0 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Teleport Functions: Suspicious teleport detected')
                    end
                else
                    SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Teleport Functions: Teleport without waypoint')
                end
            end
        end
        
        lastPosition = currentPosition
    end
end)

---------------------------------------------------------------------------------
-- ANTI CHEAT WEAPON FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Weapon Functions') then return end
    
    local lastWeaponCheck = GetGameTimer()
    local weaponCount = {}
    
    while true do
        Wait(2000)
        local ped = PlayerPedId()
        local weapons = {}
        
        -- Use IsPedArmed to check if ped has any weapon
        -- Count weapons by checking common weapon hashes
        local commonWeapons = {
            GetHashKey("WEAPON_PISTOL"), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("WEAPON_APPISTOL"),
            GetHashKey("WEAPON_MICROSMG"), GetHashKey("WEAPON_SMG"), GetHashKey("WEAPON_ASSAULTSMG"),
            GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("WEAPON_ADVANCEDRIFLE"),
            GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("WEAPON_SAWNOFFSHOTGUN"), GetHashKey("WEAPON_ASSAULTSHOTGUN"),
            GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("WEAPON_HEAVYSNIPER"), GetHashKey("WEAPON_MARKSMANRIFLE"),
            GetHashKey("WEAPON_KNIFE"), GetHashKey("WEAPON_NIGHTSTICK"), GetHashKey("WEAPON_BAT"),
            GetHashKey("WEAPON_CROWBAR"), GetHashKey("WEAPON_HAMMER"), GetHashKey("WEAPON_GOLFCLUB")
        }
        
        for _, weaponHash in ipairs(commonWeapons) do
            if HasPedGotWeapon(ped, weaponHash, false) then
                table.insert(weapons, weaponHash)
            end
        end
        
        local currentWeaponCount = #weapons
        if weaponCount.last then
            local diff = currentWeaponCount - weaponCount.last
            if diff > 5 and GetGameTimer() - lastWeaponCheck < 3000 then
                SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Weapon Functions: Suspicious weapon spawn rate')
            end
        end
        weaponCount.last = currentWeaponCount
        lastWeaponCheck = GetGameTimer()
    end
end)



---------------------------------------------------------------------------------
-- ANTI CHEAT PED FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Ped Functions') then return end
    
    while true do
        Wait(2000)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        -- Check for spawned peds with weapons (cheat makePedHostile function)
        for ped in EnumeratePeds() do
            if ped ~= playerPed and not IsPedAPlayer(ped) then
                -- Use IsPedArmed to check if ped has any weapon
                if IsPedArmed(ped, 1) or IsPedArmed(ped, 2) or IsPedArmed(ped, 4) then
                    local pedCoords = GetEntityCoords(ped)
                    local distance = #(pedCoords - playerCoords)
                    
                    if distance < 50.0 then
                        -- Check if ped is targeting player (suspicious)
                        if IsPedInCombat(ped, playerPed) then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Ped Functions: Suspicious hostile ped detected')
                        end
                    end
                end
            end
        end
    end
end)

-- Anti Cheat Object Functions (prop blacklist / spam): handled server-side only (server/main.lua)

---------------------------------------------------------------------------------
-- ANTI CHEAT EXPLOSION FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Explosion Functions') then return end
    
    local explosionTimestamps = {}
    local explosionSpamWindow = 1000
    local explosionSpamThreshold = 3

    AddEventHandler('explosionEvent', function(sender, ev)
        local now = GetGameTimer()
        local cutoff = now - explosionSpamWindow
        while #explosionTimestamps > 0 and explosionTimestamps[1] < cutoff do
            table.remove(explosionTimestamps, 1)
        end
        table.insert(explosionTimestamps, now)
        if #explosionTimestamps > explosionSpamThreshold then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Explosion Functions: Suspicious explosion rate (>3 in 1s)')
        end
    end)
end)



---------------------------------------------------------------------------------
-- ANTI CHEAT SPECTATE
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Spectate') then return end
    
    while true do
        Wait(2000)
        
        -- Check for spectate mode (cheat SpectatePlayer function)
        if NetworkIsInSpectatorMode() then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Spectate: Spectate mode detected')
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI CHEAT FORCE FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Force Functions') then return end
    
    while true do
        Wait(2000)
        local ped = PlayerPedId()
        local playerId = PlayerId()
        local pedCoords = GetEntityCoords(ped)
        
        -- Check for force field effects (cheat DoForceFieldTick function)
        local vehicles = AS_GetPool('CVehicle')
        local forceCount = 0
        
        for _, vehicle in ipairs(vehicles) do
            if DoesEntityExist(vehicle) and NetworkGetEntityOwner(vehicle) == playerId then
                local vehicleCoords = GetEntityCoords(vehicle)
                local distance = #(vehicleCoords - pedCoords)
                
                if distance < 10.0 then
                    local velocity = GetEntityVelocity(vehicle)
                    local speed = #velocity
                    
                    -- If vehicle is moving suspiciously fast near player
                    if speed > 50.0 and not IsPedInVehicle(ped, vehicle, false) then
                        forceCount = forceCount + 1
                    end
                end
            end
        end
        
        if forceCount > 3 then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Force Functions: Suspicious force field detected')
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI CHEAT CLONE FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Clone Functions') then return end
    
    while true do
        Wait(3000)
        
        -- Check for cloned peds (cheat ClonePed function)
        local playerPed = PlayerPedId()
        local playerModel = GetEntityModel(playerPed)
        local cloneCount = 0
        
        for ped in EnumeratePeds() do
            if ped ~= playerPed and not IsPedAPlayer(ped) and not isProtectedTrafficPed(ped) then
                if GetEntityModel(ped) == playerModel then
                    local pedCoords = GetEntityCoords(ped)
                    local playerCoords = GetEntityCoords(playerPed)
                    local distance = #(pedCoords - playerCoords)
                    
                    if distance < 20.0 then
                        cloneCount = cloneCount + 1
                        
                        -- Delete cloned peds immediately
                        if cloneCount > 1 then
                            -- Disabled hard delete to avoid traffic false positives.
                        end
                    end
                end
            end
        end
        
        if cloneCount > 2 then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Clone Functions: Suspicious clone detected')
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI CHEAT CAGE FUNCTIONS
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Cage Functions') then return end
    
    while true do
        Wait(2000)
        local ped = PlayerPedId()
        local pedCoords = GetEntityCoords(ped)
        
        -- Check for cage objects (cheat Cage Player function uses prop_fnclink_05crnr1)
        local objects = AS_GetPool('CObject')
        local cageCount = 0
        
        for _, obj in ipairs(objects) do
            local objModel = GetEntityModel(obj)
            if objModel == GetHashKey("prop_fnclink_05crnr1") then
                local objCoords = GetEntityCoords(obj)
                local distance = #(objCoords - pedCoords)
                
                if distance < 5.0 then
                    cageCount = cageCount + 1
                end
            end
        end
        
        if cageCount >= 2 then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Cage Functions: Cage detected')
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI CHEAT INVENTORY EXPLOIT
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti Cheat Inventory Exploit') then return end
    
    -- Monitor for suspicious inventory events
    RegisterNetEvent('qb-inventory:server:OpenInventory')
    AddEventHandler('qb-inventory:server:OpenInventory', function(type, id)
        if type == 'dgfggfdfvdv0cxvcx550' then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Inventory Exploit: Suspicious inventory access')
        end
    end)
    
    RegisterNetEvent('inventory:client:OpenInventory')
    AddEventHandler('inventory:client:OpenInventory', function(type, id)
        if type == 'dgfggfdfvdv0cxvcx550' then
            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Inventory Exploit: Suspicious inventory access')
        end
    end)
end)


---------------------------------------------------------------------------------
-- ANTI cheat MENU - Comprehensive Protection
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    
    -- cheat Menu Detection Variables
    local cheatMenuDetected = false
    local cheatFunctionCalls = {}
    local lastcheatCheck = GetGameTimer()
    
    -- Check for cheat menu global variables
    while true do
        Wait(2000)
        
        if not VexShieldIsProtectionOn('Anti cheat Menu') then
            Wait(5000)
            goto continue
        end
        
        -- Detect cheat menu global variables
        local cheatGlobals = {
            "NBA",
            "cheatAuthenticationKey",
            "cheatWebRequest",
            "cheatMenuNotification",
            "cheatLockLogger",
            "cheatResourceStop",
            "cheatHookNative",
            "cheatInjectResource",
            "cheatInjectResourceRaw",
            "cheatInjectResource2",
            "cheatResourceInjectable",
            "cheatSendDuiMessage",
            "NBAFreecamEnabled",
            "NBAFreecamObject",
            "NBAFreecamThreadRunning",
            "NBAFreecamSpeed",
            "NBASpectateState"
        }
        
        for _, globalName in ipairs(cheatGlobals) do
            if _G[globalName] ~= nil then
                SafeTriggerServerEvent('VexShield:banHandler', 'cheat Menu Detected: ' .. globalName)
                cheatMenuDetected = true
                break
            end
        end
        
        -- Detect cheat menu functions
        if not VexShieldIsProtectionOn('Anti cheat Menu Functions') then
            goto continue
        end
        
        local cheatFunctions = {
            "NBA.ToggleFreecam",
            "NBA:ToggleFreecam",
            "cheatAuthenticationKey",
            "cheatWebRequest",
            "cheatMenuNotification",
            "cheatLockLogger",
            "cheatResourceStop",
            "cheatHookNative",
            "cheatInjectResource",
            "cheatInjectResourceRaw",
            "cheatInjectResource2"
        }
        
        for _, funcName in ipairs(cheatFunctions) do
            local parts = {}
            for part in funcName:gmatch("[^.:]+") do
                table.insert(parts, part)
            end
            
            local obj = _G
            for i = 1, #parts - 1 do
                if obj[parts[i]] then
                    obj = obj[parts[i]]
                else
                    obj = nil
                    break
                end
            end
            
            if obj and obj[parts[#parts]] and type(obj[parts[#parts]]) == "function" then
                SafeTriggerServerEvent('VexShield:banHandler', 'cheat Menu Functions Detected: ' .. funcName)
            end
        end
        
        ::continue::
    end
end)

-- ANTI cheat API FUNCTIONS
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti cheat API Functions') then return end
    
    while true do
        Wait(3000)
        
        -- Check for cheat API usage
        local cheatFunctions = {
            "cheatHookNative",
            "cheatInjectResource",
            "cheatInjectResourceRaw",
            "cheatInjectResource2",
            "cheatResourceStop",
            "cheatResourceInjectable"
        }
        
        for _, funcName in ipairs(cheatFunctions) do
            if _G[funcName] and type(_G[funcName]) == "function" then
                -- Check if function is being called (basic detection)
                local funcInfo = debug.getinfo(_G[funcName], "S")
                if funcInfo then
                    SafeTriggerServerEvent('VexShield:banHandler', 'cheat API Functions: ' .. funcName .. ' detected')
                end
            end
        end
    end
end)



-- ANTI cheat SPECTATE
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti cheat Spectate') then return end
    
    while true do
        Wait(2000)
        
        -- Check for cheat spectate state
        if _G.NBASpectateState and _G.NBASpectateState.back then
            SafeTriggerServerEvent('VexShield:banHandler', 'cheat Spectate: Spectate state detected')
        end
        
        -- Check for spectate mode
        if NetworkIsInSpectatorMode() then
            SafeTriggerServerEvent('VexShield:banHandler', 'cheat Spectate: Spectate mode detected')
        end
    end
end)

-- ANTI cheat BYPASS FUNCTIONS
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    
    if not VexShieldIsProtectionOn('Anti cheat Bypass Functions') then return end
    
    while true do
        Wait(5000)
        
        -- Check for cheat bypass attempts (ReaperV4, Eagle, Electron bypass)
        local bypassPatterns = {
            "reaper",
            "ReaperV4",
            "Eagle",
            "EC-AC",
            "EC_AC",
            "ElectronAC",
            "FiveGuard"
        }
        
        -- Check for blocked events that cheat menu tries to bypass
        local blockedEvents = {
            "reaper:client:detected",
            "reaper:client:log",
            "Eagle:ban",
            "Eagle:kick",
            "EC-AC:ban",
            "EC_AC:detect"
        }
        
        -- Monitor for suspicious resource stopping attempts
        local totalRes = GetNumResources()
        for i = 0, totalRes - 1 do
            local resName = GetResourceByFindIndex(i)
            if resName then
                local lowerName = string.lower(resName)
                for _, pattern in ipairs(bypassPatterns) do
                    if string.find(lowerName, string.lower(pattern)) then
                        -- If anti-cheat resource is stopped, might be cheat bypass
                        if GetResourceState(resName) ~= "started" then
                            SafeTriggerServerEvent('VexShield:banHandler', 'cheat Bypass Functions: Suspicious resource state')
                        end
                    end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI NATIVE HOOK (Detect Native Function Hooking Attempts)
---------------------------------------------------------------------------------
CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end
    while true do
        Wait(5000)
        if not VexShieldIsProtectionOn('Anti Native Hook') then
            break
        end
        
        -- Check for suspicious native function modifications
        local suspiciousPatterns = {
            "TriggerServerEvent",
            "SetEntityHealth",
            "SetEntityInvincible",
            "GiveWeaponToPed",
            "SetEntityCoords",
            "FreezeEntityPosition"
        }
        
        for _, funcName in ipairs(suspiciousPatterns) do
            local func = _G[funcName]
            if func and type(func) == "function" then
                -- Check if function has been wrapped/hooked by checking if it's a table or has suspicious metadata
                local funcInfo = debug.getinfo(func, "S")
                if funcInfo then
                    -- If the function source is not from a known location, it might be hooked
                    -- This is a basic check and might need refinement
                end
            end
        end
        
        -- Monitor for rapid native function calls that might indicate hooking
        local hookAttemptCount = 0
        local lastHookCheck = GetGameTimer()
        
        -- This is a simplified check - actual native hook detection is complex
        if GetGameTimer() - lastHookCheck > 10000 then
            lastHookCheck = GetGameTimer()
            -- Reset counter every 10 seconds
            hookAttemptCount = 0
        end
    end
end)

-- ====================
-- INJECTION RESOURCE DETECTION
-- ====================
CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Resource Injection') then return end
    
    while not VexShieldClientState.playerLoaded or VexShieldClientState.isExempt == nil do
        Wait(500)
    end
    
    local initialResourceCount = GetNumResources()
    
    while true do
        Wait(Shared.InjectionChecking or 15000)
        
        if VexShieldClientState.playerLoaded and not VexShieldClientState.isExempt then
            local currentResourceCount = GetNumResources()
            
            if initialResourceCount and currentResourceCount ~= initialResourceCount then
                SafeTriggerServerEvent('VexShield:banHandler', 'Resource Injection Detected (NRC Method)')
            end
        end
    end
end)

-- ====================
-- INJECTION COMMAND DETECTION
-- ====================
CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Resource Injection') then return end
    
    while not VexShieldClientState.playerLoaded or VexShieldClientState.isExempt == nil do
        Wait(500)
    end
    
    local blacklistedCommands = Shared.BlacklistedCommands or {}
    
    while true do
        Wait(Shared.InjectionChecking or 15000)
        
        if VexShieldClientState.playerLoaded and not VexShieldClientState.isExempt then
            local commands = GetRegisteredCommands()
            
            for _, command in ipairs(commands) do
                for _, blacklisted in ipairs(blacklistedCommands) do
                    if command.name == blacklisted then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Injection Command Detected: ' .. command.name)
                    end
                end
            end
        end
    end
end)

-- Injection / dynamic-exec detection: client/VexShield_inject_detect.lua (separate chunk).

-- ====================
-- CHEAT ENGINE DETECTION
-- ====================
CreateThread(function()
    while not Shared or not Shared.Protections do Wait(250) end
    if not VexShieldIsProtectionOn('Anti Resource Injection') then return end
    
    while not VexShieldClientState.playerLoaded or VexShieldClientState.isExempt == nil do
        Wait(500)
    end
    
    local lastVehicle = 0
    local lastModel = nil
    
    while true do
        Wait(Shared.CheatEngineChecking or 15000)
        
        if VexShieldClientState.playerLoaded and not VexShieldClientState.isExempt then
            local ped = PlayerPedId()
            if DoesEntityExist(ped) then
                local vehicle = GetVehiclePedIsIn(ped, false)
                
                if IsPedSittingInAnyVehicle(ped) then
                    if lastVehicle == vehicle then
                        local model = GetEntityModel(vehicle)
                        if lastModel and model ~= lastModel and lastModel ~= 0 then
                            DeleteVehicle(vehicle)
                            SafeTriggerServerEvent('VexShield:banHandler', 'Cheat Engine Detected')
                        end
                    end
                    lastVehicle = vehicle
                    lastModel = GetEntityModel(vehicle)
                end
            end
        end
    end
end)

-- =============================================================================
-- NEW PROTECTIONS
-- =============================================================================
Citizen.CreateThread(function()
    while not configLoaded do Wait(250) end
    while not configLoaded or not isPlayerReady do Wait(250) end

    local rollCount = 0
    local rollTimer = 0
    
    local healCount = 0
    local healTimer = 0
    local lastHealth = 0

    -- Anti Godmode variables
    local godmodeLastHealth = 0
    local godmodeRegenCount = 0
    local godmodeRegenTimer = 0
    local godmodeInvincibleFlags = 0

    local teleportCount = 0
    local teleportTimer = 0
    local lastCoords = nil
    local illegalAttachmentStrikes = {}
    
    while true do
        Citizen.Wait(1500)
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then goto continue_prot_new end
        
        -- 1. Anti Animation Injection
        if VexShieldIsProtectionOn('Anti Animation Injection') and Shared.BlockedAnimations then
            for dict, anims in pairs(Shared.BlockedAnimations) do
                for _, animName in ipairs(anims) do
                    if IsEntityPlayingAnim(ped, dict, animName, 3) then
                        ClearPedTasksImmediate(ped)
                        SafeTriggerServerEvent('VexShield:banHandler', 'Blacklisted Animation Detected: ' .. animName)
                        goto continue_prot_new
                    end
                end
            end
        end

        -- 2. Anti Player Attach
        if VexShieldIsProtectionOn('Anti Player Attach') then
            -- A. Check if I am attached to something illegal
            if IsEntityAttached(ped) then
                local attachedTo = GetEntityAttachedTo(ped)
                if DoesEntityExist(attachedTo) then
                    if not IsEntityAVehicle(attachedTo) and not IsPedAPlayer(attachedTo) then
                        DetachEntity(ped, true, true)
                    end
                end
            end

            -- B. Check if other entities are attached to ME (Katamari/Griefing)
            -- More aggressive scan every 200ms
            if not VexShield_LastAttachScan then VexShield_LastAttachScan = 0 end
            if not ShouldSkipIllegalAttachmentCheck(ped) and GetGameTimer() - VexShield_LastAttachScan > 350 then
                VexShield_LastAttachScan = GetGameTimer()

                local function IsAttachedToPlayer(entity, targetPlayerPed)
                    if not DoesEntityExist(entity) then return false end
                    if not IsEntityAttached(entity) then return false end
                    
                    local myVehicle = GetVehiclePedIsIn(targetPlayerPed, false)
                    
                    local current = entity
                    local limit = 0
                    while IsEntityAttached(current) and limit < 10 do
                        current = GetEntityAttachedTo(current)
                        if current == targetPlayerPed then return true end
                        if myVehicle ~= 0 and current == myVehicle then return true end
                        limit = limit + 1
                    end
                    return false
                end

                local function CleanEntity(entity)
                    if DoesEntityExist(entity) then
                        DetachEntity(entity, true, true)
                        SetEntityAsMissionEntity(entity, true, true)
                        
                        -- Try to take control before deleting (Aggressive Loop)
                        local attempts = 0
                        while not NetworkHasControlOfEntity(entity) and attempts < 20 do
                            NetworkRequestControlOfEntity(entity)
                            Wait(100)
                            attempts = attempts + 1
                        end
                        
                        DeleteEntity(entity)
                        
                        -- Fallback: move it far away if delete fails
                        if DoesEntityExist(entity) then
                            SetEntityCoords(entity, 0.0, 0.0, -500.0, false, false, false, true)
                            SetEntityCollision(entity, false, false)
                            SetEntityVisible(entity, false, 0)
                            -- Force local deletion attempt
                            SetEntityAsNoLongerNeeded(entity)
                            DeleteEntity(entity)
                        end
                    end
                end

                local function ShouldReportIllegalAttachment(owner, ownerServerId, reasonKey)
                    if owner == -1 or owner == PlayerId() or not ownerServerId or ownerServerId <= 0 then
                        return false
                    end

                    local now = GetGameTimer()
                    local key = tostring(ownerServerId) .. ":" .. tostring(reasonKey)
                    local strike = illegalAttachmentStrikes[key]

                    if strike and (now - strike.lastSeen) <= 8000 then
                        strike.count = strike.count + 1
                        strike.lastSeen = now
                    else
                        strike = { count = 1, lastSeen = now }
                    end

                    illegalAttachmentStrikes[key] = strike
                    return strike.count >= 2
                end

                -- Check Objects
                local playerId = PlayerId()
                local objects = AS_GetPool('CObject')
                local weaponEntity = GetCurrentPedWeaponEntityIndex(ped)
                for _, obj in ipairs(objects) do
                    if IsAttachedToPlayer(obj, ped) then
                        -- Identify Attacker before deleting
                        local owner = NetworkGetEntityOwner(obj)
                        local ownerServerId = GetPlayerServerId(owner)
                        
                        if obj ~= weaponEntity and owner ~= playerId then
                            CleanEntity(obj)
                            
                            if ShouldReportIllegalAttachment(owner, ownerServerId, 'object_attach') then
                                 SafeTriggerServerEvent('VexShield:banAttacker', ownerServerId, 'Illegal Attachment Detected (Attaching to other players)')
                            end
                        end
                    end
                end

                -- Check Peds (NPCs)
                local peds = AS_GetPool('CPed')
                for _, npc in ipairs(peds) do
                    if npc ~= ped and not IsPedAPlayer(npc) and IsAttachedToPlayer(npc, ped) then
                        -- Identify Attacker before deleting
                        local owner = NetworkGetEntityOwner(npc)
                        local ownerServerId = GetPlayerServerId(owner)
                        
                        CleanEntity(npc)
                        
                        if ShouldReportIllegalAttachment(owner, ownerServerId, 'ped_attach') then
                             SafeTriggerServerEvent('VexShield:banAttacker', ownerServerId, 'Illegal Attachment Detected (Attaching to other players)')
                        end
                    end
                end

                -- Check Vehicles
                local vehicles = AS_GetPool('CVehicle')
                for _, veh in ipairs(vehicles) do
                    if IsAttachedToPlayer(veh, ped) then
                        -- Identify Attacker before deleting
                        local owner = NetworkGetEntityOwner(veh)
                        local ownerServerId = GetPlayerServerId(owner)
                        
                        CleanEntity(veh)
                        
                        if ShouldReportIllegalAttachment(owner, ownerServerId, 'vehicle_attach') then
                             SafeTriggerServerEvent('VexShield:banAttacker', ownerServerId, 'Illegal Attachment Detected (Attaching Vehicle to other players)')
                        end
                    end
                end
            end
        end

        -- 3. Anti Player Collision Disable (Placeholder)
        -- if Shared.Protections['Anti Player Collision Disable'] then
        -- end

        -- 5. Anti Infinite Roll
        if VexShieldIsProtectionOn('Anti Infinite Roll') then
            if IsPedEvasiveDiving(ped) then
                local now = GetGameTimer()
                if now - rollTimer < 2000 then
                    rollCount = rollCount + 1
                else
                    rollCount = 1
                    rollTimer = now
                end
                
                if rollCount > 5 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Infinite Roll Detected')
                    rollCount = 0
                end
            end
        end

        -- 6. Anti Heal Spam
        if VexShieldIsProtectionOn('Anti Heal Spam') then
            local currentHealth = GetEntityHealth(ped)
            if currentHealth > lastHealth and lastHealth > 0 then
                local now = GetGameTimer()
                if now - healTimer < 1000 then
                    healCount = healCount + 1
                else
                    healCount = 1
                    healTimer = now
                end
                
                if healCount > 4 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Heal Spam Detected')
                    healCount = 0
                end
            end
            lastHealth = currentHealth
        end

        -- 6.5. Anti Godmode
        if VexShieldIsProtectionOn('Anti Godmode') then
            local currentHealth = GetEntityHealth(ped)
            local maxHealth = GetEntityMaxHealth(ped)
            
            if not ShouldSkipGodmodeCheck(ped) then
                -- Check 1: Health exceeds max health (hardened instant detection)
                if currentHealth > (maxHealth + 100) or currentHealth > 350 then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Godmode Detected: Health Exceeds Max (' .. currentHealth .. '/' .. maxHealth .. ')')
                end
                
                -- Check 2: require persistent invincibility plus damage immunity to avoid false positives
                local invincibleNative = GetPlayerInvincible(PlayerId())
                local canBeDamaged = GetEntityCanBeDamaged(ped)
                local suspiciousInvincible = invincibleNative and (not canBeDamaged) and currentHealth >= math.floor(maxHealth * 0.9)
                if suspiciousInvincible then
                    godmodeInvincibleFlags = godmodeInvincibleFlags + 1
                    if godmodeInvincibleFlags >= 5 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Godmode Detected: Invincible Native')
                        godmodeInvincibleFlags = 0
                    end
                else
                    godmodeInvincibleFlags = 0
                end
                
                -- Check 4: Rapid health regeneration (passive godmode) - IMPROVED
                if godmodeLastHealth and currentHealth > godmodeLastHealth then
                    local healthGained = currentHealth - godmodeLastHealth
                    local now = GetGameTimer()
                    
                    -- Skip if player received medical aid (medkit, ambulance job, etc.)
                    local hasMedicalItem = false
                    if UseQBCore then
                        local playerData = QBCore.Functions.GetPlayerData()
                        if playerData and playerData.items then
                            for _, item in pairs(playerData.items) do
                                if item.name == 'firstaid' or item.name == 'bandage' or item.name == 'medkit' or item.name == 'painkillers' then
                                    hasMedicalItem = true
                                    break
                                end
                            end
                        end
                    elseif UseESX then
                        local xPlayer = ESX.GetPlayerData()
                        if xPlayer and xPlayer.inventory then
                            for _, item in pairs(xPlayer.inventory) do
                                if item.count > 0 and (item.name == 'firstaid' or item.name == 'bandage' or item.name == 'medkit') then
                                    hasMedicalItem = true
                                    break
                                end
                            end
                        end
                    end
                    
                    if healthGained > 25 and not hasMedicalItem then
                        -- Check if player is in combat (more lenient)
                        local isInCombat = IsPedInMeleeCombat(ped) or IsPedShooting(ped)
                        
                        if not isInCombat then
                            if now - godmodeRegenTimer < 5000 then
                                godmodeRegenCount = godmodeRegenCount + 1
                            else
                                godmodeRegenCount = 1
                                godmodeRegenTimer = now
                            end
                            
                            -- Require 8 consecutive instances instead of 5 (more lenient)
                            if godmodeRegenCount > 8 then
                                -- Commenting out passive regen ban, highly prone to false positives from food/water regen scripts
                                -- SafeTriggerServerEvent('VexShield:banHandler', 'Godmode Detected: Rapid Health Regen (+ ' .. healthGained .. ' HP)')
                                godmodeRegenCount = 0
                            end
                        end
                    end
                end
                godmodeLastHealth = currentHealth
            else
                godmodeInvincibleFlags = 0
                godmodeLastHealth = currentHealth
            end
        end

        ::continue_prot_new::
    end
end)

        -- =============================================================================
-- ANTI GODMODE STANDALONE DETECTION
-- =============================================================================

Citizen.CreateThread(function()
    waitUntilReady()
    
    local healthHistory = {}
    local damageTaken = false
    local lastDamageTime = 0
    
    while true do
        Citizen.Wait(2000)
        
        if not Config or not Config.Protections or not Config.Protections['Anti Godmode'] then
            goto continue_godmode
        end
        
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) or IsPlayerSwitchInProgress() or IsCutsceneActive() or IsPedDeadOrDying(ped, true) or IsEntityVisible(ped) == false or GetEntityHealth(ped) <= 0 then
            goto continue_godmode
        end
        
        local currentHealth = GetEntityHealth(ped)
        local maxHealth = GetEntityMaxHealth(ped)
        
        -- Track health history (keep last 10 readings)
        table.insert(healthHistory, 1, {health = currentHealth, time = GetGameTimer()})
        if #healthHistory > 10 then
            table.remove(healthHistory)
        end
        
        -- Check for damage taken
        if #healthHistory >= 2 then
            if healthHistory[2].health > currentHealth then
                damageTaken = true
                lastDamageTime = GetGameTimer()
            end
        end
        
        -- Check 1: Health never decreases despite damage events
        if damageTaken and (GetGameTimer() - lastDamageTime > 5000) then
            -- If 5 seconds passed since damage but health is back to max, suspicious
            if currentHealth >= maxHealth * 0.98 then
                -- Check if this pattern repeats
                local fullHealthCount = 0
                for _, record in ipairs(healthHistory) do
                    if record.health >= maxHealth * 0.98 then
                        fullHealthCount = fullHealthCount + 1
                    end
                end
                
                -- Too aggressive, can ban people who just heal normally, need more instances and context
                if fullHealthCount >= 10 and not IsPedInAnyVehicle(ped) and not (VexShieldClientState and VexShieldClientState.isExempt) then
                    SafeTriggerServerEvent('VexShield:banHandler', 'Godmode Detected: Undying Pattern')
                    damageTaken = false
                end
            end
        end
        
        -- Check 2: Health stuck at max despite combat
        if currentHealth == maxHealth and damageTaken then
            local stuckAtMaxCount = 0
            for i = 1, math.min(6, #healthHistory) do
                if healthHistory[i].health == maxHealth then
                    stuckAtMaxCount = stuckAtMaxCount + 1
                end
            end
            
            -- If health has been at max for 6 consecutive checks after taking damage
            if stuckAtMaxCount >= 6 then
                -- Checking again with a short wait to ensure no desync
                Citizen.Wait(500)
                ped = PlayerPedId()
                if GetEntityHealth(ped) == GetEntityMaxHealth(ped) then
                    -- Very risky check, many scripts set health to max.
                    -- SafeTriggerServerEvent('VexShield:banHandler', 'Godmode Detected: Health Stuck at Max')
                end
                damageTaken = false
            end
        end
        
        -- Reset damage flag if health is legitimately low
        if currentHealth < maxHealth * 0.9 then
            damageTaken = false
        end
        
        ::continue_godmode::
    end
end)

-- =============================================================================
-- ADVANCED PROTECTIONS
-- =============================================================================

-- Store originals in one table (global — main chunk local-variable limit = 200).
__ash_prot = __ash_prot or {
    resourceName = "VexShield",
    invoke = Citizen.Invoke,
    load = load,
    tse = TriggerServerEvent,
    wait = Citizen.Wait,
}

CreateThread(function()
    Wait(2000) -- Wait for startup

    -- 1. Anti Resource Rename Bypass
    if VexShieldIsProtectionOn('Anti Resource Rename Bypass') then
        if GetCurrentResourceName() ~= __ash_prot.resourceName then
             SafeTriggerServerEvent('VexShield:banHandler', 'Resource Rename Detected')
        end
    end

    -- 2. Anti Loadstring
    if VexShieldIsProtectionOn('Anti Loadstring') then
        -- Overwrite load and loadstring
        local function denyLoad(...)
            SafeTriggerServerEvent('VexShield:banHandler', 'Load/Loadstring Usage Detected')
            return nil
        end

        if _G.load then _G.load = denyLoad end
        if _G.loadstring then _G.loadstring = denyLoad end
    end
end)

-- Continuous Checks
local startedAntiNativeHook = false
local startedAntiExecMouseHeuristic = false

CreateThread(function()
    Wait(5000)
    while true do
        Wait(5000)
        
        if Shared and Shared.Protections then
            local Protections = Shared.Protections

            -- 3. Anti Global Function Hook
            if Protections['Anti Global Function Hook'] then
                 if Citizen.Invoke ~= __ash_prot.invoke then
                     SafeTriggerServerEvent('VexShield:banHandler', 'Citizen.Invoke Hook Detected')
                 end
                 -- Skip TriggerServerEvent hook detection as it's legitimately wrapped by VexShield itself
                 -- if TriggerServerEvent ~= __ash_prot.tse then
                 --      SafeTriggerServerEvent('VexShield:banHandler', 'TriggerServerEvent Hook Detected')
                 -- end
                 if Citizen.Wait ~= __ash_prot.wait then
                     SafeTriggerServerEvent('VexShield:banHandler', 'Citizen.Wait Hook Detected')
                 end
            end

            if Protections['Anti Native Hook'] and not startedAntiNativeHook then
                startedAntiNativeHook = true
                Citizen.CreateThread(function()
                    Citizen.Wait(15000) -- Ø¨Ø¹Ø¯ ØªØ­Ù…ÙŠÙ„ Ø§Ù„Ù„Ø§Ø¹Ø¨

                    while true do
                        if VexShieldIsProtectionOn('Anti Native Hook') then
                            local ped = PlayerPedId()
                            if DoesEntityExist(ped) and not IsEntityDead(ped) then
                                local proofs = 0

                                -- 1ï¸âƒ£ Return validation
                                local c1 = GetEntityCoords(ped)
                                if not c1 or type(c1.x) ~= "number" then
                                    proofs = proofs + 1
                                end

                                if c1.x == 0.0 and c1.y == 0.0 and c1.z == 0.0 then
                                    proofs = proofs + 1
                                end

                                -- 2ï¸âƒ£ Consistency check (same frame)
                                local c2 = GetEntityCoords(ped)
                                if #(vector3(c1.x, c1.y, c1.z) - vector3(c2.x, c2.y, c2.z)) > 0.5 then
                                    proofs = proofs + 1
                                end

                                -- 3ï¸âƒ£ Execution time check
                                local t1 = GetGameTimer()
                                GetEntityCoords(ped)
                                local t2 = GetGameTimer()

                                if (t2 - t1) > 12 then
                                    proofs = proofs + 1
                                end

                                -- 4ï¸âƒ£ World sanity check
                                if not DoesEntityExist(ped) then
                                    proofs = proofs + 1
                                end

                                -- ðŸš« BAN DIRECT
                                if proofs >= 3 then
                                    SafeTriggerServerEvent(
                                        'VexShield:banHandler',
                                        'Native Hook Detected | Proofs=' .. proofs
                                    )
                                end
                            end
                        end

                        Citizen.Wait(5000)
                    end
                end)
            end

            -- 5. Anti Citizen.Invoke Abuse
            if Protections['Anti Citizen.Invoke Abuse'] then
                 -- Handled by Anti Global Function Hook
            end

            -- 6. Anti Lua Executor (Heuristic)
            if Protections['Anti Lua Executor'] then
                 local badGlobals = {
                    'RunCode', 'RunFile', 'LoadScript', 'dofile', 'loadfile', 
                    'sys_eval', 'menu_run', 'TiagoMenu', 'SwagMenu', 'HamMafia',
                    'Lynx8', 'MIO', 'FendinX', 'Lumia', 'AlphaV'
                 }
                 for _, g in ipairs(badGlobals) do
                      if _G[g] ~= nil then
                           SafeTriggerServerEvent('VexShield:banHandler', 'Lua Executor/Menu Global Detected: ' .. g)
                      end
                 end
            end

            -- 6.1 Anti Executor Detection (Mouse/Camera Heuristics)
            if Protections['Anti Lua Executor'] and not startedAntiExecMouseHeuristic then
                startedAntiExecMouseHeuristic = true
                local executorFlags = {}
                local lastPosX, lastPosY = 0, 0
                local lastGamePlayCamCoords = vector3(0, 0, 0)
                local lastTimeMovedMouse = 0
                local lastTimePressedInsert = 0
                local lastTimePressedPageUP = 0
                local lastTimePressedPageDOWN = 0
                local isUsingMouseInScripts = false
                local expiresAntiExec = 0

                CreateThread(function()
                    while not configLoaded or not isPlayerReady do Wait(250) end
                    
                    while true do
                        Wait(100)
                        
                        local currentGameTimer = GetGameTimer()
                        
                        -- Check if anti-exec protection expired
                        if currentGameTimer > expiresAntiExec then
                            isUsingMouseInScripts = false
                        end
                        
                        local isGameMovingMouse = (GetControlNormal(0, 1) ~= 0) or (GetControlNormal(0, 2) ~= 0)
                        local timeSinceLastInput = GetTimeSinceLastInput()
                        local gamePlayCamCoords = GetGameplayCamCoords()
                        local beforeX, beforeY = GetNuiCursorPosition()
                        local screenX, screenY = GetActiveScreenResolution()
                        local mouseDist = #(vector2(lastPosX, lastPosY) - vector2(beforeX, beforeY))
                        
                        if isGameMovingMouse then 
                            lastTimeMovedMouse = currentGameTimer 
                        end
                        
                        if GetControlNormal(0, 121) ~= 0 then 
                            lastTimePressedInsert = currentGameTimer 
                        end
                        
                        if GetControlNormal(0, 10) ~= 0 then 
                            lastTimePressedPageUP = currentGameTimer 
                        end
                        
                        if GetControlNormal(0, 11) ~= 0 then 
                            lastTimePressedPageDOWN = currentGameTimer 
                        end
                        
                        -- Check for valid detection situation
                        local isValidSituation = true
                        if (beforeX <= 0) or (beforeY <= 0) or (beforeX >= screenX) or (beforeY >= screenY) then
                            isValidSituation = false
                        end
                        if (mouseDist < 10) or IsNuiFocused() or IsPauseMenuActive() then
                            isValidSituation = false
                        end
                        if IsHudComponentActive(19) or IsHudComponentActive(16) then
                            isValidSituation = false
                        end
                        if IsDisabledControlPressed(0, 106) then
                            isValidSituation = false
                        end
                        if (GetControlNormal(2, 239) == 0.5) or (GetControlNormal(2, 240) == 0.5) then
                            isValidSituation = false
                        end
                        if isUsingMouseInScripts or not IsPlayerControlOn(PlayerId()) then
                            isValidSituation = false
                        end
                        if not IsUsingKeyboard(0) or UpdateOnscreenKeyboard() ~= 2 then
                            isValidSituation = false
                        end
                        
                        if isValidSituation then
                            -- Check cursor position vs center
                            SetCursorLocation(0.5, 0.5)
                            local afterX, afterY = GetNuiCursorPosition()
                            local middleDist = #(vector2(screenX/2, screenY/2) - vector2(afterX, afterY))
                            SetCursorLocation(beforeX/screenX, beforeY/screenY)
                            
                            if not isGameMovingMouse then
                                if timeSinceLastInput < 50 then
                                    if middleDist > 100 then
                                        -- Suspicious but not enough
                                    elseif (middleDist == 0) and (GetTimeSinceLastInput() > 1000) and (lastGamePlayCamCoords == gamePlayCamCoords) then
                                        if lastTimePressedPageUP > (currentGameTimer - 10000) then
                                            SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: HX')
                                        elseif lastTimePressedInsert > (currentGameTimer - 10000) then
                                            SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: E2')
                                        elseif lastTimePressedPageDOWN > (currentGameTimer - 10000) then
                                            SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: E2')
                                        end
                                    else
                                        executorFlags = {}
                                    end
                                    
                                    if timeSinceLastInput > 500 then
                                        if (middleDist == 0) and (GetTimeSinceLastInput() > 1000) and (lastGamePlayCamCoords == gamePlayCamCoords) then
                                            if lastTimePressedPageUP > (currentGameTimer - 5000) then
                                                SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: HX')
                                            elseif lastTimePressedInsert > (currentGameTimer - 5000) then
                                                SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: E4')
                                            end
                                        elseif middleDist > 100 and (GetTimeSinceLastInput() > 1000) and (lastGamePlayCamCoords == gamePlayCamCoords) then
                                            if lastTimePressedInsert > (currentGameTimer - 5000) then
                                                SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: EULEN')
                                            end
                                        end
                                    end
                                end
                            elseif isGameMovingMouse and timeSinceLastInput < 50 then
                                if middleDist == 0 and (lastGamePlayCamCoords ~= GetGameplayCamCoords()) then
                                    if lastTimePressedInsert > (currentGameTimer - 2500) then
                                        SafeTriggerServerEvent('VexShield:banHandler', 'Executor Detected: E6')
                                    end
                                end
                            else
                                executorFlags = {}
                            end
                        else
                            executorFlags = {}
                        end
                        
                        lastPosX, lastPosY = beforeX, beforeY
                        lastGamePlayCamCoords = gamePlayCamCoords
                    end
                end)
            end

            -- 7. Anti Shared Object Override
            if Protections['Anti Shared Object Override'] then
                 if _G.ESX and type(_G.ESX) ~= "table" then
                      SafeTriggerServerEvent('VexShield:banHandler', 'ESX Shared Object Tampered')
                 end
                 if _G.QBCore and type(_G.QBCore) ~= "table" then
                      SafeTriggerServerEvent('VexShield:banHandler', 'QBCore Shared Object Tampered')
                 end
            end

            -- 8. Anti Export Hijack
            if Protections['Anti Export Hijack'] then
                 if type(exports) ~= "table" and type(exports) ~= "userdata" then
                       SafeTriggerServerEvent('VexShield:banHandler', 'Exports Hijacked')
                 end
                 -- Check if metatable is tampered (basic check)
                 local mt = getmetatable(exports)
                 if not mt then
                     SafeTriggerServerEvent('VexShield:banHandler', 'Exports Metatable Missing')
                 end
            end
            
            -- 9. Anti Bytecode Injection
            if Protections['Anti Bytecode Injection'] then
                -- Verify core function integrity
                local function checkIntegrity(func, name)
                    if type(func) ~= "function" then return end
                    local info = debug.getinfo(func)
                    if not info then return end
                    
                    -- If a core Lua function reports as defined in a temporary chunk or weird source
                    if info.what == "Lua" and (not info.source or string.sub(info.source, 1, 1) ~= "@") then
                        TriggerServerEvent('VexShield:banHandler', 'Bytecode Injection Detected: ' .. name)
                    end
                end
                
                checkIntegrity(TriggerServerEvent, "TriggerServerEvent")
            end

        end
    end
end)





-- =============================================================================
-- VexShield - ADVANCED ANTI PED SPAWN (IMPROVED VERSION)
-- =============================================================================

CreateThread(function()
    while not configLoaded or not Shared or not Shared.Protections do Wait(1000) end
    if not VexShieldIsProtectionOn('Anti Ped Spawn') then return end

    local config = Config.AntiPedSpawn

    -- =========================
    -- WHITELIST SCRIPTS
    -- =========================
    local allowedScripts = {}
    for _, script in pairs(config.AllowedScripts or {}) do
        allowedScripts[string.lower(script)] = true
    end

    -- =========================
    -- ALLOWED POPULATION TYPES
    -- =========================
    local allowedPopTypes = {
        [1] = true, -- permanent / mission
        [2] = true, -- ambient traffic driver / vehicle occupant
        [3] = true, -- ambient parked vehicle occupant
        [4] = true, -- ambient/civ patrol
        [5] = true, -- ambient scenario
        [6] = true, -- ambient world
        [7] = true  -- scenario
    }
    local detectionThreshold = (config and config.DetectionThreshold) or 1
    local banOnDetection = (config and config.BanOnDetection ~= false)

    -- =========================
    -- SAFE DELETE PED
    -- =========================
    local function ForceDeletePed(ped)
        if not DoesEntityExist(ped) then return end
        if IsPedAPlayer(ped) then return end
        if isProtectedTrafficPed(ped) then return end
        if IsPedInAnyVehicle(ped, true) or IsPedInAnyVehicle(ped, false) then return end
        if GetVehiclePedIsIn(ped, true) ~= 0 or GetVehiclePedIsIn(ped, false) ~= 0 then return end
        local pop = GetEntityPopulationType(ped)
        if pop >= 2 and pop <= 7 then return end

        if NetworkGetEntityIsNetworked(ped) then
            local timeout = 0
            NetworkRequestControlOfEntity(ped)
            while not NetworkHasControlOfEntity(ped) and timeout < 20 do
                Wait(5)
                timeout = timeout + 1
            end
        end

        SetEntityAsMissionEntity(ped, true, true)
        SetEntityCollision(ped, false, false)
        SetEntityAlpha(ped, 0, false)
        SetEntityCoords(ped, 0.0, 0.0, -100.0, false, false, false, false)

        DeletePed(ped)
        DeleteEntity(ped)
    end

    -- =========================
    -- DETECTION MEMORY
    -- =========================
    local lastDetectionTime = 0
    local detectionCooldown = 15000 -- 15 sec

    -- =========================
    -- MAIN LOOP
    -- =========================
    while true do
        Wait(3000)

        local playerPed = PlayerPedId()
        if not DoesEntityExist(playerPed) then goto continue end

        local playerCoords = nil
        local maxDistanceCheck = config.MaxDistanceCheck or 0.0
        local peds = AS_GetPool('CPed')

        local suspiciousCount = 0

        for i = 1, #peds do
            local ped = peds[i]

            if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                if isProtectedTrafficPed(ped) then
                    goto skipPed
                end

                -- Distance filter
                if maxDistanceCheck > 0.0 then
                    playerCoords = playerCoords or GetEntityCoords(playerPed)
                    local coords = GetEntityCoords(ped)
                    local distance = #(coords - playerCoords)
                    if distance > maxDistanceCheck then
                        goto skipPed
                    end
                end

                local popType = GetEntityPopulationType(ped)
                local script = GetEntityScript(ped)
                local attachedTo = GetEntityAttachedTo(ped)

                local isAllowed = false

                -- 1. population legit
                if allowedPopTypes[popType] then
                    isAllowed = true
                end

                -- 2. script whitelist
                if script ~= nil and allowedScripts[string.lower(script)] then
                    isAllowed = true
                end

                -- 3. attached ped
                if attachedTo ~= 0 then
                    isAllowed = true
                end

                -- =========================
                -- FINAL CHECK
                -- =========================
                if not isAllowed then
                    suspiciousCount = suspiciousCount + 1
                    ForceDeletePed(ped)
                end

                ::skipPed::
            end
        end

        -- =========================
        -- THRESHOLD + RECHECK
        -- =========================
        if suspiciousCount >= detectionThreshold then
            local now = GetGameTimer()

            if now - lastDetectionTime > detectionCooldown then
                lastDetectionTime = now

                -- ðŸ” Re-check after 2 seconds
                Wait(2000)

                local recheckCount = 0
                playerPed = PlayerPedId()
                if not DoesEntityExist(playerPed) then goto continue end
                playerCoords = nil
                local peds2 = AS_GetPool('CPed')

                for i = 1, #peds2 do
                    local ped = peds2[i]
                    if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                        if isProtectedTrafficPed(ped) then
                            goto skipRecheckPed
                        end

                        local withinRange = true
                        if maxDistanceCheck > 0.0 then
                            playerCoords = playerCoords or GetEntityCoords(playerPed)
                            local coords = GetEntityCoords(ped)
                            local distance = #(coords - playerCoords)
                            withinRange = distance <= maxDistanceCheck
                        end

                        if withinRange then
                            local popType = GetEntityPopulationType(ped)
                            local script = GetEntityScript(ped)

                            if not allowedPopTypes[popType] and (not script or not allowedScripts[string.lower(script)]) then
                                recheckCount = recheckCount + 1
                            end
                        end
                    end
                    ::skipRecheckPed::
                end

                -- =========================
                -- FINAL DECISION
                -- =========================
                if recheckCount >= detectionThreshold then
                    TriggerServerEvent('VexShield:flagPlayer', 'Anti Ped Spawn Suspicious (' .. recheckCount .. ')')

                    if banOnDetection then
                        TriggerServerEvent('VexShield:banHandler', 'Anti Ped Spawn Cheat Detected')
                    end
                end
            end
        end

        ::continue::
    end
end)


-- Server-side Anti Spawn Vehicle (pT < 6) detects on-top / ramming attacks against a victim
-- and asks us to briefly shield them so they don't die in the same tick the offending
-- vehicle is deleted. SetEntityInvincible is a client-side native, so the protection has
-- to be applied here. We clamp the duration so a spoofed payload can't keep us god-mode.
RegisterNetEvent("VexShield:tempInvincible")
AddEventHandler("VexShield:tempInvincible", function(durationMs)
    local ms = tonumber(durationMs) or 800
    if ms < 100 then ms = 100 end
    if ms > 3000 then ms = 3000 end

    local ped = PlayerPedId()
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end

    pcall(SetEntityInvincible, ped, true)
    SetTimeout(ms, function()
        local p = PlayerPedId()
        if p and p ~= 0 and DoesEntityExist(p) then
            pcall(SetEntityInvincible, p, false)
        end
    end)
end)

-- ============================================================================
-- ANTI OVERLAY (Next-Gen Deterministic & Heuristic Overlay Detector)
-- Intercepts external ImGui, DirectX, Susano, Eulen, and external cheat overlays
-- through dual-stage transition correlation, raw input hooks, and freeze telemetry.
-- ============================================================================

function isInGame()
    if not NetworkIsPlayerActive(PlayerId()) then return false end
    if GetIsLoadingScreenActive and GetIsLoadingScreenActive() then return false end
    if IsScreenFadedOut and IsScreenFadedOut() then return false end
    
    local screenWidth, screenHeight = GetActiveScreenResolution()
    if screenWidth <= 0 or screenHeight <= 0 then return false end
    
    local x = GetDisabledControlNormal(2, 239) * screenWidth
    local y = GetDisabledControlNormal(2, 240) * screenHeight
    local cx, cy = screenWidth / 2.0, screenHeight / 2.0
    
    -- Exclude centered cursor during pause menu
    if (math.abs(x - cx) < 1.0 and math.abs(y - cy) < 1.0) and IsPauseMenuActive() then
        return false
    end
    
    return true
end

-- Comprehensive Win32 Virtual Key Mapping for Cheat Overlays
local CHEAT_OVERLAY_KEYS = {
    -- Tier 1: Dedicated Cheat Menu / Overlay Toggles (Direct Ban on Verified Transition)
    [0x2D] = { name = "VK_INSERT", tier = 1 },     -- Insert (Universal default: Eulen, RedEngine, Susano, Dopamine)
    [0x2E] = { name = "VK_DELETE", tier = 1 },     -- Delete (Skript, Desudo, ImGui external menus)
    [0xA1] = { name = "VK_RSHIFT", tier = 1 },     -- Right Shift (Susano / Eulen alternate toggle)
    [0x24] = { name = "VK_HOME",   tier = 1 },     -- Home (ImGui cheat overlay toggle)
    [0x23] = { name = "VK_END",    tier = 1 },     -- End (Panic key / Menu close)
    [0x79] = { name = "VK_F10",    tier = 1 },     -- F10 (Aimbot/ESP overlay toggle)
    [0x7A] = { name = "VK_F11",    tier = 1 },     -- F11 (Menu toggle)
    [0x7B] = { name = "VK_F12",    tier = 1 },     -- F12 (Menu toggle)

    -- Tier 2: Secondary / Navigation Keys (Requires Multi-Correlation or 2 Strikes)
    [0x21] = { name = "VK_PRIOR",  tier = 2 },     -- Page Up (Cheat menu nav)
    [0x22] = { name = "VK_NEXT",   tier = 2 },     -- Page Down (Cheat menu nav)
    [0x78] = { name = "VK_F9",     tier = 2 },     -- F9 (Secondary cheat menu)
    [0x75] = { name = "VK_F6",     tier = 2 },     -- F6 (WarMenu / Lua executor menu)
    [0x74] = { name = "VK_F5",     tier = 2 },     -- F5 (WarMenu / Lua executor menu)
}

local keyPressTimes = {}
local keyReleaseTimes = {}
local keyIsDown = {}

for k, _ in pairs(CHEAT_OVERLAY_KEYS) do
    keyPressTimes[k] = -math.huge
    keyReleaseTimes[k] = -math.huge
    keyIsDown[k] = false
end

-- Raw Input Monitoring Thread (Hooks keyboard queue independently of GTA control state)
CreateThread(function()
    while true do
        Wait(0)
        local t = GetGameTimer()
        for k, _ in pairs(CHEAT_OVERLAY_KEYS) do
            local down = IsRawKeyDown(k)
            if down and not keyIsDown[k] then
                keyPressTimes[k] = t
                keyIsDown[k] = true
            elseif not down and keyIsDown[k] then
                keyReleaseTimes[k] = t
                keyIsDown[k] = false
            end
        end
    end
end)

function findCheatKeyTriggeredBetween(startTime, endTime)
    local bestKey, bestTime = nil, -math.huge
    for k, pressTime in pairs(keyPressTimes) do
        if pressTime >= startTime and pressTime <= endTime then
            if pressTime > bestTime then
                bestKey, bestTime = k, pressTime
            end
        end
    end
    -- Also check release times for quick toggles
    if not bestKey then
        for k, relTime in pairs(keyReleaseTimes) do
            if relTime >= startTime and relTime <= endTime then
                if relTime > bestTime then
                    bestKey, bestTime = k, relTime
                end
            end
        end
    end
    return bestKey, bestTime
end

local INPUT_CONTROLS = {
    1, 2,                           -- Look LR, Look UD
    21, 22, 23, 24, 25, 27,        -- Sprint, Jump, Attack, Aim, etc.
    30, 31, 32, 33, 34, 35,        -- Move LR, Move UD
    37, 38, 44, 45, 47,            -- Weapon select, Cover, etc.
    71, 72, 73, 74, 75, 76, 77,    -- Vehicle controls
}

function isFreezeLegitState()
    local ped = PlayerPedId()
    local plr = PlayerId()
    
    if not DoesEntityExist(ped) then return true end
    
    -- Check UI, pause menu, loading, cinematic, cutscenes
    if IsPauseMenuActive()
        or IsNuiFocused()
        or (IsNuiFocusKeepingInput and IsNuiFocusKeepingInput())
        or IsCinematicCamRendering()
        or IsPlayerSwitchInProgress()
        or not IsPlayerControlOn(plr)
        or IsCutsceneActive()
        or NetworkIsInMpCutscene()
        or IsEntityDead(ped)
        or IsPedRagdoll(ped)
        or IsPedFalling(ped)
        or IsPedGettingIntoAVehicle(ped)
        or IsPedClimbing(ped)
        or IsWarningMessageActive()
        or (GetIsLoadingScreenActive and GetIsLoadingScreenActive())
        or (IsScreenFadedOut and IsScreenFadedOut())
        or (IsScreenFadingOut and IsScreenFadingOut())
    then
        return true
    end

    -- In-game text prompt / keyboard input
    if UpdateOnscreenKeyboard and UpdateOnscreenKeyboard() == 0 then
        return true
    end

    -- Chat resource state
    if LocalPlayer and LocalPlayer.state and LocalPlayer.state.isChatOpen then
        return true
    end

    return false
end

function antisusanocheatoverlay()
    local SAMPLE_INTERVAL     = 25        -- High responsiveness (25ms sample rate)
    local WARMUP_WINDOW       = 2000      -- Window to verify legitimate pre-existing gameplay
    local WARMUP_REQUIRED     = 250       -- Required active ms to arm detection
    local ARM_GRACE           = 1500      -- Grace period after active gameplay
    local DETECTION_COOLDOWN  = 30000     -- 30s cooldown between detections
    local MIN_FREEZE_MS       = 300       -- Minimum freeze duration to qualify as overlay open
    local MAX_FREEZE_DURATION = 90000     -- Maximum freeze before considering AFK
    local CAM_JITTER_SQ       = 0.08      -- Tight camera movement threshold

    local lastWarmupTime     = -math.huge
    local frozenStart        = nil
    local frozenStartArmed   = false
    local lastDetectionTime  = -DETECTION_COOLDOWN
    local prevCamRot         = nil
    local activeWindow       = {}
    local tier2Strikes       = {}

    while true do
        Wait(SAMPLE_INTERVAL)
        if not VexShieldIsProtectionOn('Anti Overlay') and not VexShieldIsProtectionOn('Anti Cheat Overlay2') then goto continue end

        local now = GetGameTimer()
        if (now - lastDetectionTime) < DETECTION_COOLDOWN then goto continue end

        local skip = (not isInGame()) or isFreezeLegitState()
        if skip then
            frozenStart      = nil
            frozenStartArmed = false
            prevCamRot       = nil
            goto continue
        end

        -- Check game control inputs
        local gameActive = false
        for _, c in ipairs(INPUT_CONTROLS) do
            if IsControlPressed(0, c) then
                gameActive = true
                break
            end
        end

        -- Check gameplay camera rotation delta
        local camRot   = GetGameplayCamRot(2)
        local camMoved = false
        if prevCamRot then
            local dx = camRot.x - prevCamRot.x
            local dy = camRot.y - prevCamRot.y
            local dz = camRot.z - prevCamRot.z
            if (dx * dx + dy * dy + dz * dz) > CAM_JITTER_SQ then
                camMoved = true
            end
        end
        prevCamRot = camRot

        local active = gameActive or camMoved

        -- Maintain moving window of active gameplay
        activeWindow[#activeWindow + 1] = { time = now, active = active }
        while activeWindow[1] and (now - activeWindow[1].time) > WARMUP_WINDOW do
            table.remove(activeWindow, 1)
        end

        local activeMs = 0
        for i = 1, #activeWindow do
            if activeWindow[i].active then activeMs = activeMs + SAMPLE_INTERVAL end
        end
        if activeMs >= WARMUP_REQUIRED then
            lastWarmupTime = now
        end

        local recentlyArmed = (now - lastWarmupTime) <= ARM_GRACE

        -- ====================================================================
        -- STATE TRANSITION EVALUATION
        -- ====================================================================
        if not active then
            -- PLAYER IS IN FROZEN STATE (Camera Still, No Game Controls)
            if not frozenStart then
                frozenStart      = now
                frozenStartArmed = recentlyArmed
            end

            local freezeDuration = now - frozenStart

            -- Limit max freeze duration to prevent flagging genuine AFK
            if freezeDuration <= MAX_FREEZE_DURATION and frozenStartArmed then
                -- PATTERN 1: Active Menu Navigation while in frozen state
                -- Player is frozen for >= 350ms and activates a cheat key
                if freezeDuration >= MIN_FREEZE_MS then
                    local navKey = findCheatKeyTriggeredBetween(now - (SAMPLE_INTERVAL * 2), now)
                    if navKey then
                        local kData = CHEAT_OVERLAY_KEYS[navKey]
                        if kData then
                            if kData.tier == 1 then
                                SafeTriggerServerEvent('VexShield:banHandler', 'Anti Overlay: Active Key (' .. kData.name .. ')')
                                lastDetectionTime = now
                                frozenStart       = nil
                                frozenStartArmed  = false
                                activeWindow      = {}
                                goto continue
                            elseif kData.tier == 2 then
                                tier2Strikes[navKey] = (tier2Strikes[navKey] or 0) + 1
                                if tier2Strikes[navKey] >= 2 then
                                    SafeTriggerServerEvent('VexShield:banHandler', 'Anti Overlay: Navigation Key (' .. kData.name .. ')')
                                    lastDetectionTime = now
                                    frozenStart       = nil
                                    frozenStartArmed  = false
                                    activeWindow      = {}
                                    goto continue
                                end
                            end
                        end
                    end
                end

                -- PATTERN 2: Menu Open Transition
                -- Player was armed (active gameplay) and pressed toggle key right as freeze started
                if freezeDuration >= MIN_FREEZE_MS and freezeDuration <= (MIN_FREEZE_MS + 250) then
                    local openKey = findCheatKeyTriggeredBetween(frozenStart - 400, frozenStart + 200)
                    if openKey then
                        local kData = CHEAT_OVERLAY_KEYS[openKey]
                        if kData and kData.tier == 1 then
                            SafeTriggerServerEvent('VexShield:banHandler', 'Anti Overlay: Open Transition (' .. kData.name .. ')')
                            lastDetectionTime = now
                            frozenStart       = nil
                            frozenStartArmed  = false
                            activeWindow      = {}
                            goto continue
                        end
                    end
                end
            end
        else
            -- PLAYER JUST BECAME ACTIVE (Resumed Controls or Mouse Movement)
            if frozenStart and frozenStartArmed then
                local freezeDuration = now - frozenStart
                -- PATTERN 3: Menu Close Transition
                -- Player was frozen for >= 350ms, pressed an exit/toggle key within 500ms of resuming
                if freezeDuration >= MIN_FREEZE_MS and freezeDuration <= MAX_FREEZE_DURATION then
                    local closeKey = findCheatKeyTriggeredBetween(now - 500, now)
                    if closeKey then
                        local kData = CHEAT_OVERLAY_KEYS[closeKey]
                        if kData then
                            if kData.tier == 1 then
                                SafeTriggerServerEvent('VexShield:banHandler', 'Anti Overlay: Close Transition (' .. kData.name .. ')')
                                lastDetectionTime = now
                                frozenStart       = nil
                                frozenStartArmed  = false
                                activeWindow      = {}
                                goto continue
                            elseif kData.tier == 2 then
                                tier2Strikes[closeKey] = (tier2Strikes[closeKey] or 0) + 1
                                if tier2Strikes[closeKey] >= 2 then
                                    SafeTriggerServerEvent('VexShield:banHandler', 'Anti Overlay: Close Transition (' .. kData.name .. ')')
                                    lastDetectionTime = now
                                    frozenStart       = nil
                                    frozenStartArmed  = false
                                    activeWindow      = {}
                                    goto continue
                                end
                            end
                        end
                    end
                end
            end

            -- Reset freeze state
            frozenStart      = nil
            frozenStartArmed = false
        end

        ::continue::
    end
end

CreateThread(function()
    while not configLoaded do Wait(250) end
    antisusanocheatoverlay()
end)

-- ============================================================================
-- ADVANCED DETECTION MODULES
-- ============================================================================

-- ============================================================================
-- ANTI MENU TEXTURE DETECTION
-- Detects cheat menu overlays by verifying texture resolutions
-- ============================================================================
local menuTextures = {
    { txd = "HydroMenu", texture = "HydroMenuHeader", name = "HydroMenu", minRes = 50 },
    { txd = "John", texture = "John2", name = "SugarMenu", minRes = 50 },
    { txd = "darkside", texture = "logo", name = "Darkside", minRes = 50 },
    { txd = "ISMMENU", texture = "ISMMENUHeader", name = "ISMMENU", minRes = 50 },
    { txd = "dopatest", texture = "duiTex", name = "Copypaste Menu", minRes = 50 },
    { txd = "fm", texture = "menu_bg", name = "Fallout Menu", minRes = 50 },
    { txd = "wave", texture = "logo", name = "Wave", minRes = 50 },
    { txd = "wave1", texture = "logo1", name = "Wave (alt.)", minRes = 50 },
    { txd = "meow2", texture = "woof2", name = "Alokas66", minRes = 50, width = 1000, height = 1000 },
    { txd = "adb831a7fdd83d_Guest_d1e2a309ce7591dff86", texture = "adb831a7fdd83d_Guest_d1e2a309ce7591dff8Header6", name = "Guest Menu", minRes = 50 },
    { txd = "hugev_gif_DSGUHSDGISDG", texture = "duiTex_DSIOGJSDG", name = "HugeV Menu", minRes = 50 },
    { txd = "MM", texture = "menu_bg", name = "Metrix Methods", minRes = 50 },
    { txd = "wm", texture = "wm2", name = "WM Menu", minRes = 50 },
    { txd = "NeekerMan", texture = "NeekerMan1", name = "Lumia Menu", minRes = 50 },
    { txd = "Blood-X", texture = "Blood-X", name = "Blood-X Menu", minRes = 50 },
    { txd = "Dopamine", texture = "Dopameme", name = "Dopamine Menu", minRes = 50 },
    { txd = "Fallout", texture = "FalloutMenu", name = "Fallout Menu", minRes = 50 },
    { txd = "Luxmenu", texture = "Lux meme", name = "LuxMenu", minRes = 50 },
    { txd = "absoluteeulen", texture = "Absolut", name = "Absolut Menu", minRes = 50 },
    { txd = "KekHack", texture = "kekhack", name = "KekHack Menu", minRes = 50 },
    { txd = "Maestro", texture = "maestro", name = "Maestro Menu", minRes = 50 },
    { txd = "SkidMenu", texture = "skidmenu", name = "Skid Menu", minRes = 50 },
    { txd = "Brutan", texture = "brutan", name = "Brutan Menu", minRes = 50 },
    { txd = "FiveSense", texture = "fivesense", name = "Fivesense Menu", minRes = 50 },
    { txd = "Auttaja", texture = "auttaja", name = "Auttaja Menu", minRes = 50 },
    { txd = "BartowMenu", texture = "bartowmenu", name = "Bartow Menu", minRes = 50 },
    { txd = "Hoax", texture = "hoaxmenu", name = "Hoax Menu", minRes = 50 },
    { txd = "FendinX", texture = "fendin", name = "Fendinx Menu", minRes = 50 },
    { txd = "Hammenu", texture = "Ham", name = "Ham Menu", minRes = 50 },
    { txd = "Lynxmenu", texture = "Lynx", name = "Lynx Menu", minRes = 50 },
    { txd = "Oblivious", texture = "oblivious", name = "Oblivious Menu", minRes = 50 },
}

local knownMenuTextureDicts = {
    "rampage_tr_main", "MenyooExtras", "cockmenuuu",
}

CreateThread(function()
    local menuStrikes = {}
    while true do
        if VexShieldIsProtectionOn('Anti Menu Texture') then
            local now = GetGameTimer()
            for _, menuTexture in ipairs(menuTextures) do
                if HasStreamedTextureDictLoaded(menuTexture.txd) then
                    local resolution = GetTextureResolution(menuTexture.txd, menuTexture.texture)
                    local width = resolution.x
                    local height = resolution.y
                    local minRes = menuTexture.minRes or 50
                    local expectedWidth = menuTexture.width or 0
                    local expectedHeight = menuTexture.height or 0

                    if width >= minRes and height >= minRes and width > expectedWidth and height > expectedHeight then
                        local key = menuTexture.name
                        if not menuStrikes[key] or now - menuStrikes[key] > 60000 then
                            menuStrikes[key] = now
                        else
                            TriggerServerEvent('VexShield:banHandler', 'Menu Texture Detected: ' .. key)
                            menuStrikes[key] = nil
                        end
                    end
                end
            end

            for _, textureDictionary in ipairs(knownMenuTextureDicts) do
                if HasStreamedTextureDictLoaded(textureDictionary) then
                    TriggerServerEvent('VexShield:banHandler', 'Menu Texture Dict Detected: ' .. textureDictionary)
                end
            end
        end
        Wait(10000)
    end
end)

-- ============================================================================
-- ANTI DAMAGE CHANGER
-- Verifies weapon damage values against expected reference table
-- ============================================================================
local expectedWeaponDamage = {
    [-1357824103] = 34, [453432689] = 26, [1593441988] = 27,
    [584646201] = 25, [-1716589765] = 51, [-1045183535] = 160,
    [-1076751822] = 28, [-771403250] = 40, [137902532] = 34,
    [324215364] = 21, [736523883] = 22, [-270015777] = 23,
    [-1121678507] = 22, [-619010992] = 27, [171789620] = 28,
    [487013001] = 58, [2017895192] = 40, [-494615257] = 32,
    [-1654528753] = 14, [984333226] = 117, [-1074790547] = 30,
    [-2084633992] = 34, [-1063057011] = 34, [2132975508] = 32,
    [1649403952] = 44, [-1660422300] = 40, [2144741730] = 45,
    [1627465347] = 34, [100416529] = 101, [205991906] = 216,
    [-952879014] = 65, [1119849093] = 30, [-1466123874] = 165,
    [911657153] = 1, [1198879012] = 10, [-598887786] = 220,
    [1834241177] = 30, [-275439685] = 30, [-1746263880] = 81,
    [-2009644972] = 30, [-879347409] = 200, [-1768145561] = 32,
    [-2066285827] = 33, [1432025498] = 32, [1785463520] = 75,
    [961495388] = 40, [-86904375] = 33, [-608341376] = 47,
    [177293209] = 230, [-1075685676] = 45, [2024373456] = 28.5,
    [-1569615261] = 0, [-1882382516] = 27, [-1894373709] = 27,
    [-692129260] = 28.5, [-1544399637] = 28.5,
}

local weaponComponentHashes = {
    119648377, -696561875, 834974250, 614078421, -884429072,
    283556395, 643254679, 889808635, -1101075946, -1323216997,
    -1614924820, -1861183855, -91250417, -1899902599, -197857404,
    -2112517305, -503336118, -691692330, -781249480, -942267867,
    -1796727865, -2034401422, 580369945, -640439150, -1928132688,
    -1152981993, 1967214384, 202788691, 899381934, 2076495324,
    -1657815255, -1439939148, -1596416958, -767279652, -1135289737,
    -1023114086,
}

CreateThread(function()
    while true do
        if VexShieldIsProtectionOn('Anti Damage Changer') then
            local playerPed = PlayerPedId()
            local weapon = GetSelectedPedWeapon(playerPed)
            
            if weapon ~= 0 then
                local expectedDamage = expectedWeaponDamage[weapon]
                if expectedDamage then
                    local damage = GetWeaponDamage(weapon, 0)
                    local maxAllowed = expectedDamage + 10
                    if damage > maxAllowed and HasPedGotWeapon(playerPed, weapon, false) then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Weapon Damage Manipulated: ' .. weapon .. ' (got: ' .. damage .. ', expected: ' .. expectedDamage .. ')')
                    end
                end
            end
            
            -- Check weapon components for damage/accuracy manipulation
            for _, componentHash in ipairs(weaponComponentHashes) do
                local damageModifier = GetWeaponComponentDamageModifier(componentHash)
                local accuracyModifier = GetWeaponComponentAccuracyModifier(componentHash)
                if damageModifier and (damageModifier > 1.1 or accuracyModifier > 1.2) then
                    TriggerServerEvent('VexShield:banHandler', 'Weapon Component Manipulation Detected')
                    break
                end
            end
        end
        Wait(3000)
    end
end)

-- ============================================================================
-- ANTI FAST SHOOT
-- Compares weapon fire rate against expected reference table
-- ============================================================================
local expectedShotDelays = {
    [-38085395] = 0.333, [487013001] = 0.8, [453432689] = 0.37,
    [2144741730] = 0.108, [171789620] = 0.135, [-1076751822] = 0.37,
    [1198879012] = 0.42, [1593441988] = 0.37, [-1074790547] = 0.158,
    [100416529] = 1.567, [-1063057011] = 0.135, [584646201] = 0.1,
    [205991906] = 1.2, [2017895192] = 1.0, [-270015777] = 0.13,
    [-1654528753] = 1.0, [1305664598] = 1.22, [-1568386805] = 1.22,
    [-1357824103] = 0.12, [-952879014] = 0.3, [-1660422300] = 0.137,
    [-2084633992] = 0.135, [-494615257] = 0.3, [736523883] = 0.118,
    [137902532] = 0.4, [1119849093] = 0.02, [-1716589765] = 0.52,
    [2132975508] = 0.12, [-1716189206] = 0, [911657153] = 2.8,
    [-10959621] = 0, [-598887786] = 2.5, [-800287667] = 0,
    [-1090665087] = 0, [539292904] = 0, [133987706] = 0,
    [2138347493] = 0.8, [1233104067] = 0, [-771403250] = 0.42,
    [375527679] = 0.8, [1141786504] = 0, [856002082] = 0.4,
    [324215364] = 0.1, [-102323637] = 0, [341774354] = 0,
    [-868994466] = 0, [-1786099057] = 0, [-499989876] = 0,
    [984333226] = 0.3, [-656458692] = 0, [126349499] = 0,
    [-1420407917] = 0, [101631238] = 0, [-1466123874] = 0.8,
    [741814745] = 0, [148160082] = 0, [-1882382516] = 0.37,
    [-1894373709] = 0.37, [-692129260] = 0.37, [-1544399637] = 0.37,
}

CreateThread(function()
    while true do
        if VexShieldIsProtectionOn('Anti Fast Shoot') then
            local playerPed = PlayerPedId()
            local weapon = GetSelectedPedWeapon(playerPed)
            
            if weapon ~= 0 then
                local expectedDelay = expectedShotDelays[weapon]
                if expectedDelay then
                    local currentDelay = GetWeaponTimeBetweenShots(weapon)
                    if currentDelay and currentDelay < expectedDelay - 0.05 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Fast Shoot Detected: ' .. weapon .. ' (delay: ' .. currentDelay .. ', expected: ' .. expectedDelay .. ')')
                    end
                end
            end
        end
        Wait(3000)
    end
end)

-- ============================================================================
-- ANTI RECOIL MANIPULATION
-- Verifies weapon recoil against expected reference table
-- ============================================================================
VexShieldExpectedRecoil = VexShieldExpectedRecoil or {
    [-38085395] = 1, [487013001] = 2, [453432689] = 1,
    [2144741730] = 0.8, [171789620] = 0.4, [-1716189206] = 1,
    [-1076751822] = 1, [1198879012] = 1, [1593441988] = 1,
    [-800287667] = 1, [100416529] = 0.28, [-1063057011] = 0.333,
    [584646201] = 0.5, [205991906] = 0.28, [2017895192] = 2.25,
    [-270015777] = 0.333, [-1466123874] = 2, [-1654528753] = 1.75,
    [1305664598] = 0.5, [-1568386805] = 0.5, [-1357824103] = 0.333,
    [-952879014] = 0.28, [-1660422300] = 1, [1141786504] = 1,
    [-494615257] = 0.666, [-2084633992] = 0.333, [137902532] = 1,
    [736523883] = 0.333, [1119849093] = 0.666, [-1716589765] = 1,
    [2132975508] = 0.333, [911657153] = 0.333, [-10959621] = 1,
    [-598887786] = 1.5, [-1090665087] = 1, [539292904] = 1,
    [133987706] = 1, [2138347493] = 1, [1233104067] = 1,
    [-771403250] = 1, [375527679] = 1, [1141786504] = 1,
    [856002082] = 1, [324215364] = 0.333, [-102323637] = 1,
    [341774354] = 1, [-868994466] = 1, [-1786099057] = 1,
    [-499989876] = 1, [984333226] = 0.5, [-656458692] = 1,
    [126349499] = 1, [-1420407917] = 1, [101631238] = 1,
    [-1074790547] = 0.333, [-1833087301] = 1, [741814745] = 1,
    [148160082] = 1, [-1882382516] = 0.37, [-1894373709] = 1,
}

CreateThread(function()
    while true do
        if VexShieldIsProtectionOn('Anti Recoil Manip') then
            local playerPed = PlayerPedId()
            local weapon = GetSelectedPedWeapon(playerPed)
            
            if weapon ~= 0 then
                local normalRecoil = VexShieldExpectedRecoil[weapon]
                if normalRecoil then
                    local recoil = GetWeaponRecoilShakeAmplitude(weapon)
                    if recoil and recoil < normalRecoil - 0.5 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Recoil Manipulation Detected: ' .. weapon .. ' (recoil: ' .. recoil .. ', expected: ' .. normalRecoil .. ')')
                    end
                end
            end
        end
        Wait(3000)
    end
end)

-- ============================================================================
-- ANTI HITBOX MANIPULATION
-- Validates ped hitbox dimensions against expected values
-- ============================================================================
VexShieldHitboxConfig = VexShieldHitboxConfig or {
    normalHitboxMinY = -0.29,
    normalHitboxMaxZ = 0.98,
    normalHitboxMinY2 = 0.1,
    normalHitboxMaxZ2 = 2.29
}

CreateThread(function()
    while true do
        if VexShieldIsProtectionOn('Anti Hitbox Manip') then
            local playerPed = PlayerPedId()
            local model = GetEntityModel(playerPed)
            
            if model ~= -1667301416 and model ~= 1885233650 then
                Wait(10000)
                goto continue
            end
            
            local minimum, maximum = GetModelDimensions(model)
            local hitboxExtended = minimum.y < VexShieldHitboxConfig.normalHitboxMinY
                or maximum.z > VexShieldHitboxConfig.normalHitboxMaxZ
                or minimum.y - 0.5 > VexShieldHitboxConfig.normalHitboxMinY2
                or maximum.z - 2.24 > (VexShieldHitboxConfig.normalHitboxMaxZ2 - 2.24 + 0.05)

            if hitboxExtended then
                SafeTriggerServerEvent('VexShield:banHandler', 'Hitbox Manipulation Detected (y: ' .. minimum.y .. ' z: ' .. maximum.z .. ')')
            end
        end
        ::continue::
        Wait(10000)
    end
end)

-- ============================================================================
-- ANTI NO HEADSHOT
-- Detects players who disable headshot vulnerability (Persistent Strike Enforcement)
-- ============================================================================
local noHeadshotStrikes = 0
CreateThread(function()
    while true do
        if VexShieldIsProtectionOn('Anti No Headshot') then
            local playerPed = PlayerPedId()
            if DoesEntityExist(playerPed) and not IsEntityDead(playerPed) and not IsPedDeadOrDying(playerPed, true) then
                if GetPedConfigFlag(playerPed, 42, false) then
                    noHeadshotStrikes = noHeadshotStrikes + 1
                    SetPedConfigFlag(playerPed, 42, false)
                    if noHeadshotStrikes >= 3 then
                        SafeTriggerServerEvent('VexShield:banHandler', 'Anti No Headshot: Persistent Flag 42 manipulation')
                        noHeadshotStrikes = 0
                    end
                else
                    if noHeadshotStrikes > 0 then
                        noHeadshotStrikes = noHeadshotStrikes - 1
                    end
                end
                if GetPedConfigFlag(playerPed, 2, false) then
                    SetPedConfigFlag(playerPed, 2, false)
                end
            end
        end
        Wait(3000)
    end
end)

-- ============================================================================
-- ANTI PICKUP COLLECTION
-- Blocks collection of restricted pickup hashes
-- ============================================================================
local restrictedPickupHashes = {
    1850631618, 1948018762, 1751145014, 1817941018, -744254618,
    1426343849, -107080240, -1541298894, -214137936, -546236071,
    -1296747938, -2050315855, -1298986476, -30788308, 1765114797,
    496339155, 978070226, 1274757841, 1295434569, 792114228,
    -1888453608, -1456120371, -1766583645, -1835415205, 1577485217,
    768803961, 483787975, 2081529176, -105925489, -1989692173,
    996550793, 779501861, -31919185, -512375144, -48884066,
    -962731009, 663586612, 1587637620, 693539241, -2115084258,
    -1997886297, -2027042680, 738282662, -482507216, -2136239332,
    1852930709, 1651898027, 1263688126, -1863327941, 68603185,
    79909481, -1605465331, -1477820210, -1009939663, -1795552418,
    -831529621, 1575005502, 513448440, 545862290, 341217064,
    1897726628, -562499202, -794112265, -863291131, -1521817673,
    -1491601256, -2066319660, 1705498857, 746606563, 160266735,
    -34700440, 1125567497, -1200951717, -864236261, 772217690,
    -1514616151, 83435908, 1104334678, 1704231442, -405862452,
    483577702, 1735599485, 544828034, 292537574, -457363514,
    -564600653, 2012476125, -1070796507, -2011516760, -2071756841,
    -228982343, -95310859, -977852653, -1661912808, 157823901,
    -2124585240, -482150160, 1959050722, 1000920287, -1945122029,
    990867623, -1621765815, 1572258186, 1835046764, 1038697149,
    94531552, 1649373715, -1071729032, 1548844439, 1393009900,
    -1074893765, -336028321, 582047296, 1983869217, -114341780,
    1613316560, 837436873, -1352061783, 1311775952, -462548556,
    -1093374267, 127042729, 1601729296, 2045070941, -902939483,
    2074855423, 2010690963, 884272848, -1118969278, -40063266,
    -535568356, -1965167499, -301062413, 266812085, -102572257,
    -668632385, -171582756, -1112080475, 1632369836, -572254182,
    -1127890446, 158843122, -253098439, -747492773, -1352061783,
    155106086, -451800215, -2121850769, -1109887812, -1457529717,
    -16088425, 2220197671, 1234831722, -282365040, -862936205,
    -2068019525, 1491498856, -1978262176, -1473941020, -10738165,
    -1986805983, -1014997513,
}

CreateThread(function()
    while true do
        if VexShieldIsProtectionOn('Anti Pickup Collection') then
            local playerId = PlayerId()
            for _, pickupHash in ipairs(restrictedPickupHashes) do
                ToggleUsePickupsForPlayer(playerId, pickupHash, false)
            end
            
            -- Remove existing restricted pickups
            for _, pickupHash in ipairs(restrictedPickupHashes) do
                RemoveAllPickupsOfType(pickupHash)
            end
            
            -- Monitor pickup collection events
            AddEventHandler("CEventNetworkPlayerCollectedPickup", function()
                TriggerServerEvent('VexShield:banHandler', 'Restricted Pickup Collection Attempt')
            end)
            AddEventHandler("CEventNetworkPlayerCollectedAmbientPickup", function()
                TriggerServerEvent('VexShield:banHandler', 'Restricted Pickup Collection Attempt')
            end)
            AddEventHandler("CEventNetworkPlayerCollectedPortablePickup", function()
                TriggerServerEvent('VexShield:banHandler', 'Restricted Pickup Collection Attempt')
            end)
        end
        Wait(10000)
    end
end)

---------------------------------------------------------------------------------
-- ANTI DUMPER
---------------------------------------------------------------------------------
local StringDump = {}
StringDump.dump = string.dump
string.dump = function()
    while true do end
end

CreateThread(function()
    -- end of file logic
end)

---------------------------------------------------------------------------------
-- ANTI ESP BLOCKER (WITH VEHICLE & DISTANCE BYPASS)
---------------------------------------------------------------------------------
local spoofedPlayers = {}

CreateThread(function()
    while not configLoaded do Wait(500) end
    
    while true do
        VexShieldProtectionPollWait('Anti ESP Blocker', 0)
        
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        
        for _, player in ipairs(GetActivePlayers()) do
            local target = GetPlayerPed(player)
            if target ~= ped and DoesEntityExist(target) then
                local targetCoords = GetEntityCoords(target)
                local distance = #(coords - targetCoords)
                
                if distance > 10.0 then
                    -- Set health and armor to 0 locally. Run every frame (Wait(0)) to continuously override network sync.
                    -- This confuses ESP cheats (which hide dead players) without affecting gameplay.
                    Citizen.InvokeNative(0x6B76DC1F3AE6E6A3, target, 0)
                    Citizen.InvokeNative(0xCEA04D83135264CC, target, 0)
                    spoofedPlayers[player] = true
                else
                    -- When they get close, if they were spoofed as dead, restore health/armor once.
                    -- This prevents GTA V's vehicle passenger pull-out engine logic.
                    if spoofedPlayers[player] then
                        Citizen.InvokeNative(0x6B76DC1F3AE6E6A3, target, 200) -- Restore local health representation
                        Citizen.InvokeNative(0xCEA04D83135264CC, target, 50)  -- Restore local armor approximation
                        spoofedPlayers[player] = nil
                    end
                end
            end
        end
    end
end)

