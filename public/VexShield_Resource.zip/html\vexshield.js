let curRes = (typeof GetCurrentResourceName === 'function') ? GetCurrentResourceName() : 'VexShield';
let VexShield = exports[curRes] || exports.VexShield || exports['VexShield_Resource'];
let isServerSide = IsDuplicityVersion()

if (!isServerSide) {

    const setEntityCoords = SetEntityCoords
    let lastTeleported = 0
    SetEntityCoords = function(entity, ...args) {
        if ((GetGameTimer() - lastTeleported) > 1000) {
            if (entity === PlayerPedId()) {
                if (VexShield && VexShield.hasTeleported) VexShield.hasTeleported();
            }
            lastTeleported = GetGameTimer();
        }
        return setEntityCoords(entity, ...args);
    };

    const setEntityCoordsNoOffset = SetEntityCoordsNoOffset;
    SetEntityCoordsNoOffset = function(entity, ...args) {
        if ((GetGameTimer() - lastTeleported) > 1000) {
            if (entity === PlayerPedId()) {
                if (VexShield && VexShield.hasTeleported) VexShield.hasTeleported();
            }
            lastTeleported = GetGameTimer();
        }
        return setEntityCoordsNoOffset(entity, ...args);
    };

    const startPlayerTeleport = StartPlayerTeleport;
    StartPlayerTeleport = function(player, ...args) {
        if (player === PlayerId()) {
            if (VexShield && VexShield.hasTeleported) VexShield.hasTeleported();
        }
        return startPlayerTeleport(player, ...args);
    };

    const setPedCoordsKeepVehicle = SetPedCoordsKeepVehicle;
    SetPedCoordsKeepVehicle = function(ped, ...args) {
        if ((GetGameTimer() - lastTeleported) > 1000) {
            if (ped === PlayerPedId()) {
                if (VexShield && VexShield.hasTeleported) VexShield.hasTeleported();
            }
            lastTeleported = GetGameTimer();
        }
        return setPedCoordsKeepVehicle(ped, ...args);
    };

    const setPedIntoVehicle = SetPedIntoVehicle;
    SetPedIntoVehicle = function(ped, ...args) {
        if ((GetGameTimer() - lastTeleported) > 1000) {
            if (ped === PlayerPedId()) {
                if (VexShield && VexShield.hasTeleported) VexShield.hasTeleported();
            }
            lastTeleported = GetGameTimer();
        }
        return setPedIntoVehicle(ped, ...args);
    };

    const taskWarpPedIntoVehicle = TaskWarpPedIntoVehicle;
    TaskWarpPedIntoVehicle = function(ped, ...args) {
        if ((GetGameTimer() - lastTeleported) > 1000) {
            if (ped === PlayerPedId()) {
                if (VexShield && VexShield.hasTeleported) VexShield.hasTeleported();
            }
            lastTeleported = GetGameTimer();
        }
        return taskWarpPedIntoVehicle(ped, ...args);
    };

    const setPlayerModel = SetPlayerModel;
    SetPlayerModel = function(player, model, ...args) {
        if (player === PlayerId()) {
            if (VexShield && VexShield.hasChangedPedModel) VexShield.hasChangedPedModel();
        }
        return setPlayerModel(player, model, ...args);
    }

    const setEntityHealth = SetEntityHealth;
    let lastSettedHealth = 0;
    let lastSettedHealthValue;
    SetEntityHealth = function(entity, health, ...args) {
        if (health !== lastSettedHealthValue || (GetGameTimer() - lastSettedHealth) > 1000) {
            if (entity === PlayerPedId() && health > 0) {
                if (VexShield && VexShield.healthRefilled) VexShield.healthRefilled();
                lastSettedHealth = GetGameTimer();
                lastSettedHealthValue = health;
            }
        }
        return setEntityHealth(entity, health, ...args);
    }

    const resurrectPed = ResurrectPed;
    ResurrectPed = function(ped, ...args) {
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.playerRevived) VexShield.playerRevived();
        }
        return resurrectPed(ped, ...args);
    }

    const networkResurrectLocalPlayer = NetworkResurrectLocalPlayer;
    NetworkResurrectLocalPlayer = function(x, y, z, heading, unk, changetime, ...args) {
        if (VexShield && VexShield.playerRevived) VexShield.playerRevived();
        return networkResurrectLocalPlayer(x, y, z, heading, unk, changetime, ...args)
    }

    const reviveInjuredPed = ReviveInjuredPed;
    ReviveInjuredPed = function(ped, ...args) {
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.playerRevived) VexShield.playerRevived();
        }
        return reviveInjuredPed(ped, ...args)
    }

    const setEntityProofs = SetEntityProofs;
    SetEntityProofs = function(entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, drownProof, ...args) {
        if (entity == PlayerPedId()) {
            if (VexShield && VexShield.proofsEnabled) VexShield.proofsEnabled(bulletProof == true || bulletProof == 1 || meleeProof == true || meleeProof == 1);
        }
        return setEntityProofs(entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, drownProof, ...args);
    }

    const setEntityCanBeDamaged = SetEntityCanBeDamaged;
    let lastSettedCanBeDamaged = 0;
    let lastSettedCanBeDamagedValue;
    SetEntityCanBeDamaged = function(entity, toggle, ...args) {
        if ((GetGameTimer() - lastSettedCanBeDamaged) > 1000 || toggle !== lastSettedCanBeDamagedValue) {
            if (entity == PlayerPedId()) {
                if (VexShield && VexShield.canBeDamaged) VexShield.canBeDamaged(toggle);
                lastSettedCanBeDamaged = GetGameTimer();
                lastSettedCanBeDamagedValue = toggle;
            }
        }
        return setEntityCanBeDamaged(entity, toggle, ...args);
    }

    const setPlayerInvincible = SetPlayerInvincible;
    let lastSettedPlayerInvincible = 0;
    let lastPlayerInvincibleToggle;
    SetPlayerInvincible = function(player, toggle, ...args) {
        if (toggle !== lastPlayerInvincibleToggle || (GetGameTimer() - lastSettedPlayerInvincible) > 1000) {
            if (player == PlayerId()) {
                if (VexShield && VexShield.isInvincible) VexShield.isInvincible(toggle);
                lastSettedPlayerInvincible = GetGameTimer();
                lastPlayerInvincibleToggle = toggle;
            }
        }
        return setPlayerInvincible(player, toggle, ...args);
    }

    const setEntityInvincible = SetEntityInvincible;
    let lastSettedInvincible = 0;
    let lastInvincibleToggle;
    SetEntityInvincible = function(entity, toggle, ...args) {
        if (toggle !== lastInvincibleToggle || (GetGameTimer() - lastSettedInvincible) > 1000) {
            if (entity == PlayerPedId()) {
                if (VexShield && VexShield.isInvincible) VexShield.isInvincible(toggle);
                lastSettedInvincible = GetGameTimer();
                lastInvincibleToggle = toggle;
            }
        }
        return setEntityInvincible(entity, toggle, ...args);
    }

    const setEntityVisible = SetEntityVisible;
    let lastSettedVisible = 0;
    let lastSettedVisibleToggle;
    SetEntityVisible = function(entity, toggle, unk, ...args) {
        if (toggle !== lastSettedVisibleToggle || (GetGameTimer() - lastSettedVisible) > 1000) {
            if (entity == PlayerPedId()) {
                if (VexShield && VexShield.isVisible) VexShield.isVisible(toggle);
                lastSettedVisible = GetGameTimer();
                lastSettedVisibleToggle = toggle;
            }
        }
        return setEntityVisible(entity, toggle, unk, ...args);
    }

    const restorePlayerStamina = RestorePlayerStamina;
    RestorePlayerStamina = function(player, p1, ...args) {
        if (player === PlayerId()) {
            if (VexShield && VexShield.resettedStamina) VexShield.resettedStamina();
        }
        return restorePlayerStamina(player, p1, ...args);
    }

    const resetPlayerStamina = ResetPlayerStamina;
    ResetPlayerStamina = function(player, ...args) {
        if (player === PlayerId()) {
            if (VexShield && VexShield.resettedStamina) VexShield.resettedStamina();
        }
        return resetPlayerStamina(player, ...args);
    }

    const modifyVehicleTopSpeed = ModifyVehicleTopSpeed;
    ModifyVehicleTopSpeed = function(vehicle, value, ...args) {
        const playerPedId = PlayerPedId();
        const vehiclePedIsIn = GetVehiclePedIsIn(playerPedId, false);
        if ((vehicle === vehiclePedIsIn) && (GetPedInVehicleSeat(vehiclePedIsIn, -1) === playerPedId)) {
            if (VexShield && VexShield.newTopSpeedModifier) VexShield.newTopSpeedModifier(value);
        }
        return modifyVehicleTopSpeed(vehicle, value, ...args);
    }
    SetVehicleEnginePowerMultiplier = ModifyVehicleTopSpeed;

    const setVehicleCheatPowerIncrease = SetVehicleCheatPowerIncrease;
    SetVehicleCheatPowerIncrease = function(vehicle, value, ...args) {
        const playerPedId = PlayerPedId();
        const vehiclePedIsIn = GetVehiclePedIsIn(playerPedId, false);
        if ((vehicle === vehiclePedIsIn) && (GetPedInVehicleSeat(vehiclePedIsIn, -1) === playerPedId)) {
            if (VexShield && VexShield.newCheatPowerIncrease) VexShield.newCheatPowerIncrease(value);
        }
        return setVehicleCheatPowerIncrease(vehicle, value, ...args);
    }
    SetVehicleEngineTorqueMultiplier = SetVehicleCheatPowerIncrease

    const setVehicleGravityAmount = SetVehicleGravityAmount;
    SetVehicleGravityAmount = function(vehicle, gravity, ...args) {
        const playerPedId = PlayerPedId();
        const vehiclePedIsIn = GetVehiclePedIsIn(playerPedId, false);
        if ((vehicle === vehiclePedIsIn) && (GetPedInVehicleSeat(vehiclePedIsIn, -1) === playerPedId)) {
            if (VexShield && VexShield.newGravity) VexShield.newGravity(gravity);
        }
        return setVehicleGravityAmount(vehicle, gravity, ...args);
    }

    const setWeaponDamageModifier = SetWeaponDamageModifier;
    let weaponsModified = {};
    SetWeaponDamageModifier = function(weaponHash, damageMultiplier, ...args){
        if (!weaponsModified[weaponHash] || weaponsModified[weaponHash] !== damageMultiplier){
            if (VexShield && VexShield.setNewDamage) VexShield.setNewDamage(weaponHash, damageMultiplier);
        }
        weaponsModified[weaponHash] = damageMultiplier;
        return setWeaponDamageModifier(weaponHash, damageMultiplier, ...args);
    }
    SetWeaponDamageModifierThisFrame = SetWeaponDamageModifier;
    N_0x4757f00bc6323cfe = SetWeaponDamageModifier;

    const addAmmoToPed = AddAmmoToPed;
    AddAmmoToPed = function(ped, weaponHash, ammo, ...args){
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.hasAddedAmmo) VexShield.hasAddedAmmo()
        }
        return addAmmoToPed(ped, weaponHash, ammo, ...args)
    }

    const addAmmoToPedByType = AddAmmoToPedByType;
    AddAmmoToPedByType = function(ped, ammoType, ammo, ...args){
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.hasAddedAmmo) VexShield.hasAddedAmmo()
        }
        return addAmmoToPedByType(ped, ammoType, ammo, ...args)
    }
    AddPedAmmo = AddAmmoToPedByType

    const refillAmmoInstantly = RefillAmmoInstantly;
    RefillAmmoInstantly = function(ped, ...args){
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.hasAddedAmmo) VexShield.hasAddedAmmo()
        }
        return refillAmmoInstantly(ped, ...args)
    }
    PedSkipNextReloading = RefillAmmoInstantly;

    const setAmmoInClip = SetAmmoInClip;
    SetAmmoInClip = function(ped, weaponHash, ammo, ...args){
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.hasAddedAmmo) VexShield.hasAddedAmmo()
        }
        return setAmmoInClip(ped, weaponHash, ammo, ...args)
    }

    const setPedAmmo = SetPedAmmo;
    SetPedAmmo = function(ped, weaponHash, ammo, ...args){
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.hasAddedAmmo) VexShield.hasAddedAmmo()
        }
        return setPedAmmo(ped, weaponHash, ammo,...args)
    }

    const setPedAmmoByType = SetPedAmmoByType;
    SetPedAmmoByType = function(ped, ammoType, ammo, ...args){
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.hasAddedAmmo) VexShield.hasAddedAmmo()
        }
        return setPedAmmoByType(ped, ammoType, ammo, ...args)
    }

    const setMouseCursorActiveThisFrame = SetMouseCursorActiveThisFrame;
    let lastCalledMouse = 0;
    SetMouseCursorActiveThisFrame = function(...args){
        if ((GetGameTimer() - lastCalledMouse) > 1000){
            if (VexShield && VexShield.disableE2) VexShield.disableE2();
            lastCalledMouse = GetGameTimer();
        }
        return setMouseCursorActiveThisFrame(...args);
    }
    ShowCursorThisFrame = SetMouseCursorActiveThisFrame;

    const disableAllControlActions = DisableAllControlActions;
    let lastCalledDisableControls = 0;
    DisableAllControlActions = function(padIndex, ...args){
        if ((GetGameTimer() - lastCalledDisableControls) > 1000){
            if (VexShield && VexShield.disableAllControls) VexShield.disableAllControls();
            lastCalledDisableControls = GetGameTimer();
        }
        return disableAllControlActions(padIndex, ...args);
    }

    const disableControlAction = DisableControlAction;
    let lastCalledDisableCamControls = 0;
    DisableControlAction = function(padIndex, control, disable, ...args){
        if (disable && (control === 1 || control === 2) && ((GetGameTimer() - lastCalledDisableCamControls) > 1000)){
            if (VexShield && VexShield.disableCamControls) VexShield.disableCamControls();
            lastCalledDisableCamControls = GetGameTimer();
        }
        return disableControlAction(padIndex, control, disable, ...args);
    }

    const requestStreamedTextureDict = RequestStreamedTextureDict;
    let allowedTextures = {};
    RequestStreamedTextureDict = function(textureDict, p1, ...args){
        if (!allowedTextures[textureDict]){
            allowedTextures[textureDict] = true;
            if (VexShield && VexShield.allowTexture) VexShield.allowTexture(textureDict);
        }
        return requestStreamedTextureDict(textureDict, p1, ...args);
    }

    const drawSprite = DrawSprite;
    DrawSprite = function(textureDict, ...args){
        if (!allowedTextures[textureDict]){
            allowedTextures[textureDict] = true;
            if (VexShield && VexShield.allowTexture) VexShield.allowTexture(textureDict);
        }
        return drawSprite(textureDict, ...args);
    }

    const createRuntimeTxd = CreateRuntimeTxd;
    CreateRuntimeTxd = function(textureDict, ...args){
        if (!allowedTextures[textureDict]){
            allowedTextures[textureDict] = true;
            if (VexShield && VexShield.allowTexture) VexShield.allowTexture(textureDict);
        }
        return createRuntimeTxd(textureDict, ...args);
    }

    const requestScaleformMovie = RequestScaleformMovie
    RequestScaleformMovie = function(scaleformName, ...args) {
        if (typeof scaleformName === "string" && scaleformName.toLowerCase() !== null) {
            scaleformName = scaleformName.toLowerCase();
            if (scaleformName === "scaleformui") {
                allowedTextures["mpleaderboard"] = true;
                allowedTextures["mpinventory"] = true;
                allowedTextures["commonmenutu"] = true;
                allowedTextures["mphud"] = true;
                allowedTextures["mpshopsale"] = true;
                allowedTextures["mprankbadge"] = true;
                allowedTextures["mpcarhud"] = true;
                allowedTextures["mpcarhud2"] = true;
                allowedTextures["shared"] = true;
                allowedTextures["commonmenu"] = true;
                if (VexShield && VexShield.allowTexture) {
                    VexShield.allowTexture("mpleaderboard");
                    VexShield.allowTexture("mpinventory");
                    VexShield.allowTexture("commonmenutu");
                    VexShield.allowTexture("mphud");
                    VexShield.allowTexture("mpshopsale");
                    VexShield.allowTexture("mprankbadge");
                    VexShield.allowTexture("mpcarhud");
                    VexShield.allowTexture("mpcarhud2");
                    VexShield.allowTexture("shared");
                    VexShield.allowTexture("commonmenu");
                }
            } else if (scaleformName.indexOf("mp_car_stats") !== -1) {
                allowedTextures["mpcarhud"] = true;
                allowedTextures["mpcarhud2"] = true;
                if (VexShield && VexShield.allowTexture) {
                    VexShield.allowTexture("mpcarhud");
                    VexShield.allowTexture("mpcarhud2");
                }
            }
        }
        return requestScaleformMovie(scaleformName, ...args);
    }
    RequestScaleformMovie_2 = RequestScaleformMovie;

    const giveWeaponToPed = GiveWeaponToPed
    GiveWeaponToPed = function(ped, weaponHash, ...args) {
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.giveWeapon) VexShield.giveWeapon(weaponHash);
        }
        return giveWeaponToPed(ped, weaponHash, ...args);
    }

    const createWeaponObject = CreateWeaponObject;
    CreateWeaponObject = function(weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, ...args) {
        if (showWorldModel) {
            if (VexShield && VexShield.giveWeapon) VexShield.giveWeapon(weaponHash);
        }
        return createWeaponObject(weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, ...args);
    }

    const removeAllPedWeapons = RemoveAllPedWeapons;
    RemoveAllPedWeapons = function(ped, p1, ...args) {
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.removeAllWeapons) VexShield.removeAllWeapons();
        }
        return removeAllPedWeapons(ped, p1, ...args);
    }

    const removeWeaponFromPed = RemoveWeaponFromPed;
    RemoveWeaponFromPed = function(ped, weaponHash, ...args) {
        if (ped === PlayerPedId()) {
            if (VexShield && VexShield.removeWeapon) VexShield.removeWeapon(weaponHash);
        }
        return removeWeaponFromPed(ped, weaponHash, ...args);
    }

    const createObject = CreateObject;
    CreateObject = function(modelHash, x, y, z, isNetwork, ...args){
        let networked = isNetwork;
        if(typeof x == "vector3"){
            networked = z;
        }
        if(networked && (networked == true || networked == 1)){
            if (VexShield && VexShield.CreateObject) VexShield.CreateObject(modelHash);
        }
        return createObject(modelHash, x, y, z, isNetwork, ...args);
    };

    const createObjectNoOffset = CreateObjectNoOffset;
    CreateObjectNoOffset = function(modelHash, x, y, z, isNetwork, ...args){
        let networked = isNetwork;
        if(typeof x == "vector3"){
            networked = z;
        }
        if(networked && (networked == true || networked == 1)){
            if (VexShield && VexShield.CreateObject) VexShield.CreateObject(modelHash);
        }
        return createObjectNoOffset(modelHash, x, y, z, isNetwork, ...args);
    };

    const createVehicle = CreateVehicle;
    CreateVehicle = function(modelHash, x, y, z, heading, isNetwork, ...args){
        let networked = isNetwork;
        if(typeof x == "vector3"){
            networked = z;
        }
        if(networked && (networked == true || networked == 1)){
            if (VexShield && VexShield.CreateVehicle) VexShield.CreateVehicle(modelHash);
        }
        return createVehicle(modelHash, x, y, z, heading, isNetwork, ...args);
    };

    const createPed = CreatePed;
    CreatePed = function(pedType, modelHash, x, y, z, heading, isNetwork, ...args){
        let networked = isNetwork;
        if(typeof x == "vector3"){
            networked = z;
        }
        if(networked && (networked == true || networked == 1)){
            if (VexShield && VexShield.CreatePed) VexShield.CreatePed(modelHash);
        }
        return createPed(pedType, modelHash, x, y, z, heading, isNetwork, ...args);
    };

    const createPedInsideVehicle = CreatePedInsideVehicle;
    CreatePedInsideVehicle = function(vehicle, pedType, modelHash, seat, isNetwork, ...args){
        if(isNetwork && (isNetwork == true || isNetwork == 1)){
            if (VexShield && VexShield.CreatePed) VexShield.CreatePed(modelHash);
        }
        return createPedInsideVehicle(vehicle, pedType, modelHash, seat, isNetwork, ...args);
    };

    const setVehicleNumberPlateText = SetVehicleNumberPlateText;
    SetVehicleNumberPlateText = function(vehicle, plateText, ...args){
        if (VexShield && VexShield.ChangeVehiclePlate) VexShield.ChangeVehiclePlate(vehicle, plateText)
        return setVehicleNumberPlateText(vehicle, plateText, ...args);
    };

} else {
    const fs = require('fs');
    const path = require('path');

    exports('SaveResourceFile', (resourceName, fileName, data) => {
        try {
            const resPath = GetResourcePath(resourceName);
            if (!resPath) return false;
            const fullPath = path.join(resPath, fileName);
            fs.writeFileSync(fullPath, data, 'utf8');
            return true;
        } catch (err) {
            console.error(`[VexShield JS Save Error] for ${resourceName}/${fileName}:`, err ? err.message : err);
            return false;
        }
    });

    exports('LoadResourceFile', (resourceName, fileName) => {
        try {
            const resPath = GetResourcePath(resourceName);
            if (!resPath) return null;
            const fullPath = path.join(resPath, fileName);
            if (fs.existsSync(fullPath)) {
                return fs.readFileSync(fullPath, 'utf8');
            }
        } catch (err) {
        }
        return null;
    });

    const https = require('https');
    const { URL } = require('url');

    function uploadBanClipToDiscord(webhookUrl, clipB64, callback) {
        try {
            if (!webhookUrl || typeof webhookUrl !== 'string' || !webhookUrl.includes('discord.com/api/webhooks')) {
                if (typeof callback === 'function') callback(null, 'invalid_webhook_url');
                return;
            }
            if (!clipB64 || typeof clipB64 !== 'string') {
                if (typeof callback === 'function') callback(null, 'empty_base64');
                return;
            }
            const buf = Buffer.from(clipB64, 'base64');
            if (!buf || buf.length < 32) {
                if (typeof callback === 'function') callback(null, 'clip_buffer_too_small');
                return;
            }

            const waitParam = webhookUrl.includes('wait=') ? '' : (webhookUrl.includes('?') ? '&wait=true' : '?wait=true');
            const targetUrl = webhookUrl + waitParam;
            const parsedUrl = new URL(targetUrl);
            const boundary = '----VexShieldBoundary' + Date.now() + Math.floor(Math.random() * 100000);

            const payloadJson = JSON.stringify({
                content: '🎥 **VexShield Ban Evidence Clip**',
                attachments: [{ id: 0, filename: 'vexshield-ban.webm' }]
            });

            const part1 = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json\r\n\r\n${payloadJson}\r\n`);
            const part2Header = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="files[0]"; filename="vexshield-ban.webm"\r\nContent-Type: video/webm\r\n\r\n`);
            const part2Footer = Buffer.from(`\r\n--${boundary}--\r\n`);
            const body = Buffer.concat([part1, part2Header, buf, part2Footer]);

            const req = https.request(parsedUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': `multipart/form-data; boundary=${boundary}`,
                    'Content-Length': body.length,
                    'User-Agent': 'VexShield-DiscordRelay/1.0'
                },
                timeout: 18000
            }, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        try {
                            const j = JSON.parse(data);
                            const url = j.attachments && j.attachments[0] && j.attachments[0].url;
                            if (url) {
                                if (typeof callback === 'function') callback(url, null);
                                return;
                            }
                        } catch (_) {}
                    }
                    if (typeof callback === 'function') callback(null, `discord_http_${res.statusCode}: ${data.slice(0, 200)}`);
                });
            });

            req.on('timeout', () => {
                req.destroy();
                if (typeof callback === 'function') callback(null, 'discord_request_timeout');
            });

            req.on('error', (err) => {
                if (typeof callback === 'function') callback(null, err ? err.message : 'discord_request_error');
            });

            req.write(body);
            req.end();
        } catch (err) {
            if (typeof callback === 'function') callback(null, err ? err.message : 'discord_upload_exception');
        }
    }

    exports('UploadBanClipToDiscord', (webhookUrl, clipB64, callback) => {
        uploadBanClipToDiscord(webhookUrl, clipB64, (url, err) => {
            if (typeof callback === 'function') callback(url, err);
        });
    });

    on('VexShield:UploadBanClipToDiscord', (webhookUrl, clipB64, callback) => {
        uploadBanClipToDiscord(webhookUrl, clipB64, (url, err) => {
            if (typeof callback === 'function') callback(url, err);
        });
    });

    on('VexShield:InternalUploadBanClip', (webhookUrl, clipB64, requestId, banId, playerSrc) => {
        uploadBanClipToDiscord(webhookUrl, clipB64, (url, err) => {
            emit('VexShield:InternalUploadBanClipResult', requestId, url, err, banId, playerSrc);
        });
    });
}
