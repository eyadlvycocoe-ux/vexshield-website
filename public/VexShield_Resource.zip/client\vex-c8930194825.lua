-- [VEX-INTERNAL-CORE: 0x9F4C2A-C7820194824]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

local ESX = nil
local QBCore = nil
local UseESX = false
local UseQBCore = false
local playerHistory = {}
local announcements = {}
local vexliveOpen = false
local vexAdminSessionToken = nil
local vexAdminSessionExpiresAt = 0
local vexAdminSessionSeq = 0
local vexAdminSessionPending = {}
local vexAdminSessionRequesting = false

-- Global FiveM functions
local RegisterKeyMapping = RegisterKeyMapping

local function VexShieldHasAdminSession()
    return type(vexAdminSessionToken) == "string"
        and vexAdminSessionToken ~= ""
        and GetGameTimer() < ((tonumber(vexAdminSessionExpiresAt) or 0) - 5000)
end

local function VexShieldRequestAdminSession()
    TriggerServerEvent('VexShield:AdminSessionInit')
end

RegisterNetEvent('VexShield:AdminSessionReady')
AddEventHandler('VexShield:AdminSessionReady', function(token, expiresAt)
    if type(token) ~= "string" or token == "" then
        return
    end
    vexAdminSessionToken = token
    vexAdminSessionExpiresAt = tonumber(expiresAt) or (GetGameTimer() + 600000)
    vexAdminSessionSeq = 0
    vexAdminSessionRequesting = false
    local pending = vexAdminSessionPending
    vexAdminSessionPending = {}
    for _, item in ipairs(pending) do
        Citizen.SetTimeout(0, function()
            item.fn()
        end)
    end
end)

local function VexShieldTriggerAdminServerEvent(eventName, ...)
    local args = { ... }
    local function fire()
        if not VexShieldHasAdminSession() then return end
        vexAdminSessionSeq = (vexAdminSessionSeq or 0) + 1
        TriggerServerEvent(eventName, table.unpack(args), vexAdminSessionToken, vexAdminSessionSeq)
    end
    if not VexShieldHasAdminSession() then
        vexAdminSessionPending[#vexAdminSessionPending + 1] = { fn = fire }
        if not vexAdminSessionRequesting then
            vexAdminSessionRequesting = true
            VexShieldRequestAdminSession()
        end
        return
    end
    fire()
end


-- On resource start, attempt to detect which framework is running
CreateThread(function()
    Wait(1000) -- give time for frameworks to start

    if GetResourceState("qb-core") == "started" then
        UseQBCore = true
        QBCore = exports["qb-core"]:GetCoreObject()

    elseif GetResourceState("es_extended") == "started" then
        UseESX = true
        local function compareVersions(v1, v2)
            local v1Parts = {}
            local v2Parts = {}
        
            -- Split the version strings into parts
            for part in string.gmatch(v1, "[^%.]+") do
                table.insert(v1Parts, tonumber(part))
            end
            for part in string.gmatch(v2, "[^%.]+") do
                table.insert(v2Parts, tonumber(part))
            end
        
            -- Compare each part numerically
            for i = 1, math.max(#v1Parts, #v2Parts) do
                local v1Part = v1Parts[i] or 0
                local v2Part = v2Parts[i] or 0
                if v1Part > v2Part then
                    return true
                elseif v1Part < v2Part then
                    return false
                end
            end
        
            return false -- Versions are equal
        end
        
        if compareVersions(GetResourceMetadata("es_extended", "version"), "1.9.0") then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
    end
end)

lib.callback.register('VexAnticheat:getBans', function(source)
    return LoadBans() -- Schrijf eventueel LoadBans() zelf of haal uit DB
end)


--------------------------------------------------------------
-- HELPER: WRAPPED SERVER CALLBACK (ESX.TriggerServerCallback 
--         OR QBCore.Functions.TriggerCallback)
--------------------------------------------------------------
local function FrameworkTriggerServerCallback(name, cb, ...)

    while not (UseESX or UseQBCore) do
        Citizen.Wait(1000)
    end
    
    if UseESX and ESX then
        ESX.TriggerServerCallback(name, cb, ...)
    elseif UseQBCore and QBCore then
        QBCore.Functions.TriggerCallback(name, cb, ...)
    else
        print("^1[VexShield] No framework to handle callback: " .. tostring(name))
    end
end

--------------------------------------------------------------
-- HELPER: GET PLAYER'S 'GROUP' CROSS-FRAMEWORK
--         (In QBCore, there's no default 'group'. 
--         We'll just guess it might be in qbData.job.name.)
--------------------------------------------------------------
local function GetFrameworkPlayerGroup()
    while not (UseESX or UseQBCore) do
        Citizen.Wait(1000)
    end
    if UseESX and ESX then
        local xData = ESX.GetPlayerData()
        return xData and xData.group or "user"

    elseif UseQBCore and QBCore then
        local qbData = QBCore.Functions.GetPlayerData()
        if qbData and qbData.job then
            -- You might have a custom approach, but let's just return the job name
            return qbData.job.name
        end
        return "user"
    end
    return "unknown"
end

--------------------------------------------------------------
-- The rest of your code, updated to remove direct ESX calls --
--------------------------------------------------------------
local Shared = {}
local configLoaded = false

-- Toggle state for freecam
local freeCamActive = false
-- Reference to our active camera
local freeCamHandle = nil
-- Store the camera’s rotation so we don’t rely on ped heading
local freeCamRot = vector3(0.0, 0.0, 0.0)

-- Load config via cross-framework callback
local function loadConfig()
    local ok, cfg = pcall(function()
        return lib.callback.await('VexAnticheat:get:config_lib', false)
    end)
    if ok and cfg then
        Shared = cfg
        configLoaded = true
        return
    end
    FrameworkTriggerServerCallback('VexAnticheat:get:config', function(config)
        Shared = config
        configLoaded = true
    end)
end

loadConfig()

---------------------------------------
-- FREECAM FUNCTIONS
---------------------------------------
local function StartFreecam()
    if freeCamActive then return end
    freeCamActive = true

    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    freeCamRot = GetEntityRotation(playerPed, 2)

    freeCamHandle = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(freeCamHandle, coords.x, coords.y, coords.z + 2.0)
    SetCamRot(freeCamHandle, freeCamRot.x, freeCamRot.y, freeCamRot.z, 2)

    SetCamActive(freeCamHandle, true)
    RenderScriptCams(true, false, 0, true, true)

    FreezeEntityPosition(playerPed, true)
    SetEntityVisible(playerPed, false, false)
    SetEntityCollision(playerPed, false, false)
    if LocalPlayer and LocalPlayer.state then LocalPlayer.state:set('VexShield_freecam', true, true) end
end

local function StopFreecam()
    if not freeCamActive then return end
    freeCamActive = false

    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(freeCamHandle, false)
    freeCamHandle = nil

    local playerPed = PlayerPedId()
    FreezeEntityPosition(playerPed, false)
    SetEntityVisible(playerPed, true, false)
    SetEntityCollision(playerPed, true, true)
    if LocalPlayer and LocalPlayer.state then LocalPlayer.state:set('VexShield_freecam', false, true) end
end

---------------------------------------
-- FREECAM RENDERING THREAD
---------------------------------------
Citizen.CreateThread(function()
    local speedNormal = 0.5
    local speedFast   = 3.0

    while true do
        if freeCamActive and freeCamHandle then
            Citizen.Wait(100)
            local camCoords = GetCamCoord(freeCamHandle)
            local camRot    = GetCamRot(freeCamHandle, 2)
            local moveSpeed = IsControlPressed(0, 21) and speedFast or speedNormal 

            if IsControlPressed(0, 32) then 
                camCoords = camCoords + RotationToDirection(camRot) * moveSpeed
            end
            if IsControlPressed(0, 33) then 
                camCoords = camCoords - RotationToDirection(camRot) * moveSpeed
            end
            if IsControlPressed(0, 34) then 
                local heading = (camRot.z - 90.0) % 360.0
                local dir = vector3(math.cos(math.rad(heading)), math.sin(math.rad(heading)), 0.0)
                camCoords = camCoords + (dir * moveSpeed)
            end
            if IsControlPressed(0, 35) then 
                local heading = (camRot.z + 90.0) % 360.0
                local dir = vector3(math.cos(math.rad(heading)), math.sin(math.rad(heading)), 0.0)
                camCoords = camCoords + (dir * moveSpeed)
            end
            if IsControlPressed(0, 85) then 
                camCoords = vector3(camCoords.x, camCoords.y, camCoords.z + moveSpeed)
            end
            if IsControlPressed(0, 48) then 
                camCoords = vector3(camCoords.x, camCoords.y, camCoords.z - moveSpeed)
            end

            local xAxis = (GetDisabledControlNormal(0, 1) * 8.0)
            local yAxis = (GetDisabledControlNormal(0, 2) * 8.0)
            camRot = vector3(camRot.x - yAxis, 0.0, camRot.z - xAxis)

            local playerPed = PlayerPedId()
            for _, player in ipairs(GetActivePlayers()) do
                local ped = GetPlayerPed(player)
                if ped ~= playerPed then
                    local pedCoords = GetEntityCoords(ped)
                    if #(camCoords - pedCoords) < 50.0 then 
                        DrawText3D(pedCoords.x, pedCoords.y, pedCoords.z + 1.0, "ID: " .. GetPlayerServerId(player))
                    end
                end
            end

            SetCamCoord(freeCamHandle, camCoords.x, camCoords.y, camCoords.z)
            SetCamRot(freeCamHandle, camRot.x, camRot.y, camRot.z, 2)
        else
            Citizen.Wait(500)
        end
    end
end)

function DrawText3D(x, y, z, text)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

function RotationToDirection(rotation)
    local adjustedRotation = {
        x = math.rad(rotation.x),
        y = math.rad(rotation.y),
        z = math.rad(rotation.z)
    }
    local direction = vector3(
        -math.sin(adjustedRotation.z) * math.cos(adjustedRotation.x),
         math.cos(adjustedRotation.z) * math.cos(adjustedRotation.x),
         math.sin(adjustedRotation.x)
    )
    return direction
end

---------------------------------------
-- NUI CALLBACKS / COMMANDS
---------------------------------------

-- Toggling FreeCam from NUI
RegisterNUICallback("FreeCamToggle", function(data, cb)
    if freeCamActive then
        StopFreecam()
    else
        StartFreecam()
    end
    cb('ok')
end)

-- vexLIVE command: open overlay live panel
RegisterCommand('VEXLIVE', function()
    local isAdmin = false
    local ok, result = pcall(function()
        return lib.callback.await('VexAnticheat:get:isAdmin', false)
    end)
    if ok then isAdmin = result end

    if isAdmin then
        vexliveOpen = true
        vexAdminSessionToken = nil
        vexAdminSessionExpiresAt = 0
        vexAdminSessionSeq = 0
        vexAdminSessionRequesting = true
        VexShieldRequestAdminSession()
        SetNuiFocusKeepInput(false)
        SetNuiFocus(true, true)
        SendNUIMessage({ type = 'openVexLive' })
        VexShieldTriggerAdminServerEvent('VexShield:RequestPlayersList')
    else
        FrameworkTriggerServerCallback('VexAnticheat:get:group', function(group)
            if Shared.ADMIN_GROUPS and Shared.ADMIN_GROUPS[group] then
                vexliveOpen = true
                vexAdminSessionToken = nil
                vexAdminSessionExpiresAt = 0
                vexAdminSessionSeq = 0
                vexAdminSessionRequesting = true
                VexShieldRequestAdminSession()
                SetNuiFocusKeepInput(false)
                SetNuiFocus(true, true)
                SendNUIMessage({ type = 'openVexLive' })
                VexShieldTriggerAdminServerEvent('VexShield:RequestPlayersList')
            else
                TriggerEvent('chat:addMessage', { args = { 'System', 'No permission' } })
            end
        end)
    end
end, false)

RegisterNUICallback('closeVexLive', function(_, cb)
    vexliveOpen = false
    if display then
        SetNuiFocus(true, true)
    else
        SetNuiFocus(false, false)
    end
    cb('ok')
end)

-- This command triggers the NUI menu:
RegisterCommand("VexMenu", function()
    print("^2[VexShield] /VexMenu invoked^0")
    local isAdmin = false
    local ok, result = pcall(function()
        return lib.callback.await('VexAnticheat:get:isAdmin', false)
    end)
    if ok then isAdmin = result end
    if isAdmin then
        OpenAdminPanel()
    else
        FrameworkTriggerServerCallback('VexAnticheat:get:group', function(group)
            if Shared.ADMIN_GROUPS and Shared.ADMIN_GROUPS[group] then
                OpenAdminPanel()
            else
                TriggerEvent('chat:addMessage', { args = { 'System', 'No permission' } })
            end
        end)
    end
end, false)

RegisterCommand("vexadmin", function()
    print("^2[VexShield] /vexadmin invoked^0")
    local isAdmin = false
    local ok, result = pcall(function()
        return lib.callback.await('VexAnticheat:get:isAdmin', false)
    end)
    if ok then isAdmin = result end
    if isAdmin then
        OpenAdminPanel()
    else
        FrameworkTriggerServerCallback('VexAnticheat:get:group', function(group)
            if Shared.ADMIN_GROUPS and Shared.ADMIN_GROUPS[group] then
                OpenAdminPanel()
            else
                TriggerEvent('chat:addMessage', { args = { 'System', 'No permission' } })
            end
        end)
    end
end, false)

RegisterCommand("vex", function()
    print("^2[VexShield] /vex invoked^0")
    local isAdmin = false
    local ok, result = pcall(function()
        return lib.callback.await('VexAnticheat:get:isAdmin', false)
    end)
    if ok then isAdmin = result end
    if isAdmin then
        OpenAdminPanel()
    else
        FrameworkTriggerServerCallback('VexAnticheat:get:group', function(group)
            if Shared.ADMIN_GROUPS and Shared.ADMIN_GROUPS[group] then
                OpenAdminPanel()
            else
                TriggerEvent('chat:addMessage', { args = { 'System', 'No permission' } })
            end
        end)
    end
end, false)

CreateThread(function()
    Wait(1500)
    TriggerEvent('chat:addSuggestion', '/vexadmin', 'Open VexShield panel')
    TriggerEvent('chat:addSuggestion', '/Vexadmin', 'Open VexShield panel')
    TriggerEvent('chat:addSuggestion', '/vex', 'Open VexShield panel')
end)

RegisterKeyMapping('vexmenu', 'Open VexShield panel', 'keyboard', 'F6')

RegisterNUICallback("closeUI", function(data, cb)
    vexliveOpen = false
    display = false
    SetNuiFocus(false, false)
    cb('ok')
end)



RegisterNUICallback('banPlayer', function(data, cb)
    local playerId = tonumber(data.playerId or data.id or data.playerID)
    local reason = data.reason
    local duration = tonumber(data.duration) or 0
    if playerId and reason then
        VexShieldTriggerAdminServerEvent('VexShield:banHandler:Admin', playerId, reason)
        Citizen.SetTimeout(1000, function()
            VexShieldTriggerAdminServerEvent('VexShield:RequestPlayersList')
            VexShieldTriggerAdminServerEvent("VexShield:RequestBans")
        end)
        cb({ success = true, duration = duration })
    else
        cb({ success = false, message = "Invalid player or reason" })
    end
end)

function OpenAdminPanel()
    display = true
    vexliveOpen = false
    vexAdminSessionToken = nil
    vexAdminSessionExpiresAt = 0
    vexAdminSessionSeq = 0
    vexAdminSessionRequesting = true
    VexShieldRequestAdminSession()
    SetNuiFocusKeepInput(false)
    SetNuiFocus(true, true)

    -- Show panel immediately; load metrics in background (no vehicle/resource scans on open)
    SendNUIMessage({ type = "open" })
    SendNUIMessage({
        type = "VexShieldConfig",
        discordAvatarApi = GetConvar("VexShield_discord_avatar_api", "https://vexshield.net/api/public/discord-avatar"),
    })
    VexShieldTriggerAdminServerEvent('VexShield:RequestAdminProfile')

    CreateThread(function()
        SendNUIMessage({
            type = "updateData",
            dashboardData = GetDashboardDataLight(),
        })
    end)
end

function CloseAdminPanel()
    display = false
    vexliveOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = "close"
    })
end

CreateThread(function()
    while true do
        if display or vexliveOpen then
            DisableAllControlActions(0)
            DisableAllControlActions(1)
            DisableControlAction(0, 200, true)
            DisableControlAction(0, 322, true)
            SetNuiFocusKeepInput(false)
            if not IsNuiFocused() then
                SetNuiFocus(true, true)
            end
            Wait(0)
        else
            Wait(250)
        end
    end
end)

function GetDashboardDataLight()
    local players = GetActivePlayers()
    local playerCount = #players
    local hours = GetClockHours()
    local minutes = GetClockMinutes()
    local currentTime = string.format("%02d:%02d", hours, minutes)
    table.insert(playerHistory, {time = currentTime, count = playerCount})
    if #playerHistory > 24 then
        table.remove(playerHistory, 1)
    end
    return {
        playerCount = playerCount,
        connections = playerCount,
        playerHistory = playerHistory
    }
end

function GetDashboardData()
    local base = GetDashboardDataLight()
    base.resourceCount = GetNumResources()
    local vehicles = GetGamePool('CVehicle')
    base.vehicleCount = #vehicles
    return base
end

function GetPlayersData()
    local players = {}

    for _, playerId in ipairs(GetActivePlayers()) do
        local playerName = GetPlayerName(playerId) or "Unknown"
        local playerServerId = GetPlayerServerId(playerId) or -1
        local ping = (type(GetPlayerPing) == 'function' and GetPlayerPing(playerId)) or 0
        local ped = GetPlayerPed(playerId)
        local hp = GetEntityHealth(ped)
        local maxHp = GetEntityMaxHealth(ped)
        local healthPct = 0
        if maxHp and maxHp > 0 then
            healthPct = math.floor((hp / maxHp) * 100)
            if healthPct < 0 then healthPct = 0 end
            if healthPct > 100 then healthPct = 100 end
        end
        local armed = IsPedArmed(ped, 7)
        local threatScore = math.min(100, math.max(0, math.floor(ping / 2)))

        table.insert(players, {
            id = playerServerId,
            name = playerName,
            status = armed and "ARMED" or "ONLINE",
            ping = ping,
            health = healthPct,
            onlineMinutes = 0,
            threatScore = threatScore
        })
    end

    return players
end

function GetResourcesData()
    local resources = {}
    
    for i = 0, GetNumResources() - 1 do
        local resourceName = GetResourceByFindIndex(i)
        
        local version = GetResourceMetadata(resourceName, "version", 0) or "1.0"
        local author = GetResourceMetadata(resourceName, "author", 0) or "Unknown"
        local status = GetResourceState(resourceName)
        
        table.insert(resources, {
            name = resourceName,
            status = status,
            version = version,
            author = author
        })
    end
    
    return resources
end

function GetVehiclesData()
    local vehicles = {}
    local vehiclePool = GetGamePool('CVehicle')

    for i = 1, #vehiclePool do
        local vehicle = vehiclePool[i]

        -- Sla voertuigen over die geen netwerkentiteit zijn (anders krijg je warnings)
        if not NetworkGetEntityIsNetworked(vehicle) then
            goto continue
        end

        local model = GetEntityModel(vehicle)
        local modelName = GetDisplayNameFromVehicleModel(model)

        local owner = "No Driver"
        local playerPed = PlayerPedId()
        if GetPedInVehicleSeat(vehicle, -1) == playerPed then
            owner = "You"
        end

        local coords = GetEntityCoords(vehicle)
        local streetName, crossingRoad = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local location = GetStreetNameFromHashKey(streetName)

        local plate = GetVehicleNumberPlateText(vehicle)

        if crossingRoad ~= 0 then
            location = location .. " / " .. GetStreetNameFromHashKey(crossingRoad)
        end

        table.insert(vehicles, {
            id = NetworkGetEntityIsNetworked(vehicle) and NetworkGetNetworkIdFromEntity(vehicle) or 0,
            model = modelName,
            owner = owner,
            plate = plate,
            location = location
        })

        ::continue::
    end

    return vehicles
end


RegisterNUICallback('closePanel', function(data, cb)
    CloseAdminPanel()
    cb('ok')
end)

RegisterNUICallback('close', function(data, cb)
    CloseAdminPanel()
    cb('ok')
end)

-- Forward server-side player list to NUI
RegisterNetEvent('VexShield:SendPlayersList')
AddEventHandler('VexShield:SendPlayersList', function(players)
    SendNUIMessage({ type = 'playerList', players = players or {} })
end)

RegisterNetEvent('VexShield:SendPlayerAvatars')
AddEventHandler('VexShield:SendPlayerAvatars', function(avatars)
    SendNUIMessage({ type = 'playerAvatars', avatars = avatars or {} })
end)

RegisterNetEvent('VexShield:SendAdminProfile')
AddEventHandler('VexShield:SendAdminProfile', function(profile)
    profile = profile or {}
    SendNUIMessage({ type = 'adminProfile', name = profile.name, avatar = profile.avatar })
end)

RegisterNetEvent('VexShield:SendPlayersPlaceData')
AddEventHandler('VexShield:SendPlayersPlaceData', function(players)
    SendNUIMessage({ type = 'playersPlace', players = players or {} })
end)

-- ===================== Reports / Team / Admin chat =====================
RegisterNetEvent('VexShield:SendReports')
AddEventHandler('VexShield:SendReports', function(reports)
    SendNUIMessage({ type = 'reports', reports = reports or {} })
end)

RegisterNetEvent('VexShield:SendAdmins')
AddEventHandler('VexShield:SendAdmins', function(admins)
    SendNUIMessage({ type = 'adminsList', admins = admins or {} })
end)

RegisterNetEvent('VexShield:SendAdminChat')
AddEventHandler('VexShield:SendAdminChat', function(messages)
    SendNUIMessage({ type = 'adminChat', messages = messages or {} })
end)

RegisterNetEvent('VexShield:AdminChatMessage')
AddEventHandler('VexShield:AdminChatMessage', function(message)
    SendNUIMessage({ type = 'adminChatMessage', message = message or {} })
end)

RegisterNetEvent('VexShield:ReportAck')
AddEventHandler('VexShield:ReportAck', function(ok, message)
    if ok == false then
        TriggerEvent('chat:addMessage', {
            color = { 255, 180, 72 },
            args = { '[Report]', message or 'You already have a pending report.' }
        })
    else
        TriggerEvent('chat:addMessage', {
            color = { 43, 217, 143 },
            args = { '[Report]', message or 'Your report has been sent to the admin team. Thank you!' }
        })
    end
end)

RegisterNUICallback('getReports', function(_, cb)
    VexShieldTriggerAdminServerEvent('VexShield:RequestReports')
    cb('ok')
end)

RegisterNUICallback('claimReport', function(data, cb)
    VexShieldTriggerAdminServerEvent('VexShield:ClaimReport', tonumber(data.id) or data.id)
    cb('ok')
end)

RegisterNUICallback('closeReport', function(data, cb)
    VexShieldTriggerAdminServerEvent('VexShield:CloseReport', tonumber(data.id) or data.id)
    cb('ok')
end)

RegisterNUICallback('getAdmins', function(_, cb)
    VexShieldTriggerAdminServerEvent('VexShield:RequestAdmins')
    cb('ok')
end)

RegisterNUICallback('getAdminChat', function(_, cb)
    VexShieldTriggerAdminServerEvent('VexShield:RequestAdminChat')
    cb('ok')
end)

RegisterNUICallback('sendAdminChat', function(data, cb)
    if data and data.message and data.message ~= '' then
        VexShieldTriggerAdminServerEvent('VexShield:AdminChatSend', tostring(data.message))
    end
    cb('ok')
end)

-- Lightweight game notification (framework-independent)
local function VexShieldNotify(msg)
    AddTextEntry('VexShieldReportNotif', msg)
    BeginTextCommandThefeedPost('VexShieldReportNotif')
    EndTextCommandThefeedPostTicker(false, true)
end

local reportFormPending = false

-- Reportcheat command removed

-- Server tells us whether this player already has an open report.
RegisterNetEvent('VexShield:MyReport')
AddEventHandler('VexShield:MyReport', function(report)
    local doOpen = reportFormPending
    reportFormPending = false
    if doOpen then
        SetNuiFocus(true, true)
    end
    SendNUIMessage({ type = 'myReport', report = report or false, open = doOpen })
end)

-- Submit a brand-new report
RegisterNUICallback('submitReport', function(data, cb)
    local subject = data and data.subject
    if subject and tostring(subject) ~= '' then
        local targetId = nil
        if data.targetId ~= nil and tostring(data.targetId) ~= '' then
            targetId = tonumber(data.targetId)
        end
        TriggerServerEvent('VexShield:SubmitReport', targetId, tostring(subject))
    end
    SetNuiFocus(false, false)
    cb('ok')
end)

-- Player continues the conversation in their existing report
RegisterNUICallback('playerReportMessage', function(data, cb)
    if data and data.message and tostring(data.message) ~= '' then
        TriggerServerEvent('VexShield:PlayerReportMessage', tostring(data.message))
    end
    cb('ok')
end)

RegisterNUICallback('closeReportForm', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

-- Admin replies inside a report
RegisterNUICallback('reportReply', function(data, cb)
    if data and data.id ~= nil and data.message and tostring(data.message) ~= '' then
        VexShieldTriggerAdminServerEvent('VexShield:ReportReply', tonumber(data.id) or data.id, tostring(data.message))
    end
    cb('ok')
end)

-- Notifications
RegisterNetEvent('VexShield:AdminReportNotify')
AddEventHandler('VexShield:AdminReportNotify', function(data)
end)

RegisterNetEvent('VexShield:ReportPlayerNotify')
AddEventHandler('VexShield:ReportPlayerNotify', function(msg)
end)

RegisterNetEvent('VexShield:ReportClosedNotify')
AddEventHandler('VexShield:ReportClosedNotify', function()
end)

RegisterNUICallback('getPlayerList', function(data, cb)
    VexShieldTriggerAdminServerEvent('VexShield:RequestPlayersList')
    cb('ok')
end)

RegisterNUICallback('sendMessageToPlayer', function(data, cb)
    local playerId = tonumber(data.playerId)
    local message = data.message
    
    if playerId and message then
        VexShieldTriggerAdminServerEvent('VexShield:send:message', playerId, message)
    end
    
    cb('ok')
end)

RegisterNUICallback('addAnnouncement', function(data, cb)
    local title = data.title
    local content = data.content
    
    if title and content then
        local time = "Just now"
        table.insert(announcements, 1, {
            title = title,
            content = content,
            time = time
        })
        
        VexShieldTriggerAdminServerEvent('VexShield:announce', title, content)
    end
    
    cb('ok')
end)







local isNoclipActive = false

local function ToggleNoclip()
    local ped = PlayerPedId()

    if isNoclipActive then
        SetEntityInvincible(ped, false)
        SetEntityVisible(ped, true, false)
        FreezeEntityPosition(ped, false)
        SetEntityCollision(ped, true, true)
        isNoclipActive = false
        if LocalPlayer and LocalPlayer.state then LocalPlayer.state:set('VexShield_noclip', false, true) end
    else
        SetEntityInvincible(ped, true)
        SetEntityVisible(ped, false, false)
        FreezeEntityPosition(ped, true)
        SetEntityCollision(ped, false, false)
        isNoclipActive = true
        if LocalPlayer and LocalPlayer.state then LocalPlayer.state:set('VexShield_noclip', true, true) end
    end
end

-- Tick loop
CreateThread(function()
    while true do
        if isNoclipActive then
            Wait(0)
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local camRot = GetGameplayCamRot(2)
            local direction = RotationToDirection(camRot)
            local rightDir = RotationToDirection(vector3(0.0, 0.0, camRot.z + 90.0))

            local speed = IsControlPressed(0, 21) and 2.5 or 1.0 -- SHIFT = sneller

            -- Vooruit / achteruit
            if IsControlPressed(0, 32) then -- W
                coords = coords + direction * speed
            end
            if IsControlPressed(0, 33) then -- S
                coords = coords - direction * speed
            end
            -- Links / rechts
            if IsControlPressed(0, 34) then -- A
                coords = coords - rightDir * speed
            end
            if IsControlPressed(0, 35) then -- D
                coords = coords + rightDir * speed
            end
            -- Omhoog / omlaag
            if IsControlPressed(0, 44) then -- Q
                coords = coords + vector3(0.0, 0.0, speed)
            end
            if IsControlPressed(0, 20) then -- Z
                coords = coords - vector3(0.0, 0.0, speed)
            end

            SetEntityCoordsNoOffset(ped, coords.x, coords.y, coords.z, true, true, true)
        else
            Wait(500)
        end
    end
end)


-- NUI callback
RegisterNUICallback('toggleNoclip', function(data, cb)
    ToggleNoclip()
    cb('ok')
end)


RegisterNUICallback('kickPlayer', function(data, cb)
    local playerId = tonumber(data.playerId or data.id or data.playerID)
    local reason = data.reason

    if playerId and reason then
        VexShieldTriggerAdminServerEvent('VexShield:kickPlayer:Admin', playerId, reason)
        Citizen.SetTimeout(1000, function()
            VexShieldTriggerAdminServerEvent('VexShield:RequestPlayersList')
            VexShieldTriggerAdminServerEvent("VexShield:RequestBans")
        end)
        cb({ success = true })
    else
        cb({ success = false, message = "Invalid player or reason" })
    end
end)

RegisterNUICallback('unbanPlayer', function(data, cb)
    local banId = data.banId or data.banID
    if banId then
        VexShieldTriggerAdminServerEvent('VexShield:unbanHandler:Admin', banId)
        Citizen.SetTimeout(1000, function()
            VexShieldTriggerAdminServerEvent('VexShield:RequestBans')
        end)
        cb({ success = true })
    else
        cb({ success = false, message = "Invalid ban ID" })
    end
end)

RegisterNUICallback('unbanAll', function(data, cb)
    VexShieldTriggerAdminServerEvent('VexShield:unbanAll:Admin')
    cb('ok')
end)

-- Handle live screen streaming callbacks
RegisterNUICallback('startLiveScreen', function(data, cb)
    local targetId = tonumber(data.id)
    local options = data.options
    if targetId then
        TriggerServerEvent('VexShield:startLiveScreen', targetId, options)
        cb('ok')
    else
        cb('error')
    end
end)

RegisterNUICallback('stopLiveScreen', function(data, cb)
    local targetId = tonumber(data.id)
    if targetId then
        TriggerServerEvent('VexShield:stopLiveScreen', targetId)
    else
        TriggerServerEvent('VexShield:stopLiveScreen')
    end
    cb('ok')
end)

-- Live Stream NUI Callbacks (like tgiann-admin-troll & luxu_admin)
RegisterNUICallback('requestPeerConnection', function(data, cb)
    cb({})
    local targetSrc = tonumber(data.targetSrc)
    local peerId = data.peerId
    local mode = data.mode or 'fast'
    local forceRetry = data.forceRetry == true
    if targetSrc and peerId then
        VexShieldTriggerAdminServerEvent('VexShield:server:requestPeerConnection', {
            targetSrc = targetSrc,
            peerId = peerId,
            mode = mode,
            forceRetry = forceRetry
        })
    end
end)

RegisterNUICallback('toggleVoiceListen', function(data, cb)
    cb({})
    local targetSrc = tonumber(data and data.targetSrc)
    if targetSrc then
        print(string.format("^3[VexShield Voice NUI]^7 NUI requested toggleVoiceListen for target player ID: ^2%d^7", targetSrc))
        VexShieldTriggerAdminServerEvent('VexShield:server:toggleVoiceListen', targetSrc)
    else
        print("^1[VexShield Voice NUI]^7 Error: toggleVoiceListen received invalid targetSrc")
    end
end)

-- Voice Channel Client Bridge (pma-voice / mumble-voip / saltychat / native mumble support)
local currentVoiceScript = nil

local function VexShieldDetectVoiceScript()
    if currentVoiceScript then return currentVoiceScript end
    local voiceScripts = {'pma-voice', 'mumble-voip', 'saltychat', 'saltychat-fivem', 'tokovoip'}
    for _, scriptName in ipairs(voiceScripts) do
        if GetResourceState(scriptName) == 'started' then
            currentVoiceScript = scriptName
            return currentVoiceScript
        end
    end
    if GetResourceState('pma-voice') ~= 'missing' then
        currentVoiceScript = 'pma-voice'
        return currentVoiceScript
    end
    return 'mumble'
end

RegisterNetEvent('VexShield:client:setVoiceChannel')
AddEventHandler('VexShield:client:setVoiceChannel', function(channel)
    local chan = tonumber(channel) or 0
    local voiceScript = VexShieldDetectVoiceScript()
    
    print(string.format("^3[VexShield Voice Client]^7 Setting voice channel to ^2%d^7 (Detected Voice System: ^6%s^7)", chan, tostring(voiceScript)))
    
    if voiceScript == 'pma-voice' then
        local success, err = pcall(function()
            exports['pma-voice']:setCallChannel(chan)
        end)
        if success then
            print(string.format("^2[VexShield Voice Client]^7 Successfully set call channel via pma-voice to ^2%d^7", chan))
        else
            print(string.format("^1[VexShield Voice Client]^7 pma-voice export error: %s (Falling back to native mumble)^7", tostring(err)))
            pcall(function() NetworkSetVoiceChannel(chan) end)
        end
    elseif voiceScript == 'mumble-voip' then
        local success, err = pcall(function()
            exports['mumble-voip']:SetCallChannel(chan)
        end)
        if success then
            print(string.format("^2[VexShield Voice Client]^7 Successfully set call channel via mumble-voip to ^2%d^7", chan))
        else
            print(string.format("^1[VexShield Voice Client]^7 mumble-voip export error: %s^7", tostring(err)))
        end
    else
        print(string.format("^2[VexShield Voice Client]^7 Setting native FiveM Mumble voice channel to ^2%d^7", chan))
        pcall(function() NetworkSetVoiceChannel(chan) end)
        pcall(function() MumbleSetSubmixForServerId(chan, -1) end)
    end
end)

RegisterNUICallback('peerDisconnectMsgToViewer', function(data, cb)
    cb({})
    local viewerSrc = tonumber(data.viewerSrc)
    if viewerSrc then
        VexShieldTriggerAdminServerEvent('VexShield:server:peerDisconnectMsgToViewer', viewerSrc)
    end
end)

RegisterNUICallback('stopPeerStream', function(data, cb)
    cb({})
    local targetSrc = tonumber(data.targetSrc)
    if targetSrc then
        VexShieldTriggerAdminServerEvent('VexShield:server:peerDissconnectMsgToStreamer', targetSrc)
    end
end)

RegisterNUICallback('restorePanelFocus', function(_, cb)
    if display or vexliveOpen then
        SetNuiFocusKeepInput(false)
        SetNuiFocus(true, true)
    end
    cb('ok')
end)

-- Handle stream request from server (for the streamer/target player)
local isStreaming = false
local streamingThread = nil
local lastWebViewerPeerId = ""
local lastWebViewerPeerAt = 0

RegisterNetEvent('VexShield:client:requestPeerConnection')
AddEventHandler('VexShield:client:requestPeerConnection', function(data, viewerSrc)
    local peerId = data and data.peerId
    peerId = peerId and tostring(peerId) or ""
    local now = GetGameTimer()
    local fromWeb = data and data.fromWebDashboard == true
    local forceRetry = data and data.forceRetry == true
    if fromWeb and not forceRetry and peerId ~= "" and peerId == lastWebViewerPeerId and isStreaming then
        return
    end
    local dedupeMs = fromWeb and 350 or 400
    if not forceRetry and peerId ~= "" and peerId == lastWebViewerPeerId and (now - lastWebViewerPeerAt) < dedupeMs then
        return
    end
    lastWebViewerPeerId = peerId
    lastWebViewerPeerAt = now

    isStreaming = true

    -- Web dashboard live view: keep NUI/game-view compositor active (canvas must paint for captureStream).
    -- This is just a keep-alive thread; it does no work, so a slow interval is enough (was Wait(16) = 60/s of pointless wakeups).
    CreateThread(function()
        while isStreaming do
            Wait(500)
        end
    end)
    
    -- Enable NUI overlays to be visible in stream
    -- This allows HUD, inventory, and other NUI elements to appear in the stream
    CreateThread(function()
        while isStreaming do
            -- Capture NUI overlays for WebRTC without breaking the admin panel cursor
            if not display and not vexliveOpen then
                SetNuiFocusKeepInput(true)
            end
            Wait(100)
        end
    end)
    
    SendNUIMessage({
        type = 'streamMyScreen',
        data = data,
        viewerSrc = viewerSrc
    })
end)

-- Handle disconnect message from server (for the streamer)
RegisterNetEvent('VexShield:client:peerDissconnectMsgToStreamer')
AddEventHandler('VexShield:client:peerDissconnectMsgToStreamer', function()
    isStreaming = false
    lastWebViewerPeerId = ""
    lastWebViewerPeerAt = 0
    SetNuiFocusKeepInput(false)
    if display or vexliveOpen then
        SetNuiFocus(true, true)
    else
        SetNuiFocus(false, false)
    end

    SendNUIMessage({
        type = 'peerDissconnectMsgToStreamer'
    })
end)

-- Handle disconnect message from server (for the viewer)
RegisterNetEvent('VexShield:client:peerDisconnectMsgToViewer')
AddEventHandler('VexShield:client:peerDisconnectMsgToViewer', function()
    SendNUIMessage({
        type = 'peerDisconnectMsgToViewer'
    })
end)

RegisterNUICallback('takeScreenshot', function(data, cb)
    local targetId = tonumber(data.id)
    if targetId then
        VexShieldTriggerAdminServerEvent('VexShield:TakeScreenshot', targetId)
        cb('ok')
    else
        cb('error')
    end
end)

RegisterNUICallback('restartResource', function(data, cb)
    local resourceName = data.resourceName
    
    if resourceName then
        VexShieldTriggerAdminServerEvent('VexShield:restartResource', resourceName)
    end
    
    cb('ok')
end)

RegisterNUICallback('stopResource', function(data, cb)
    local resourceName = data.resourceName
    
    if resourceName then
        VexShieldTriggerAdminServerEvent('VexShield:stopResource', resourceName)
    end
    
    cb('ok')
end)

RegisterNUICallback('startResource', function(data, cb)
    local resourceName = data.resourceName
    
    if resourceName then
        VexShieldTriggerAdminServerEvent('VexShield:startResource', resourceName)
    end
    
    cb('ok')
end)





RegisterNUICallback('teleportPlayerToMe', function(data, cb)
    local playerId = tonumber(data.playerId)
    
    if playerId then
        VexShieldTriggerAdminServerEvent('VexShield:teleportPlayerToMe', playerId)
    end
    
    cb('ok')
end)

RegisterNUICallback('teleportToPlayer', function(data, cb)
    local playerId = tonumber(data.playerId)
    
    if playerId then
        VexShieldTriggerAdminServerEvent('VexShield:teleportToPlayer', playerId)
    end
    
    cb('ok')
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(60000)
        
        if display then
            local dashboardData = GetDashboardData()
            local playersData = GetPlayersData()
            local resourcesData = GetResourcesData()
            local vehiclesData = GetVehiclesData()
            
            SendNUIMessage({
                type = "updateData",
                dashboardData = dashboardData,
                playersData = playersData,
                resourcesData = resourcesData,
                vehiclesData = vehiclesData,
                announcementsData = announcements
            })
        end
    end
end)

RegisterNUICallback("client/getBans", function(data, cb)
    local responded = false
    local function respond(b)
        if not responded then
            responded = true
            cb(b or {})
        end
    end

    local function requestViaEvent()
        VexShieldTriggerAdminServerEvent("VexShield:RequestBans")
        local handler
        handler = AddEventHandler("VexShield:SendBans", function(bans)
            respond(bans)
            RemoveEventHandler(handler)
        end)
    end

    if UseESX and ESX then
        ESX.TriggerServerCallback('VexAnticheat:get:banlist', function(bans)
            if type(bans) == 'table' then
                respond(bans)
            else
                requestViaEvent()
            end
        end)
    elseif UseQBCore and QBCore then
        QBCore.Functions.TriggerCallback('VexAnticheat:get:banlist', function(bans)
            if type(bans) == 'table' then
                respond(bans)
            else
                requestViaEvent()
            end
        end)
    else
        requestViaEvent()
    end
end)

RegisterNUICallback("getBans", function(_, cb)
    local responded = false
    local handler
    handler = AddEventHandler("VexShield:SendBans", function(bans)
        if not responded then
            responded = true
            cb(bans or {})
            RemoveEventHandler(handler)
        end
    end)

    VexShieldTriggerAdminServerEvent("VexShield:RequestBans")

    Citizen.SetTimeout(1500, function()
        if not responded then
            FrameworkTriggerServerCallback('VexAnticheat:get:banlist', function(bans)
                responded = true
                cb(bans or {})
                RemoveEventHandler(handler)
            end)
        end
    end)
end)

-- Forward VexShield bans list to NUI for live updates
RegisterNetEvent("VexShield:SendBans")
AddEventHandler("VexShield:SendBans", function(bans)
    SendNUIMessage({ type = "banList", bans = bans or {} })
end)

RegisterNUICallback('getServerStats', function(_, cb)
    VexShieldTriggerAdminServerEvent('VexShield:RequestServerStats')
    RegisterNetEvent('VexShield:SendServerStats')
    AddEventHandler('VexShield:SendServerStats', function(stats)
        cb(stats or { maxClients = 32, bansCount = 0 })
    end)
end)
RegisterNUICallback('getPlayersPlaceData', function(data, cb)
    VexShieldTriggerAdminServerEvent('VexShield:RequestPlayersPlaceData')
    -- Fallback to local data if server doesn't respond
    local players = {}
    for _, playerId in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(playerId)
        if ped and ped ~= 0 then
            local coords = GetEntityCoords(ped)
            players[#players+1] = {
                id = GetPlayerServerId(playerId) or playerId,
                name = GetPlayerName(playerId) or 'Unknown',
                x = coords.x,
                y = coords.y
            }
        end
    end
    SendNUIMessage({ type = 'playersPlace', players = players })
    cb('ok')
end)



RegisterNetEvent('VexShield:RequestPlayerCoords')
AddEventHandler('VexShield:RequestPlayerCoords', function(requestingSrc)
    -- Get our own coordinates
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local serverId = GetPlayerServerId(PlayerId())
    
    -- Send our coordinates back to the server
    TriggerServerEvent('VexShield:SendPlayerCoords', requestingSrc, serverId, {
        id = serverId,
        name = GetPlayerName(PlayerId()),
        x = coords.x,
        y = coords.y,
        z = coords.z
    })
end)

RegisterNetEvent('VexShield:SendLogs')
AddEventHandler('VexShield:SendLogs', function(logs)
    SendNUIMessage({ type = 'logs', logs = logs or {} })
end)

-- Handle live stream frames from server and forward to NUI panel
RegisterNetEvent('VexShield:LiveStreamFrame')
AddEventHandler('VexShield:LiveStreamFrame', function(data)
    -- Forward the live stream frame data to NUI panel
    SendNUIMessage({ 
        type = 'liveStreamFrame', 
        id = data.id,
        playerId = data.id,
        base64 = data.base64,
        starting = data.starting,
        error = data.error,
        action = data.action
    })
end)
RegisterNUICallback('getLogs', function(_, cb)
    local responded = false
    local handler
    handler = AddEventHandler('VexShield:SendLogs', function(logs)
        if not responded then
            responded = true
            cb(logs or {})
            RemoveEventHandler(handler)
        end
    end)
    VexShieldTriggerAdminServerEvent('VexShield:RequestLogs')
    Citizen.SetTimeout(1500, function()
        if not responded then
            RemoveEventHandler(handler)
            cb({})
        end
    end)
end)


RegisterNUICallback('generalAction', function(data, cb)
    local action = tostring(data.action or '')
    if action == 'delete_vehicles' or action == 'delete_vehicles_police' then
        local vehicles = GetGamePool('CVehicle')
        for i = 1, #vehicles do
            DeleteEntity(vehicles[i])
        end
        local dashboardData = GetDashboardData()
        local vehiclesData = GetVehiclesData()
        SendNUIMessage({
            type = 'updateData',
            dashboardData = dashboardData,
            vehiclesData = vehiclesData
        })
        cb('ok')
        return
    elseif action == 'delete_peds' or action == 'delete_peds_police' then
        local peds = GetGamePool('CPed')
        local playerPed = PlayerPedId()
        for i = 1, #peds do
            local ped = peds[i]
            if ped ~= playerPed and not IsPedAPlayer(ped) then
                DeleteEntity(ped)
            end
        end
        local dashboardData = GetDashboardData()
        local vehiclesData = GetVehiclesData()
        SendNUIMessage({
            type = 'updateData',
            dashboardData = dashboardData,
            vehiclesData = vehiclesData
        })
        cb('ok')
        return
    elseif action == 'delete_objects' or action == 'delete_objects_police' then
        local objects = GetGamePool('CObject')
        for i = 1, #objects do
            DeleteEntity(objects[i])
        end
        local dashboardData = GetDashboardData()
        local vehiclesData = GetVehiclesData()
        SendNUIMessage({
            type = 'updateData',
            dashboardData = dashboardData,
            vehiclesData = vehiclesData
        })
        cb('ok')
        return
    elseif action == 'delete_entity' then
        local vehicles = GetGamePool('CVehicle')
        for i = 1, #vehicles do
            DeleteEntity(vehicles[i])
        end
        local peds = GetGamePool('CPed')
        local playerPed = PlayerPedId()
        for i = 1, #peds do
            local ped = peds[i]
            if ped ~= playerPed and not IsPedAPlayer(ped) then
                DeleteEntity(ped)
            end
        end
        local objects = GetGamePool('CObject')
        for i = 1, #objects do
            DeleteEntity(objects[i])
        end
        local dashboardData = GetDashboardData()
        local vehiclesData = GetVehiclesData()
        SendNUIMessage({
            type = 'updateData',
            dashboardData = dashboardData,
            vehiclesData = vehiclesData
        })
        cb('ok')
        return
    elseif action == 'fix' then
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            SetVehicleFixed(veh)
            SetVehicleDirtLevel(veh, 0.0)
            SetVehicleEngineHealth(veh, 1000.0)
            SetVehicleBodyHealth(veh, 1000.0)
        else
            SetEntityHealth(ped, 200)
            ClearPedBloodDamage(ped)
            ResetPedMovementClipset(ped, 0.0)
        end
        cb('ok')
        return
    end
    cb('ok')
end)
