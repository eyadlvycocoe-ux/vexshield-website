Config = Config or {}
-- =============================================================================
--  _   _ _______   _______ _    _ _____ ______ _      _____  
-- | | | |  ___\ \ / /  ___| |  | |_   _|  ____| |    |  __ \ 
-- | | | | |__  \ V / \ `--.| |__| | | | | |__  | |    | |  | |
-- | | | |  __| /   \  `--. \  __  | | | |  __| | |    | |  | |
-- \ \_/ / |___/ /^\ \/\__/ / |  | |_| |_| |____| |____| |__| |
--  \___/\____/\/   \/\____/|_|  |_|_____|______|______|_____/ 
--                   VEXSHIELD ENTERPRISE ANTICHEAT
-- =============================================================================
-- [Version] vBeta
-- [Architecture] Production FiveM Anticheat Engine
-- [Author] VexShield Security Operations

-- =============================================================================
-- 1. CORE SERVER & LICENSING
-- =============================================================================
Config.Servername = "VexShield Test Server"
-- Set this to your Server's License Key from the VexShield Dashboard
Config.LicenseKey = "VEXSHIELD-LOCAL-TEST-KEY-777"

Config.Discordinvite = "https://discord.gg/serverinvite"
Config.RequireDiscord = true
Config.Language = "en" -- Supported: "en", "nl", "de", "fr", "sp", "el", "sv", "tr"
Config.ServerLogo = nil
Config.Framework = "auto" -- Supported: auto | standalone | qbcore | qbox | esx | ox_core | vrp | custom

-- =============================================================================
-- 2. PERMISSIONS & ADMINISTRATIVE ACCESS
-- =============================================================================

-- Exempt Groups: Framework job/group names fully exempt from automatic enforcement
Config.EXEMPT_GROUPS = { 
    ["owner"] = true,
    ["admin"] = true,
    ["staff"] = true
}

-- Admin Groups: Access to in-game management commands (/vex, /vexlive)
-- Leave empty {} to restrict menu access strictly to identifiers in html/admin.json
Config.ADMIN_GROUPS = {}

-- Dynamic Resource & Job Whitelist Cache (auto-synced from html/whitelist.json)
Config.WhitelistedJobs = Config.WhitelistedJobs or {}

-- =============================================================================
-- 3. DISCORD LOGGING & EVIDENCE CAPTURE
-- =============================================================================
Config.logsBans = "https://discord.com/api/webhooks/1558680219290963998/3uUf3sOGS60JeD79g8X2qBJCSWObQLm4X5jZtZPY5ZJKKyaTgPtSqA6izF1ZSjbDPN1T"
Config.logsConnection = "https://discord.com/api/webhooks/1558680269396123730/AoYlvK9kFCpxLJquz5jcjA09jueY0BF2p4cL8Mx6TZis-QScXGz5YjxjpNgcCE0wnHok"
Config.logsLeave = "https://discord.com/api/webhooks/1558680375809802384/qurV4C8yt3qTIaOdYCwUoibsPrvdkPvjz_8NsIMvA5fmG8VYtTtLuBFb2j-EM8u9CdRc"
Config.logsWebhook = "https://discord.com/api/webhooks/1558680435561730210/yc_sSUXPyyNgAQikVRyjw25SKtAryzy4NeY3y8xu0Vb4GAHoclMH3I6oLgeLem-ow0jX"
Config.screenshotWebhook = "https://discord.com/api/webhooks/1558680219290963998/3uUf3sOGS60JeD79g8X2qBJCSWObQLm4X5jZtZPY5ZJKKyaTgPtSqA6izF1ZSjbDPN1T"

-- High-Definition Evidence Video Recording (Hardware-Accelerated CEF Clip Buffer)
Config.BanClipEnabled = true
Config.BanClipDurationMs = 10000             -- 10 seconds pre-ban buffered gameplay video
Config.BanClipVideoBitsPerSecond = 260000     -- Clean video bitrate

-- =============================================================================
-- 4. SERVER PURE MODE & CRASH INTERCEPTION
-- =============================================================================
Config.PureMode = {
    Enabled = false,
    ScriptHookAllowed = 0,
    PureLevel = 2,
    FilterRequestControl = 1
}

Config.AntiCrash = {
    Enabled = true,
    AntiCrashModels = true,     -- Intercept malicious crash models (BLIMP, CARGOPLANE, SUBMARINE, RHINO)
    AntiCrashExplosions = true,  -- Intercept scaleform & invisible crash explosions
    AntiCrashParticles = true,   -- Suppress blacklisted crash particle effects
    AntiCrashScenarios = true    -- Block crash scenario groups
}

-- =============================================================================
-- 5. COMBAT, WEAPONS & AIMBOT SECURITY (INSTANT DETECTION & BAN)
-- =============================================================================
-- All combat exploits trigger immediate detection and instant permanent ban.
-- Blocking/canceling damage is completely removed in favor of instant enforcement.
Config.Weapons = {
    AntiSpoofedBullets = true,
    AntiAimBot = true,          -- Instant detect and permanent ban on aim-lock / snap
    AntiSilentAim = true,       -- Instant detect and permanent ban on bullet-curve / angle deviation
}

Config.Beta = {
    AntiSilentAim = true,       -- Advanced multi-angle trajectory analysis
}

Config.AntiGiveWeapon = {
    Enabled = true,
    StrictResourceWhitelist = true,
    UseGlobalResourceWhitelist = false,
    AllowedResources = {
        "qb-core",
        "qb-inventory",
        "qs-inventory",
        "ox_inventory",
        "es_extended",
        "esx_policejob",
        "esx_weaponshop",
    },
    BlockBlacklistedWeapons = true,
    MaxEventsPer10Seconds = 8,
    StrikeLimit = 2,
    StrikeWindowMs = 30000,
    BypassMs = 8000,
}

-- =============================================================================
-- 6. REAL-TIME DETECTION MODULES
-- =============================================================================
Config.Protections = {

    -- [Player Movement & State]
    ['Anti Noclip'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Noclip2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Noclip3'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Noclip4'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Noclip5'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Bebetter Noclip'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Parachute Noclip'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Force Fall'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Armour Detection'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti invisible'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti invisible2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Teleport'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Teleport2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Speedhack'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Fast Run'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti SuperJump'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti SuperJump2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Night/ThermalVision'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Infinite Stamina'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spectate'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Look Around'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freecam'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freecam2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freecam3'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freecam #4'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freecam #5'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freecam #6'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Block Input'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti LUA Input'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Player Blips'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spoof Name'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti OCR'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Fling'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Game & World Interaction]
    ['Anti Crash'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Super Punch'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Model Changer'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Ped Scale'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Camera Rotation'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Rape Player'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Player Harassment'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Lua Freeze'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Player On Fire'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Freeze Player'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Ragdoll Abuse'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Task Clear Loop'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Animation Injection'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Player Attach'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Player Collision Disable'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Infinite Roll'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Heal Spam'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Godmode'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Npc Hijack'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Solo Session'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Clear Tasks'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Aggresive Peds'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Blacklisted Particles'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Object Spawn'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Attach Object to Player'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Unauthorized Entity Spawn'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Weapons & Ammo]
    ['Anti Spawn Weapon'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spawn Weapon2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spawn Weapon3'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spoofed Damage/Weapon'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Shoot Without Weapon'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti NoRecoil'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti NoReload'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Explosion Bullet'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Explosion Bullet2'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Infinite Ammo'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Give Money'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Kill Punch'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Weapon Damage Changer'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Blacklisted Weapon'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    
    -- [Vehicles & Entities]
    ['Anti Carry Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Throw Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Boost vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Vehicle Spam'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Bring Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Bring All Vehicles'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Repair Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Delete Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Bug Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spawn Vehicle/Entity'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spawn Entity'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Vehicle Weapon'] = { Enabled = true, L1 = true, L2 = true, L3 = true }, 
    ['Anti Plate Changer'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Launch/Fly Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Car Speed Hack'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Entity Manipulation'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Clone Player'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Vehicle Mod Abuse'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spawn Ped'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Blacklisted Vehicle'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Blacklisted Ped'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Explosions]
    ['Anti Ai Explosion'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Explosion'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Silent Explosion'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Phone Explosion'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Invisible Explosion'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Inaudible Explosion'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Network, Events & System]
    ['Anti Cipher'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spoof'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Vpn'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Afk'] = { Enabled = false, L1 = false, L2 = false, L3 = false },
    ['Anti Stop Resource'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Unknown Resource'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Spam Trigger'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Trigger Event'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['blacklisted Trigger'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Event Token Bypass'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Resource Injection'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Voice Exploits'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Global Voice'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Inventory Exploit'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Cheat Menus & Injection]
    ['Cheat Ai Detection'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Lua Menu'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti NUI Blocker'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti DevTools'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Clipboard Scanner'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Menu'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Menu Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Spawn Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Teleport Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Weapon Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Vehicle Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Ped Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Object Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Advanced Hooks & Protections]
    ['Anti Lua Executor'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti AC Scanner'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Unauthorized Admin'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Bytecode Injection'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Global Function Hook'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Native Hook'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Loadstring'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Citizen.Invoke Abuse'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Export Hijack'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Shared Object Override'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Resource Rename Bypass'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Explosion Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Spectate'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Force Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Clone Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Cage Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Cheat Inventory Exploit'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Additional Menu Detections]
    ['Anti cheat Menu'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti cheat Menu Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti cheat API Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti cheat Spectate'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti cheat Bypass Functions'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    
    -- [Kill & Combat]
    ['Anti Kill'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Kill2'] = { Enabled = true, L1 = true, L2 = true, L3 = true }, 
    ['Anti Kill All'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Taze'] = { Enabled = true, L1 = true, L2 = true, L3 = true },

    -- [Aim & Damage Modules]
    ['Anti Aim Bot'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Silent Aim'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Overlay'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Menu Texture'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Damage Changer'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Fast Shoot'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Recoil Manip'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Hitbox Manip'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti No Headshot'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
    ['Anti Pickup Collection'] = { Enabled = true, L1 = true, L2 = true, L3 = true },
}


-- =============================================================================
-- 7. ENFORCEMENT ACTIONS MAPPING
-- =============================================================================
Config.EnforcementActions = {
    ['Anti Crash'] = "ban",
    -- [Player]
    ['Anti Noclip'] = "ban",
    ['Anti Noclip2'] = "ban",
    ['Anti Noclip3'] = "ban",
    ['Anti Noclip4'] = "ban",
    ['Anti Noclip5'] = "ban",
    ['Anti Bebetter Noclip'] = "ban",
    ['Anti Parachute Noclip'] = "ban",
    ['Anti Force Fall'] = "ban",
    ['Armour Detection'] = "ban",
    ['Anti invisible'] = "ban",
    ['Anti invisible2'] = "ban",
    ['Anti Teleport'] = "ban",
    ['Anti Teleport2'] = "ban",
    ['Anti Speedhack'] = "ban",
    ['Anti Fast Run'] = "ban",
    ['Anti SuperJump'] = "ban",
    ['Anti SuperJump2'] = "ban",
    ['Anti Night/ThermalVision'] = "ban",
    ['Anti Infinite Stamina'] = "ban",
    ['Anti Spectate'] = "ban",
    ['Anti Look Around'] = "ban",
    ['Anti Freecam'] = "ban",
    ['Anti Freecam2'] = "ban",
    ['Anti Freecam3'] = "ban",
    ['Anti Freecam #4'] = "ban",
    ['Anti Freecam #5'] = "ban",
    ['Anti Freecam #6'] = "ban",
    ['Anti Block Input'] = "ban",
    ['Anti LUA Input'] = "ban",
    ['Anti Player Blips'] = "ban",
    ['Anti Spoof Name'] = "ban",
    ['Anti OCR'] = "ban",
    ['Anti Fling'] = "ban",

    -- [Game & World]
    ['Anti Super Punch'] = "ban",
    ['Anti Model Changer'] = "ban",
    ['Anti Rape Player'] = "ban",
    ['Anti Player Harassment'] = "ban",
    ['Anti Lua Freeze'] = "ban",
    ['Anti Player On Fire'] = "ban",
    ['Anti Freeze Player'] = "ban",
    ['Anti Ragdoll Abuse'] = "ban",
    ['Anti Task Clear Loop'] = "ban",
    ['Anti Animation Injection'] = "ban",
    ['Anti Player Attach'] = "ban",
    ['Anti Player Collision Disable'] = "ban",
    ['Anti Infinite Roll'] = "ban",
    ['Anti Heal Spam'] = "ban",
    ['Anti Godmode'] = "ban",
    ['Anti Npc Hijack'] = "ban",
    ['Anti Solo Session'] = "ban",
    ['Anti Clear Tasks'] = "ban",
    ['Anti Aggresive Peds'] = "ban",
    ['Blacklisted Particles'] = "ban",
    ['Anti Object Spawn'] = "ban",
    ['Anti Attach Object to Player'] = "kick",
    ['Anti Unauthorized Entity Spawn'] = "ban",

    -- [Weapons]
    ['Anti Spawn Weapon'] = "ban",
    ['Anti Spawn Weapon2'] = "ban",
    ['Anti Spawn Weapon3'] = "ban",
    ['Anti Spoofed Damage/Weapon'] = "ban",
    ['Anti Shoot Without Weapon'] = "ban",
    ['Anti NoRecoil'] = "ban",
    ['Anti NoReload'] = "ban",
    ['Anti Explosion Bullet'] = "ban",
    ['Anti Explosion Bullet2'] = "ban",
    ['Anti Infinite Ammo'] = "ban",
    ['Anti Give Money'] = "ban",
    ['Anti Kill Punch'] = "ban",
    ['Anti Weapon Damage Changer'] = "ban",
    ['Anti Blacklisted Weapon'] = "ban",

    -- [Vehicles]
    ['Anti Carry Vehicle'] = "ban",
    ['Anti Throw Vehicle'] = "ban",
    ['Anti Boost vehicle'] = "ban",
    ['Vehicle Spam Detected'] = "ban",
    ['Bring Vehicle Detected'] = "ban",
    ['Bring All Vehicles Detected'] = "ban",
    ['Repair Vehicle Detected'] = "ban",
    ['Delete Vehicle Detected'] = "ban",
    ['Bug Vehicle Detected'] = "ban",
    ['Anti Spawn Vehicle/Entity'] = "ban",
    ['Anti Spawn Entity'] = "ban",
    ['Anti Vehicle Weapon'] = "ban", 
    ['Anti Plate Changer'] = "ban",
    ['Anti Launch/Fly Vehicle'] = "ban",
    ['Anti Car Speed Hack'] = "ban",
    ['Anti Entity Manipulation'] = "ban",
    ['Anti Clone Player'] = "ban",
    ['Anti Vehicle Mod Abuse'] = "ban",
    ['Anti Spawn Ped'] = "ban",
    ['Anti Blacklisted Vehicle'] = "ban",
    ['Anti Blacklisted Ped'] = "ban",

    -- [Explosions]
    ['Anti Ai Explosion'] = "ban",
    ['Anti Explosion'] = "ban",
    ['Anti Silent Explosion'] = "ban",
    ['Anti Phone Explosion'] = "ban",
    ['Anti Invisible Explosion'] = "ban",

    -- [Network & System]
    ['Anti Cipher'] = "ban",
    ['Anti Stop Resource'] = "ban",
    ['Anti Spoof'] = "ban",
    ['Anti Resource Injection'] = "ban",
    ['Anti Voice Exploits'] = "ban",
    ['Anti Global Voice'] = "ban",
    ['Anti Inventory Exploit'] = "ban",

    -- [Cheat Menus & Injection]
    ['Cheat Ai Detection'] = "ban",
    ['Anti Lua Menu'] = "ban",
    ['Anti NUI Blocker'] = "ban",
    ['Anti DevTools'] = "ban",
    ['Clipboard Scanner'] = "ban",
    ['Anti Cheat Menu'] = "ban",
    ['Anti Cheat Menu Functions'] = "ban",
    ['Anti Cheat Spawn Functions'] = "ban",
    ['Anti Cheat Teleport Functions'] = "ban",
    ['Anti Cheat Weapon Functions'] = "ban",
    ['Anti Cheat Vehicle Functions'] = "ban",
    ['Anti Cheat Ped Functions'] = "ban",
    ['Anti Cheat Object Functions'] = "ban",
    ['Anti Cheat Explosion Functions'] = "ban",
    ['Anti Cheat Spectate'] = "ban",
    ['Anti Cheat Force Functions'] = "ban",
    ['Anti Cheat Clone Functions'] = "ban",
    ['Anti Cheat Cage Functions'] = "ban",
    ['Anti Cheat Inventory Exploit'] = "ban",
    ['Anti cheat Menu'] = "ban",
    ['Anti cheat Menu Functions'] = "ban",
    ['Anti cheat API Functions'] = "ban",
    ['Anti cheat Spectate'] = "ban",
    ['Anti cheat Bypass Functions'] = "ban",
    
    -- [Advanced Protections]
    ['Anti Lua Executor'] = "ban",
    ['Anti AC Scanner'] = "ban",
    ['Anti Unauthorized Admin'] = "ban",
    
    -- [Ported Detections]
    ['Anti License Clear'] = "ban",
    ['Anti No Headshot'] = "ban",
    ['Anti Weapon Components'] = "ban",
    ['Anti Horn Boost'] = "ban",
    
    -- [Kill Protections]
    ['Anti Kill'] = "ban",
    ['Anti Kill2'] = "ban",
    ['Anti Kill All'] = "ban",
    ['Anti Taze'] = "ban",
    
    -- [Aim & Hitbox]
    ['Anti Aim Bot'] = "ban",
    ['Anti Silent Aim'] = "ban",
    ['Anti Overlay'] = "ban",
    ['Anti Menu Texture'] = "ban",
    ['Anti Damage Changer'] = "ban",
    ['Anti Fast Shoot'] = "ban",
    ['Anti Recoil Manip'] = "ban",
    ['Anti Hitbox Manip'] = "ban",
    ['Anti Pickup Collection'] = "ban",
}

-- =============================================================================
-- 7. EXPLOSIONS CONFIGURATION (VexShield Engine)
-- =============================================================================


-- =============================================================================
-- 8. EXPLOSION SECURITY ENGINE
-- =============================================================================
Config.Explosions = {
    CancelAllExplosions = false,
    EnableExplosionsAI = true,
    EnableExplosionsBlackList = true,
    EnableExplosionsLimiter = true,
    ExplosionsLimitIn5Seconds = 5,
    DetectInvisibleExplosions = true,
    DetectInaudibleExplosions = true,
    LogExplosionSpawnsToConsole = true,
    BlackListedExplosions = {
        [29] = true, -- EXP_TAG_PROXMINE
        [32] = true, -- EXP_TAG_AIR_DEFENCE
        [35] = true, -- EXP_TAG_RAILGUN
        [36] = true, -- EXP_TAG_BLIMP2
        [37] = true, -- EXP_TAG_FIREWORK
        [38] = true, -- EXP_TAG_SNOWBALL
        [59] = true, -- EXP_TAG_ORBITAL_CANNON
    }
}


-- =============================================================================
-- 9. VEHICLE & PED SPAWN SECURITY
-- =============================================================================
Config.AntiPedSpawn = { ['Enabled'] = true, ['AllowedScripts'] = { "qb-core" } }

-- Vehicle Spawn Protection Settings
Config.AntiSpawnVehicleEnabled = true
Config.AntiSpawnVehicleOccupancyGraceMs = 0
Config.AntiSpawnVehicleOccupancyMaxDist = 45.0
Config.AntiSpawnVehicleFarSpawnDist = 120.0
Config.AntiSpawnVehicleHeadingEnabled = false
Config.AntiSpawnVehicleHeadingMaxDiff = 150.0
Config.AntiSpawnVehicleRammingProtectMs = 800
Config.AntiSpawnVehicleDebug = false
Config.AntiSpawnVehicleVerifyFrameworkTriggers = false

-- Client Vehicle Spam Detection Settings
Config.VehicleSpamCheckMs = 5000
Config.VehicleSpamRadius = 15.0
Config.VehicleSpamIncreaseThreshold = 8
Config.VehicleSpamMinNearbyVehicles = 10
Config.VehicleSpamRequiredStrikes = 3
Config.VehicleSpamStrikeWindowMs = 20000

Config.AllowedVehicleSpawnResources = {
    "qb-core",
    "es_extended",
    "qbx_core",
    "qb-garages",
    "qb-vehicleshop",
    "esx_vehicleshop",
    "esx_garage",
    "qs-vehiclekeys",
    "rentcar",
    "jg-advancedgarages",
    "car_rental",
    "army-ground-vehicle-garage",
    "army-aircraft-garage",
    "tstudio_impound",
    "policegarage",
    "qb-customs",
    "wasabi_police",
    "wasabi_ambulance",
    "qb-policejob",
    "esx_policejob"
}

Config.PedSpawnLimit = 50
Config.PedSpawnWindowMs = 5000


-- =============================================================================
-- 10. OBJECT & ENTITY PROTECTION
-- =============================================================================
Config.ObjectProtections = {
    ['BanOnUnauthorized'] = false,
    ['MaxObjects'] = 8,
    ['DeleteOnSpawnAttempts'] = 4,
    ['ServerCleanup'] = true,
    ['ServerCleanupIntervalMs'] = 50,
    ['ServerCleanupRadius'] = 12.0,
    ['ServerCleanupRepeats'] = 8,
    ['PostCreateCleanup'] = true,
    ['PostCreateCleanupDelayMs'] = 0,
    ['PostCreateCleanupChecks'] = 6,
    ['PostCreateCleanupCheckIntervalMs'] = 100,
    ['ObjectSweepIntervalMs'] = 1000,
    ['CleanupAdminObjects'] = true,
    ['AllowedScripts'] = {
        "qb-core",
        "es_extended",
        "qbx_core",
        "ox_inventory",
        "qb-inventory",
        "qs-inventory",
        "lj-inventory",
        "kq_outfitbag",
        "dpemotes",
        "rpemotes",
        "scully_emotemenu",
        "qb-target",
        "ox_target",
        "qtarget",
        "qb-smallresources",
        "qb-doorlock",
        "ox_doorlock",
        "nui_doorlock",
        "qb-housing",
        "qs-housing",
        "ps-housing",
        "qb-garages",
        "wasabi_ambulance",
        "esx_ambulancejob",
        "qb-policejob",
        "esx_policejob",
        "wasabi_police",
        "wasabi_bridge",
        "ox_lib",
        "cd_drawtextui",
        "qb-weed",
        "qb-drugs",
        "qb-stashes",
        "qb-interior",
        "interiors",
        "bob74_ipl",
        "qb-furniture",
        "qb-weapons",
        "qb-tackle",
        "qb-radialmenu",
        "progressbar",
        "rc",
        "drones",
        "mapmanager"
    },
    ['AllowedModels'] = {
        "prop_big_bag_01",
        "prop_paper_bag_small",
        "prop_cs_rub_binbag_01",
        "prop_money_bag_01",
        "p_ld_heist_bag_s_1",
        "prop_roadcone02a",
        "prop_roadcone01a",
        "prop_barrier_work05",
        "prop_barrier_work06a",
        "prop_mp_barrier_01",
        "prop_stat_pack_01",
        "prop_ld_health_pack",
        "xm_prop_x17_bag_med_01a",
        "prop_amb_beer_bottle",
        "prop_phone_ing",
        "prop_npc_phone_02",
        "prop_cigar_02",
        "prop_ld_flow_bottle",
        "prop_sandwich_01",
        "p_cs_cuff_keys_s",
        "prop_test_baffe",
        "prop_box_wood02a",
        "prop_box_guncase_01a"
    }
}

Config.MaxSpawn = {
    ['MaxVehiclesPerPlayer'] = 0, ['MaxPedsPerPlayer'] = 30, ['MaxPropsPerPlayer'] = 0,
    ['MaxVehiclesGlobal'] = 0, ['MaxPedsGlobal'] = 150, ['MaxPropsGlobal'] = 0,
    ['MaxSameVehicleModel'] = 0, ['MaxSamePedModel'] = 20, ['MaxSamePropModel'] = 0,
    ['ResetOnDisconnect'] = true, ['EnableGlobalLimits'] = false, ['EnablePerModelLimits'] = false,
}

Config.ProgressPropsMax = 2
Config.ObjectSpamThreshold = 200
Config.PropSpawnLimit = 1
Config.PropSpawnWindowMs = 300


-- =============================================================================
-- 11. NETWORK, SPOOFING & EVENT PROTECTION
-- =============================================================================
Config.SpoofDetection = {
    ['Enabled'] = true,
    ['MinTokens'] = 3,
    ['RequireLicense'] = true,
    ['RequireSteam'] = false,
    ['RequireDiscord'] = true,
    ['AllowPrivateIPs'] = false,
    ['MinFlagsToBlock'] = 2,
    ['MinFlagsToBan'] = 2,
    ['RuntimeGraceMs'] = 45000,
    ['HashTokenFingerprints'] = true,
    ['LegacyFingerprintSecrets'] = {},
    ['FingerprintVersion'] = 2,
    ['WaveNuiEnabled'] = false,
    ['FingerprintAnalysis'] = true,
    ['CheckIPConsistency'] = true,
    ['DetectTokenRecycling'] = true,
    ['EntropyScoring'] = true,
    ['EntropyReconnectWindowSec'] = 120,
    ['EntropyReconnectMaxAttempts'] = 6,
    ['BlacklistedTokens'] = {
        "0000000000000000000000000000000000000000",
        "ffffffffffffffffffffffffffffffffffffffff",
    },
}

Config.InjectionChecking = 15000
Config.CheatEngineChecking = 15000

Config.AllowedResources = { "handup_search", "policejob", "ems_job", "kq_outfitbag" }


-- =============================================================================
-- 12. CLIENT TUNABLES & INTERACTION SECURITY
-- =============================================================================
Config.Client = {
    ['Max Distance Teleporting'] = 500,
    ['Anti invisible'] = {
        ['Whitelisted Areas'] = { {coords = vector3(-34.0726, -1097.2799, 26.4224), radius = 20} }
    },
    ['Whitelisted Models'] = {
        [tostring(GetHashKey("mp_m_freemode_01"))] = true,
        [tostring(GetHashKey("mp_f_freemode_01"))] = true
    },
    ['Plate Changing'] = {
        ['Whitelisted Areas'] = { {coords = vector3(-34.0726, -1097.2799, 26.4224), radius = 20} }
    },
    ['Event Security'] = {
        ['Enabled'] = true,
        ['Mode'] = "enforce", -- "log" | "warn" | "enforce"
        ['TokenTTLMs'] = 5000,
        ['RateLimitPerSec'] = 10
    },
    ['Event Registry'] = {
        ['Public'] = {
            ["playerSpawned"] = true,
            ["onClientResourceStart"] = true,
            ["onResourceStart"] = true,
            ["onResourceStop"] = true
        },
        ['Protected'] = {
            ["esx:giveInventoryItem"] = true,
            ["QBCore:Server:AddItem"] = true,
            ["qb-banking:server:Deposit"] = true
        },
        ['Sensitive'] = {
            ["QBCore:Server:GiveCommission"] = true,
            ["esx:withdrawMoney"] = true,
            ["qb-banking:server:Withdraw"] = true
        }
    },
    ['Noclip/Freecam Whitelist'] = { 
        ['Whitelisted Areas'] = { {coords = vector3(-34.0726, -1097.2799, 26.4224), radius = 20} }
    },    
    ['Explosion Whitelist'] = { [2] = true, [4] = true, [7] = true, [10] = true, [13] = true },
    ['Explosion Protection'] = {
        SpamThreshold = 1,
        SpamWindowMs = 2500,
        StrikeLimit = 2,
        StrikeWindowMs = 60000,
        StrikeCooldownMs = 8000,
        LogBlocked = true,
        LogCooldownMs = 4000,
        DangerousTypes = {},
        BanDangerousTypes = false,
    },
    ['AntiTaze'] = {
        ['TazerWeaponHash'] = GetHashKey("WEAPON_STUNGUN"),
        ['MaxTazeDistance'] = 10.0  
    },
    ['Vehicle Repair'] = {
        ['Whitelisted Areas'] = { {coords = vector3(-211.55, -1324.55, 30.89), radius = 50.0} }
    },
    ['Anti Speedhack'] = {
        ['Whitelisted Areas'] = {},
        PollIntervalMs    = 1000,
        MaxOnFootSpeed    = 12.0,
        MaxVehicleSpeed   = 145.0,
        TeleportResetDist = 250.0,
        WarnLimit         = 3,
        VehicleExitGrace  = 3000,
    },
    ['AntiAFK'] = { MaxAFKTime = 300 },
    ['BlacklistedParticles'] = { "scr_xs_dr", "scr_rcbarry1", "scr_rcbarry2" },
    ['InfiniteAmmoMax'] = 250,
    ['InfiniteAmmoMin'] = 0,
    ['AntiSpamTrigger'] = { 
        ResetLimit = true, ResetTime = 10,
        Triggers = {
            ["inventory:open"] = { limit = 10, action = "kick" },
            ["example:trigger"] = { limit = 5, action = "ban" },
            ["ServerValidEmote"] = { limit = 100, action = "ban" },
            ["inventory:server:OpenInventory"] = { limit = 5, action = "ban" },
            ["hospital:server:RevivePlayer"] = { limit = 3, action = "ban" },
            ["QBCore:Server:AddItem"] = { limit = 10, action = "ban" },
        }
    },
}


-- =============================================================================
-- 13. GLOBAL BLACKLISTS & WHITELISTS
-- =============================================================================
Config.BlacklistedMenuWords = {
    "vtz menu",
    "Open Key:", "god mode", "modmenu",
    "kill menu", "FORCE RADAR", "FAKE DEAD",
    "Weapon Menu", "Self Menu", "Vehicle Menu", "Semi God Mode", 
    "Teleport Option", "Teleport to waypoint", "Fast Run", "Infinite Stamina",
    "Remove all weapons", 
    "Explode Everyone", "Give Money", "Crash Fivem Player Menu", "crash fivem player menu",
    "Lua options", "Self Options", "Troll Menu", "Troll Features", "Panic Button", 
    "Destroy Menu", "Cage Players", "Rage bot", "Unlimited ammo",
    "fling player", "fling", "air",
    "One shot", "All players", "Player Online", "Successfully injected", "CFW Options", 
    "Money Options", "Detected", "Online Players Options", "Server troll", "kill engine", 
    "Kill Player", "Remove All Weapons", "Full Armor Player", "give weapon(s)", 
    "kick player", "spoof", "kill everyone", "esx money", "MainMenu", "SelfMenu", 
    "OnlinePlayersMenu", "WeaponMenu", "Make All Vehciles Fly", "Vehcile Fly",
    "SingleWeaponMenu", "MaliciousMenu", "ESXMenu", "ESXJobMenu", "ESX Boss", 
    "Spawn Props On Player", "Explosion Loop", "Freeze Player",
    "ESXMoneyMenu", "VehMenu", "VehSpawnOpt", "PlayerOptionsMenu", 
    "Bullets Gun Options", "ESX Triggers", "Explosion", "Kick Out Of Veh",
    "Event Blocker", "Destroyer", "Spectate", "Wallhack", "triggers",
    "Menu perso", "menu by", "Ped Menu", "explode", "Particle", "PlayerTrollMenu", 
    "PlayerESXMenu", "PlayerESXJobMenu", "PlayerESXTriggerMenu", "BulletGunMenu", 
    "TrollMenu", "VehicleRamMenu", "ESXBossMenu", "ESX Drugs/Items", "Send Fake Message",
    "SpawnPropsMenu", "SingleWepPlayer", "VehBoostMenu", "ESXMiscMenu", "ESX Options", 
    "Weapon Cusomization Options", "ESXDrugMenu", "SettingsMenu", "VRPMenu", "VRP Options", 
    "ESX Jobs", "ESX Money Menu", "trigger", 
    "fuck server", "superjump", "Inyection", "Inyected", "Dumper", "Executor",
    "Give Single Weapon", "Airstrike Player", "Taze Player", "Helicopter Chase Player", 
    "Rape Everyone", "9/11 into Player", "Destroy Vehicle",
    "cheat", "cheats", "anonymous", "hacker", "eulen", "eulencheats", "owner", 
    "administrator", "shit", "fuck", "fucking", "anticheat", "<", ">", "img", 
    "script", '"', "http", "https", "body", "desudo"
}

Config.ClipboardScanner = {
    Enabled = true,
    ScanIntervalMs = 7500, -- Periodic scanner check interval
    Enforcement = "ban",    -- Default enforcement: "ban", "kick", "warn", "log"
    MaxSnippetLength = 60, -- Max characters of matched snippet to preserve in logs
    Blacklist = {
        -- [Trigger Execution & Native Invocations]
        "triggerserverevent", "triggerevent", "triggerlatentserverevent",
        "triggerservereventinternal", "triggereventinternal",
        "emitnet(", "emitnet (", "emit(", "emit (",
        "citizencallnativereturnspec", "citizen.invokenative", "invokenative",
        "registernetevent", "addeventhandler",

        -- [Cheat Menus, Injections & Loaders]
        "lynxmenu", "falloutmenu", "dopamine", "hammafia", "ham mafia",
        "eulencheats", "eulen", "redengine", "skptclient", "vtz menu",
        "tiagomenu", "hydromenu", "desudo", "chocohax", "nexusmenu",
        "darkside", "skidmenu", "lumiamenu", "isloader", "cheat engine",
        "dumper", "lua executor", "fivem executor", "fivem cheat",
        "mod menu", "injector", "inyection", "bypass ac", "ac bypass",

        -- [Malicious Functions & Exploitation Strings]
        "loadstring(", "loadstring (", "dumper.dump", "dump_all",
        "esx:getsharedobject", "qbcore:getobject", "qbcore:getcoreobject",
        "setentitycoords(", "giveweapontoped(", "setentityinvincible(", "addexplosion(",
        "networkexplodetaggedvehicles", "fuck server", "rageloop",
        "tazeall", "killall", "crash fivem", "cageserver", "freezeall",

        -- [Exploit Economy & Pay Triggers]
        "adminmenu:givebank", "esx_truckerjob:pay", "vrp:pay", "esx_gopostal:pay",
        "bank:deposit", "esx:giveinventoryitem", "givemoney", "givecash",
        "esx_society:depositmoney", "esx_society:withdrawmoney",
        "qb-banking:server:deposit", "qb-banking:server:withdraw",
        "qb-bossmenu:server:withdrawmoney", "esx_billing:sendbill",
        "esx_garbagejob:pay", "esx_miner:giveitem", "delivery:job:pay",

        -- [Exploit Items, Weapons & Admin Triggers]
        "qb-weapons:server:addweapon", "qb-inventory:server:additem", "ox_inventory:giveitem",
        "esx_ambulancejob:revive", "hospital:server:revive", "qbx_medical:server:playerrevived",
        "esx_policejob:handcuff", "police:server:cuffplayer", "esx_jailer:sendtojail",
        "qb-jail:server:jailplayer", "easyadmin:", "txadmin:", "vmenu:",

        -- [Cheat Sources & Repositories]
        "raw.githubusercontent.com/", "pastebin.com/raw/", "hastebin.com/raw/",
        "keyauth.win", "cheats.gg", "eulencheats.com"
    }
}

Config.BlockedAnimations = {
    ["anim@arena@celeb@flat@paired@no_props@"] = {
        "piggyback_b_player_a", "piggyback_c_player_a_face", "piggyback_c_player_a",
        "piggyback_c_player_b_face", "piggyback_b_player_b", "piggyback_b_player_a_face",
        "piggyback_c_player_b"
    },
    ["switch@trevor@jerking_off"] = { "trev_jerking_off_loop", "trev_jerking_off_exit_cam" },
    ["mini@strip_club@lap_dance@"] = { "lap_dance_crowd_01", "lap_dance_girl_01", "lap_dance_leadout_a" },
    ["misscarsteal2peeing"] = { "peeing_loop" },
    ["mp_player_int_upperwank"] = { "mp_player_int_wank_01" },
    ["mini@prostitutes@sexnorm_veh"] = { "sex_loop_prostitute", "bj_loop_prostitute" },
    ["mini@strip_club@private_dance@part3"] = { "priv_dance_p3" },
    ["mini@strip_club@pole_dance@pole_dance1"] = { "pd_dance_01" },
    ["mini@strip_club@lap_dance@ld_girl_a_song_a_p1"] = { "ld_girl_a_song_a_p1" },
    ["mini@strip_club@lap_dance@ld_girl_a_song_a_p2"] = { "ld_girl_a_song_a_p2" },
    ["mini@strip_club@lap_dance@ld_girl_a_song_a_p3"] = { "ld_girl_a_song_a_p3" },
    ["misscarsteal2pimpsex"] = { "shagloop_pimp", "shagloop_hooker" },
    ["timetable@trevor@skull_loving_bear"] = { "skull_loving_bear" },
    ["rcmpaparazzo_2"] = { "shag_loop_poppy_a", "shag_loop_poppy", "shag_loop_a" },
}

Config.BlacklistedNames = {
    "hammafia", "redengine", "cheat", "cheats", "anonymous", "hacker", "eulen",
    "eulencheats", "owner", "administrator", "shit", "fuck", "fucking", "anticheat",
    "<", ">", "img", "script", "\"", "http", "https", "body", "desudo"
}

Config.BlacklistedCommands = {
    "eulen", "redengine", "lynx", "lynxmenu", "ham", "hammafia", "dopamine",
    "fallout", "brutan", "skript", "desudo", "panik", "god", "noclip", "invis",
    "superjump", "explosiveammo", "giveshit", "spawncar", "killall", "tpm",
    "spectate", "fendinx", "alphav", "lux", "hydromenu", "tiago", "war_menu",
    "chocolate", "carmenu", "magneto", "executor", "luaexecutor"
}

Config.BlacklistedProps = {
    "prop_ld_bomb", "prop_air_bigradar", "prop_logpile_07b", "prop_logpile_07",
    "prop_logpile_06b", "prop_logpile_06", "prop_logpile_05", "prop_logpile_04",
    "prop_logpile_03", "prop_logpile_02", "prop_logpile_01", "hei_prop_carrier_radar_1_l1",
    "v_res_mexball", "prop_rock_1_a", "prop_rock_1_b", "prop_rock_1_c", "prop_rock_1_d",
    "prop_player_gasmask", "prop_rock_1_e", "prop_rock_1_f", "prop_rock_1_g", "prop_rock_1_h",
    "prop_test_boulder_01", "prop_test_boulder_02", "prop_test_boulder_03", "prop_test_boulder_04",
    "apa_mp_apa_crashed_usaf_01a", "ex_prop_exec_crashdp", "apa_mp_apa_yacht_o1_rail_a",
    "apa_mp_apa_yacht_o1_rail_b", "apa_mp_h_yacht_armchair_01", "apa_mp_h_yacht_armchair_03",
    "apa_mp_h_yacht_armchair_04", "apa_mp_h_yacht_barstool_01", "apa_mp_h_yacht_bed_01",
    "apa_mp_h_yacht_bed_02", "apa_mp_h_yacht_coffee_table_01", "apa_mp_h_yacht_coffee_table_02",
    "apa_mp_h_yacht_floor_lamp_01", "apa_mp_h_yacht_side_table_01", "apa_mp_h_yacht_side_table_02",
    "apa_mp_h_yacht_sofa_01", "apa_mp_h_yacht_sofa_02", "apa_mp_h_yacht_stool_01",
    "apa_mp_h_yacht_strip_chair_01", "apa_mp_h_yacht_table_lamp_01", "apa_mp_h_yacht_table_lamp_02",
    "apa_mp_h_yacht_table_lamp_03", "prop_flag_columbia", "apa_mp_apa_yacht_o2_rail_a",
    "apa_mp_apa_yacht_o2_rail_b", "apa_mp_apa_yacht_o3_rail_a", "apa_mp_apa_yacht_o3_rail_b",
    "apa_mp_apa_yacht_option1", "proc_searock_01", "apa_mp_h_yacht_", "apa_mp_apa_yacht_option1_cola",
    "apa_mp_apa_yacht_option2", "apa_mp_apa_yacht_option2_cola", "apa_mp_apa_yacht_option2_colb",
    "apa_mp_apa_yacht_option3", "apa_mp_apa_yacht_option3_cola", "apa_mp_apa_yacht_option3_colb",
    "apa_mp_apa_yacht_option3_colc", "apa_mp_apa_yacht_option3_cold", "apa_mp_apa_yacht_option3_cole",
    "apa_mp_apa_yacht_jacuzzi_cam", "apa_mp_apa_yacht_jacuzzi_ripple003", "apa_mp_apa_yacht_jacuzzi_ripple1",
    "apa_mp_apa_yacht_jacuzzi_ripple2", "apa_mp_apa_yacht_radar_01a", "apa_mp_apa_yacht_win",
    "prop_crashed_heli", "apa_mp_apa_yacht_door", "prop_shamal_crash", "xm_prop_x17_shamal_crash",
    "apa_mp_apa_yacht_door2", "apa_mp_apa_yacht", "prop_flagpole_2b", "prop_flagpole_2c",
    "prop_flag_canada", "apa_prop_yacht_float_1a", "apa_prop_yacht_float_1b", "apa_prop_yacht_glass_01",
    "apa_prop_yacht_glass_02", "apa_prop_yacht_glass_03", "prop_beach_fire", "prop_rock_4_big2",
    "prop_beachflag_le", "freight", "stt_prop_race_start_line_03b", "stt_prop_stunt_soccer_sball",
    "prop_cs_dildo_01", "prop_speaker_05", "prop_speaker_01", "prop_speaker_03", "surano",
    "ar_prop_ar_bblock_huge_01", "dt1_05_build1_damage", "prop_juicestand", "prop_knife",
    "p_bloodsplat_s", "p_spinning_anus_s", "dt1_lod_slod3", "prop_xmas_tree_int",
    "prop_cs_cardbox_01", "prop_alien_egg_01", "prop_tv_03", "prop_windmill_01_l1",
    "stt_prop_stunt_track_start", "stt_prop_stunt_track_start_02", "apa_prop_flag_mexico_yt",
    "apa_prop_flag_us_yt", "apa_prop_flag_uk_yt", "prop_jetski_ramp_01", "prop_const_fence03b_cr",
    "prop_fnclink_03gate5", "ind_prop_firework_01", "ind_prop_firework_02", "ind_prop_firework_03",
    "ind_prop_firework_04", "ind_prop_firework_box", "prop_weed_01", "xs_prop_hamburgher_wl",
    "prop_container_01a", "prop_contnr_pile_01a", "ce_xr_ctr2", "stt_prop_ramp_jump_xxl",
    "hei_prop_carrier_jet", "prop_parking_hut_2", "csx_seabed_rock3_", "db_apart_03_",
    "db_apart_09_", "sr_prop_spec_tube_xxs_01a", "p_tram_crash_s", "prop_fnclink_03a",
    "prop_fnclink_05crnr1", "xs_prop_plastic_bottle_wl", "prop_windmill_01", "prop_gold_cont_01",
    "p_cablecar_s", "prop_ferris_car_01", "p_ferris_car_01", "stt_prop_ramp_spiral_l",
    "stt_prop_ramp_spiral_l_l", "stt_prop_ramp_multi_loop_rb", "stt_prop_ramp_spiral_l_xxl",
    "stt_prop_ramp_spiral_xxl", "stt_prop_stunt_bblock_huge_01", "stt_prop_stunt_bblock_huge_02",
    "stt_prop_stunt_bblock_huge_03", "stt_prop_stunt_bblock_huge_04", "stt_prop_stunt_bblock_huge_05",
    "stt_prop_stunt_bblock_hump_01", "stt_prop_stunt_bblock_qp", "stt_prop_stunt_bblock_qp2",
    "stt_prop_stunt_jump_loop", "stt_prop_stunt_landing_zone_01", "stt_prop_stunt_track_dwslope45",
    "stt_prop_stunt_track_dwturn", "stt_prop_stunt_track_dwslope30", "stt_prop_stunt_track_dwsh15",
    "stt_prop_stunt_track_dwshort", "stt_prop_stunt_track_dwslope15", "stt_prop_stunt_track_exshort",
    "stt_prop_stunt_track_fork", "stt_prop_stunt_track_funlng", "stt_prop_stunt_track_funnel",
    "stt_prop_stunt_track_hill", "stt_prop_stunt_track_slope15", "stt_prop_stunt_track_slope30",
    "stt_prop_stunt_track_slope45", "prop_gas_pump_1a", "prop_gas_pump_1b", "prop_gas_pump_1c",
    "prop_vintage_pump", "prop_gas_pump_old2", "prop_gas_pump_old3", "apa_mp_h_acc_box_trinket_01",
    "prop_roundbailer02", "prop_roundbailer01", "prop_container_05a", "stt_prop_stunt_bowling_ball",
    "apa_mp_h_acc_rugwoolm_03", "prop_container_ld2", "p_ld_stinger_s", "hei_prop_carrier_cargo_02a",
    "prop_steps_big_01", "v_ilev_lest_bigscreen", "prop_carcreeper", "apa_mp_h_bed_double_09",
    "apa_mp_h_bed_wide_05", "prop_cattlecrush", "prop_cs_documents_01", "prop_construcionlamp_01",
    "prop_fncconstruc_01d", "prop_fncconstruc_02a", "p_dock_crane_cabl_s", "prop_dock_crane_01",
    "prop_dock_crane_02_cab", "prop_dock_float_1", "prop_dock_crane_lift", "apa_mp_h_bed_double_08",
    "csx_seabed_bldr4_", "imp_prop_impexp_sofabed_01a", "cs4_lod_04_slod2", "po1_lod_slod4",
    "id2_lod_slod4", "ap1_lod_slod4", "sm_lod_slod2_22", "prop_gas_tank_01a", "p_crahsed_heli_s",
    "prop_gascyl_01a", "prop_ld_toilet_01", "prop_ld_bomb_anim", "prop_ld_farm_couch01",
    "stt_prop_stunt_track_uturn", "stt_prop_stunt_tube_l", "stt_prop_stunt_tube_m",
    "stt_prop_stunt_tube_qg", "stt_prop_stunt_tube_s", "stt_prop_stunt_tube_jmp2",
    "stt_prop_stunt_track_turnice"
}

Config.BlacklistedVehicles = {
    "rhino", "hydra", "lazer", "buzzard", "buzzard2", "savage",
    "annihilator", "valkyrie", "akula", "hunter",
    "jet", "besra", "molotok", "pyro", "starling",
    "nokota", "rogue", "alphaz1", "howard", "microlight",
    "cargobob", "cargobob2", "cargobob3", "cargobob4",
    "kosatka", "submersible", "submersible2", "tug",
    "apc", "oppressor", "oppressor2", "khanjali",
    "insurgent", "insurgent2", "insurgent3",
    "technical", "technical2", "technical3", "halftrack",
    "cerberus", "cerberus2", "cerberus3",
    "bruiser", "bruiser2", "bruiser3",
    "dominator4", "dominator5", "dominator6",
    "dukes2", "blazer5", "stromberg", "deluxo", "ruiner2",
    "volatol", "strikeforce",
    "phantom2", "hauler2", "dump", "handler"
}

Config.BlacklistedPeds = {
    "s_m_y_swat_01", "s_m_y_hwaycop_01", "s_m_y_marine_01", "s_m_y_marine_02", "s_m_y_marine_03",
    "csb_mweather", "g_m_m_chicold_01", "g_m_m_chigoon_01", "u_m_y_zombie_01",
    "a_c_boar", "a_c_sharkhammer", "a_c_sharktiger", "a_c_humpback", "a_c_killerwhale", "a_c_cat_01",
    "a_c_chop", "a_c_coyote", "a_c_crow", "a_c_deer", "a_c_dog_01", "a_c_dolphin", "a_c_fish",
    "a_c_hen", "a_c_husky", "a_c_monkey", "a_c_panther", "a_c_pig", "a_c_poodle", "a_c_pug",
    "a_c_rabbit_01", "a_c_rat", "a_c_retriever", "a_c_rhesus", "a_c_rottweiler", "a_c_seagull",
    "a_c_shepherd", "a_c_westy", "a_c_mtlion", "a_c_cow", "a_c_chimp", "ig_ramp_gang", "cs_orleans",
    "csb_ramp_hic", "csb_ramp_hipster", "csb_ramp_mex", "csb_ramp_marine", "csb_prolsec",
    "player_zero", "player_one", "player_two"
}

Config.WhiteListPeds = {
    "mp_f_freemode_01",
    "mp_m_freemode_01"
}

Config.EnablePedWhitelist = false

Config.BlacklistedWeapons = {
    "weapon_railgun", "weapon_minigun", "weapon_rpg",
    "weapon_hominglauncher", "weapon_grenadelauncher",
    "weapon_grenadelauncher_smoke", "weapon_firework",
    "weapon_raypistol", "weapon_raycarbine", "weapon_rayminigun",
    "weapon_stinger", "weapon_compactlauncher",
    "weapon_proxmine", "weapon_pipebomb"
}
