-- [VEX-INTERNAL-CORE: 0x9F4C2A-C9182049182]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

local VexShield = {
    resourceName = GetCurrentResourceName(),
    playerSpawned = false,
    BanToken = GlobalState.AS_BanToken,
    Config = (GlobalState.AS_ConfigKey and GlobalState[GlobalState.AS_ConfigKey]) or {
        Beta = {
            AntiUnisolatedInjection = true,
            IgnoredExecutionPatterns = {}
        }
    },
    serverId = GetPlayerServerId(PlayerId()),
    tonumber = tonumber,
    tostring = tostring,
    assert = assert,
    type = type,
    msgpack = msgpack.pack,
    print = print,
    Wait = Wait,
    CreateThread = CreateThread,
    TriggerServerEvent = TriggerServerEvent,
    TriggerEvent = TriggerEvent,
    Native = {},
    Lua = {},
    debug = {
        getinfo = debug.getinfo,
        executions = false,
        short_executions = false
    }
}

local protectedCfxNatives = {
    "PlayerPedId", "PlayerId", "GetPlayerPed", "GetPlayerServerId", "GetPlayerName",
    "GetCurrentPedWeapon", "GetSelectedPedWeapon", "GetBestPedWeapon", "IsPedArmed",
    "GetWeaponObjectFromPed", "IsAimCamActive", "HasPedGotWeapon", "GetEntityHeightAboveGround",
    "GetEntityCoords", "GetGroundZFor_3dCoord", "IsPedInAnyVehicle", "IsPedFalling",
    "IsGameplayCamRendering", "GetEntityModel", "IsEntityDead", "GetEntityHealth",
    "GetPedArmour", "IsPedSprinting", "IsPedWalking", "IsPedOnFoot", "GetEntitySpeed",
    "DoesEntityExist", "GetVehiclePedIsUsing", "GetPedInVehicleSeat", "IsPedDeadOrDying",
    "IsNuiFocused", "GetVehiclePedIsIn", "GetGameTimer", "IsDisabledControlPressed",
    "IsPauseMenuActive", "IsPedAPlayer", "IsPedSwimmingUnderWater", "IsPedSwimming",
    "GetPlayerSprintStaminaRemaining", "GetEntityAttachedTo", "GetGamePool", "IsPedOnVehicle",
    "IsPedJumping", "GetEntityMaxHealth", "GetPlayerInvincible", "GetPlayerInvincible_2",
    "GetEntityCanBeDamaged", "GetPedType", "IsPlayerFreeForAmbientTask", "IsPedRunningRagdollTask",
    "IsPedJumpingOutOfVehicle", "IsPedRunningMeleeTask", "IsPedDiving", "GetPedConfigFlag",
    "IsPedClimbing", "IsEntityInAir", "IsPedFalling", "NetworkIsInSpectatorMode",
    "GetVehicleTopSpeedModifier", "GetVehicleCheatPowerIncrease", "GetVehicleGravityAmount",
    "GetStateBagValue", "SetStateBagValue", "GetGameplayCamCoord", "GetGameplayCamRot", "GetHashKey",
}

for _, native in ipairs(protectedCfxNatives) do VexShield.Native[native] = _G[native] end
VexShield.Lua = { pairs = pairs, ipairs = ipairs, next = next, type = type, tonumber = tonumber, tostring = tostring, print = print, pcall = pcall, assert = assert }

local playerBagName = ("player:%d"):format(VexShield.serverId)
local SafeGetLocalPlayerState = function(key) return VexShield.Native.GetStateBagValue(playerBagName, key) end
local SafeSetLocalPlayerState = function(key, value, replicated)
    local payload = VexShield.msgpack(value)
    return VexShield.Native.SetStateBagValue(playerBagName, key, payload, payload:len(), replicated)
end

-- SHA256 Helper
local function sha256_simple(s)
    local h = 0x811c9dc5
    for i = 1, #s do h = ((h ~ s:byte(i)) * 0x01000193) & 0xffffffff end
    return string.format("%08x", h)
end

local whitelistedSources = {}
local blacklistedSources = { ["[string \"\"]"] = true }
local executionCache = {}
local activeLinesCache = {}
local fileContentCache = {}
local fileLinesCache = {}

local function VexShieldReportInjection(reason, severity)
    reason = tostring(reason or "Detected unknown native hook"):sub(1, 160)
    severity = tonumber(severity) or 1
    VexShield.TriggerServerEvent("VexShield:flagInjection", reason, severity)
end

local function getResourceAndFileNamesOfSource(source)
    if not source or source:sub(1, 1) ~= "@" then return nil, nil, true end
    local slashPos = source:find("/", 2, true)
    if not slashPos then return nil, nil, true end
    return source:sub(2, slashPos - 1), source:sub(slashPos + 1), false
end

local function getCachedFileLines(resourceName, fileName)
    local cacheKey = resourceName .. "/" .. fileName
    if fileLinesCache[cacheKey] then return fileLinesCache[cacheKey].lines, fileLinesCache[cacheKey].hasComments end
    local content = LoadResourceFile(resourceName, fileName)
    if not content then return nil, false end
    content = content:gsub("\r\n", "\n"):gsub("\r", "\n")
    local lines = {}
    local hasComments = false
    for line in content:gmatch("([^\n]*)\n?") do table.insert(lines, line) end
    fileLinesCache[cacheKey] = { lines = lines, hasComments = content:find("/*", 1, true) ~= nil }
    return lines, fileLinesCache[cacheKey].hasComments
end

local function doesLineContainString(resourceName, fileName, lineNumber, stringToFind)
    local lines, hasComments = getCachedFileLines(resourceName, fileName)
    if not lines or lineNumber > #lines then return nil, false end
    local line = lines[lineNumber]
    return line, line:find(stringToFind, 1, true) ~= nil
end

local function ValidateActiveLines(resourceName, info)
    local resource, fileName = getResourceAndFileNamesOfSource(info.short_src)
    if not resource or not fileName then return true end
    local lines, hasComments = getCachedFileLines(resource, fileName)
    if not lines or hasComments then return true end
    for lineNum = info.linedefined, info.lastlinedefined do
        local line = lines[lineNum]
        if line then
            local trimmedLine = line:match("^%s*(.-)%s*$") or ""
            local isActive = info.activelines and info.activelines[lineNum] or false
            if (trimmedLine == "" or trimmedLine:match("^%-%-")) and isActive then return false end
        end
    end
    return true
end

local function CheckIsValidExecution(resourceName, source, currentLine, funcName)
    local resource, fileName, loadCall = getResourceAndFileNamesOfSource(source)
    if loadCall or whitelistedSources[source] then return true end
    if not resource or not fileName then return false end
    local line, match = doesLineContainString(resource, fileName, currentLine, funcName)
    return match
end

local IsValidExecution = function(funcName, resourceName, stacks, additionalStacks, isFXAP)
    stacks = type(stacks) == "table" and stacks or {}
    additionalStacks = additionalStacks or 0
    local info = stacks[3 + additionalStacks] or {}
    local info2 = stacks[2 + additionalStacks] or {}

    local shortSrc = tostring(info.short_src or "")
    local fullSource = tostring(info.source or "")
    if whitelistedSources[shortSrc] or whitelistedSources[fullSource] then return true end
    if blacklistedSources[shortSrc] or blacklistedSources[fullSource] or shortSrc:find("%[string \"") then return false end
    if shortSrc:find("citizen:/", 1, true) then return true end
    if shortSrc == "?" then
        if fullSource == "=?" and info2.name and not isFXAP then return false end
        return true
    end
    
    if info.what == "Lua" and info.linedefined > 0 then
        if not ValidateActiveLines(resourceName, info) then return false end
        if not CheckIsValidExecution(resourceName, info.short_src, info.linedefined, "function") then return false end
        if not CheckIsValidExecution(resourceName, info.short_src, info.currentline, funcName) then return false end
    end

    if info.what == "main" and info.linedefined == 0 and info.currentline > 0 then
        if not CheckIsValidExecution(resourceName, info.short_src, info.currentline, funcName) then return false end
    end

    return true
end

exports("IsValidExecution", function(functionName, functionName2, stacks, additionalStacks, isFXAP)
    local resourceName = GetInvokingResource()
    local isValid = IsValidExecution(functionName, resourceName, stacks, additionalStacks, isFXAP)
    if not isValid and functionName2 then
        isValid = IsValidExecution(functionName2, resourceName, stacks, additionalStacks, isFXAP)
    end
    if not isValid then
        VexShieldReportInjection("Attempted illegal native call: " .. tostring(functionName), 2)
    end
    return isValid
end)

exports("AllowSource", function(source) whitelistedSources[source] = true end)

-- Advanced Monitoring Exports (for vexshield.js)
exports("hasTeleported", function() VexShieldReportInjection("Attempted to teleport via native hook", 2) end)
exports("hasChangedPedModel", function() VexShieldReportInjection("Attempted to change ped model via hook", 2) end)
exports("healthRefilled", function() VexShieldReportInjection("Attempted health manipulation via hook", 1) end)
exports("playerRevived", function() VexShieldReportInjection("Attempted revive via hook", 1) end)
exports("proofsEnabled", function(toggle) if toggle then VexShieldReportInjection("Attempted to enable entity proofs via hook", 2) end end)
exports("canBeDamaged", function(toggle) if not toggle then VexShieldReportInjection("Attempted to enable invincibility via hook", 1) end end)
exports("isInvincible", function(toggle) if toggle then VexShieldReportInjection("Attempted to enable invincibility via hook", 1) end end)
exports("isVisible", function(toggle) if not toggle then VexShieldReportInjection("Attempted to become invisible via hook", 1) end end)
exports("resettedStamina", function() VexShieldReportInjection("Attempted to bypass stamina limit via hook", 1) end)
exports("newTopSpeedModifier", function(val) if (tonumber(val) or 1.0) > 1.0 then VexShieldReportInjection("Attempted vehicle speed manipulation via hook", 1) end end)
exports("newCheatPowerIncrease", function(val) if (tonumber(val) or 1.0) > 1.0 then VexShieldReportInjection("Attempted vehicle torque manipulation via hook", 1) end end)
exports("newGravity", function(val) if (tonumber(val) or 9.8) ~= 9.8 then VexShieldReportInjection("Attempted vehicle gravity manipulation via hook", 1) end end)
exports("setNewDamage", function(weapon, mult) if (tonumber(mult) or 1.0) > 1.0 then VexShieldReportInjection("Attempted weapon damage manipulation via hook", 1) end end)
exports("hasAddedAmmo", function() VexShieldReportInjection("Attempted ammo manipulation via hook", 1) end)
local blacklistedMenuTextures = {
    ["eulen"] = true, ["redengine"] = true, ["ham"] = true, ["hamhacks"] = true,
    ["dopamine"] = true, ["lynxmenu"] = true, ["lynx"] = true, ["fallout"] = true,
    ["brutan"] = true, ["hydromenu"] = true, ["hydro"] = true, ["tzx"] = true,
    ["darkside"] = true, ["darksiders"] = true, ["hangar"] = true, ["skript"] = true,
    ["sugar"] = true, ["executor"] = true, ["warmenu"] = true, ["alien"] = true,
    ["hacker"] = true, ["nexus"] = true, ["desudo"] = true, ["2take1"] = true,
    ["tiago"] = true, ["plane"] = true, ["absolute"] = true, ["crown"] = true,
    ["reaper"] = true, ["swag"] = true, ["fendin"] = true, ["alphav"] = true
}

local blacklistedCrashModels = {
    [GetHashKey("prop_fnclink_05crnr1")] = true,
    [GetHashKey("prop_gold_cont_01")] = true,
    [GetHashKey("p_ld_stinger_s")] = true,
    [GetHashKey("stt_prop_ramp_jump_l")] = true,
    [GetHashKey("prop_beach_fire")] = true,
    [GetHashKey("cargoplane")] = true,
    [GetHashKey("blimp")] = true,
    [GetHashKey("blimp2")] = true,
    [GetHashKey("blimp3")] = true,
    [GetHashKey("rhino")] = true,
    [GetHashKey("submersible")] = true,
    [GetHashKey("submersible2")] = true,
}

local trustedInventoryResources = {
    ["qb-core"] = true, ["qb-inventory"] = true, ["qs-inventory"] = true,
    ["ox_inventory"] = true, ["es_extended"] = true, ["esx_policejob"] = true,
    ["esx_weaponshop"] = true, ["core_inventory"] = true, ["mf-inventory"] = true
}

exports("disableE2", function()
    local invoker = GetInvokingResource()
    if not invoker and not IsNuiFocused() and not IsPauseMenuActive() then
        VexShieldReportInjection("Attempted unauthorized cursor manipulation", 1)
    end
end)

exports("disableAllControls", function()
    local invoker = GetInvokingResource()
    if not invoker and not IsNuiFocused() and not IsPauseMenuActive() then
        VexShieldReportInjection("Attempted unauthorized control lock", 1)
    end
end)

exports("disableCamControls", function()
    local ped = PlayerPedId()
    if DoesEntityExist(ped) and not IsPedInAnyVehicle(ped, false) and GetEntitySpeed(ped) > 1.5 then
        if not IsNuiFocused() and not IsPauseMenuActive() and not NetworkIsInSpectatorMode() then
            VexShieldReportInjection("Attempted camera freeze / freecam manipulation", 1)
        end
    end
end)

exports("allowTexture", function(dict)
    if type(dict) == "string" then
        local lowerDict = dict:lower()
        for pattern in pairs(blacklistedMenuTextures) do
            if lowerDict:find(pattern, 1, true) then
                VexShieldReportInjection("Detected blacklisted cheat menu texture: " .. dict, 2)
                return
            end
        end
    end
end)

exports("giveWeapon", function(hash)
    local invoker = GetInvokingResource()
    if invoker and trustedInventoryResources[invoker:lower()] then return end
    VexShieldReportInjection("Attempted weapon spawn via hook: " .. tostring(hash), 2)
end)

exports("removeAllWeapons", function()
    local invoker = GetInvokingResource()
    if invoker and trustedInventoryResources[invoker:lower()] then return end
    VexShieldReportInjection("Attempted weapon stripping via hook", 2)
end)

exports("removeWeapon", function(hash)
    local invoker = GetInvokingResource()
    if invoker and trustedInventoryResources[invoker:lower()] then return end
    VexShieldReportInjection("Attempted weapon removal via hook: " .. tostring(hash), 1)
end)

exports("CreateObject", function(model)
    local m = tonumber(model) or (type(model) == "string" and GetHashKey(model)) or 0
    if blacklistedCrashModels[m] then
        VexShieldReportInjection("Attempted crash/cage object spawn via hook: " .. tostring(model), 2)
        return
    end
    local invoker = GetInvokingResource()
    if not invoker then
        VexShieldReportInjection("Attempted unauthorized object creation from unknown caller", 2)
    end
end)

exports("CreateVehicle", function(model)
    local m = tonumber(model) or (type(model) == "string" and GetHashKey(model)) or 0
    if blacklistedCrashModels[m] then
        VexShieldReportInjection("Attempted blacklisted vehicle spawn via hook: " .. tostring(model), 2)
        return
    end
    local invoker = GetInvokingResource()
    if not invoker then
        VexShieldReportInjection("Attempted unauthorized vehicle creation from unknown caller", 2)
    end
end)

exports("CreatePed", function(model)
    local invoker = GetInvokingResource()
    if not invoker then
        VexShieldReportInjection("Attempted unauthorized ped creation from unknown caller", 2)
    end
end)

exports("ChangeVehiclePlate", function(veh, text)
    local invoker = GetInvokingResource()
    if not invoker then
        VexShieldReportInjection("Attempted vehicle plate manipulation via hook", 1)
    end
end)
