-- ============================================
-- VexShield AntiCheat - Complete Dashboard Integration
-- Version: Beta
-- ============================================
-- =============================================================================
-- CONFIGURATION
-- =============================================================================

-- Public dashboard API when no direct base is set
local PUBLIC_API_BASE = "https://vexshield.site"

function resolveConnectionApiOrigin()
    local b = GetConvar("vexshield_api_base", GetConvar("VexShield_api_base", ""))
    if b and b ~= "" then return (b:gsub("/$", "")) end
    if Config and Config.LicenseApiDirectBase and Config.LicenseApiDirectBase ~= "" then
        return (Config.LicenseApiDirectBase:gsub("/$", ""))
    end
    if type(VexShield_ConnectionApiBase) == "string" and VexShield_ConnectionApiBase ~= "" then
        return VexShield_ConnectionApiBase:gsub("/$", "")
    end
    return nil
end

local _connectionOrigin = resolveConnectionApiOrigin()
local API_BASE = _connectionOrigin or PUBLIC_API_BASE

function refreshApiEndpoints()
    local origin = resolveConnectionApiOrigin()
    if origin and origin ~= "" then
        _connectionOrigin = origin
        API_BASE = origin
    else
        API_BASE = PUBLIC_API_BASE
    end
    API_URL = API_BASE .. "/api/report.js"
    MONITORING_API = API_BASE .. "/api/functions/live-monitoring"
    BLACKLIST_API = API_BASE .. "/api/functions/blacklisted-servers"
    BLACKLIST_SYNC_API = API_BASE .. "/api/functions/sync-discord-guilds"
    if Config and Config.LicenseKey and Config.LicenseKey ~= "" and (not LICENSE_KEY or LICENSE_KEY == "") then
        LICENSE_KEY = Config.LicenseKey
    end
end

function licenseApiOrigin()
    return _connectionOrigin or ""
end
local LICENSE_PATH = "/api/v1/verification/config/hard-link-server-verification-lvkWoc9AgIxFoWLTc8hCC52AOMB3ZhPkZRvQFsg.json"
local API_URL = API_BASE .. "/api/report.js"
local BLACKLIST_API = API_BASE .. "/api/functions/blacklisted-servers"
local BLACKLIST_SYNC_API = API_BASE .. "/api/functions/sync-discord-guilds"
-- Global ban list (public JSON: entries[].identifiers + banDetails)
local GLOBAL_STATE_PATH = "/api/public/global-blacklist.json"

local SERVER_IP = GetConvar("vexshield_server_ip", GetConvar("VexShield_server_ip", ""))
if not SERVER_IP or SERVER_IP == "" then
    SERVER_IP = "127.0.0.1"
end
local LICENSE_KEY = GetConvar("vexshield_license_key", GetConvar("VexShield_license_key", ""))
if LICENSE_KEY == "" and Config and Config.LicenseKey and Config.LicenseKey ~= "" then
    LICENSE_KEY = Config.LicenseKey
end
-- Canonical server_id from dashboard (VexShield-xxxx / ASHLD-xxxx).
local SERVER_ID = GetConvar("vexshield_server_id", GetConvar("VexShield_server_id", ""))
if (not SERVER_ID or SERVER_ID == "") and Config and Config.ServerId and Config.ServerId ~= "" then
    SERVER_ID = Config.ServerId
end
if not SERVER_ID or SERVER_ID == "" then
    SERVER_ID = nil
end

-- Paths to anticheat files (relative to resource root)
local RESOURCE_NAME = GetCurrentResourceName()
local LOGS_FILE = "html/logs.json"
local BANS_FILE = "html/ban.json"  -- ban.json is the SOURCE OF TRUTH
local BLACKLIST_BLOCK_FILE = "html/blacklist_block.json"
local CONFIG_FILE = "vex_config.lua"
local isApplyingDashboardSettings = false
local isSavingConfigFile = false

-- Intervals (in ms)
local SNAPSHOT_INTERVAL = 15000      -- 15 seconds (join/drop also push immediately)
local CONSOLE_FLUSH_INTERVAL = 5000  -- 5 seconds
local COMMAND_POLL_INTERVAL = 500   -- 500ms: faster kick/ban/live-stream command delivery
local ADMIN_JSON_POLL_MIN_MS = 2500 -- apply admin_json from poll at most every 2.5s
local ADMIN_JSON_SETTINGS_FETCH_MIN_MS = 5000 -- fallback pull when poll response omits admin_json
local LOGS_SYNC_INTERVAL = 10000     -- 10 seconds
local BANS_SYNC_INTERVAL = 90000     -- backup only; ban/unban always sync immediately (forceFull)
local SETTINGS_SYNC_INTERVAL = 60000 -- 60 seconds
local RESOURCE_SYNC_INTERVAL = 60000 -- 60 seconds (slower to reduce load)
local MONITORING_POLL_INTERVAL = 2500 -- list active streams (Live Monitoring)
-- Increase frame interval to reduce client FPS impact
local MONITORING_FRAME_INTERVAL = 3500 -- between frame captures per monitored player

-- Live Monitoring API
local MONITORING_API = API_BASE .. "/api/functions/live-monitoring"

-- Blacklisted Discord Servers cache
local blacklistedServersCache = {}
local lastBlacklistFetch = 0
local BLACKLIST_CACHE_INTERVAL = 300 -- 5 minutes

-- Global blacklist from /api/public/global-blacklist.json
local globalBanDiscordSet = {} -- [discord_id string] = meta table
local globalBanLicenseSet = {} -- [normalized license hex] = meta table
local globalBanSteamSet = {} -- [steam hex without prefix] = meta table
-- Updated when any global-ban HTTP attempt finishes (success or all URLs failed)
local lastGlobalBanSnapshotAt = 0
local GLOBAL_BAN_CACHE_INTERVAL = 600 -- seconds; refresh global blacklist every 10 minutes
local CONNECT_BLACKLIST_MAX_WAIT_MS = 2500 -- max blocking wait per HTTP step on player connect
local globalBanFetchInProgress = false
local GLOBAL_BLACKLIST_LOGO = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless"
local GLOBAL_BLACKLIST_TICKET_URL = "https://discord.gg/5WgtMWbtgD"

-- Limits
local MAX_BATCH = 200
local MAX_QUEUE = 5000

local BLOCKED_DASHBOARD_IPS = { ["144.91.69.111"] = true }

function isUsableServerIP(ip)
    if not ip or ip == "" or ip == "Onbekend" then return false end
    return not BLOCKED_DASHBOARD_IPS[ip]
end

-- =============================================================================
-- STATE
-- =============================================================================

-- Dashboard HTTP (report / poll_commands) is validated by POST body (license_key + server_ip).
-- Do not gate on GET license JSON success or snapshots and commands stay empty forever.
local dashboardSyncWasReady = false

function canSyncDashboard()
    local cvIp = GetConvar("VexShield_server_ip", "")
    if isUsableServerIP(cvIp) then
        SERVER_IP = cvIp
    elseif not isUsableServerIP(SERVER_IP) then
        SERVER_IP = "127.0.0.1"
    end
    local cvLic = GetConvar("VexShield_license_key", "")
    if cvLic and cvLic ~= "" then
        LICENSE_KEY = cvLic
    elseif (not LICENSE_KEY or LICENSE_KEY == "") and Config and Config.LicenseKey then
        LICENSE_KEY = Config.LicenseKey
    end
    return LICENSE_KEY and LICENSE_KEY ~= "" and isUsableServerIP(SERVER_IP)
end
local consoleQueue = {}
local sendingConsole = false
local lastSnapshotString = nil
local banList = {}
local lastSyncedBanFingerprint = nil
local lastBanListFingerprint = nil
local lastLogsSyncId = 0
local resourceSyncPending = false
local lastResourceSyncTime = 0

-- Live monitoring state
local monitoredPlayers = {}  -- { [playerId] = true }
local activeStreamPlayers = {} -- { [playerId] = true }
local lastMonitoringCheck = 0
local lastFrameRequestAt = {} -- { [playerId] = os.time() }
local screenshotResourceStarted = nil
local pendingBlacklistBans = {} -- { [playerId] = true }
local blacklistBlockEnabled = true -- dashboard: settings.blacklist_block_enabled

-- =============================================================================
-- ASYNC IP RESOLUTION (fallback when convar/Config don't provide SERVER_IP)
-- =============================================================================

function resolveServerIPAsync(callback)
    -- Priority 1: convar (set by main.lua after license check)
    local cvIp = GetConvar("VexShield_server_ip", "")
    if isUsableServerIP(cvIp) then
        callback(cvIp)
        return
    end

    -- Priority 2: public IP via ipify (never use API/dashboard host as game server IP)
    PerformHttpRequest("https://api.ipify.org?format=json", function(status, response)
        if status == 200 and response and response ~= "" then
            local ok, data = pcall(json.decode, response)
            if ok and data and data.ip and data.ip ~= "" then
                callback(data.ip)
                return
            end
        end
        callback(nil)
    end, "GET", "")
end

-- =============================================================================
-- VALIDATE CONFIGURATION
-- =============================================================================

if not LICENSE_KEY or LICENSE_KEY == "" then
    print("^1[VexShield] site.lua: LICENSE_KEY not found. Set VexShield_license_key convar or Config.LicenseKey.^0")
    return
end

-- =============================================================================
-- DEFERRAL CARDS LIBRARY
-- =============================================================================

local DeferralCards = {
    Card = {},
    CardElement = {},
    Container = {},
    Action = {},
    Input = {}
}

function DeferralCards.Card.Create(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'AdaptiveCard'
    pOptions.version = pOptions.version or '1.4'
    pOptions.body = pOptions.body or {}
    pOptions['$schema'] = 'http://adaptivecards.io/schemas/adaptive-card.json'
    if json and type(json.encode) == "function" then
        local ok, encoded = pcall(json.encode, pOptions)
        if ok and type(encoded) == "string" then return encoded end
    end
    return "{}"
end

function DeferralCards.CardElement.TextBlock(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'TextBlock'
    pOptions.text = pOptions.text or 'Text'
    return pOptions
end

function DeferralCards.CardElement.Image(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Image'
    pOptions.url = pOptions.url or 'https://via.placeholder.com/100x100?text=Temp+Image'
    return pOptions
end

function DeferralCards.Container.Create(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Container'
    pOptions.items = pOptions.items or {}
    return pOptions
end

function DeferralCards.Container.ActionSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'ActionSet'
    pOptions.actions = pOptions.actions or {}
    return pOptions
end

function DeferralCards.Container.ColumnSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'ColumnSet'
    pOptions.columns = pOptions.columns or {}
    return pOptions
end

function DeferralCards.Container.Column(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Column'
    pOptions.items = pOptions.items or {}
    return pOptions
end

function DeferralCards.Action.OpenUrl(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Action.OpenUrl'
    pOptions.url = pOptions.url or 'https://www.google.co.uk/'
    return pOptions
end

function DeferralCards.Container.Fact(self, pOptions)
    if not pOptions then return end
    pOptions.title = pOptions.title or 'Title'
    pOptions.value = pOptions.value or 'Value'
    return pOptions
end

function DeferralCards.Container.FactSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'FactSet'
    pOptions.facts = pOptions.facts or {}
    return pOptions
end

-- =============================================================================
-- UTILITY FUNCTIONS
-- =============================================================================

function readFile(file)
    local content = LoadResourceFile(RESOURCE_NAME, file)
    if not content or content == "" then
        local base = GetResourcePath(RESOURCE_NAME)
        if base and base ~= "" then
            local path = base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/" .. file
            local f = io.open(path, "r")
            if f then
                content = f:read("*a")
                f:close()
            end
        end
    end
    return content
end

function writeFile(file, content)
    local ok = SaveResourceFile(RESOURCE_NAME, file, content, -1)
    if not ok then
        local base = GetResourcePath(RESOURCE_NAME)
        if base and base ~= "" then
            local path = base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/" .. file
            local f = io.open(path, "w+b")
            if f then
                f:write(content)
                f:close()
                ok = true
            end
        end
    end
    return ok
end

-- ban.json: LoadResourceFile can return a stale/empty view right after main.lua SaveResourceFile.
-- Prefer the on-disk file under GetResourcePath so sync never wipes bans or the dashboard.
function banJsonAbsolutePath()
    local base = GetResourcePath(RESOURCE_NAME)
    if not base or base == "" then return nil end
    return base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/html/ban.json"
end

function readBanJsonDisk()
    local path = banJsonAbsolutePath()
    if path then
        local f = io.open(path, "r")
        if f then
            local c = f:read("*a")
            f:close()
            if c and c:match("%S") then return c end
        end
    end
    return LoadResourceFile(RESOURCE_NAME, BANS_FILE)
end

function writeBanJsonFile(content, forceEmpty)
    if not content or content == "" then return end
    -- Never replace a real ban list with [] (race after main.lua SaveBans, or failed json.encode)
    local trim = (content:gsub("^%s+", ""):gsub("%s+$", ""))
    if not forceEmpty and #trim <= 2 and (trim == "[]" or trim == "{}") then
        local pchk = banJsonAbsolutePath()
        if pchk then
            local rf = io.open(pchk, "r")
            if rf then
                local existing = rf:read("*a") or ""
                rf:close()
                if #existing > 48 then
                    return
                end
            end
        end
    end
    SaveResourceFile(RESOURCE_NAME, BANS_FILE, content, -1)
    local path = banJsonAbsolutePath()
    if path then
        local wf = io.open(path, "w")
        if wf then
            wf:write(content)
            wf:close()
        end
    end
end

local ADMIN_JSON_FILE = "html/admin.json"

function adminJsonAbsolutePath()
    local base = GetResourcePath(RESOURCE_NAME)
    if not base or base == "" then return nil end
    return base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/html/admin.json"
end

-- SaveResourceFile alone can leave LoadResourceFile stale; mirror ban.json dual-write.
function writeAdminJsonFile(content)
    if not content or content == "" then return end
    SaveResourceFile(RESOURCE_NAME, ADMIN_JSON_FILE, content, -1)
    local path = adminJsonAbsolutePath()
    if path then
        local wf = io.open(path, "w")
        if wf then
            wf:write(content)
            wf:close()
        end
    end
end

function readAdminJsonFile()
    local content = nil
    local path = adminJsonAbsolutePath()
    if path then
        local f = io.open(path, "r")
        if f then
            content = f:read("*a")
            f:close()
        end
    end
    if not content or content == "" then
        content = LoadResourceFile(RESOURCE_NAME, ADMIN_JSON_FILE)
    end
    if content and content:match("%S") then
        return content
    end
    return nil
end

function jsonDecode(str)
    if not str or str == "" then return nil end
    if not json or type(json.decode) ~= "function" then return nil end
    local ok, result = pcall(json.decode, str)
    if ok then return result end
    return nil
end

function jsonEncode(tbl)
    if not json or type(json.encode) ~= "function" then return nil end
    local ok, result = pcall(json.encode, tbl)
    if ok and type(result) == "string" then return result end
    return nil
end

function jsonEncodeOrFallback(tbl, fallback)
    local s = jsonEncode(tbl)
    if s then return s end
    return fallback or "{}"
end

local lastSyncedAdminJsonFingerprint = nil
local lastAdminJsonPollApplyAt = 0
local lastAdminJsonSettingsFetchAt = 0
local syncSettingsToDashboard

function normalizeAdminJsonIdentifier(value)
    if not value or value == "" then return nil end
    local s = tostring(value):gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", ""):lower()
    if s == "" then return nil end
    if s:match("^%d+$") then return "discord:" .. s end
    if s:match("^discord:%d+$") then return s end
    if s:match("^license:.+") or s:match("^license2:.+") or s:match("^steam:.+") or s:match("^fivem:.+") or s:match("^xbl:.+") or s:match("^live:.+") then
        return s
    end
    if s:match("^[a-f0-9]+$") and #s >= 32 and #s <= 64 then
        return "license:" .. s
    end
    return nil
end

function collectAdminJsonIds(list)
    local out = {}
    if type(list) ~= "table" then return out end
    for _, entry in ipairs(list) do
        local id
        if type(entry) == "table" then
            id = normalizeAdminJsonIdentifier(entry.identifier or entry.discordId or entry.discord_id or entry.id)
        else
            id = normalizeAdminJsonIdentifier(entry)
        end
        if id then
            out[#out + 1] = id
        end
    end
    table.sort(out)
    return out
end

function collectScopedAdminJsonEntries(list)
    local out = {}
    if type(list) ~= "table" then return out end
    for _, entry in ipairs(list) do
        if type(entry) == "table" then
            local id = normalizeAdminJsonIdentifier(entry.identifier or entry.discordId or entry.discord_id or entry.id)
            if id then
                local bypass = {}
                if type(entry.bypass) == "table" then
                    for _, permission in ipairs(entry.bypass) do
                        bypass[#bypass + 1] = tostring(permission)
                    end
                end
                table.sort(bypass)
                local access = {}
                if type(entry.access) == "table" then
                    for _, permission in ipairs(entry.access) do
                        access[#access + 1] = tostring(permission)
                    end
                end
                table.sort(access)
                out[#out + 1] = id .. ":b=" .. table.concat(bypass, ",") .. ":a=" .. table.concat(access, ",")
            end
        end
    end
    table.sort(out)
    return out
end

function adminJsonFingerprint(adminJson)
    if type(adminJson) == "string" then
        adminJson = jsonDecode(adminJson) or {}
    end
    if type(adminJson) ~= "table" then return "" end
    local admins = collectScopedAdminJsonEntries(adminJson.admins or adminJson.Admins)
    local menu = collectAdminJsonIds(adminJson.VexMenu)
    return table.concat(admins, ";") .. "|" .. table.concat(menu, ",")
end

function applyAdminJsonFromDashboard(adminJson, opts)
    opts = opts or {}
    if type(adminJson) == "string" then
        adminJson = jsonDecode(adminJson) or {}
    end
    if type(adminJson) ~= "table" then return false end
    local fp = adminJsonFingerprint(adminJson)
    if fp == lastSyncedAdminJsonFingerprint then return false end
    -- Ignore stale empty payloads so old queued commands cannot wipe a valid list.
    if fp == "|" and opts.allowEmpty ~= true and lastSyncedAdminJsonFingerprint and lastSyncedAdminJsonFingerprint ~= "|" then
        return false
    end
    local encoded = jsonEncodeOrFallback(adminJson, "")
    if encoded == "" then return false end
    writeAdminJsonFile(encoded)
    lastSyncedAdminJsonFingerprint = fp
    print(("^2[VexShield]^7 admin.json synced from dashboard (%s)^0"):format(fp ~= "" and fp or "empty"))
    if type(ReloadAdminJsonLists) == "function" then
        ReloadAdminJsonLists(true)
    end
    if opts.syncDashboard == true and type(syncSettingsToDashboard) == "function" then
        CreateThread(function()
            Wait(0)
            syncSettingsToDashboard()
        end)
    end
    return true
end

function loadBlacklistBlockFromFile()
    local content = readFile(BLACKLIST_BLOCK_FILE)
    if not content or not content:match("%S") then return end
    local data = jsonDecode(content)
    if type(data) == "table" and data.enabled ~= nil then
        blacklistBlockEnabled = data.enabled ~= false
    end
end

function persistBlacklistBlockToFile()
    writeFile(BLACKLIST_BLOCK_FILE, jsonEncodeOrFallback({ enabled = blacklistBlockEnabled }, '{"enabled":true}'))
    return true
end

function applyBlacklistBlockToggle(enabled)
    if enabled == nil then return false end
    blacklistBlockEnabled = enabled ~= false
    CreateThread(function()
        Wait(0)
        persistBlacklistBlockToFile()
    end)
    return true
end

function escapeLuaPattern(s)
    return (tostring(s):gsub("([%(%)%.%+%-%*%?%[%]%^%$%%])", "%%%1"))
end

function collectPlayerIdentifiers(src)
    local raw = {}
    local pid = tonumber(src)
    if pid and pid > 0 then
        local ok, ids = pcall(GetPlayerIdentifiers, pid)
        if ok and type(ids) == "table" then
            raw = ids
        end
    end

    local info = {
        raw = raw,
        license = nil,
        license2 = nil,
        discord = nil,
        steam = nil,
        fivem = nil,
        xbl = nil
    }

    for _, id in ipairs(info.raw) do
        if id:match("^license:") then
            if not info.license then
                info.license = id
            else
                info.license2 = info.license2 or id
            end
        elseif id:match("^license2:") then
            info.license2 = id
        elseif id:match("^discord:") then
            info.discord = id
        elseif id:match("^steam:") then
            info.steam = id
        elseif id:match("^fivem:") then
            info.fivem = id
        elseif id:match("^xbl:") then
            info.xbl = id
        end
    end

    return info
end

function buildIdentifierSet(info)
    local set = {}
    local function add(value)
        if value and value ~= "" then
            set[tostring(value)] = true
        end
    end

    add(info.license)
    add(info.license2)
    add(info.discord)
    add(info.steam)
    add(info.fivem)
    add(info.xbl)
    if info.discord then add(info.discord:gsub("^discord:", "")) end
    if info.license then add(info.license:gsub("^license:", "")) end
    if info.license2 then add(info.license2:gsub("^license2:", "")) end

    return set
end

function identifierMatchesSet(value, idSet)
    if not value or value == "" then return false end
    local str = tostring(value)
    if idSet[str] then return true end
    if str:match("^discord:") and idSet[str:gsub("^discord:", "")] then return true end
    if str:match("^license:") and idSet[str:gsub("^license:", "")] then return true end
    if str:match("^license2:") and idSet[str:gsub("^license2:", "")] then return true end
    return false
end

function isEphemeralPlayerSourceId(value)
    local s = tostring(value or "")
    return s ~= "" and s:match("^%d+$") ~= nil
end

function clearBanListKeysForBan(ban)
    if not ban then return end
    local keys = {
        ban.license or ban.LICENSE,
        ban.license2 or ban.LICENSE2,
        ban.player_id,
        ban.discord,
        ban.steam,
        ban.fivem,
        ban.xbl,
    }
    for _, key in ipairs(keys) do
        if key and tostring(key) ~= "" then
            banList[tostring(key)] = nil
            local dk = tostring(key):gsub("^discord:", "")
            if dk ~= tostring(key) then
                banList[dk] = nil
            end
        end
    end
end

function httpPost(url, data, cb)
    refreshApiEndpoints()
    local targetUrl = url
    if targetUrl == API_URL or string.find(tostring(targetUrl), "/api/functions/report") then
        targetUrl = API_URL
    end
    local payload = jsonEncodeOrFallback(data, "{}")
    PerformHttpRequest(targetUrl, function(status, response, headers)
        if cb then pcall(cb, status, response) end
    end, "POST", payload, { ["Content-Type"] = "application/json" })
end

function fetchAdminJsonFromDashboard(reason)
    if not canSyncDashboard() then return end
    httpPost(API_URL, {
        server_id = SERVER_ID,
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "get_settings"
    }, function(status, response)
        if status ~= 200 then return end
        local data = jsonDecode(response) or {}
        if data.server_id and tostring(data.server_id) ~= "" then
            SERVER_ID = tostring(data.server_id)
        end
        if data.admin_json then
            applyAdminJsonFromDashboard(data.admin_json, { allowEmpty = true })
        end
    end)
end

-- Entity enumerators
function EnumerateEntities(initFunc, moveFunc, disposeFunc)
    return coroutine.wrap(function()
        local handle, entity = initFunc()
        if entity == 0 then
            disposeFunc(handle)
            return
        end
        local ok = true
        repeat
            coroutine.yield(entity)
            ok, entity = moveFunc(handle)
        until not ok
        disposeFunc(handle)
    end)
end

function EnumerateVehicles()
    return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
end

function EnumeratePeds()
    return EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed)
end

function EnumerateObjects()
    return EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject)
end

-- =============================================================================
-- LICENSE VERIFICATION
-- =============================================================================

function collectSiteLicenseUrls()
    local seen = {}
    local urls = {}
    local function push(u)
        if type(u) ~= "string" or u == "" or seen[u] then return end
        seen[u] = true
        urls[#urls + 1] = u
    end
    -- Priority 1: Official VexShield Cloud API & Static JSON Verification
    push("https://vexshield.site/licenses-secret-x8f9v2m4p1q7z3w5.json")
    push("https://vexshield.site/api/db/servers")
    push("https://vexshield-website.vercel.app/licenses-secret-x8f9v2m4p1q7z3w5.json")
    push("https://vexshield-website.vercel.app/api/db/servers")

    local direct = licenseApiOrigin()
    if direct ~= "" then
        push(direct .. LICENSE_PATH)
        push(direct .. "/licenses-secret-x8f9v2m4p1q7z3w5.json")
        push(direct .. "/api/db/servers")
    end
    if Config and Config.LicenseVerifyUrl and Config.LicenseVerifyUrl ~= "" then
        push(Config.LicenseVerifyUrl)
    end
    local cv = GetConvar("VexShield_license_verify_url", "")
    if cv ~= "" then push(cv) end
    if Config and type(Config.LicenseVerifyFallbackUrls) == "table" then
        for _, u in ipairs(Config.LicenseVerifyFallbackUrls) do push(u) end
    end
    push("http://127.0.0.1:5001/licenses-secret-x8f9v2m4p1q7z3w5.json")
    push("http://localhost:5001/licenses-secret-x8f9v2m4p1q7z3w5.json")
    return urls
end

function verifyLicense(callback)
    if Config and Config.BypassLicense == true then
        callback(true)
        return
    end

    local urls = collectSiteLicenseUrls()
    local serverIpClean = tostring(SERVER_IP or ""):gsub(":%d+$", ""):gsub("^%s+", ""):gsub("%s+$", "")

    local function tryIndex(i)
        if i > #urls then
            callback(false)
            return
        end
        local url = urls[i]
        PerformHttpRequest(url, function(status, response)
            if status ~= 200 or not response or response == "" then
                tryIndex(i + 1)
                return
            end
            local servers = jsonDecode(response)
            if not servers or type(servers) ~= "table" then
                tryIndex(i + 1)
                return
            end
            local found = false
            for _, srv in ipairs(servers) do
                local srvIp = tostring(srv["server ip"] or srv.server_ip or "")
                local srvIpClean = srvIp:gsub(":%d+$", ""):gsub("^%s+", ""):gsub("%s+$", "")
                local srvLicense = tostring(srv["license"] or srv.license_key or "")
                local srvStatus = tostring(srv.status or "")
                
                local licMatches = (srvLicense ~= "" and srvLicense == LICENSE_KEY)
                local isNotRevoked = (srvStatus ~= "disabled" and srvStatus ~= "revoked")
                local ipMatches = (srvIpClean == "0.0.0.0" or srvIpClean == "*" or srvIpClean == "" or srvIpClean == serverIpClean or serverIpClean == "127.0.0.1" or serverIpClean == "localhost" or srvIpClean == "127.0.0.1" or srvIpClean == "localhost")

                if licMatches and isNotRevoked and ipMatches then
                    found = true
                    SERVER_ID = srv.server_id or srv["server id"] or srv["server_id"] or srv.id
                    break
                end
            end
            callback(found)
        end, "GET", "")
    end

    tryIndex(1)
end

-- =============================================================================
-- CONSOLE LOGGING
-- =============================================================================

-- Monotonic unique ts (GetGameTimer is ms; +seq avoids duplicate ts in same tick).
local consoleLogSeq = 0
function enqueueConsole(message)
    consoleLogSeq = consoleLogSeq + 1
    local base = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
    local ts = base + consoleLogSeq
    table.insert(consoleQueue, { ts = ts, message = tostring(message) })
    
    if #consoleQueue > MAX_QUEUE then
        local drop = #consoleQueue - MAX_QUEUE
        for i = 1, drop do table.remove(consoleQueue, 1) end
    end
end

-- Forward most Lua server console output to the dashboard (txAdmin-style feed is C++/Citizen; this captures Lua `print`).
function stripConsoleColorCodes(msg)
    return (tostring(msg):gsub("%^%d", ""):gsub("~[a-z]~", ""))
end

do
    local _origPrint = _G.print
    _G.print = function(...)
        local n = select("#", ...)
        local parts = {}
        for i = 1, n do
            parts[i] = tostring(select(i, ...))
        end
        local line = table.concat(parts, "\t")
        _origPrint(...)
        enqueueConsole(stripConsoleColorCodes(line))
    end
end

-- =============================================================================
-- PLAYERS SNAPSHOT
-- =============================================================================

function buildPlayersSnapshot()
    local list = {}
    for _, pid in ipairs(GetPlayers()) do
        local p = tonumber(pid)
        if not p or not GetPlayerName(p) then goto continue end
        local ped = GetPlayerPed(p)
        local coords = { x = 0.0, y = 0.0, z = 0.0 }
        if ped and ped ~= 0 then
            local c = GetEntityCoords(ped)
            coords = { x = c.x, y = c.y, z = c.z }
        end
        local identifiers = GetPlayerIdentifiers(p) or {}
        
        local license = "unknown"
        local rawIp = nil
        for _, id in ipairs(identifiers) do
            if id:match("^license:") then
                license = id
            elseif id:match("^ip:") then
                rawIp = id:sub(4) -- strip "ip:" prefix for clean display
            end
        end
        if not rawIp then
            local endpoint = GetPlayerEndpoint(p)
            if endpoint then
                local v4 = endpoint:match("(%d+%.%d+%.%d+%.%d+)")
                if v4 then rawIp = v4 end
            end
        end
        
        table.insert(list, {
            player_id = tostring(p),
            source = p,
            player_name = GetPlayerName(p) or "Unknown",
            ping = GetPlayerPing(p) or 0,
            coords = { x = coords.x, y = coords.y, z = coords.z },
            license = license,
            ip = rawIp,
            identifiers = identifiers
        })
        ::continue::
    end
    return list
end

function sendPlayersSnapshot(force)
    if not canSyncDashboard() then return end
    
    local snap = buildPlayersSnapshot()
    local sjson = jsonEncodeOrFallback(snap, "[]")

    -- Always send players_snapshot so dashboard updated_at stays fresh (heartbeat alone left stale rows).
    if not force and lastSnapshotString == sjson then
        httpPost(API_URL, {
            report_type = "players_snapshot",
            server_ip = SERVER_IP,
            license_key = LICENSE_KEY,
            snapshot = snap,
            total_players = #snap
        }, function() end)
        return
    end
    
    lastSnapshotString = sjson
    httpPost(API_URL, { 
        report_type = "players_snapshot", 
        server_ip = SERVER_IP, 
        license_key = LICENSE_KEY, 
        snapshot = snap,
        total_players = #snap
    }, function() end)
end

function queuePlayersSnapshot(force, delayMs)
    CreateThread(function()
        Wait(delayMs or (force and 250 or 0))
        sendPlayersSnapshot(force == true)
    end)
end

-- =============================================================================
-- CONSOLE LOGS FLUSH
-- =============================================================================

function flushConsoleBatch()
    if sendingConsole or #consoleQueue == 0 then return end
    if not canSyncDashboard() then return end
    
    sendingConsole = true
    local batchCount = math.min(MAX_BATCH, #consoleQueue)
    local batch = {}
    
    for i = 1, batchCount do 
        table.insert(batch, consoleQueue[i]) 
    end
    
    httpPost(API_URL, { 
        report_type = "console_logs", 
        server_ip = SERVER_IP, 
        license_key = LICENSE_KEY, 
        console_logs = batch 
    }, function(status)
        if status >= 200 and status < 300 then
            for i = 1, batchCount do 
                table.remove(consoleQueue, 1) 
            end
        end
        sendingConsole = false
    end)
end

-- =============================================================================
-- ACTIVITY LOGS SYNC (logs.json -> Activity Page)
-- =============================================================================

function syncActivityLogs()
    if not canSyncDashboard() then return end
    
    local content = readFile(LOGS_FILE)
    local logs = jsonDecode(content) or {}
    
    if #logs == 0 then return end
    
    -- Only sync logs with id > lastLogsSyncId
    local newLogs = {}
    local maxId = lastLogsSyncId
    
    for _, log in ipairs(logs) do
        local logId = log.id or 0
        if logId > lastLogsSyncId then
            table.insert(newLogs, log)
            if logId > maxId then maxId = logId end
        end
    end
    
    if #newLogs == 0 then return end
    
    httpPost(API_URL, {
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "sync_activity_logs",
        activity_logs = newLogs
    }, function(status)
        if status >= 200 and status < 300 then
            lastLogsSyncId = maxId
        end
    end)
end

-- =============================================================================
-- BANS SYNC - ban.json is the SINGLE SOURCE OF TRUTH
-- =============================================================================

function banJsonFingerprint(content)
    if not content or content == "" then return nil end
    local len = #content
    if len <= 128 then return tostring(len) .. ":" .. content end
    return tostring(len) .. ":" .. content:sub(1, 64) .. ":" .. content:sub(-64)
end

function countBanRows(bans)
    if type(bans) ~= "table" then return 0 end
    local n = 0
    for _ in ipairs(bans) do n = n + 1 end
    if n > 0 then return n end
    for _, ban in pairs(bans) do
        if type(ban) == "table" then n = n + 1 end
    end
    return n
end

function bansToArray(bans)
    local out = {}
    if type(bans) ~= "table" then return out end
    for i, ban in ipairs(bans) do
        out[i] = ban
    end
    if #out > 0 then return out end
    for _, ban in pairs(bans) do
        if type(ban) == "table" then
            out[#out + 1] = ban
        end
    end
    return out
end

function rebuildBanListFromBans(bans)
    banList = {}
    for _, ban in ipairs(bans) do
        local reason = ban.details or ban.reason or ban.REASON or "Banned"
        local banId = ban.id or ban.BANID or ban.ban_id
        local function addBanKey(key)
            if key and key ~= "" then
                banList[tostring(key)] = { reason = reason, banId = banId }
            end
        end

        addBanKey(ban.license or ban.LICENSE or "")
        addBanKey(ban.license2 or ban.LICENSE2 or "")
        if ban.player_id and not isEphemeralPlayerSourceId(ban.player_id) then
            addBanKey(ban.player_id)
        end
        addBanKey(ban.discord or "")
        addBanKey(ban.steam or "")
        addBanKey(ban.fivem or "")
        addBanKey(ban.xbl or "")
    end
end

function refreshBanListIfStale()
    local content = readBanJsonDisk()
    if not content or not content:match("%S") then return end
    local fingerprint = banJsonFingerprint(content)
    if fingerprint == lastBanListFingerprint and next(banList) then return end
    local bans = jsonDecode(content)
    if bans == nil or type(bans) ~= "table" then return end
    rebuildBanListFromBans(bans)
    lastBanListFingerprint = fingerprint
end

-- Send local bans (full state) to dashboard
-- This REPLACES all database bans with what's in ban.json
-- Database bans NOT in ban.json will be DELETED
function syncBansToSupabase(forceFull, allowEmpty)
    if not canSyncDashboard() then return end

    local content = readBanJsonDisk()
    if not content or not content:match("%S") then
        -- Stale/empty LoadResourceFile after SaveResourceFile would sync [] and wipe dashboard rows.
        return
    end
    local bans = jsonDecode(content)
    if bans == nil or type(bans) ~= "table" then
        -- Invalid JSON — do not replace dashboard state with an empty list.
        return
    end

    bans = bansToArray(bans)
    local banCount = countBanRows(bans)
    if banCount == 0 and not allowEmpty then
        -- Empty ban.json (or stale read) must not wipe dashboard bans.
        return
    end

    local fingerprint = banJsonFingerprint(content)
    rebuildBanListFromBans(bans)
    lastBanListFingerprint = fingerprint

    if not forceFull and fingerprint == lastSyncedBanFingerprint then
        return
    end

    -- IMPORTANT: Send the FULL state to dashboard
    -- Dashboard will DELETE any bans not in this list when replace_all is set
    httpPost(API_URL, {
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "sync_bans_from_anticheat",
        bans = bans,
        replace_all = true
    }, function(status)
        if status >= 200 and status < 300 then
            lastSyncedBanFingerprint = fingerprint
        end
    end)
end

AddEventHandler('VexShield:DashboardRequestBanSync', function()
    lastSyncedBanFingerprint = nil
    CreateThread(function()
        syncBansToSupabase(true)
        Wait(750)
        syncBansToSupabase(true)
    end)
end)

-- For edits: never treat a stale empty read as []. Re-read file; if missing or empty, start from [].
function readBanJsonForMutation()
    local c = readBanJsonDisk()
    if c and c:match("%S") then return c end
    local path = banJsonAbsolutePath()
    if not path then return nil end
    local f = io.open(path, "r")
    if not f then
        return "[]"
    end
    local raw = f:read("*a") or ""
    f:close()
    if raw:match("%S") then
        return raw
    end
    return "[]"
end

-- Helper: add/update a ban in ban.json and immediately sync to dashboard
function addOrUpdateBanToFile(opts)
    opts = opts or {}

    local license = tostring(opts.license or opts.player_id or "")
    if license == "" then
        return false, "missing license/player_id"
    end

    local playerName = tostring(opts.playerName or opts.player_name or opts.player or "Unknown")
    local reason = tostring(opts.reason or opts.details or "Banned")
    local admin = tostring(opts.admin or opts.banned_by or "Anticheat")
    local mode = tostring(opts.mode or "Anticheat")

    local content = readBanJsonForMutation()
    if not content then
        return false, "ban.json temporarily unreadable"
    end
    local bans = jsonDecode(content) or {}
    if type(bans) ~= "table" then bans = {} end

    -- If already banned (same license), update the entry instead of duplicating
    for _, ban in ipairs(bans) do
        local banLicense = tostring(ban.player_id or ban.license or ban.LICENSE or "")
        if banLicense ~= "" and banLicense == license then
            ban.player = playerName
            ban.player_name = ban.player_name or playerName
            ban.player_id = license
            ban.license = license
            ban.details = reason
            ban.reason = ban.reason or reason
            ban.admin = admin
            ban.banned_by = ban.banned_by or admin
            ban.mode = mode
            ban.type = ban.type or "BAN_PLAYER"
            ban.ts = ban.ts or os.time()
            ban.banned_at = ban.banned_at or os.time()
            if opts.identifiers then ban.identifiers = opts.identifiers end
            if opts.ip then ban.ip = opts.ip end
            if opts.discord then ban.discord = opts.discord end
            if opts.steam then ban.steam = opts.steam end
            if opts.fivem then ban.fivem = opts.fivem end
            if opts.xbl then ban.xbl = opts.xbl end

            local enc = jsonEncode(bans)
            if not enc then
                return false, "json encode failed"
            end
            writeBanJsonFile(enc)
            banList[license] = { reason = reason, banId = ban.id or ban.BANID or ban.ban_id }
            lastSyncedBanFingerprint = nil
            syncBansToSupabase(true)
            return true, ban.id
        end
    end

    -- Calculate next numeric ID for ban.json
    local maxId = 0
    for _, b in ipairs(bans) do
        local numId = 0
        if type(b.id) == "number" then
            numId = b.id
        elseif type(b.id) == "string" then
            local num = b.id:match("Vex%-(%d+)")
            if num then numId = tonumber(num) or 0 end
        end
        if numId > maxId then maxId = numId end
    end

    local newEntry = {
        id = "Vex-" .. (maxId + 1),
        player = playerName,
        player_name = playerName,
        player_id = license,
        license = license,
        name = playerName,
        details = reason,
        reason = reason,
        admin = admin,
        banned_by = admin,
        mode = mode,
        type = "BAN_PLAYER",
        ts = os.time(),
        banned_at = os.time(),
        identifiers = opts.identifiers or nil,
        ip = opts.ip or nil,
        discord = opts.discord or nil,
        steam = opts.steam or nil,
        fivem = opts.fivem or nil,
        xbl = opts.xbl or nil
    }

    table.insert(bans, newEntry)
    local encNew = jsonEncode(bans)
    if not encNew then
        return false, "json encode failed"
    end
    writeBanJsonFile(encNew)
    banList[license] = { reason = reason, banId = newEntry.id }
    
    lastSyncedBanFingerprint = nil
    syncBansToSupabase(true)
    return true, newEntry.id
end

-- =============================================================================
-- SETTINGS SYNC (config.lua -> Dashboard)
-- =============================================================================

function buildDashboardClientConfig()
    local client = (Config and Config.Client) or {}
    local antiAfk = type(client["AntiAFK"]) == "table" and client["AntiAFK"] or {}
    local function toNumber(value, fallback)
        if type(value) == "number" then return value end
        return fallback
    end

    return {
        maxArmour = toNumber(client["MAX ARMOUR"], 20),
        maxDistanceTeleporting = toNumber(client["Max Distance Teleporting"], 500.0),
        infiniteAmmoMax = toNumber(client["InfiniteAmmoMax"], 250),
        infiniteAmmoMin = toNumber(client["InfiniteAmmoMin"], 0),
        progressPropsMax = toNumber(Config and Config.ProgressPropsMax, 150),
        objectSpamThreshold = toNumber(Config and Config.ObjectSpamThreshold, 200),
        propSpawnLimit = toNumber(Config and Config.PropSpawnLimit, 1),
        propSpawnWindowMs = toNumber(Config and Config.PropSpawnWindowMs, 300),
        afkMaxTime = toNumber(antiAfk.MaxAFKTime, 300)
    }
end

function groupsArrayToMap(list)
    if type(list) ~= "table" then return nil end
    local map = {}
    for _, name in ipairs(list) do
        if type(name) == "string" and name ~= "" then
            map[name] = true
        end
    end
    return map
end

function groupsMapToArray(map)
    if type(map) ~= "table" then return {} end
    local list = {}
    for name, enabled in pairs(map) do
        if enabled then
            list[#list + 1] = name
        end
    end
    table.sort(list)
    return list
end

syncSettingsToDashboard = function()
    if isApplyingDashboardSettings then return end
    if not canSyncDashboard() then return end
    if not Config then return end

    local adminJson = jsonDecode(readAdminJsonFile() or "")
    local pureMode = Config.PureMode or {}
    local spoofDet = Config.SpoofDetection or {}
    local smartProp = Config.SmartPropDelete or {}
    local maxSpawn = Config.MaxSpawn or {}
    local weaponCfg = Config.Weapons or {}
    local betaCfg = Config.Beta or {}
    local inputHijack = Config.CheatMenuInputHijack or {}

    local settings = {
        protections = Config.Protections or {},
        enforcementActions = Config.EnforcementActions or {},
        server_name = Config.Servername,
        discord_invite = Config.Discordinvite,
        language = Config.Language,
        framework = Config.Framework,
        require_steam = Config.RequireSteam,
        require_discord = Config.RequireDiscord,
        log_ip_information = Config.LogIPInformation,
        resource_whitelist_enabled = Config.ResourceWhitelistEnabled,
        resource_whitelist_action = Config.ResourceWhitelistAction,
        server_logo = Config.ServerLogo,
        minimum_online_seconds_before_ban = Config.MinimumOnlineSecondsBeforeBan,
        give_money_max_increase = Config.GiveMoneyMaxIncrease,
        give_money_check_interval = Config.GiveMoneyCheckInterval,
        inventory = Config.Inventory,
        modules = Config.modules or {},
        client_config = buildDashboardClientConfig(),
        blacklist_block_enabled = blacklistBlockEnabled,
        pure_mode = {
            enabled = pureMode.Enabled,
            scriptHookAllowed = pureMode.ScriptHookAllowed,
            pureLevel = pureMode.PureLevel,
            filterRequestControl = pureMode.FilterRequestControl,
        },
        cheat_menu_input_hijack = {
            enabled = inputHijack.Enabled,
            checkIntervalMs = inputHijack.CheckIntervalMs,
            sampleDelayMs = inputHijack.SampleDelayMs,
            requiredStrikes = inputHijack.RequiredStrikes,
            strikeWindowMs = inputHijack.StrikeWindowMs,
            reportCooldownMs = inputHijack.ReportCooldownMs,
            minCursorDelta = inputHijack.MinCursorDelta,
            maxCameraDelta = inputHijack.MaxCameraDelta,
            minDisabledControls = inputHijack.MinDisabledControls,
            requireOnFoot = inputHijack.RequireOnFoot,
        },
        spoof_detection = {
            enabled = spoofDet.Enabled,
            minTokens = spoofDet.MinTokens,
            requireLicense = spoofDet.RequireLicense,
            requireSteam = spoofDet.RequireSteam,
            allowPrivateIPs = spoofDet.AllowPrivateIPs,
            minFlagsToBan = spoofDet.MinFlagsToBan,
            fingerprintAnalysis = spoofDet.FingerprintAnalysis,
            checkIPConsistency = spoofDet.CheckIPConsistency,
            detectTokenRecycling = spoofDet.DetectTokenRecycling,
        },
        smart_prop_delete = {
            enabled = smartProp.Enabled,
            maxPropSize = smartProp.MaxPropSize,
            minDistanceFromPlayer = smartProp.MinDistanceFromPlayer,
            maxDistanceFromPlayer = smartProp.MaxDistanceFromPlayer,
            checkUnnaturalSpawn = smartProp.CheckUnnaturalSpawn,
            autoDeleteEnabled = smartProp.AutoDeleteEnabled,
            banOnSuspicious = smartProp.BanOnSuspicious,
        },
        max_spawn = {
            maxVehiclesPerPlayer = maxSpawn.MaxVehiclesPerPlayer,
            maxPedsPerPlayer = maxSpawn.MaxPedsPerPlayer,
            maxPropsPerPlayer = maxSpawn.MaxPropsPerPlayer,
            maxVehiclesGlobal = maxSpawn.MaxVehiclesGlobal,
            maxPedsGlobal = maxSpawn.MaxPedsGlobal,
            maxPropsGlobal = maxSpawn.MaxPropsGlobal,
            maxSameVehicleModel = maxSpawn.MaxSameVehicleModel,
            maxSamePedModel = maxSpawn.MaxSamePedModel,
            maxSamePropModel = maxSpawn.MaxSamePropModel,
            resetOnDisconnect = maxSpawn.ResetOnDisconnect,
            enableGlobalLimits = maxSpawn.EnableGlobalLimits,
            enablePerModelLimits = maxSpawn.EnablePerModelLimits,
        },
        injection_config = {
            injectionChecking = Config.InjectionChecking,
            injectionResourceDetecting = Config.InjectionResourceDetecting,
            injectionCommandDetecting = Config.InjectionCommandDetecting,
            injectionGlobalDetecting = Config.InjectionGlobalDetecting,
            injectionSpecialDetecting = Config.InjectionSpecialDetecting,
            cheatEngineChecking = Config.CheatEngineChecking,
        },
        weapon_config = {
            antiSpoofedBullets = weaponCfg.AntiSpoofedBullets,
            antiAimBot = weaponCfg.AntiAimBot,
            aimbotInstantBlock = weaponCfg.AimbotInstantBlock,
            aimbotInstantBlockBan = weaponCfg.AimbotInstantBlockBan,
            aimbotBlockDurationMs = weaponCfg.AimbotBlockDurationMs,
            aimbotClientBlockMs = weaponCfg.AimbotClientBlockMs,
            silentAimInstantBlock = weaponCfg.SilentAimInstantBlock,
            silentAimInstantBlockBan = weaponCfg.SilentAimInstantBlockBan,
            silentAimBlockDurationMs = weaponCfg.SilentAimBlockDurationMs,
            silentAimClientBlockMs = weaponCfg.SilentAimClientBlockMs,
        },
        beta_config = {
            antiSilentAim = betaCfg.AntiSilentAim,
        },
        spawn_config = {
            vehicleSpawnLimit = Config.VehicleSpawnLimit,
            vehicleSpawnWindowMs = Config.VehicleSpawnWindowMs,
            pedSpawnLimit = Config.PedSpawnLimit,
            pedSpawnWindowMs = Config.PedSpawnWindowMs,
            antiSpawnVehicleEnabled = Config.AntiSpawnVehicleEnabled,
            antiPedSpawnEnabled = Config.AntiPedSpawn and Config.AntiPedSpawn.Enabled,
            enablePedWhitelist = Config.EnablePedWhitelist,
        },
        blacklisted_menu_words = Config.BlacklistedMenuWords or {},
        blacklisted_triggers = Config.BlacklistedTriggers or {},
        whitelisted_triggers = Config.WhitelistedTriggers or {},
        blacklisted_names = Config.BlacklistedNames or {},
        allowed_vehicle_spawn_resources = Config.AllowedVehicleSpawnResources or {},
        full_whitelist_resources = Config.FullWhitelistResources or {},
        exempt_groups = groupsMapToArray(Config.EXEMPT_GROUPS),
        admin_groups = groupsMapToArray(Config.ADMIN_GROUPS),
        allowed_resources = Config.AllowedResources or {},
        inventory_allowed_jobs = Config.InventoryAllowedJobs or {},
        blacklisted_vehicle_plates = Config.BlackListedVehiclePlates or {},
        blacklisted_commands = Config.BlacklistedCommands or {},
        whitelist_peds = Config.WhiteListPeds or {},
        blacklisted_vehicles = Config.BlacklistedVehicles or {},
        blacklisted_peds = Config.BlacklistedPeds or {},
        blacklisted_weapons = Config.BlacklistedWeapons or {},
    }

    local discord_webhooks = {
        mainLogs = Config.mainLogs,
        logsConnection = Config.logsConnection,
        logsBans = Config.logsBans,
        logsLeave = Config.logsLeave,
        screenshotWebhook = Config.screenshotWebhook,
        TriggerResourceslogs = Config.TriggerResourceslogs,
        logsWebhook = Config.logsWebhook,
    }

    httpPost(API_URL, {
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "sync_settings",
        settings = settings,
        discord_webhooks = discord_webhooks,
        admin_json = adminJson,
        anti_objects = Config.BlacklistedProps or {},
        anti_blackwords = Config.BlacklistedNames or {}
    }, function() end)
end

function pullBlacklistBlockFromDashboard(cb)
    if not canSyncDashboard() then
        if cb then cb() end
        return
    end
    httpPost(API_URL, {
        server_id = SERVER_ID,
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "get_settings",
    }, function(status, response)
        if status == 200 then
            local data = jsonDecode(response) or {}
            if data.server_id and tostring(data.server_id) ~= "" then
                SERVER_ID = tostring(data.server_id)
            end
            local settings = data.settings or {}
            if type(settings) == "string" then
                settings = jsonDecode(settings) or {}
            end
            if type(settings) == "table" and settings.blacklist_block_enabled ~= nil then
                blacklistBlockEnabled = settings.blacklist_block_enabled ~= false
                CreateThread(function()
                    Wait(0)
                    persistBlacklistBlockToFile()
                end)
            end
        end
        if cb then cb() end
    end)
end

-- =============================================================================
-- DASHBOARD COMMANDS HANDLER
-- =============================================================================

local syncResourcesToDashboard

function applySettingsFromDashboard(settings)
    local success = false
    local result = "No changes to apply"
    local changed = false

    if type(settings) == "table" and settings.blacklist_block_enabled ~= nil then
        local onlyBlacklist = true
        for key, _ in pairs(settings) do
            if key ~= "blacklist_block_enabled" then
                onlyBlacklist = false
                break
            end
        end
        if onlyBlacklist then
            applyBlacklistBlockToggle(settings.blacklist_block_enabled)
            return true, "Blacklist block " .. (blacklistBlockEnabled and "enabled" or "disabled")
        end
    end

    if Config then
        -- Apply protections
        if settings.protections then
            local count = 0
            for _ in pairs(settings.protections) do count = count + 1 end
            for key, val in pairs(settings.protections) do
                if Config.Protections then
                    if type(val) == "table" and type(Config.Protections[key]) == "table" then
                        for k, v in pairs(val) do
                            Config.Protections[key][k] = v
                        end
                    else
                        Config.Protections[key] = val
                    end
                    changed = true
                end
            end
        end
        
        -- Apply enforcement actions
        if settings.enforcementActions then
            for key, action in pairs(settings.enforcementActions) do
                if Config.EnforcementActions then
                    Config.EnforcementActions[key] = action
                    changed = true
                end
            end
        end
        
        -- Apply Discord webhooks
        if settings.discord_webhooks then
            local webhooks = settings.discord_webhooks
            if webhooks.mainLogs ~= nil then Config.mainLogs = webhooks.mainLogs; changed = true end
            if webhooks.logsConnection ~= nil then Config.logsConnection = webhooks.logsConnection; changed = true end
            if webhooks.logsBans ~= nil then Config.logsBans = webhooks.logsBans; changed = true end
            if webhooks.logsLeave ~= nil then Config.logsLeave = webhooks.logsLeave; changed = true end
            if webhooks.screenshotWebhook ~= nil then Config.screenshotWebhook = webhooks.screenshotWebhook; changed = true end
            if webhooks.TriggerResourceslogs ~= nil then Config.TriggerResourceslogs = webhooks.TriggerResourceslogs; changed = true end
            if webhooks.logsWebhook ~= nil then Config.logsWebhook = webhooks.logsWebhook; changed = true end
        end
        
        -- Apply blacklists
        if settings.anti_objects then Config.BlacklistedProps = settings.anti_objects; changed = true end
        if settings.anti_blackwords then Config.BlacklistedNames = settings.anti_blackwords; changed = true end
        
        -- Apply server config options
        if settings.server_name ~= nil then Config.Servername = settings.server_name; changed = true end
        if settings.discord_invite ~= nil then Config.Discordinvite = settings.discord_invite; changed = true end
        if settings.language ~= nil then Config.Language = settings.language; changed = true end
        if settings.framework ~= nil then Config.Framework = settings.framework; changed = true end
        if settings.require_steam ~= nil then Config.RequireSteam = settings.require_steam; changed = true end
        if settings.require_discord ~= nil then Config.RequireDiscord = settings.require_discord; changed = true end
        if settings.log_ip_information ~= nil then Config.LogIPInformation = settings.log_ip_information; changed = true end
        if settings.resource_whitelist_enabled ~= nil then Config.ResourceWhitelistEnabled = settings.resource_whitelist_enabled; changed = true end
        if settings.resource_whitelist_action ~= nil then Config.ResourceWhitelistAction = settings.resource_whitelist_action; changed = true end
        if settings.server_logo ~= nil then Config.ServerLogo = settings.server_logo; changed = true end
        if settings.minimum_online_seconds_before_ban ~= nil then Config.MinimumOnlineSecondsBeforeBan = settings.minimum_online_seconds_before_ban; changed = true end
        if settings.give_money_max_increase ~= nil then Config.GiveMoneyMaxIncrease = settings.give_money_max_increase; changed = true end
        if settings.give_money_check_interval ~= nil then Config.GiveMoneyCheckInterval = settings.give_money_check_interval; changed = true end
        if settings.inventory then Config.Inventory = settings.inventory; changed = true end
        if settings.modules then Config.modules = settings.modules; changed = true end
        if settings.blacklist_block_enabled ~= nil then
            applyBlacklistBlockToggle(settings.blacklist_block_enabled)
            changed = true
        end
        if settings.client_config then
            local clientCfg = settings.client_config
            Config.Client = Config.Client or {}

            if clientCfg.maxArmour ~= nil then Config.Client["MAX ARMOUR"] = clientCfg.maxArmour; changed = true end
            if clientCfg.maxDistanceTeleporting ~= nil then Config.Client["Max Distance Teleporting"] = clientCfg.maxDistanceTeleporting; changed = true end
            if clientCfg.infiniteAmmoMax ~= nil then Config.Client["InfiniteAmmoMax"] = clientCfg.infiniteAmmoMax; changed = true end
            if clientCfg.infiniteAmmoMin ~= nil then Config.Client["InfiniteAmmoMin"] = clientCfg.infiniteAmmoMin; changed = true end
            if clientCfg.afkMaxTime ~= nil then
                Config.Client["AntiAFK"] = Config.Client["AntiAFK"] or {}
                if type(Config.Client["AntiAFK"]) == "table" then
                    Config.Client["AntiAFK"].MaxAFKTime = clientCfg.afkMaxTime
                    changed = true
                end
            end
            if clientCfg.progressPropsMax ~= nil then Config.ProgressPropsMax = clientCfg.progressPropsMax; changed = true end
            if clientCfg.objectSpamThreshold ~= nil then Config.ObjectSpamThreshold = clientCfg.objectSpamThreshold; changed = true end
            if clientCfg.propSpawnLimit ~= nil then Config.PropSpawnLimit = clientCfg.propSpawnLimit; changed = true end
            if clientCfg.propSpawnWindowMs ~= nil then Config.PropSpawnWindowMs = clientCfg.propSpawnWindowMs; changed = true end
        end
        if settings.weapon_config then
            local weaponCfg = settings.weapon_config
            Config.Weapons = Config.Weapons or {}
            if weaponCfg.antiSpoofedBullets ~= nil then Config.Weapons.AntiSpoofedBullets = weaponCfg.antiSpoofedBullets; changed = true end
            if weaponCfg.antiAimBot ~= nil then Config.Weapons.AntiAimBot = weaponCfg.antiAimBot; changed = true end
            if weaponCfg.aimbotInstantBlock ~= nil then Config.Weapons.AimbotInstantBlock = weaponCfg.aimbotInstantBlock; changed = true end
            if weaponCfg.aimbotInstantBlockBan ~= nil then Config.Weapons.AimbotInstantBlockBan = weaponCfg.aimbotInstantBlockBan; changed = true end
            if weaponCfg.aimbotBlockDurationMs ~= nil then Config.Weapons.AimbotBlockDurationMs = weaponCfg.aimbotBlockDurationMs; changed = true end
            if weaponCfg.aimbotClientBlockMs ~= nil then Config.Weapons.AimbotClientBlockMs = weaponCfg.aimbotClientBlockMs; changed = true end
            if weaponCfg.silentAimInstantBlock ~= nil then Config.Weapons.SilentAimInstantBlock = weaponCfg.silentAimInstantBlock; changed = true end
            if weaponCfg.silentAimInstantBlockBan ~= nil then Config.Weapons.SilentAimInstantBlockBan = weaponCfg.silentAimInstantBlockBan; changed = true end
            if weaponCfg.silentAimBlockDurationMs ~= nil then Config.Weapons.SilentAimBlockDurationMs = weaponCfg.silentAimBlockDurationMs; changed = true end
            if weaponCfg.silentAimClientBlockMs ~= nil then Config.Weapons.SilentAimClientBlockMs = weaponCfg.silentAimClientBlockMs; changed = true end
        end
        if settings.beta_config then
            local betaCfg = settings.beta_config
            Config.Beta = Config.Beta or {}
            if betaCfg.antiSilentAim ~= nil then Config.Beta.AntiSilentAim = betaCfg.antiSilentAim; changed = true end
        end
        local blVeh = settings.blacklisted_vehicles or settings.blacklistedVehicles or settings.BlacklistedVehicles
        if blVeh then Config.BlacklistedVehicles = blVeh; changed = true end
        local blPeds = settings.blacklisted_peds or settings.blacklistedPeds or settings.BlacklistedPeds
        if blPeds then Config.BlacklistedPeds = blPeds; changed = true end
        local blWeapons = settings.blacklisted_weapons or settings.blacklistedWeapons or settings.BlacklistedWeapons
        if blWeapons then Config.BlacklistedWeapons = blWeapons; changed = true end
        local blMenuWords = settings.blacklisted_menu_words or settings.blacklistedMenuWords or settings.BlacklistedMenuWords
        if blMenuWords then Config.BlacklistedMenuWords = blMenuWords; changed = true end
        local blTriggers = settings.blacklisted_triggers or settings.blacklistedTriggers or settings.BlacklistedTriggers
        if blTriggers then Config.BlacklistedTriggers = blTriggers; changed = true end
        local wlTriggers = settings.whitelisted_triggers or settings.whitelistedTriggers or settings.WhitelistedTriggers
        if wlTriggers then Config.WhitelistedTriggers = wlTriggers; changed = true end
        local blNames = settings.blacklisted_names or settings.blacklistedNames or settings.BlacklistedNames
        if blNames then Config.BlacklistedNames = blNames; changed = true end
        local avsResources = settings.allowed_vehicle_spawn_resources or settings.allowedVehicleSpawnResources or settings.AllowedVehicleSpawnResources
        if avsResources then Config.AllowedVehicleSpawnResources = avsResources; changed = true end
        local fwResources = settings.full_whitelist_resources or settings.fullWhitelistResources or settings.FullWhitelistResources
        if fwResources then Config.FullWhitelistResources = fwResources; changed = true end
        local exGroups = settings.exempt_groups or settings.exemptGroups or settings.EXEMPT_GROUPS
        if exGroups then
            local mapped = groupsArrayToMap(exGroups)
            if mapped then Config.EXEMPT_GROUPS = mapped; changed = true end
        end
        local adGroups = settings.admin_groups or settings.adminGroups or settings.ADMIN_GROUPS
        if adGroups then
            local mapped = groupsArrayToMap(adGroups)
            if mapped then Config.ADMIN_GROUPS = mapped; changed = true end
        end
        local alResources = settings.allowed_resources or settings.allowedResources or settings.AllowedResources
        if alResources then Config.AllowedResources = alResources; changed = true end
        local invJobs = settings.inventory_allowed_jobs or settings.inventoryAllowedJobs or settings.InventoryAllowedJobs
        if invJobs then Config.InventoryAllowedJobs = invJobs; changed = true end
        local blPlates = settings.blacklisted_vehicle_plates or settings.blackListedVehiclePlates or settings.BlackListedVehiclePlates
        if blPlates then Config.BlackListedVehiclePlates = blPlates; changed = true end
        local blCommands = settings.blacklisted_commands or settings.blacklistedCommands or settings.BlacklistedCommands
        if blCommands then Config.BlacklistedCommands = blCommands; changed = true end
        local wlPeds = settings.whitelist_peds or settings.whiteListPeds or settings.WhiteListPeds
        if wlPeds then Config.WhiteListPeds = wlPeds; changed = true end

        if settings.pure_mode then
            local pm = settings.pure_mode
            Config.PureMode = Config.PureMode or {}
            if pm.enabled ~= nil then Config.PureMode.Enabled = pm.enabled; changed = true end
            if pm.scriptHookAllowed ~= nil then Config.PureMode.ScriptHookAllowed = pm.scriptHookAllowed; changed = true end
            if pm.pureLevel ~= nil then Config.PureMode.PureLevel = pm.pureLevel; changed = true end
            if pm.filterRequestControl ~= nil then Config.PureMode.FilterRequestControl = pm.filterRequestControl; changed = true end
        end
        if settings.cheat_menu_input_hijack then
            local ih = settings.cheat_menu_input_hijack
            Config.CheatMenuInputHijack = Config.CheatMenuInputHijack or {}
            local inputHijackKeys = {
                enabled = "Enabled",
                checkIntervalMs = "CheckIntervalMs",
                sampleDelayMs = "SampleDelayMs",
                requiredStrikes = "RequiredStrikes",
                strikeWindowMs = "StrikeWindowMs",
                reportCooldownMs = "ReportCooldownMs",
                minCursorDelta = "MinCursorDelta",
                maxCameraDelta = "MaxCameraDelta",
                minDisabledControls = "MinDisabledControls",
                requireOnFoot = "RequireOnFoot",
            }
            for dashKey, luaKey in pairs(inputHijackKeys) do
                if ih[dashKey] ~= nil then
                    Config.CheatMenuInputHijack[luaKey] = ih[dashKey]
                    changed = true
                end
            end
        end
        if settings.spoof_detection then
            local sd = settings.spoof_detection
            Config.SpoofDetection = Config.SpoofDetection or {}
            if sd.enabled ~= nil then Config.SpoofDetection.Enabled = sd.enabled; changed = true end
            if sd.minTokens ~= nil then Config.SpoofDetection.MinTokens = sd.minTokens; changed = true end
            if sd.requireLicense ~= nil then Config.SpoofDetection.RequireLicense = sd.requireLicense; changed = true end
            if sd.requireSteam ~= nil then Config.SpoofDetection.RequireSteam = sd.requireSteam; changed = true end
            if sd.allowPrivateIPs ~= nil then Config.SpoofDetection.AllowPrivateIPs = sd.allowPrivateIPs; changed = true end
            if sd.minFlagsToBan ~= nil then Config.SpoofDetection.MinFlagsToBan = sd.minFlagsToBan; changed = true end
            if sd.fingerprintAnalysis ~= nil then Config.SpoofDetection.FingerprintAnalysis = sd.fingerprintAnalysis; changed = true end
            if sd.checkIPConsistency ~= nil then Config.SpoofDetection.CheckIPConsistency = sd.checkIPConsistency; changed = true end
            if sd.detectTokenRecycling ~= nil then Config.SpoofDetection.DetectTokenRecycling = sd.detectTokenRecycling; changed = true end
        end
        if settings.smart_prop_delete then
            local sp = settings.smart_prop_delete
            Config.SmartPropDelete = Config.SmartPropDelete or {}
            if sp.enabled ~= nil then Config.SmartPropDelete.Enabled = sp.enabled; changed = true end
            if sp.maxPropSize ~= nil then Config.SmartPropDelete.MaxPropSize = sp.maxPropSize; changed = true end
            if sp.minDistanceFromPlayer ~= nil then Config.SmartPropDelete.MinDistanceFromPlayer = sp.minDistanceFromPlayer; changed = true end
            if sp.maxDistanceFromPlayer ~= nil then Config.SmartPropDelete.MaxDistanceFromPlayer = sp.maxDistanceFromPlayer; changed = true end
            if sp.checkUnnaturalSpawn ~= nil then Config.SmartPropDelete.CheckUnnaturalSpawn = sp.checkUnnaturalSpawn; changed = true end
            if sp.autoDeleteEnabled ~= nil then Config.SmartPropDelete.AutoDeleteEnabled = sp.autoDeleteEnabled; changed = true end
            if sp.banOnSuspicious ~= nil then Config.SmartPropDelete.BanOnSuspicious = sp.banOnSuspicious; changed = true end
        end
        if settings.max_spawn then
            local ms = settings.max_spawn
            Config.MaxSpawn = Config.MaxSpawn or {}
            local spawnKeys = {
                maxVehiclesPerPlayer = "MaxVehiclesPerPlayer",
                maxPedsPerPlayer = "MaxPedsPerPlayer",
                maxPropsPerPlayer = "MaxPropsPerPlayer",
                maxVehiclesGlobal = "MaxVehiclesGlobal",
                maxPedsGlobal = "MaxPedsGlobal",
                maxPropsGlobal = "MaxPropsGlobal",
                maxSameVehicleModel = "MaxSameVehicleModel",
                maxSamePedModel = "MaxSamePedModel",
                maxSamePropModel = "MaxSamePropModel",
                resetOnDisconnect = "ResetOnDisconnect",
                enableGlobalLimits = "EnableGlobalLimits",
                enablePerModelLimits = "EnablePerModelLimits",
            }
            for dashKey, luaKey in pairs(spawnKeys) do
                if ms[dashKey] ~= nil then
                    Config.MaxSpawn[luaKey] = ms[dashKey]
                    changed = true
                end
            end
        end
        if settings.injection_config then
            local ic = settings.injection_config
            if ic.injectionChecking ~= nil then Config.InjectionChecking = ic.injectionChecking; changed = true end
            if ic.injectionResourceDetecting ~= nil then Config.InjectionResourceDetecting = ic.injectionResourceDetecting; changed = true end
            if ic.injectionCommandDetecting ~= nil then Config.InjectionCommandDetecting = ic.injectionCommandDetecting; changed = true end
            if ic.injectionGlobalDetecting ~= nil then Config.InjectionGlobalDetecting = ic.injectionGlobalDetecting; changed = true end
            if ic.injectionSpecialDetecting ~= nil then Config.InjectionSpecialDetecting = ic.injectionSpecialDetecting; changed = true end
            if ic.cheatEngineChecking ~= nil then Config.CheatEngineChecking = ic.cheatEngineChecking; changed = true end
        end
        if settings.spawn_config then
            local sc = settings.spawn_config
            if sc.vehicleSpawnLimit ~= nil then Config.VehicleSpawnLimit = sc.vehicleSpawnLimit; changed = true end
            if sc.vehicleSpawnWindowMs ~= nil then Config.VehicleSpawnWindowMs = sc.vehicleSpawnWindowMs; changed = true end
            if sc.pedSpawnLimit ~= nil then Config.PedSpawnLimit = sc.pedSpawnLimit; changed = true end
            if sc.pedSpawnWindowMs ~= nil then Config.PedSpawnWindowMs = sc.pedSpawnWindowMs; changed = true end
            if sc.antiSpawnVehicleEnabled ~= nil then Config.AntiSpawnVehicleEnabled = sc.antiSpawnVehicleEnabled; changed = true end
            if sc.antiPedSpawnEnabled ~= nil then
                Config.AntiPedSpawn = Config.AntiPedSpawn or {}
                Config.AntiPedSpawn.Enabled = sc.antiPedSpawnEnabled
                changed = true
            end
            if sc.enablePedWhitelist ~= nil then Config.EnablePedWhitelist = sc.enablePedWhitelist; changed = true end
        end
    end

    if changed then
        success = true
        result = "Settings applied (" .. CONFIG_FILE .. " save queued)"
        local settingsForPersist = settings
        CreateThread(function()
            if isSavingConfigFile then
                Wait(500)
            end
            isSavingConfigFile = true
            isApplyingDashboardSettings = true

            local content = readFile(CONFIG_FILE)
            if not content or content == "" then
                isSavingConfigFile = false
                isApplyingDashboardSettings = false
                return
            end

            local yieldStep = 0
            local function maybeYield()
                yieldStep = yieldStep + 1
                if yieldStep % 12 == 0 then Wait(0) end
            end
            
            -- Helper to update a protection entry (handles special characters properly)
            local function updateProtection(key, enabled)
                local escapedKey = key:gsub("([%(%)%.%+%-%*%?%[%]%^%$%%/])", "%%%1")

                local isEnabled = true
                if type(enabled) == "table" then
                    if enabled.Enabled ~= nil then
                        isEnabled = (enabled.Enabled == true or enabled.Enabled == 1 or enabled.Enabled == "true")
                    elseif enabled.enabled ~= nil then
                        isEnabled = (enabled.enabled == true or enabled.enabled == 1 or enabled.enabled == "true")
                    elseif enabled.value ~= nil then
                        isEnabled = (enabled.value == true or enabled.value == 1 or enabled.value == "true")
                    end
                elseif type(enabled) == "boolean" then
                    isEnabled = enabled
                end

                local l1 = isEnabled
                local l2 = isEnabled
                local l3 = isEnabled
                if type(enabled) == "table" then
                    if enabled.L1 ~= nil then l1 = (enabled.L1 == true or enabled.L1 == 1 or enabled.L1 == "true") and isEnabled
                    elseif enabled.l1 ~= nil then l1 = (enabled.l1 == true or enabled.l1 == 1 or enabled.l1 == "true") and isEnabled end

                    if enabled.L2 ~= nil then l2 = (enabled.L2 == true or enabled.L2 == 1 or enabled.L2 == "true") and isEnabled
                    elseif enabled.l2 ~= nil then l2 = (enabled.l2 == true or enabled.l2 == 1 or enabled.l2 == "true") and isEnabled end

                    if enabled.L3 ~= nil then l3 = (enabled.L3 == true or enabled.L3 == 1 or enabled.L3 == "true") and isEnabled
                    elseif enabled.l3 ~= nil then l3 = (enabled.l3 == true or enabled.l3 == 1 or enabled.l3 == "true") and isEnabled end
                end

                local replacement = "['" .. key .. "'] = { Enabled = " .. tostring(isEnabled) .. ", L1 = " .. tostring(l1) .. ", L2 = " .. tostring(l2) .. ", L3 = " .. tostring(l3) .. " }"

                -- Pattern 1: Table format e.g. ['Anti Noclip'] = { ... } (balanced %b{})
                local p1 = "%['" .. escapedKey .. "'%]%s*=%s*%b{}"
                local newContent, count1 = content:gsub(p1, function() return replacement end)
                if count1 > 0 then
                    content = newContent
                    return true
                end

                -- Pattern 2: Double quote table e.g. ["Anti Noclip"] = { ... }
                local p2 = "%[\"" .. escapedKey .. "\"%]%s*=%s*%b{}"
                local newContent2, count2 = content:gsub(p2, function() return replacement end)
                if count2 > 0 then
                    content = newContent2
                    return true
                end

                -- Pattern 3: Boolean format e.g. ['Anti Noclip'] = true / false
                local p3 = "%['" .. escapedKey .. "'%]%s*=%s*%a+"
                local newContent3, count3 = content:gsub(p3, function() return replacement end)
                if count3 > 0 then
                    content = newContent3
                    return true
                end

                -- Pattern 4: Boolean double quote format e.g. ["Anti Noclip"] = true / false
                local p4 = "%[\"" .. escapedKey .. "\"%]%s*=%s*%a+"
                local newContent4, count4 = content:gsub(p4, function() return replacement end)
                if count4 > 0 then
                    content = newContent4
                    return true
                end

                return false
            end
            
            -- Helper to update an enforcement action entry
            local function updateEnforcementAction(key, action)
                local escapedKey = key:gsub("([%(%)%.%+%-%*%?%[%]%^%$%%/])", "%%%1")
                local replacement = "['" .. key .. "'] = \"" .. tostring(action) .. "\""
                
                local p1 = "%['" .. escapedKey .. "'%]%s*=%s*\"[^\"]*\""
                local newContent, count = content:gsub(p1, function() return replacement end)
                if count > 0 then
                    content = newContent
                    return true
                end

                local p2 = "%[\"" .. escapedKey .. "\"%]%s*=%s*\"[^\"]*\""
                local newContent2, count2 = content:gsub(p2, function() return replacement end)
                if count2 > 0 then
                    content = newContent2
                    return true
                end

                return false
            end
            
            -- Update protections (dashboard payload only — avoids scanning entire Config.Protections)
            if settingsForPersist.protections then
                for key, enabled in pairs(settingsForPersist.protections) do
                    updateProtection(key, enabled)
                    maybeYield()
                end
            end
            
            -- Update enforcement actions (dashboard payload only)
            if settingsForPersist.enforcementActions then
                for key, action in pairs(settingsForPersist.enforcementActions) do
                    updateEnforcementAction(key, action)
                    maybeYield()
                end
            end
            
            -- Update simple config strings
            local function setConfigString(field, value)
                if value == nil then return end
                local valueStr = tostring(value)
                local escapedField = escapeLuaPattern(field)
                
                local pat1 = "Config%." .. escapedField .. "%s*=%s*\"[^\"]*\""
                local pat2 = "Config%." .. escapedField .. "%s*=%s*'[^']*'"
                local rep = "Config." .. field .. " = \"" .. valueStr .. "\""
                
                local newContent, count1 = content:gsub(pat1, rep)
                if count1 > 0 then
                    content = newContent
                    return
                end
                
                newContent, count2 = content:gsub(pat2, rep)
                if count2 > 0 then
                    content = newContent
                end
            end
            
            -- Update number configs
            local function setConfigNumber(field, value)
                if value == nil then return end
                local escapedField = escapeLuaPattern(field)
                local pat = "Config%." .. escapedField .. "%s*=%s*[%d%.]+"
                local rep = "Config." .. field .. " = " .. tostring(value)
                local newContent, count = content:gsub(pat, rep)
                if count > 0 then
                    content = newContent
                end
            end
            
            -- Update boolean configs
            local function setConfigBool(field, value)
                if value == nil then return end
                local escapedField = escapeLuaPattern(field)
                local pat1 = "Config%." .. escapedField .. "%s*=%s*true"
                local pat2 = "Config%." .. escapedField .. "%s*=%s*false"
                local rep = "Config." .. field .. " = " .. tostring(value)
                
                local newContent, count1 = content:gsub(pat1, rep)
                if count1 > 0 then
                    content = newContent
                    return
                end
                
                newContent, count2 = content:gsub(pat2, rep)
                if count2 > 0 then
                    content = newContent
                end
            end

            local function setConfigClientNumber(clientKey, value)
                if value == nil then return end
                local escapedKey = escapeLuaPattern(clientKey)
                local pat = "%['" .. escapedKey .. "'%]%s*=%s*[%d%.]+"
                local rep = "['" .. clientKey .. "'] = " .. tostring(value)
                local newContent, count = content:gsub(pat, rep)
                if count > 0 then
                    content = newContent
                end
            end

            local function setConfigAntiAfkMax(value)
                if value == nil then return end
                local pat = "MaxAFKTime%s*=%s*[%d%.]+"
                local rep = "MaxAFKTime = " .. tostring(value)
                local newContent, count = content:gsub(pat, rep)
                if count > 0 then
                    content = newContent
                end
            end

            local function luaSerialize(value, indent)
                indent = indent or 0
                local pad = string.rep("    ", indent)
                local t = type(value)
                if t == "table" then
                    local isArray = true
                    local maxIndex = 0
                    for k, _ in pairs(value) do
                        if type(k) ~= "number" then
                            isArray = false
                            break
                        end
                        if k > maxIndex then maxIndex = k end
                    end
                    local lines = { "{" }
                    if isArray then
                        for i = 1, maxIndex do
                            local v = value[i]
                            if v ~= nil then
                                table.insert(lines, pad .. "    " .. luaSerialize(v, indent + 1) .. ",")
                            end
                        end
                    else
                        for k, v in pairs(value) do
                            local key
                            if type(k) == "string" and k:match("^[%a_][%w_]*$") then
                                key = k
                            else
                                key = "['" .. tostring(k):gsub("'", "\\'") .. "']"
                            end
                            table.insert(lines, pad .. "    " .. key .. " = " .. luaSerialize(v, indent + 1) .. ",")
                        end
                    end
                    table.insert(lines, pad .. "}")
                    return table.concat(lines, "\n")
                elseif t == "string" then
                    return string.format("%q", value)
                elseif t == "boolean" or t == "number" then
                    return tostring(value)
                end
                return "nil"
            end

            local function setConfigTable(field, value)
                if value == nil then return end
                local escapedField = escapeLuaPattern(field)
                local pattern = "Config%." .. escapedField .. "%s*=%s*%b{}"
                local serialized = "Config." .. field .. " = " .. luaSerialize(value, 0)
                local newContent, count = content:gsub(pattern, serialized)
                if count > 0 then
                    content = newContent
                    return true
                end
                return false
            end
            
            -- Apply string configs
            if Config then
                local function persistScalar(fn)
                    fn()
                    maybeYield()
                end
                persistScalar(function() setConfigString("Servername", Config.Servername) end)
                persistScalar(function() setConfigString("Discordinvite", Config.Discordinvite) end)
                persistScalar(function() setConfigString("Language", Config.Language) end)
                persistScalar(function() setConfigString("Framework", Config.Framework) end)
                persistScalar(function() setConfigString("ServerLogo", Config.ServerLogo) end)
                persistScalar(function() setConfigString("ResourceWhitelistAction", Config.ResourceWhitelistAction) end)
                if settingsForPersist.discord_webhooks then
                    persistScalar(function() setConfigString("mainLogs", Config.mainLogs) end)
                    persistScalar(function() setConfigString("logsConnection", Config.logsConnection) end)
                    persistScalar(function() setConfigString("logsBans", Config.logsBans) end)
                    persistScalar(function() setConfigString("logsLeave", Config.logsLeave) end)
                    persistScalar(function() setConfigString("screenshotWebhook", Config.screenshotWebhook) end)
                    persistScalar(function() setConfigString("TriggerResourceslogs", Config.TriggerResourceslogs) end)
                    persistScalar(function() setConfigString("logsWebhook", Config.logsWebhook) end)
                end
                
                persistScalar(function() setConfigBool("RequireSteam", Config.RequireSteam) end)
                persistScalar(function() setConfigBool("RequireDiscord", Config.RequireDiscord) end)
                persistScalar(function() setConfigBool("LogIPInformation", Config.LogIPInformation) end)
                persistScalar(function() setConfigBool("ResourceWhitelistEnabled", Config.ResourceWhitelistEnabled) end)
                
                persistScalar(function() setConfigNumber("MinimumOnlineSecondsBeforeBan", Config.MinimumOnlineSecondsBeforeBan) end)
                persistScalar(function() setConfigNumber("GiveMoneyMaxIncrease", Config.GiveMoneyMaxIncrease) end)
                persistScalar(function() setConfigNumber("GiveMoneyCheckInterval", Config.GiveMoneyCheckInterval) end)
                if settingsForPersist.client_config then
                    persistScalar(function() setConfigNumber("ProgressPropsMax", Config.ProgressPropsMax) end)
                    persistScalar(function() setConfigNumber("ObjectSpamThreshold", Config.ObjectSpamThreshold) end)
                    persistScalar(function() setConfigNumber("PropSpawnLimit", Config.PropSpawnLimit) end)
                    persistScalar(function() setConfigNumber("PropSpawnWindowMs", Config.PropSpawnWindowMs) end)
                end

                local function persistTable(field, value)
                    if value ~= nil then
                        setConfigTable(field, value)
                        maybeYield()
                    end
                end
                if settingsForPersist.inventory then persistTable("Inventory", Config.Inventory) end
                if settingsForPersist.modules then persistTable("modules", Config.modules) end
                if settingsForPersist.anti_objects then persistTable("BlacklistedProps", Config.BlacklistedProps) end
                if settingsForPersist.anti_blackwords or settingsForPersist.blacklisted_names then
                    persistTable("BlacklistedNames", Config.BlacklistedNames)
                end
                if settingsForPersist.blacklisted_vehicles then persistTable("BlacklistedVehicles", Config.BlacklistedVehicles) end
                if settingsForPersist.blacklisted_peds then persistTable("BlacklistedPeds", Config.BlacklistedPeds) end
                if settingsForPersist.blacklisted_weapons then persistTable("BlacklistedWeapons", Config.BlacklistedWeapons) end
                if settingsForPersist.blacklisted_menu_words then persistTable("BlacklistedMenuWords", Config.BlacklistedMenuWords) end
                if settingsForPersist.blacklisted_triggers then persistTable("BlacklistedTriggers", Config.BlacklistedTriggers) end
                if settingsForPersist.whitelisted_triggers then persistTable("WhitelistedTriggers", Config.WhitelistedTriggers) end
                if settingsForPersist.allowed_vehicle_spawn_resources then persistTable("AllowedVehicleSpawnResources", Config.AllowedVehicleSpawnResources) end
                if settingsForPersist.full_whitelist_resources then persistTable("FullWhitelistResources", Config.FullWhitelistResources) end
                if settingsForPersist.allowed_resources then persistTable("AllowedResources", Config.AllowedResources) end
                if settingsForPersist.blacklisted_vehicle_plates then persistTable("BlackListedVehiclePlates", Config.BlackListedVehiclePlates) end
                if settingsForPersist.blacklisted_commands then persistTable("BlacklistedCommands", Config.BlacklistedCommands) end
                if settingsForPersist.whitelist_peds then persistTable("WhiteListPeds", Config.WhiteListPeds) end
                if settingsForPersist.exempt_groups then persistTable("EXEMPT_GROUPS", Config.EXEMPT_GROUPS) end
                if settingsForPersist.admin_groups then persistTable("ADMIN_GROUPS", Config.ADMIN_GROUPS) end
                if settingsForPersist.inventory_allowed_jobs then persistTable("InventoryAllowedJobs", Config.InventoryAllowedJobs) end
                if settingsForPersist.pure_mode then persistTable("PureMode", Config.PureMode) end
                if settingsForPersist.cheat_menu_input_hijack then persistTable("CheatMenuInputHijack", Config.CheatMenuInputHijack) end
                if settingsForPersist.spoof_detection then persistTable("SpoofDetection", Config.SpoofDetection) end
                if settingsForPersist.smart_prop_delete then persistTable("SmartPropDelete", Config.SmartPropDelete) end
                if settingsForPersist.max_spawn then persistTable("MaxSpawn", Config.MaxSpawn) end
                if settingsForPersist.weapon_config then persistTable("Weapons", Config.Weapons) end
                if settingsForPersist.beta_config then persistTable("Beta", Config.Beta) end
                if settingsForPersist.injection_config then
                    persistScalar(function() setConfigNumber("InjectionChecking", Config.InjectionChecking) end)
                    persistScalar(function() setConfigNumber("CheatEngineChecking", Config.CheatEngineChecking) end)
                    persistScalar(function() setConfigBool("InjectionResourceDetecting", Config.InjectionResourceDetecting) end)
                    persistScalar(function() setConfigBool("InjectionCommandDetecting", Config.InjectionCommandDetecting) end)
                    persistScalar(function() setConfigBool("InjectionGlobalDetecting", Config.InjectionGlobalDetecting) end)
                    persistScalar(function() setConfigBool("InjectionSpecialDetecting", Config.InjectionSpecialDetecting) end)
                end
                if settingsForPersist.spawn_config then
                    persistScalar(function() setConfigNumber("VehicleSpawnLimit", Config.VehicleSpawnLimit) end)
                    persistScalar(function() setConfigNumber("VehicleSpawnWindowMs", Config.VehicleSpawnWindowMs) end)
                    persistScalar(function() setConfigNumber("PedSpawnLimit", Config.PedSpawnLimit) end)
                    persistScalar(function() setConfigNumber("PedSpawnWindowMs", Config.PedSpawnWindowMs) end)
                    persistScalar(function() setConfigBool("AntiSpawnVehicleEnabled", Config.AntiSpawnVehicleEnabled) end)
                    persistScalar(function() setConfigBool("EnablePedWhitelist", Config.EnablePedWhitelist) end)
                end
                if settingsForPersist.client_config then
                    persistScalar(function() setConfigClientNumber("MAX ARMOUR", Config.Client and Config.Client["MAX ARMOUR"]) end)
                    persistScalar(function() setConfigClientNumber("Max Distance Teleporting", Config.Client and Config.Client["Max Distance Teleporting"]) end)
                    persistScalar(function() setConfigClientNumber("InfiniteAmmoMax", Config.Client and Config.Client["InfiniteAmmoMax"]) end)
                    persistScalar(function() setConfigClientNumber("InfiniteAmmoMin", Config.Client and Config.Client["InfiniteAmmoMin"]) end)
                    persistScalar(function() setConfigAntiAfkMax(Config.Client and Config.Client["AntiAFK"] and Config.Client["AntiAFK"].MaxAFKTime) end)
                end
            end
            writeFile(CONFIG_FILE, content)
            local nowMs = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
            if not _lastSettingsSyncLogAt or (nowMs - _lastSettingsSyncLogAt) > 2500 then
                _lastSettingsSyncLogAt = nowMs
                print("^1[VEXSHIELD]^7 » ^5CORE ENGINE^7 | ^2Security profile updated & synchronized with " .. tostring(CONFIG_FILE or "vex_config.lua") .. "^0")
            end
            if VexShieldReloadConfig then
                pcall(VexShieldReloadConfig)
            end
            isSavingConfigFile = false
            SetTimeout(2000, function()
                isApplyingDashboardSettings = false
            end)
        end)
    else
        success = true
        result = "No changes to apply"
    end

    return success, result
end

--- Remove GTA/FiveM color codes so dashboard names match GetPlayerName().
function stripFivemNameFormatting(s)
    if type(s) ~= "string" then return "" end
    local t = s:gsub("%^%d", ""):gsub("~[a-z]~", "")
    return (t:match("^%s*(.-)%s*$") or t)
end

function dashboardNameMatchesLive(wanted, liveName)
    if type(wanted) ~= "string" or wanted == "" or type(liveName) ~= "string" or liveName == "" then
        return false
    end
    return string.lower(stripFivemNameFormatting(wanted)) == string.lower(stripFivemNameFormatting(liveName))
end

--- Map dashboard live-view payload to a valid FiveM player source (handles stale/wrong numeric ids).
function resolveOnlinePlayerSource(cmdData)
    if type(cmdData) ~= "table" then return nil end
    local pid = tonumber(cmdData.source)
        or tonumber(cmdData.player_id)
        or tonumber(cmdData.player_id_str)
        or tonumber(cmdData.playerId)
    if pid and GetPlayerName(pid) then
        return pid
    end
    local wantedName = cmdData.player_name or cmdData.playerName
    if type(wantedName) == "string" then
        wantedName = wantedName:match("^%s*(.-)%s*$") or wantedName
        if wantedName ~= "" then
            for _, sid in ipairs(GetPlayers()) do
                local src = tonumber(sid)
                local n = GetPlayerName(src)
                if n and dashboardNameMatchesLive(wantedName, n) then
                    return src
                end
            end
        end
    end
    local wantedLic = cmdData.license or cmdData.playerLicense
    if type(wantedLic) == "string" then
        wantedLic = wantedLic:match("^%s*(.-)%s*$") or wantedLic
        if wantedLic ~= "" then
            local fullWanted = wantedLic:sub(1, 8) == "license:" and wantedLic or ("license:" .. wantedLic)
            local bareWanted = wantedLic:gsub("^license:", "")
            for _, sid in ipairs(GetPlayers()) do
                local src = tonumber(sid)
                local ids = GetPlayerIdentifiers(src) or {}
                for _, iden in ipairs(ids) do
                    if iden == wantedLic or iden == fullWanted or iden:gsub("^license:", "") == bareWanted then
                        return src
                    end
                end
            end
        end
    end
    -- Dashboard sent only peer_id / stale ids: if exactly one player is online, use them.
    local only = GetPlayers()
    if #only == 1 then
        local src = tonumber(only[1])
        if src and GetPlayerName(src) then
            return src
        end
    end
    return nil
end

local webLivePeerDedupe = {}
local WEB_PEER_DEDUPE_MS = 150
local WEB_PEER_REPUSH_MIN_MS = 700
local activeWebStreams = {} -- [targetSrc] = { peerId, signaling_mode, untilMs }

function stopWebStreamForSource(targetSrc)
    targetSrc = tonumber(targetSrc)
    if not targetSrc then return end
    activeWebStreams[targetSrc] = nil
    local prefix = tostring(targetSrc) .. "\1"
    for k in pairs(webLivePeerDedupe) do
        if type(k) == "string" and k:sub(1, #prefix) == prefix then
            webLivePeerDedupe[k] = nil
        end
    end
    TriggerClientEvent("VexShield:client:peerDissconnectMsgToStreamer", targetSrc)
end

function pushWebPeerStream(targetSrc, peerId, signalingMode, forceRetry)
    TriggerClientEvent("VexShield:client:requestPeerConnection", targetSrc, {
        targetSrc = targetSrc,
        peerId = peerId,
        signaling_mode = signalingMode or "cloud",
        fromWebDashboard = true,
        forceRetry = forceRetry == true,
    }, 0)
end

function ensureWebStreamLoop(targetSrc, peerId, signalingMode)
    targetSrc = tonumber(targetSrc)
    if not targetSrc or not peerId or peerId == "" then return end
    local nowMs = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
    local existing = activeWebStreams[targetSrc]
    if existing and existing.peerId == peerId and existing.loopRunning then
        existing.untilMs = nowMs + 90000
        existing.signaling_mode = signalingMode or existing.signaling_mode or "cloud"
        -- Browser retries mean the previous WebRTC call reached the viewer but produced no frames
        -- or closed. Re-push immediately instead of waiting up to 12s for the keepalive loop.
        if not existing.lastPushAt or (nowMs - existing.lastPushAt) >= WEB_PEER_REPUSH_MIN_MS then
            existing.lastPushAt = nowMs
            pushWebPeerStream(targetSrc, peerId, existing.signaling_mode, true)
        end
        return
    end
    activeWebStreams[targetSrc] = {
        peerId = peerId,
        signaling_mode = signalingMode or "cloud",
        untilMs = nowMs + 90000,
        loopRunning = true,
        lastPushAt = nowMs,
    }
    pushWebPeerStream(targetSrc, peerId, signalingMode, false)
    CreateThread(function()
        while true do
            Wait(12000)
            local state = activeWebStreams[targetSrc]
            if not state or state.peerId ~= peerId then break end
            local tick = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
            if tick > state.untilMs then break end
            if not GetPlayerName(targetSrc) then break end
            state.lastPushAt = tick
            pushWebPeerStream(targetSrc, peerId, state.signaling_mode, false)
        end
        local state = activeWebStreams[targetSrc]
        if state and state.peerId == peerId then
            state.loopRunning = false
        end
    end)
end

local pollDashboardCommands

function handleDashboardCommand(cmd)
    local cmdId = cmd.id
    local cmdType = cmd.command_type
    local cmdData = cmd.command_data or {}
    if type(cmdData) == "string" then
        cmdData = jsonDecode(cmdData) or {}
    end
    
    
    local success = false
    local result = "Unknown"
    
    if cmdType == "kick" then
        local pid = tonumber(cmdData.player_id)
        local reason = cmdData.reason or "Kicked by dashboard"
        
        if pid and GetPlayerName(pid) then
            DropPlayer(pid, "[VexShield] " .. reason)
            success = true
            result = "Kicked player " .. GetPlayerName(pid)
        else
            result = "Player not found"
        end
        
    elseif cmdType == "ban" then
        local targetSource = tonumber(cmdData.player_id or 0)
        local reason = cmdData.reason or "Banned by dashboard"
        local playerName = cmdData.player_name or "Unknown"
        local license = cmdData.license or ""
        
        -- Get real identifiers if player is online
        local collectedIp, collectedDiscord, collectedSteam, collectedFivem, collectedXbl = nil, nil, nil, nil, nil
        if targetSource and targetSource > 0 and GetPlayerName(targetSource) then
            playerName = GetPlayerName(targetSource)
            local identifiers = GetPlayerIdentifiers(targetSource) or {}
            for _, id in ipairs(identifiers) do
                if id:match("^license:") and license == "" then
                    license = id
                elseif id:match("^ip:") then
                    collectedIp = id:sub(4)
                elseif id:match("^discord:") then
                    collectedDiscord = id
                elseif id:match("^steam:") then
                    collectedSteam = id
                elseif id:match("^fivem:") then
                    collectedFivem = id
                elseif id:match("^xbl:") then
                    collectedXbl = id
                end
            end
            -- Drop player immediately
            DropPlayer(targetSource, "[VexShield] " .. reason)
        end
        
        if license == "" then
            result = "Cannot ban: player license not available yet"
            success = false
        else
        local ok, banId = addOrUpdateBanToFile({
            license = license,
            playerName = playerName,
            reason = reason,
            admin = "Dashboard",
            mode = "Manuel",
            ip = collectedIp,
            discord = collectedDiscord,
            steam = collectedSteam,
            fivem = collectedFivem,
            xbl = collectedXbl
        })
        
        if ok then
            success = true
            result = "Banned " .. playerName .. " (ID: " .. tostring(banId) .. ")"
        else
            result = "Failed to ban: " .. tostring(banId)
        end
        end
        
    elseif cmdType == "unban" then
        -- UNBAN: Remove from ban.json and sync to dashboard
        
        local content = readBanJsonDisk()
        local bans = jsonDecode(content) or {}
        local newBans = {}
        local found = false
        local unbannedPlayer = "Unknown"
        
        -- Extract all possible identifiers from command
        local cmdBanId = tostring(cmdData.ban_id or cmdData.id or "")
        local cmdPlayerId = tostring(cmdData.player_id or "")
        local cmdPlayerName = tostring(cmdData.player_name or "")
        local cmdLicense = tostring(cmdData.license or "")
        local cmdFivem = tostring(cmdData.fivem or "")
        local cmdDiscord = tostring(cmdData.discord or "")
        local cmdSteam = tostring(cmdData.steam or "")
        
        
        for _, ban in ipairs(bans) do
            local match = false
            
            -- Extract identifiers from this ban entry
            local banId = tostring(ban.id or ban.BANID or ban.ban_id or "")
            local banLicense = tostring(ban.license or ban.LICENSE or "")
            local banLicense2 = tostring(ban.license2 or "")
            local banPlayerId = tostring(ban.player_id or "")
            local banFivem = tostring(ban.fivem or "")
            local banDiscord = tostring(ban.discord or "")
            local banSteam = tostring(ban.steam or "")
            local banPlayer = tostring(ban.player or "")
            local banPlayerName = tostring(ban.player_name or "")
            local banName = tostring(ban.name or "")
            
            -- Strict match logic
            local foundById = (cmdBanId ~= "" and banId == cmdBanId)
            local foundByLicense = (cmdLicense ~= "" and (banLicense == cmdLicense or banLicense2 == cmdLicense or banPlayerId == cmdLicense))
            local foundByFivem = (cmdFivem ~= "" and cmdFivem ~= "Onbekend" and banFivem == cmdFivem)
            local foundByDiscord = (cmdDiscord ~= "" and cmdDiscord ~= "Onbekend" and banDiscord == cmdDiscord)
            local foundBySteam = (cmdSteam ~= "" and cmdSteam ~= "Onbekend" and banSteam == cmdSteam)
            
            -- Only match by name if we have absolutely nothing else, and name isn't "Unknown"
            local foundByName = false
            if cmdPlayerName ~= "" and cmdPlayerName ~= "Unknown" and cmdBanId == "" and cmdLicense == "" and cmdDiscord == "" then
                if banPlayer == cmdPlayerName or banPlayerName == cmdPlayerName or banName == cmdPlayerName then
                    foundByName = true
                end
            end
            
            if foundById or foundByLicense or foundByFivem or foundByDiscord or foundBySteam or foundByName then
                match = true
            end
            
            if not match then
                table.insert(newBans, ban)
            else
                found = true
                unbannedPlayer = banName ~= "" and banName or (banPlayerName ~= "" and banPlayerName or (banPlayer ~= "" and banPlayer or cmdPlayerName))
                if unbannedPlayer == "" then unbannedPlayer = "Unknown" end
                
                clearBanListKeysForBan(ban)
            end
        end
        
        if found then
            -- Write updated bans back to ban.json
            local uenc = jsonEncode(newBans)
            if uenc then
                writeBanJsonFile(uenc, true)
            end
            
            -- Add unban to logs.json
            local logsContent = readFile(LOGS_FILE)
            local logs = jsonDecode(logsContent) or {}
            local maxLogId = 0
            for _, l in ipairs(logs) do
                if (l.id or 0) > maxLogId then maxLogId = l.id end
            end
            table.insert(logs, {
                id = maxLogId + 1,
                type = "UNBAN_PLAYER",
                ts = os.time(),
                player = unbannedPlayer,
                details = "Unbanned by Dashboard",
                admin = "Dashboard"
            })
            writeFile(LOGS_FILE, jsonEncodeOrFallback(logs, "[]"))
            
            success = true
            result = "Unbanned " .. tostring(unbannedPlayer)
            
            -- CRITICAL: Immediately sync to dashboard so database matches ban.json
            lastSyncedBanFingerprint = nil
            syncBansToSupabase(true, true)
        else
            result = "Ban not found in ban.json"
        end
        
    elseif cmdType == "warn" then
        local pid = tonumber(cmdData.player_id)
        local reason = cmdData.reason or "Warning from dashboard"
        
        if pid and GetPlayerName(pid) then
            TriggerClientEvent("chat:addMessage", pid, {
                color = {255, 165, 0},
                multiline = true,
                args = {"[VexShield Warning]", reason}
            })
            
            -- Add to logs.json
            local logsContent = readFile(LOGS_FILE)
            local logs = jsonDecode(logsContent) or {}
            local maxLogId = 0
            for _, l in ipairs(logs) do
                if (l.id or 0) > maxLogId then maxLogId = l.id end
            end
            table.insert(logs, {
                id = maxLogId + 1,
                type = "WARN_PLAYER",
                ts = os.time(),
                player = GetPlayerName(pid),
                details = reason,
                admin = "Dashboard"
            })
            writeFile(LOGS_FILE, jsonEncodeOrFallback(logs, "[]"))
            
            success = true
            result = "Warned player " .. GetPlayerName(pid)
        else
            result = "Player not found"
        end

    elseif cmdType == "blacklist_block" then
        local enabled = cmdData.enabled
        if enabled == nil then enabled = cmdData.blacklist_block_enabled end
        if applyBlacklistBlockToggle(enabled) then
            success = true
            result = "Blacklist block " .. (blacklistBlockEnabled and "enabled" or "disabled")
        else
            result = "Missing enabled flag"
        end
    
    elseif cmdType == "update_settings" then
        -- Apply settings from dashboard to Config and persist to config.lua
        local settings = cmdData.settings or {}
        if type(settings) == "string" then
            settings = jsonDecode(settings) or {}
        end

        if cmdData.fetch_settings or not settings or next(settings) == nil then
            httpPost(API_URL, {
                server_id = SERVER_ID,
                server_ip = SERVER_IP,
                license_key = LICENSE_KEY,
                report_type = "get_settings"
            }, function(status, response)
                if status == 200 then
                    local data = jsonDecode(response) or {}
                    if data.server_id and tostring(data.server_id) ~= "" then
                        SERVER_ID = tostring(data.server_id)
                    end
                    local payload = data.settings or {}
                    if type(payload) == "string" then
                        payload = jsonDecode(payload) or {}
                    end
                    if data.anti_objects then payload.anti_objects = data.anti_objects end
                    if data.anti_blackwords then payload.anti_blackwords = data.anti_blackwords end
                    if data.admin_json then applyAdminJsonFromDashboard(data.admin_json) end
                    CreateThread(function()
                        Wait(0)
                        local appliedOk, appliedRes = applySettingsFromDashboard(payload)
                        httpPost(API_URL, {
                            server_ip = SERVER_IP,
                            license_key = LICENSE_KEY,
                            report_type = "command_result",
                            command_id = cmdId,
                            success = appliedOk,
                            result = appliedRes
                        })
                    end)
                else
                    httpPost(API_URL, {
                        server_ip = SERVER_IP,
                        license_key = LICENSE_KEY,
                        report_type = "command_result",
                        command_id = cmdId,
                        success = false,
                        result = "Failed to fetch settings (HTTP " .. tostring(status) .. ")"
                    })
                end
            end)
            return true
        end

        CreateThread(function()
            Wait(0)
            success, result = applySettingsFromDashboard(settings)
            httpPost(API_URL, {
                server_ip = SERVER_IP,
                license_key = LICENSE_KEY,
                report_type = "command_result",
                command_id = cmdId,
                success = success,
                result = result
            })
        end)
        return true

    elseif cmdType == "update_admin_json" then
        local adminJson = cmdData.admin_json or cmdData
        if type(adminJson) == "string" then
            adminJson = jsonDecode(adminJson) or {}
        end
        if type(adminJson) ~= "table" then
            result = "Invalid admin_json payload"
        elseif applyAdminJsonFromDashboard(adminJson, { allowEmpty = true, syncDashboard = true }) then
            success = true
            result = "admin.json updated (admins/VexMenu)"
        else
            success = true
            result = "admin.json unchanged"
        end

    elseif cmdType == "air_update" then
        CreateThread(function()
            Wait(0)
            local ok, res = false, "VexShieldRunUpdate not loaded"
            if type(VexShieldRunUpdate) == "function" then
                ok, res = VexShieldRunUpdate(true)
            end
            success = ok
            result = res or (ok and "Update completed" or "Update failed")
            httpPost(API_URL, {
                server_ip = SERVER_IP,
                license_key = LICENSE_KEY,
                report_type = "command_result",
                command_id = cmdId,
                success = success,
                result = result,
            })
        end)
        return true
        
    elseif cmdType == "execute_command" then
        local command = cmdData.command
        if command and command ~= "" then
            enqueueConsole("[Dashboard] > " .. tostring(command))
            ExecuteCommand(command)
            success = true
            result = "Executed command: " .. command
        else
            result = "Missing command"
        end
        
    elseif cmdType == "delete_vehicles" or cmdType == "delete_all_vehicles" then
        local deleted = 0
        local scanned = 0
        local vehicles = {}

        if GetAllVehicles then
            vehicles = GetAllVehicles() or {}
        else
            for veh in EnumerateVehicles() do
                table.insert(vehicles, veh)
            end
        end

        for _, veh in ipairs(vehicles) do
            if DoesEntityExist(veh) then
                scanned = scanned + 1
                if SetEntityAsMissionEntity then pcall(SetEntityAsMissionEntity, veh, true, true) end
                if DeleteEntity then pcall(DeleteEntity, veh) end
                if DeleteVehicle then pcall(DeleteVehicle, veh) end
                if not DoesEntityExist(veh) then
                    deleted = deleted + 1
                end
            end
        end

        success = true
        result = "Deleted " .. deleted .. " / " .. scanned .. " vehicles"

    elseif cmdType == "delete_npcs" or cmdType == "delete_all_npcs" then
        local deleted = 0
        local scanned = 0
        local peds = {}

        if GetAllPeds then
            peds = GetAllPeds() or {}
        else
            for ped in EnumeratePeds() do
                table.insert(peds, ped)
            end
        end

        for _, ped in ipairs(peds) do
            if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                scanned = scanned + 1
                if SetEntityAsMissionEntity then pcall(SetEntityAsMissionEntity, ped, true, true) end
                if DeleteEntity then pcall(DeleteEntity, ped) end
                if DeletePed then pcall(DeletePed, ped) end
                if not DoesEntityExist(ped) then
                    deleted = deleted + 1
                end
            end
        end

        success = true
        result = "Deleted " .. deleted .. " / " .. scanned .. " NPCs"

    elseif cmdType == "delete_objects" or cmdType == "delete_all_objects" then
        local deleted = 0
        local scanned = 0
        local objects = {}

        if GetAllObjects then
            objects = GetAllObjects() or {}
        else
            for obj in EnumerateObjects() do
                table.insert(objects, obj)
            end
        end

        for _, obj in ipairs(objects) do
            if DoesEntityExist(obj) then
                scanned = scanned + 1
                if SetEntityAsMissionEntity then pcall(SetEntityAsMissionEntity, obj, true, true) end
                if DeleteEntity then pcall(DeleteEntity, obj) end
                if DeleteObject then pcall(DeleteObject, obj) end
                if not DoesEntityExist(obj) then
                    deleted = deleted + 1
                end
            end
        end

        success = true
        result = "Deleted " .. deleted .. " / " .. scanned .. " objects"

    elseif cmdType == "start_monitoring" then
        local pid = tonumber(cmdData.player_id)
        if pid and GetPlayerName(pid) then
            monitoredPlayers[tostring(pid)] = true
            lastFrameRequestAt[pid] = 0
            success = true
            result = "Started monitoring player " .. GetPlayerName(pid)
        else
            result = "Player not found"
        end

    elseif cmdType == "stop_monitoring" then
        local pid = tonumber(cmdData.player_id)
        if pid then
            monitoredPlayers[tostring(pid)] = nil
            lastFrameRequestAt[pid] = nil
            success = true
            result = "Stopped monitoring player " .. tostring(pid)
        else
            result = "Missing player_id"
        end

    -- Web dashboard live view: same WebRTC path as html/ac-air_index (PeerJS viewer in browser).
    elseif cmdType == "request_peer_stream" then
        local peerId = tostring(cmdData.peer_id or cmdData.peerId or "")
        local signalingMode = tostring(cmdData.signaling_mode or cmdData.signalingMode or "cloud")
        local targetSrc = resolveOnlinePlayerSource(cmdData)
        if targetSrc and peerId ~= "" then
            local dedupeKey = tostring(targetSrc) .. "\1" .. peerId
            local nowMs = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
            local lastAt = webLivePeerDedupe[dedupeKey]
            if lastAt and (nowMs - lastAt) < WEB_PEER_DEDUPE_MS then
                success = true
                result = "Peer stream request deduplicated"
            else
                webLivePeerDedupe[dedupeKey] = nowMs
                ensureWebStreamLoop(targetSrc, peerId, signalingMode)
                success = true
                result = "Peer stream requested for player " .. tostring(targetSrc)
            end
        else
            result = "Invalid player_id or peer_id (or player not found; try refreshing player list)"
        end

    elseif cmdType == "stop_peer_stream" then
        local targetSrc = resolveOnlinePlayerSource(cmdData)
        if targetSrc then
            stopWebStreamForSource(targetSrc)
            success = true
            result = "Stopped peer stream for player " .. tostring(targetSrc)
        else
            result = "Missing player or could not resolve player for stop_peer_stream"
        end

    elseif cmdType == "unban_blacklist" then
        -- GLOBAL UNBAN BLACKLIST: Remove discord_blacklist bans from ban.json
        local discordId = cmdData.discord_id
        
        if not discordId or discordId == "" then
            result = "Missing discord_id"
        else
            local content = readBanJsonDisk()
            local bans = jsonDecode(content) or {}
            local newBans = {}
            local removed = 0
            
            for _, ban in ipairs(bans) do
                local banDiscord = tostring(ban.discord or "")
                local banPlayerId = tostring(ban.player_id or "")
                local banReason = tostring(ban.reason or ban.details or "")
                
                -- Match by discord identifier or if it's a blacklist ban for this discord
                local isBlacklistBan = banReason:lower():find("blacklist") ~= nil
                local matchesDiscord = (banDiscord == ("discord:" .. discordId)) 
                    or (banDiscord == discordId)
                    or (banPlayerId == ("discord:" .. discordId))
                
                if isBlacklistBan and matchesDiscord then
                    removed = removed + 1
                    clearBanListKeysForBan(ban)
                else
                    table.insert(newBans, ban)
                end
            end
            
            if removed > 0 then
                local blenc = jsonEncode(newBans)
                if blenc then
                    writeBanJsonFile(blenc)
                end
                success = true
                result = "Removed " .. removed .. " blacklist ban(s)"
            else
                success = true
                result = "No blacklist bans found for this discord"
            end
        end
        
    elseif cmdType == "start_resource" then
        local resourceName = cmdData.resource_name
        if resourceName and resourceName ~= "" then
            local state = GetResourceState(resourceName)
            if state == "stopped" then
                StartResource(resourceName)
                success = true
                result = "Started resource: " .. resourceName
            else
                success = true
                result = "Resource " .. resourceName .. " is already " .. state
            end
        else
            result = "Missing resource_name"
        end
        
    elseif cmdType == "stop_resource" then
        local resourceName = cmdData.resource_name
        if resourceName and resourceName ~= "" then
            local state = GetResourceState(resourceName)
            if state == "started" then
                StopResource(resourceName)
                success = true
                result = "Stopped resource: " .. resourceName
            else
                success = true
                result = "Resource " .. resourceName .. " is already " .. state
            end
        else
            result = "Missing resource_name"
        end
        
    elseif cmdType == "restart_resource" then
        local resourceName = cmdData.resource_name
        if resourceName and resourceName ~= "" then
            local currentState = GetResourceState(resourceName)
            if currentState == "started" then
                StopResource(resourceName)
                Wait(500)
            end
            StartResource(resourceName)
            success = true
            result = "Restarted resource: " .. resourceName
        else
            result = "Missing resource_name"
        end
        
    elseif cmdType == "sync_resources" then
        if canSyncDashboard() then
            syncResourcesToDashboard()
            success = true
            result = "Resources sync initiated"
        else
            result = "Missing license_key or server_ip"
        end
        
    elseif cmdType == "get_resources" then
        if canSyncDashboard() then
            local resources = {}
            local total = GetNumResources()
            
            for i = 0, total - 1 do
                local name = GetResourceByFindIndex(i)
                if name and name ~= RESOURCE_NAME then
                    local state = GetResourceState(name)
                    table.insert(resources, {
                        name = name,
                        status = string.lower(state or "stopped"),
                        type = "existing"
                    })
                end
            end
            
            success = true
            result = jsonEncodeOrFallback({ resources = resources, count = #resources }, "{}")
        else
            result = "Missing license_key or server_ip"
        end
    else
        result = "Unknown command: " .. tostring(cmdType)
    end
    
    -- Report result back to dashboard
    httpPost(API_URL, {
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "command_result",
        command_id = cmdId,
        success = success,
        result = result
    })

    -- Instant follow-up poll so dashboard commands never wait for the next interval tick.
    CreateThread(function()
        Wait(0)
        pollDashboardCommands()
    end)
    
    return success
end

pollDashboardCommands = function()
    if not canSyncDashboard() then return end
    
    httpPost(API_URL, {
        server_id = SERVER_ID,
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "poll_commands"
    }, function(status, response)
        if status ~= 200 then
            return
        end
        
        local data = jsonDecode(response)
        if not data then return end
        if data.server_id and tostring(data.server_id) ~= "" then
            SERVER_ID = tostring(data.server_id)
        end

        if data.admin_json then
            local nowMs = (GetGameTimer and GetGameTimer()) or 0
            if nowMs - lastAdminJsonPollApplyAt >= ADMIN_JSON_POLL_MIN_MS then
                if applyAdminJsonFromDashboard(data.admin_json) then
                    lastAdminJsonPollApplyAt = nowMs
                end
            end
        end

        if not data.commands or #data.commands == 0 then return end
        
        
        for _, cmd in ipairs(data.commands) do
            CreateThread(function()
                Wait(0)
                local ok, err = pcall(handleDashboardCommand, cmd)
                if not ok then
                    httpPost(API_URL, {
                        server_ip = SERVER_IP,
                        license_key = LICENSE_KEY,
                        report_type = "command_result",
                        command_id = cmd.id,
                        success = false,
                        result = "Command failed: " .. tostring(err)
                    })
                end
            end)
        end
    end)
end

-- =============================================================================
-- EVENT HANDLERS
-- =============================================================================

RegisterNetEvent('VexShield:addBan')
AddEventHandler('VexShield:addBan', function(payload)
    local p = payload or {}

    local targetSource = tonumber(p.player_id or p.source or 0)
    local playerName = tostring(p.playerName or p.player_name or p.player or "Unknown")
    local reason = tostring(p.reason or p.details or "Banned")
    local admin = tostring(p.admin or p.banned_by or "Anticheat")
    local mode = tostring(p.mode or "Anticheat")

    local license = tostring(p.license or p.player_id_license or "")
    local collectedIp, collectedDiscord, collectedSteam, collectedFivem, collectedXbl = nil, nil, nil, nil, nil

    if targetSource and targetSource > 0 and GetPlayerName(targetSource) then
        playerName = GetPlayerName(targetSource) or playerName
        local identifiers = GetPlayerIdentifiers(targetSource) or {}
        for _, id in ipairs(identifiers) do
            if id:match("^license:") and license == "" then
                license = id
            elseif id:match("^ip:") then
                collectedIp = id:sub(4)
            elseif id:match("^discord:") then
                collectedDiscord = id
            elseif id:match("^steam:") then
                collectedSteam = id
            elseif id:match("^fivem:") then
                collectedFivem = id
            elseif id:match("^xbl:") then
                collectedXbl = id
            end
        end

        if license == "" then
            license = tostring(targetSource)
        end

        DropPlayer(targetSource, "[VexShield] " .. reason)
    end

    addOrUpdateBanToFile({
        license = license,
        playerName = playerName,
        reason = reason,
        admin = admin,
        mode = mode,
        ip = p.ip or collectedIp,
        discord = p.discord or collectedDiscord,
        steam = p.steam or collectedSteam,
        fivem = p.fivem or collectedFivem,
        xbl = p.xbl or collectedXbl
    })
end)

exports('AddBan', function(payload)
    TriggerEvent('VexShield:addBan', payload)
end)

-- =============================================================================
-- GLOBAL BLACKLIST (API: entries[].identifiers + banDetails.reason)
-- =============================================================================

local DEFAULT_GLOBAL_BAN_REASON = "Global blacklist"

function collectGlobalBanUrls()
    local seen = {}
    local urls = {}
    local function push(u)
        if type(u) ~= "string" or u == "" or seen[u] then return end
        seen[u] = true
        urls[#urls + 1] = u
    end
    push(PUBLIC_API_BASE .. GLOBAL_STATE_PATH)
    push("https://www.vexshield.net" .. GLOBAL_STATE_PATH)
    local direct = licenseApiOrigin()
    if direct ~= "" then
        push(direct .. GLOBAL_STATE_PATH)
    end
    if API_BASE and API_BASE ~= "" then
        push(API_BASE .. GLOBAL_STATE_PATH)
    end
    push("http://vexshield.net" .. GLOBAL_STATE_PATH)
    push("http://www.vexshield.net" .. GLOBAL_STATE_PATH)
    return urls
end

function isInvalidGlobalBanIdentifier(val)
    if val == nil then return true end
    local s = tostring(val):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if s == "" or s == "null" then return true end
    return s == "not provided" or s == "no linked" or s == "hidden"
        or s == "n/a" or s == "na" or s == "none" or s == "unknown"
end

function normalizeGlobalBanLicense(lic)
    if isInvalidGlobalBanIdentifier(lic) then return nil end
    local s = tostring(lic):lower():gsub("^license:", ""):gsub("^license2:", "")
    if s == "" or isInvalidGlobalBanIdentifier(s) then return nil end
    return s
end

function normalizeGlobalBanDiscord(disc)
    if isInvalidGlobalBanIdentifier(disc) then return nil end
    local s = tostring(disc):lower():gsub("^discord:", "")
    if s == "" or isInvalidGlobalBanIdentifier(s) then return nil end
    return s
end

function normalizeGlobalBanSteam(steam)
    if isInvalidGlobalBanIdentifier(steam) then return nil end
    local s = tostring(steam):lower():gsub("^steam:", "")
    if s == "" or isInvalidGlobalBanIdentifier(s) then return nil end
    return s
end

function makeGlobalBanMeta(reason, ids, ban, playerInfo)
    local screenshotUrl = nil
    if type(ban) == "table" and type(ban.screenshotUrls) == "table" then
        screenshotUrl = ban.screenshotUrls[1]
    end
    return {
        reason = (reason and tostring(reason) ~= "") and tostring(reason) or DEFAULT_GLOBAL_BAN_REASON,
        serverName = (type(ban) == "table" and ban.serverName and tostring(ban.serverName) ~= "") and tostring(ban.serverName) or "—",
        addedAt = type(ban) == "table" and ban.addedAt or nil,
        banType = type(ban) == "table" and ban.type or "Global",
        license = ids and ids.license or nil,
        discord = ids and ids.discord or nil,
        steam = ids and ids.steam or nil,
        playerName = type(playerInfo) == "table" and playerInfo.name or nil,
        screenshotUrl = screenshotUrl,
    }
end

function addGlobalBanToSets(reason, discordRaw, licenseRaw, steamRaw, ban, playerInfo)
    local meta = makeGlobalBanMeta(reason, {
        license = licenseRaw,
        discord = discordRaw,
        steam = steamRaw,
    }, ban, playerInfo)
    local did = normalizeGlobalBanDiscord(discordRaw)
    if did then globalBanDiscordSet[did] = meta end
    local nl = normalizeGlobalBanLicense(licenseRaw)
    if nl then globalBanLicenseSet[nl] = meta end
    local st = normalizeGlobalBanSteam(steamRaw)
    if st then globalBanSteamSet[st] = meta end
end

function globalBanPayloadValid(data)
    return data and (type(data.entries) == "table" or type(data.blacklisted_users) == "table")
end

function rebuildGlobalBanSetsFromData(data)
    globalBanDiscordSet = {}
    globalBanLicenseSet = {}
    globalBanSteamSet = {}
    if not data then return end

    local processed = 0
    local function maybeYield()
        processed = processed + 1
        if processed % 400 == 0 then
            Wait(0)
        end
    end

    if type(data.entries) == "table" then
        for _, entry in ipairs(data.entries) do
            maybeYield()
            if type(entry) == "table" then
                local ids = entry.identifiers
                local ban = entry.banDetails
                local reason = (type(ban) == "table" and ban.reason) or DEFAULT_GLOBAL_BAN_REASON
                if type(ids) == "table" then
                    addGlobalBanToSets(reason, ids.discord, ids.license, ids.steam, ban, entry.playerInfo)
                end
            end
        end
        return
    end

    if type(data.blacklisted_users) == "table" then
        for _, u in ipairs(data.blacklisted_users) do
            maybeYield()
            if type(u) == "table" then
                addGlobalBanToSets(u.reason, u.discord_id, u.license, u.steam)
            end
        end
    end
end

function globalBanCacheFresh()
    return (os.time() - lastGlobalBanSnapshotAt) < GLOBAL_BAN_CACHE_INTERVAL
end

function fetchGlobalBanList(callback)
    if globalBanFetchInProgress then
        if callback then callback(false) end
        return
    end
    globalBanFetchInProgress = true
    local urls = collectGlobalBanUrls()
    local function finish(ok)
        globalBanFetchInProgress = false
        if ok then
            lastGlobalBanSnapshotAt = os.time()
        end
        if callback then callback(ok == true) end
    end
    local function attempt(i)
        if i > #urls then
            finish(false)
            return
        end
        PerformHttpRequest(urls[i], function(status, response)
            if status == 200 and response and response ~= "" then
                local body = response
                CreateThread(function()
                    local parsed = jsonDecode(body)
                    if globalBanPayloadValid(parsed) then
                        rebuildGlobalBanSetsFromData(parsed)
                        finish(true)
                    else
                        attempt(i + 1)
                    end
                end)
                return
            end
            attempt(i + 1)
        end, "GET", "")
    end
    attempt(1)
end

function formatGlobalBanRelativeTime(iso)
    if not iso or iso == "" then return "Unknown" end
    local y, mo, d, h, mi, s = tostring(iso):match("^(%d+)-(%d+)-(%d+)T(%d+):(%d+):(%d+)")
    if not y then return tostring(iso) end
    local addedAt = os.time({
        year = tonumber(y),
        month = tonumber(mo),
        day = tonumber(d),
        hour = tonumber(h),
        min = tonumber(mi),
        sec = tonumber(s),
    })
    if not addedAt then return tostring(iso) end
    local elapsed = os.difftime(os.time(), addedAt)
    if elapsed < 60 then return "Just now" end
    if elapsed < 3600 then return math.floor(elapsed / 60) .. " minutes ago" end
    if elapsed < 86400 then return math.floor(elapsed / 3600) .. " hours ago" end
    if elapsed < 2592000 then return math.floor(elapsed / 86400) .. " days ago" end
    if elapsed < 31536000 then return math.floor(elapsed / 2592000) .. " months ago" end
    return math.floor(elapsed / 31536000) .. " years ago"
end

function formatGlobalBanLicenseDisplay(licenseVal)
    if isInvalidGlobalBanIdentifier(licenseVal) then return "Not Provided" end
    return tostring(licenseVal)
end

function buildGlobalBlacklistDeferralCard(playerName, discordId, meta)
    meta = meta or {}
    local serverLogoUrl = Config and Config.ServerLogo
    local name = Config and Config.Servername
    local showHeader = (serverLogoUrl and serverLogoUrl ~= "") or (name and name ~= "" and name ~= "Server Name")
    local VexShieldLogoUrl = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless'
    
    local reason = (meta and meta.reason and meta.reason ~= "" and meta.reason ~= "Unknown") and meta.reason or "Global Security Blacklist Enforcement"
    if #reason > 280 then
        reason = reason:sub(1, 277) .. "..."
    end

    local leftColumnItems = {
        -- VexShield Main Title Header
        DeferralCards.CardElement:TextBlock({
            text = "VexShield",
            weight = "Bolder",
            size = "ExtraLarge",
            horizontalAlignment = "Center",
            spacing = "Medium"
        }),

        -- Blacklist Identifier Badge
        DeferralCards.CardElement:TextBlock({
            text = "Global Security Restriction",
            color = "Subtle",
            weight = "Bolder",
            size = "Medium",
            horizontalAlignment = "Center",
            spacing = "Small"
        }),

        -- Yellow Warning Line
        DeferralCards.CardElement:TextBlock({
            text = "Account Blacklisted by VexShield Protection",
            color = "Warning",
            weight = "Bolder",
            size = "Medium",
            horizontalAlignment = "Center",
            spacing = "Medium"
        }),

        -- Red Primary Impact Message with Reason
        DeferralCards.CardElement:TextBlock({
            text = "Reason: " .. reason,
            color = "Attention",
            weight = "Bolder",
            size = "Large",
            wrap = true,
            horizontalAlignment = "Center",
            spacing = "Medium"
        }),

        -- Support Explanation
        DeferralCards.CardElement:TextBlock({
            text = "Your account or identifiers are flagged on the VexShield Global Blacklist database. Access to this server ecosystem is permanently restricted.",
            color = "Subtle",
            weight = "Lighter",
            size = "Small",
            wrap = true,
            horizontalAlignment = "Center",
            spacing = "Medium"
        })
    }

    if meta.screenshotUrl and meta.screenshotUrl ~= "" then
        table.insert(leftColumnItems, DeferralCards.CardElement:TextBlock({
            text = "Security Telemetry Evidence:",
            weight = "Bolder",
            size = "Small",
            horizontalAlignment = "Center",
            spacing = "Small"
        }))
        table.insert(leftColumnItems, DeferralCards.CardElement:Image({
            url = meta.screenshotUrl,
            size = "Medium",
            horizontalAlignment = "Center",
            height = "100px"
        }))
    end

    -- Action Buttons (Row 1: VexShield & Support Discord)
    table.insert(leftColumnItems, DeferralCards.Container:ActionSet({
        actions = {
            DeferralCards.Action:OpenUrl({
                url = 'https://vexshield.com/',
                size = 'Medium',
                id = 'vexshield_website',
                title = 'VexShield'
            }),
            DeferralCards.Action:OpenUrl({
                url = 'https://discord.gg/vPjntrd3nY',
                size = 'Medium',
                id = 'vexshield_discord',
                title = 'Support Discord'
            })
        },
        horizontalAlignment = 'Center',
        spacing = 'Medium'
    }))

    -- Action Buttons (Row 2: Server Discord)
    table.insert(leftColumnItems, DeferralCards.Container:ActionSet({
        actions = {
            DeferralCards.Action:OpenUrl({
                url = (Config and Config.Discordinvite) or 'https://discord.gg',
                size = 'Medium',
                id = 'server_discord',
                title = 'Server Discord'
            })
        },
        horizontalAlignment = 'Center',
        spacing = 'Small'
    }))

    local mainBodyColumns = {
        -- Left Column: Text & Buttons
        DeferralCards.Container:Column({
            width = 'stretch',
            items = leftColumnItems
        }),
        -- Right Column: VexShield Logo Image
        DeferralCards.Container:Column({
            width = 'auto',
            verticalContentAlignment = 'Center',
            items = {
                DeferralCards.CardElement:Image({
                    url = VexShieldLogoUrl,
                    size = 'Large',
                    height = '230px'
                })
            }
        })
    }

    local items = {}

    if showHeader then
        table.insert(items, DeferralCards.Container:ColumnSet({
            columns = {
                DeferralCards.Container:Column({
                    width = 'auto',
                    items = {
                        DeferralCards.CardElement:Image({
                            url = serverLogoUrl or VexShieldLogoUrl,
                            size = 'Small',
                            height = '35px'
                        })
                    }
                }),
                DeferralCards.Container:Column({
                    width = 'stretch',
                    verticalContentAlignment = 'Center',
                    items = {
                        DeferralCards.CardElement:TextBlock({
                            text = name or "",
                            weight = 'Bolder',
                            size = 'Large',
                            wrap = true
                        })
                    }
                })
            },
            spacing = 'Medium'
        }))
    end

    table.insert(items, DeferralCards.Container:ColumnSet({
        columns = mainBodyColumns,
        spacing = 'Large'
    }))

    table.insert(items, DeferralCards.CardElement:TextBlock({
        text = "Disclaimer: UI above has been provided by the server and is not part of the FiveM UI",
        color = 'Subtle',
        weight = 'Lighter',
        size = 'Small',
        horizontalAlignment = 'Center',
        spacing = 'Large'
    }))

    return DeferralCards.Card:Create({
        body = {
            DeferralCards.Container:Create({
                items = items,
                isVisible = true
            })
        }
    })
end

function checkGlobalBlacklist(discordId, lic1, lic2, steamHex)
    if discordId and discordId ~= "" and globalBanDiscordSet[discordId] then
        return true, globalBanDiscordSet[discordId]
    end
    if steamHex and steamHex ~= "" and globalBanSteamSet[steamHex] then
        return true, globalBanSteamSet[steamHex]
    end
    if lic1 then
        local n = normalizeGlobalBanLicense(lic1)
        if n and globalBanLicenseSet[n] then
            return true, globalBanLicenseSet[n]
        end
    end
    if lic2 then
        local n2 = normalizeGlobalBanLicense(lic2)
        if n2 and globalBanLicenseSet[n2] then
            return true, globalBanLicenseSet[n2]
        end
    end
    return false, nil
end

-- =============================================================================
-- BLACKLISTED DISCORD SERVERS CHECK
-- =============================================================================

-- Fetch blacklisted servers from API (with caching)
function fetchBlacklistedServers()
    local now = os.time()
    if now - lastBlacklistFetch < BLACKLIST_CACHE_INTERVAL and #blacklistedServersCache > 0 then
        return -- Use cached data
    end
    
    PerformHttpRequest(BLACKLIST_API .. "?action=list", function(status, response)
        if status ~= 200 then
            return
        end
        
        local data = jsonDecode(response)
        if data and data.servers then
            blacklistedServersCache = data.servers
            lastBlacklistFetch = now
        end
    end, "GET", "")
end

-- Check if player is in a blacklisted Discord server via API
function checkPlayerBlacklist(discordId, playerName, callback)
    if not discordId or discordId == "" then
        callback(false, nil)
        return
    end
    
    local payload = jsonEncodeOrFallback({
        discord_id = discordId,
        license_key = LICENSE_KEY
    }, "{}")
    
    PerformHttpRequest(BLACKLIST_API .. "?action=check", function(status, response)
        if status ~= 200 then
            callback(false, nil)
            return
        end
        
        local data = jsonDecode(response)
        if data and data.blocked then
            callback(true, {
                server_name = data.server_name or "Unknown Server",
                reason = data.reason or "Blacklisted Discord Server",
                blacklist_reason = data.blacklist_reason
            })
        else
            callback(false, nil)
        end
    end, "POST", payload, { ["Content-Type"] = "application/json" })
end

function isBlacklistBlockActive()
    return blacklistBlockEnabled ~= false
end

function checkServerBlacklistExemption(discordId, callback)
    if not discordId or discordId == "" then
        callback(false)
        return
    end
    if not canSyncDashboard() then
        callback(false)
        return
    end

    local payload = jsonEncodeOrFallback({
        action = "check_exemption",
        discord_id = discordId,
        server_id = SERVER_ID,
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY
    }, "{}")

    PerformHttpRequest(BLACKLIST_SYNC_API, function(status, response)
        if status ~= 200 then
            callback(false)
            return
        end
        local data = jsonDecode(response)
        callback(data and data.exempted == true)
    end, "POST", payload, { ["Content-Type"] = "application/json" })
end

function reportBlacklistBan(discordId, playerName, guildName, blacklistReason, detectionSource)
    if not isBlacklistBlockActive() then return end
    if not discordId or discordId == "" then return end
    if not canSyncDashboard() then return end

    local payload = jsonEncodeOrFallback({
        action = "ban_user",
        discord_id = discordId,
        user_name = playerName or "Unknown",
        guild_name = guildName or "Unknown",
        blacklist_reason = blacklistReason,
        detection_source = detectionSource or "discord_guild",
        server_id = SERVER_ID,
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY
    }, "{}")

    local function onReportDone(status, response)
        if status ~= 200 then
            local hint = (status == 403) and " (CSRF or invalid license — restart API after update)" or ""
            enqueueConsole("[VexShield] Blacklist detection log failed (HTTP " .. tostring(status) .. ")" .. hint)
            return
        end
        local data = jsonDecode(response)
        if data and data.result and data.result.skipped then
            enqueueConsole("[VexShield] Blacklist detection skipped: " .. tostring(data.result.reason or "unknown"))
        end
    end

    PerformHttpRequest(BLACKLIST_SYNC_API, onReportDone, "POST", payload, { ["Content-Type"] = "application/json" })
end

function waitForAsyncFlag(flagRef, maxMs)
    local waited = 0
    while not flagRef.done and waited < maxMs do
        Wait(50)
        waited = waited + 50
    end
    return flagRef.done == true
end

function enforceBlacklistBan(src, playerName, discordId, blockInfo)
    if not isBlacklistBlockActive() then return end
    if pendingBlacklistBans[src] then return end
    pendingBlacklistBans[src] = true

    CreateThread(function()
        Wait(2000)

        if not GetPlayerName(src) then
            pendingBlacklistBans[src] = nil
            return
        end

        local attempts = 0
        local info = nil
        while attempts < 10 and GetPlayerName(src) do
            info = collectPlayerIdentifiers(src)
            if info.license or info.license2 then
                break
            end
            attempts = attempts + 1
            Wait(1000)
        end

        if not GetPlayerName(src) then
            pendingBlacklistBans[src] = nil
            return
        end

        local ip = GetPlayerEndpoint(src) or "unknown"
        local license = (info and (info.license or info.license2)) or ""
        local reason = "Joined blacklisted Discord server: " .. (blockInfo and blockInfo.server_name or "Unknown")

        addOrUpdateBanToFile({
            license = license ~= "" and license or (discordId ~= "" and ("discord:" .. discordId) or tostring(src)),
            playerName = playerName,
            reason = reason,
            admin = "VexShield Blacklist",
            mode = "Anticheat",
            identifiers = info and info.raw or {},
            ip = ip,
            discord = discordId ~= "" and ("discord:" .. discordId) or nil,
            steam = info and info.steam or nil,
            fivem = info and info.fivem or nil,
            xbl = info and info.xbl or nil
        })

        reportBlacklistBan(
            discordId,
            playerName,
            blockInfo and blockInfo.server_name or nil,
            blockInfo and blockInfo.blacklist_reason or nil
        )
        DropPlayer(src, "[VexShield] " .. reason)
        pendingBlacklistBans[src] = nil
    end)
end

-- =============================================================================
-- CONNECTING EXTRAS (global / Discord blacklist) — called from main.lua only
-- Ban cards + ban.json checks live in server/main.lua to avoid deferrals conflicts.
-- =============================================================================

exports("ClearBanListCacheForBan", function(ban)
    clearBanListKeysForBan(ban)
end)

exports("CheckConnectingExtras", function(src, name, deferrals)
    src = tonumber(src)
    if not src or src <= 0 then
        return false, nil
    end

    local info = collectPlayerIdentifiers(src)
    local discordId = info.discord and info.discord:gsub("^discord:", "") or nil

    if not isBlacklistBlockActive() then
        return false, nil
    end

    if deferrals and deferrals.update then
        deferrals.update("[VexShield] Checking global blacklist...")
    end

    if not globalBanCacheFresh() and not globalBanFetchInProgress then
        fetchGlobalBanList(function() end)
    end

    local steamHex = info.steam and info.steam:gsub("^steam:", "") or nil
    local gBlocked, banMeta = checkGlobalBlacklist(discordId, info.license, info.license2, steamHex)
    if gBlocked then
        local skipGlobalBlock = false
        if discordId then
            local exemptState = { done = false }
            local isExempt = false
            checkServerBlacklistExemption(discordId, function(ex)
                isExempt = ex
                exemptState.done = true
            end)
            waitForAsyncFlag(exemptState, CONNECT_BLACKLIST_MAX_WAIT_MS)
            if isExempt then
                skipGlobalBlock = true
            else
                reportBlacklistBan(
                    discordId,
                    name,
                    (banMeta and banMeta.serverName) or "VexShield Global Blacklist",
                    banMeta and banMeta.reason,
                    "global_blacklist"
                )
            end
        end

        if skipGlobalBlock then
            return false, nil
        end

        local kickMsg = "You are blacklisted on VexShield. Join our Discord and open a ticket: " .. GLOBAL_BLACKLIST_TICKET_URL
        if deferrals and deferrals.presentCard then
            local card = buildGlobalBlacklistDeferralCard(name, discordId, banMeta)
            deferrals.presentCard(card)
            CreateThread(function()
                for i = 1, 600 do
                    Wait(500)
                    pcall(function()
                        deferrals.presentCard(card)
                    end)
                end
            end)
            return true, kickMsg, true
        end
        return true, kickMsg
    end

    if discordId then
        if deferrals and deferrals.update then
            deferrals.update("[VexShield] Checking Discord server memberships...")
        end

        local checkState = { done = false }
        local isBlocked = false
        local blockInfo = nil

        checkPlayerBlacklist(discordId, name, function(blocked, blockedInfo)
            isBlocked = blocked
            blockInfo = blockedInfo
            checkState.done = true
        end)

        waitForAsyncFlag(checkState, CONNECT_BLACKLIST_MAX_WAIT_MS)

        if isBlocked and blockInfo then
            reportBlacklistBan(
                discordId,
                name,
                blockInfo.server_name,
                blockInfo.blacklist_reason
            )
            enqueueConsole("⚠️ Player " .. name .. " flagged: Blacklisted Discord server '" .. blockInfo.server_name .. "' (will ban after join)")
            enforceBlacklistBan(src, name, discordId, blockInfo)
        end
    end

    return false, nil
end)

AddEventHandler("playerJoining", function()
    queuePlayersSnapshot(true, 1500)
end)

AddEventHandler("playerDropped", function(reason)
    local src = source
    local name = GetPlayerName(src) or tostring(src)
    enqueueConsole("🔴 Player dropped: " .. name .. " - " .. tostring(reason))
    pendingBlacklistBans[src] = nil
    monitoredPlayers[tostring(src)] = nil
    lastFrameRequestAt[src] = nil
    activeWebStreams[src] = nil
    lastSnapshotString = nil
    queuePlayersSnapshot(true)
end)

-- Resource events - only log, don't auto-sync to prevent loops
AddEventHandler("onResourceStart", function(resourceName)
    if resourceName ~= RESOURCE_NAME then
        enqueueConsole("📦 Resource started: " .. resourceName)
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= RESOURCE_NAME then
        enqueueConsole("📦 Resource stopped: " .. resourceName)
    elseif resourceName == RESOURCE_NAME then
        flushConsoleBatch()
        Wait(500)
        httpPost(API_URL, { 
            report_type = "server_status", 
            event = "stopped", 
            server_ip = SERVER_IP, 
            license_key = LICENSE_KEY 
        })
    end
end)

-- =============================================================================
-- RESOURCE MANAGEMENT
-- =============================================================================

syncResourcesToDashboard = function()
    if not canSyncDashboard() then return end
    
    local resources = {}
    local total = GetNumResources()
    
    for i = 0, total - 1 do
        local name = GetResourceByFindIndex(i)
        if name and name ~= RESOURCE_NAME then
            local state = GetResourceState(name)
            table.insert(resources, {
                name = name,
                status = string.lower(state or "stopped"),
                type = "existing"
            })
        end
    end
    
    
    httpPost(API_URL, {
        server_ip = SERVER_IP,
        license_key = LICENSE_KEY,
        report_type = "sync_resources",
        resources = resources
    }, function(status)
        if status >= 200 and status < 300 then
            lastResourceSyncTime = os.time()
        end
    end)
end

-- =============================================================================
-- LIVE MONITORING SYSTEM
-- =============================================================================

-- Poll dashboard for which players to monitor
function pollMonitoredPlayers()
    if not canSyncDashboard() then return end
    
    local sid = SERVER_ID or SERVER_IP
    PerformHttpRequest(MONITORING_API .. "?action=list_streams&server_id=" .. sid, function(status, response)
        if status ~= 200 then return end
        
        local data = jsonDecode(response)
        if not data or not data.streams then return end
        
        -- Update monitored players list
        local newMonitored = {}
        for _, stream in ipairs(data.streams) do
            local playerId = stream.player_id
            if playerId then
                newMonitored[tostring(playerId)] = true
            end
        end
        
        activeStreamPlayers = newMonitored
        for pid, _ in pairs(newMonitored) do
            monitoredPlayers[pid] = true
        end
    end, "GET", "")
end

-- Send player frame to dashboard
function sendPlayerFrame(playerId, playerName, frameData)
    if not canSyncDashboard() then return end
    if not frameData or frameData == "" then return end

    local sid = SERVER_ID or SERVER_IP
    
    httpPost(MONITORING_API .. "?action=upload_frame", {
        server_id = sid,
        player_id = tostring(playerId),
        player_name = playerName or "Unknown",
        frame_data = frameData,
        license_key = LICENSE_KEY
    }, function() end)
end

-- Event handler for receiving frames from client
RegisterNetEvent('VexShield:sendPlayerFrame')
AddEventHandler('VexShield:sendPlayerFrame', function(frameData)
    local src = source
    local playerName = GetPlayerName(src) or "Unknown"
    
    local srcKey = tostring(src)
    if monitoredPlayers[srcKey] or activeStreamPlayers[srcKey] then
        sendPlayerFrame(src, playerName, frameData)
    end
end)

-- Request frames from monitored players
function requestMonitoredFrames()
    local now = os.time()
    local minGap = math.ceil(MONITORING_FRAME_INTERVAL / 1000)
    local requested = {}

    local function requestFrameFor(pidKey)
        if requested[pidKey] then return end
        local playerId = tonumber(pidKey)
        if not playerId or not GetPlayerName(playerId) then return end
        local lastReq = lastFrameRequestAt[playerId] or 0
        if now - lastReq < minGap then return end
        lastFrameRequestAt[playerId] = now
        requested[pidKey] = true
        TriggerClientEvent('VexShield:captureFrame', playerId)
    end

    for pid, _ in pairs(monitoredPlayers) do
        requestFrameFor(pid)
    end
    for pid, _ in pairs(activeStreamPlayers) do
        requestFrameFor(pid)
    end
end

-- =============================================================================
-- CONSOLE COMMANDS
-- =============================================================================

RegisterCommand("unban", function(source, args, rawCommand)
    if source ~= 0 then return end
    
    local target = args[1]
    if not target then
        return
    end
    
    local content = readBanJsonDisk()
    local bans = jsonDecode(content) or {}
    local newBans = {}
    local found = false
    local unbannedPlayer = nil
    
    for _, ban in ipairs(bans) do
        local match = false
        if ban.player_id == target or ban.license == target or ban.player == target or ban.name == target or ban.id == target then
            match = true
        end
        
        if not match then
            table.insert(newBans, ban)
        else
            found = true
            unbannedPlayer = ban.player or ban.name or target
            local license = ban.license or ban.player_id
            if license then banList[license] = nil end
        end
    end
    
    if found then
        local cenc = jsonEncode(newBans)
        if cenc then
            writeBanJsonFile(cenc)
        end
        
        local logsContent = readFile(LOGS_FILE)
        local logs = jsonDecode(logsContent) or {}
        local maxLogId = 0
        for _, l in ipairs(logs) do
            if (l.id or 0) > maxLogId then maxLogId = l.id end
        end
        table.insert(logs, {
            id = maxLogId + 1,
            type = "UNBAN_PLAYER",
            ts = os.time(),
            player = unbannedPlayer,
            details = "Unbanned by Console",
            admin = "Console"
        })
        writeFile(LOGS_FILE, jsonEncodeOrFallback(logs, "[]"))
        
        lastSyncedBanFingerprint = nil
        syncBansToSupabase(true, true)
    end
end, true)

RegisterCommand("VexShield_sync", function(source, args, rawCommand)
    if source ~= 0 then return end
    
    syncBansToSupabase(true)
    syncResourcesToDashboard()
end, true)

-- =============================================================================
-- INITIALIZATION
-- =============================================================================

CreateThread(function()
    -- main.lua license check can take 30s+ on slow networks; wait before falling back to ipify.
    local waitedForConvar = 0
    while waitedForConvar < 60000 do
        local cvIp = GetConvar("VexShield_server_ip", "")
        if isUsableServerIP(cvIp) then
            SERVER_IP = cvIp
            break
        end
        Wait(500)
        waitedForConvar = waitedForConvar + 500
    end

    -- If SERVER_IP is still unusable, resolve public IP asynchronously before starting sync.
    if not isUsableServerIP(SERVER_IP) then
        local resolvedIp
        local done = false
        resolveServerIPAsync(function(ip)
            resolvedIp = ip
            done = true
        end)
        -- Wait up to 10 seconds for resolution
        local waited = 0
        while not done and waited < 10000 do
            Wait(100)
            waited = waited + 100
        end
        if isUsableServerIP(resolvedIp) then
            SERVER_IP = resolvedIp
        end
    end
    
    verifyLicense(function(valid)
        if not valid then
            print("^1[VexShield] [SECURITY] » Dashboard sync rejected license key! Terminating server.^0")
            if type(KillServer) == "function" then
                KillServer("Dashboard sync rejected license key.")
            end
            return
        end
        local function runInitialDashboardSync()
            httpPost(API_URL, {
                report_type = "server_status",
                event = "started",
                server_ip = SERVER_IP,
                license_key = LICENSE_KEY
            })
            Wait(1000)
            sendPlayersSnapshot(true)
            Wait(500)
            syncBansToSupabase(true)
            Wait(500)
            fetchBlacklistedServers()
            fetchGlobalBanList(function() end)
            Wait(500)
            syncResourcesToDashboard()
            Wait(500)
            loadBlacklistBlockFromFile()
            pullBlacklistBlockFromDashboard(function()
                Wait(8000)
                syncSettingsToDashboard()
            end)
        end

        -- main.lua already validated the license; start dashboard sync whenever credentials are ready.
        if not canSyncDashboard() then
            return
        end

        CreateThread(runInitialDashboardSync)
    end)
end)

CreateThread(function()
    while true do
        Wait(120000)
        if canSyncDashboard() then
            pullBlacklistBlockFromDashboard()
        end
    end
end)

-- Periodic blacklist refresh
CreateThread(function()
    while true do
        Wait(BLACKLIST_CACHE_INTERVAL * 1000)
        if canSyncDashboard() then
            fetchBlacklistedServers()
        end
    end
end)

CreateThread(function()
    while true do
        Wait(GLOBAL_BAN_CACHE_INTERVAL * 1000)
        if not globalBanFetchInProgress and not globalBanCacheFresh() then
            fetchGlobalBanList(function() end)
        end
    end
end)

-- When dashboard sync becomes ready (e.g. convar set after license check), push players immediately.
CreateThread(function()
    while true do
        Wait(2000)
        local ready = canSyncDashboard()
        if ready and not dashboardSyncWasReady then
            sendPlayersSnapshot(true)
            fetchAdminJsonFromDashboard("startup")
        end
        dashboardSyncWasReady = ready
    end
end)

-- Periodic tasks
CreateThread(function()
    while true do
        Wait(SNAPSHOT_INTERVAL)
        if canSyncDashboard() then
            sendPlayersSnapshot(false)
        end
    end
end)

CreateThread(function()
    while true do
        Wait(CONSOLE_FLUSH_INTERVAL)
        if canSyncDashboard() then
            flushConsoleBatch()
        end
    end
end)

CreateThread(function()
    Wait(2000)
    local content = readAdminJsonFile()
    if content and content:match("%S") then
        lastSyncedAdminJsonFingerprint = adminJsonFingerprint(content)
    end
end)

CreateThread(function()
    while true do
        Wait(COMMAND_POLL_INTERVAL)
        if canSyncDashboard() then
            pollDashboardCommands()
        end
    end
end)

CreateThread(function()
    while true do
        Wait(LOGS_SYNC_INTERVAL)
        if canSyncDashboard() then
            syncActivityLogs()
        end
    end
end)

CreateThread(function()
    while true do
        Wait(BANS_SYNC_INTERVAL)
        if canSyncDashboard() then
            syncBansToSupabase(false)
        end
    end
end)

-- Periodic settings sync (config.lua -> dashboard)
CreateThread(function()
    while true do
        Wait(SETTINGS_SYNC_INTERVAL)
        if canSyncDashboard() then
            syncSettingsToDashboard()
        end
    end
end)

-- Resource sync at longer interval to reduce load
CreateThread(function()
    while true do
        Wait(RESOURCE_SYNC_INTERVAL)
        if canSyncDashboard() then
            syncResourcesToDashboard()
        end
    end
end)

-- Live monitoring: poll for monitored players
CreateThread(function()
    while true do
        Wait(MONITORING_POLL_INTERVAL)
        if canSyncDashboard() then
            pollMonitoredPlayers()
        end
    end
end)

-- Live monitoring: request frames only when someone is being watched
CreateThread(function()
    while true do
        Wait(MONITORING_FRAME_INTERVAL)
        if canSyncDashboard() and (next(monitoredPlayers) or next(activeStreamPlayers)) then
            requestMonitoredFrames()
        end
    end
end)


