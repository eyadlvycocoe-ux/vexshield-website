fx_version 'cerulean'
game 'gta5'
lua54 'yes'
node_js 'yes'

author 'VexShield'
name 'VexShield'
version 'vBeta'
description '[VexShield vBeta]'

client_scripts {
    'html/vexshield.js',
    'client/vex-c2984209480.lua',
    'client/vex-c4920194820.lua',
    'client/vex-c8930194825.lua'
}

server_scripts {
    'html/vexshield.js',
    'vex_config.lua',
    'server/vex-s1049281048.lua',
    'server/vex-s2984209480.lua',
    'server/vex-s3849102948.lua'
}

shared_scripts {
    '@ox_lib/init.lua',
}

ui_page 'html/vex-index.html'

files {
    'html/vex-index.html',
    'html/vex-style.css',
    'html/admin.json',
    'html/ban.json',
    'html/logs.json',
    'html/vexshield.js',
    'html/whitelist.json'
}

dependencies {
    'ox_lib',
}

exports {
    'CheckConnectingExtras',
    'ClearBanListCacheForBan',
    'processResources',
    'IsValidExecution',
    'AllowSource',
    'hasTeleported',
    'hasChangedPedModel',
    'healthRefilled',
    'playerRevived',
    'proofsEnabled',
    'canBeDamaged',
    'isInvincible',
    'isVisible',
    'resettedStamina',
    'newTopSpeedModifier',
    'newCheatPowerIncrease',
    'SignEventPayload',
    'VexShieldIsProtectionOn',
    'UploadBanClipToDiscord'
}
