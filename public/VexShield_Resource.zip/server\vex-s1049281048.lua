-- [VEX-INTERNAL-CORE: 0x9F4C2A-S1049281048]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

Config = Config or {}

function applyPureModeSettings()
    if Config and Config.PureMode and Config.PureMode.Enabled then
        SetConvar("sv_scriptHookAllowed", tostring(Config.PureMode.ScriptHookAllowed))
        SetConvar("sv_pureLevel", tostring(Config.PureMode.PureLevel))
        SetConvar("sv_filterRequestControl", tostring(Config.PureMode.FilterRequestControl))
        print("^2[VEXSHIELD] >> Server Pure Mode configurations applied.^0")
    end
end
applyPureModeSettings()

local lastConfigRaw = nil

local function readDiskConfig()
    local resName = GetCurrentResourceName()
    local content = LoadResourceFile(resName, "vex_config.lua")
    if not content or content == "" then
        content = LoadResourceFile(resName, "config.lua")
    end
    if not content or content == "" then
        local base = GetResourcePath(resName)
        if base and base ~= "" then
            local p1 = base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/vex_config.lua"
            local f = io.open(p1, "r")
            if f then
                content = f:read("*a")
                f:close()
            else
                local p2 = base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/config.lua"
                local f2 = io.open(p2, "r")
                if f2 then
                    content = f2:read("*a")
                    f2:close()
                end
            end
        end
    end
    if type(content) == "string" and content ~= "" and not content:find("^[0-9A-Fa-f]+$") then
        return content
    end
    return nil
end

function VexShieldReloadConfig(src)
    local raw = readDiskConfig()
    if not raw or raw == "" then
        print("^1[VEXSHIELD] >> Auto-Reload Error: Could not read vex_config.lua!^7")
        if src and type(src) == "number" and src > 0 then
            TriggerClientEvent('chat:addMessage', src, { args = { '^1[VexShield]', 'Config reload failed: Could not read vex_config.lua' } })
        end
        return false, "Could not read vex_config.lua"
    end

    -- Create an environment where Config resets fresh to avoid stale options lingering
    local env = {
        Config = {},
        GetHashKey = GetHashKey,
        GetCurrentResourceName = GetCurrentResourceName,
        vec3 = vec3,
        vector3 = vector3,
        tostring = tostring,
        tonumber = tonumber,
        pairs = pairs,
        ipairs = ipairs,
        type = type,
        table = table,
        string = string,
        math = math
    }
    setmetatable(env, { __index = _G })

    local chunk, err = load(raw, "@vex_config.lua", "t", env)
    if not chunk then
        print("^1[VexShield] Auto-Reload Syntax Error in vex_config.lua: " .. tostring(err) .. "^7")
        if src and type(src) == "number" and src > 0 then
            TriggerClientEvent('chat:addMessage', src, { args = { '^1[VexShield]', 'Config reload failed: Syntax Error in vex_config.lua: ' .. tostring(err) } })
        end
        return false, err
    end

    local ok, runErr = pcall(chunk)
    if not ok then
        print("^1[VexShield] Auto-Reload Execution Error in vex_config.lua: " .. tostring(runErr) .. "^7")
        if src and type(src) == "number" and src > 0 then
            TriggerClientEvent('chat:addMessage', src, { args = { '^1[VexShield]', 'Config reload failed: Execution Error in vex_config.lua: ' .. tostring(runErr) } })
        end
        return false, runErr
    end

    if type(env.Config) == "table" then
        local prevWhitelistedJobs = (type(Config) == "table" and type(Config.WhitelistedJobs) == "table") and Config.WhitelistedJobs or {}
        Config = env.Config
        if not Config.WhitelistedJobs or type(Config.WhitelistedJobs) ~= "table" then
            Config.WhitelistedJobs = prevWhitelistedJobs
        end
    end

    lastConfigRaw = raw
    applyPureModeSettings()

    -- Synchronize updated Config to all connected clients
    TriggerClientEvent("VexShield:ClientSyncConfig", -1, Config)
    TriggerEvent("VexShield:OnConfigReloaded", Config)

    -- Synchronize dashboard state if site.lua function is present
    if syncSettingsToDashboard then
        pcall(syncSettingsToDashboard)
    end

    local nowMs = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
    if not _lastConfigReloadPrintAt or (nowMs - _lastConfigReloadPrintAt) > 2500 then
        _lastConfigReloadPrintAt = nowMs
        print("^1[VEXSHIELD]^7 » ^3RUNTIME^7 | ^2Configuration hot-reloaded successfully^0")
    end
    if src and type(src) == "number" and src > 0 then
        TriggerClientEvent('chat:addMessage', src, { args = { '^1[VexShield]', '^2Configuration reloaded and synchronized successfully!' } })
    end
    return true
end

-- Automatic disk watcher thread: checks config.lua every 1000ms directly on disk
CreateThread(function()
    Wait(1000)
    lastConfigRaw = readDiskConfig()
    while true do
        Wait(1000)
        local currentRaw = readDiskConfig()
        if currentRaw and currentRaw ~= "" then
            if not lastConfigRaw then
                lastConfigRaw = currentRaw
            elseif currentRaw ~= lastConfigRaw then
                lastConfigRaw = currentRaw
                local nowWatch = (GetGameTimer and GetGameTimer()) or (os.time() * 1000)
                if not _lastConfigReloadPrintAt or (nowWatch - _lastConfigReloadPrintAt) > 2500 then
                    print("^1[VEXSHIELD]^7 » ^5WATCHER^7 | ^3Live modification detected in vex_config.lua! Synchronizing...^0")
                end
                VexShieldReloadConfig()
            end
        end
    end
end)

-- Command /airreload to trigger config reload on demand (Console or Admin)
RegisterCommand('airreload', function(source, args, rawCommand)
    if source == 0 then
        VexShieldReloadConfig(0)
    elseif IsPlayerVexMenuAllowed and IsPlayerVexMenuAllowed(source) then
        VexShieldReloadConfig(source)
    else
        TriggerClientEvent('chat:addMessage', source, { args = { '^1[VexShield]', 'No permission to reload config.' } })
    end
end, false)

local ESX = nil
local QBCore = nil
local UseESX = false
local UseQBCore = false
-- Extra frameworks (globals to avoid the per-chunk local limit). Qbox (qbx_core), ox_core, vRP.
UseQBox = false
UseOx = false
UseVRP = false
local recentBans = {}
local storedPlayerNames = {}
local joinedAt = {}
local playersReady = {}
local firstJoinByLicense = {}
local FIRST_JOIN_FILE = "html/first_join.json"

function licenseKeyFromPlayer(playerId)
    for _, id in ipairs(GetPlayerIdentifiers(playerId)) do
        if string.match(id, "^license:") then
            return string.lower(id)
        end
    end
    return nil
end

function normalizeLicenseKey(licenseStr)
    if not licenseStr or licenseStr == "" or licenseStr == "Unknown" then return nil end
    local key = string.lower(tostring(licenseStr))
    if string.match(key, "^license:") then return key end
    return "license:" .. key
end

function loadFirstJoinByLicense()
    local raw = LoadResourceFile(GetCurrentResourceName(), FIRST_JOIN_FILE)
    if not raw or raw == "" then return end
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == "table" then firstJoinByLicense = data end
end

function persistFirstJoinByLicense()
    SaveResourceFile(GetCurrentResourceName(), FIRST_JOIN_FILE, json.encode(firstJoinByLicense, { indent = true }), -1)
end

function notePlayerFirstJoin(playerId)
    local key = licenseKeyFromPlayer(playerId)
    if not key or firstJoinByLicense[key] then return end
    firstJoinByLicense[key] = os.time()
    CreateThread(function()
        persistFirstJoinByLicense()
    end)
end

function firstJoinUnixForLicense(licenseStr)
    local key = normalizeLicenseKey(licenseStr)
    if not key then return nil end
    return firstJoinByLicense[key]
end
-- Serialize ban.json read-modify-write (concurrent bans used to overwrite each other)
local airBanJsonBusy = false
-- Entity spawn tracking (used by unified entityCreating + playerDropped cleanup)
local entitySpamTrackers = {}
local vehicleSpamTrackers = {}
local __AS_MAX_SPAM_COORDS = 32
local __AS_PedCreateTracker = {}
-- Forward declaration: banPlayer (defined earlier) must call the local, not a nil global
local sendLogsOnlyWebhook

-- Shared strike tracker for repeated medium-risk signals.
VexShieldRuntime = VexShieldRuntime or {}
VexShieldRuntime.StrikeTrackers = VexShieldRuntime.StrikeTrackers or {}

function VexShieldRecordStrike(src, key, maxStrikes, windowMs, actionReason)
    local sid = tonumber(src)
    if not sid or sid <= 0 then return false, 0 end
    key = tostring(key or "generic")
    maxStrikes = tonumber(maxStrikes) or 3
    windowMs = tonumber(windowMs) or 60000
    local now = GetGameTimer()
    local trackerKey = tostring(sid) .. ":" .. key
    local tracker = VexShieldRuntime.StrikeTrackers[trackerKey]
    if not tracker or (now - (tracker.windowStart or 0)) > windowMs then
        tracker = { count = 0, windowStart = now }
        VexShieldRuntime.StrikeTrackers[trackerKey] = tracker
    end
    tracker.count = (tracker.count or 0) + 1
    if tracker.count >= maxStrikes then
        VexShieldRuntime.StrikeTrackers[trackerKey] = nil
        if actionReason and banPlayer then
            banPlayer(sid, actionReason)
        end
        return true, tracker.count
    end
    return false, tracker.count
end

function VexShieldClearStrikes(src)
    local sid = tonumber(src)
    if not sid then return end
    local prefix = tostring(sid) .. ":"
    for key in pairs(VexShieldRuntime.StrikeTrackers or {}) do
        if key:sub(1, #prefix) == prefix then
            VexShieldRuntime.StrikeTrackers[key] = nil
        end
    end
end

local __AS_DeleteEntity = DeleteEntity
local __AS_DeletePed = DeletePed

function __AS_ShouldProtectTrafficPedServer(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if IsPedAPlayer(ped) then return true end
    if IsPedInAnyVehicle(ped, false) then return true end
    -- Protect ambient/traffic peds by checking if they have a valid model that's not a player
    local model = GetEntityModel(ped)
    if model and model ~= 0 then
        -- Most ambient ped models are valid entities, we protect them
        -- Only allow deletion if the ped is explicitly marked for deletion by game systems
        return true
    end
    return false
end

DeleteEntity = function(entity, ...)
    if entity and entity ~= 0 and DoesEntityExist(entity) and GetEntityType(entity) == 1 and __AS_ShouldProtectTrafficPedServer(entity) then
        return
    end
    return __AS_DeleteEntity(entity, ...)
end

DeletePed = function(ped, ...)
    if __AS_ShouldProtectTrafficPedServer(ped) then
        return
    end
    return __AS_DeletePed(ped, ...)
end

-- Stable token fingerprint (GetPlayerToken order is not guaranteed)
function sortPlayerTokens(tokens)
    if type(tokens) == "table" and #tokens > 1 then
        table.sort(tokens)
    end
end

function buildTokenFingerprint(tokens)
    if type(tokens) ~= "table" or #tokens == 0 then return "" end
    sortPlayerTokens(tokens)
    return table.concat(tokens, "|")
end

function isAntiSpoofEnabled()
    if not VexShieldIsProtectionEnabled('Anti Spoof') then return false end
    local sd = Config.SpoofDetection
    if type(sd) == "table" and sd.Enabled == false then return false end
    return true
end

function clearRuntimeSpoofState(src)
    src = tonumber(src)
    if not src or src <= 0 then return end
    if _G.__runtimeFP then _G.__runtimeFP[src] = nil end
    if _G.__runtimeGraceUntil then _G.__runtimeGraceUntil[src] = nil end
    if _G.__fingerprints then
        for fp, sid in pairs(_G.__fingerprints) do
            if sid == src then _G.__fingerprints[fp] = nil end
        end
    end
end

-- SECURITY & EVENT OBFUSCATION HANDLER
local SecurityConfig = {
    Salt = "AS_SECURE_SALT_99281_CHANGE_ME",
    ObfuscateEvents = true
}

-- VexShield Advanced System
function randomString(count)
    local chars = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz123456789"
    local rndmString = ""
    for i = 1, count do
        local rndm = math.random(1, #chars)
        rndmString = rndmString .. chars:sub(rndm, rndm)
    end
    return rndmString
end

GlobalState.AS_BanToken = randomString(math.random(15, 30))
GlobalState.AS_SubKey = randomString(math.random(15, 30))
GlobalState.AS_ConfigKey = "AS_ConfigKey"
SetConvarReplicated(GlobalState.AS_SubKey, randomString(math.random(15, 30)))
GlobalState.AS_AntiTriggerClient = true

-- Mock config for injection check
GlobalState["AS_ConfigKey"] = {
    Beta = {
        AntiUnisolatedInjection = true,
        IgnoredExecutionPatterns = {}
    }
}

function GetEncryptedEventName(eventName)
    if not SecurityConfig.ObfuscateEvents then return eventName end
    local hash = GetHashKey(eventName .. SecurityConfig.Salt)
    return "AS_EVT_" .. tostring(hash)
end

VexShieldProtectedEvents = VexShieldProtectedEvents or {}

AddEventHandler("__VexShield_internal:protectEvent", function(eventName)
    local resourceName = GetInvokingResource()
    if type(eventName) ~= "string" or eventName == "" or not resourceName then return end
    VexShieldProtectedEvents[eventName .. ":" .. resourceName] = true
end)

exports("IsEventProtected", function(eventName)
    local resourceName = GetInvokingResource()
    if type(eventName) ~= "string" or eventName == "" or not resourceName then return false end
    return VexShieldProtectedEvents[eventName .. ":" .. resourceName] == true
end)

AddEventHandler("VexShield:ProtectedEventViolation", function(playerId, eventName, resourceName, violationReason)
    local sid = tonumber(playerId)
    if not sid or sid <= 0 then return end
    local src = tonumber(source) or 0
    if src > 0 and src ~= sid then return end
    
    local pName = (GetPlayerName and GetPlayerName(sid)) or "Unknown Player"
    local resState = resourceName and GetResourceState(resourceName) or "unknown"

    -- Ignore queue, connection, loading events or resources
    local eventLower = tostring(eventName or ""):lower()
    local resLower = tostring(resourceName or ""):lower()
    if eventLower:find("queue") or eventLower:find("playeractivated") or resLower:find("queue") or resLower:find("loading") or resLower:find("multicharacter") then
        return
    end

    -- Check if resource is whitelisted in config
    if resourceName and Config and Config.AllowedResources and Config.AllowedResources[resourceName] then
        return
    end

    -- Check if player is still in connection / loading state
    -- If a player is not marked as ready yet or joined within the last 15 seconds, and the resource is a legitimate started server resource,
    -- this is a client loading handshake delay, NOT a cheat injection.
    local isPlayerLoading = (not playersReady or not playersReady[sid]) or (joinedAt and joinedAt[sid] and (os.time() - joinedAt[sid]) < 15)
    if isPlayerLoading and resState == "started" then
        return
    end

    -- Check for critical security violations (missing token/signature, executor trigger, unencrypted call, replay attack, tampered token)
    local reasonLower = (violationReason or ""):lower()
    local isCriticalViolation = (reasonLower ~= "" and (
        reasonLower:find("executor") or 
        reasonLower:find("unencrypted") or
        reasonLower:find("missing signature") or
        reasonLower:find("bad signature") or
        reasonLower:find("tampered") or
        reasonLower:find("hijacking") or
        reasonLower:find("replay") or
        reasonLower:find("injection") or
        reasonLower:find("unauthorized")
    ))
    
    -- Auto-allow if resource is valid AND there is no critical security violation / unencrypted trigger
    if resourceName and resState ~= "missing" and not isCriticalViolation and (violationReason == nil or violationReason == "") then
        return
    end

    local reason = ("Attempted unauthorized event trigger: %s (%s)"):format(tostring(eventName or "unknown"), tostring(resourceName or "unknown"))
    if violationReason and violationReason ~= "" then
        reason = reason .. " - " .. tostring(violationReason)
    end

    -- Clean, professional anticheat log
    print(("^1[VexShield] Blocked unauthorized event trigger: '%s' from [%d] %s (%s) - %s^0"):format(
        tostring(eventName or "unknown"),
        sid,
        tostring(pName),
        tostring(resourceName or "unknown"),
        tostring(violationReason or "invalid signature")
    ))

    banPlayer(sid, reason)
end)

-- Entity Spawn Encryption Violation Handler
AddEventHandler("VexShield:UnauthorizedEntitySpawn", function(playerId, entityType, modelHash)
    local sid = tonumber(playerId)
    if not sid or sid <= 0 then return end
    
    -- Check if Anti Unauthorized Entity Spawn protection is enabled
    if not Config.Protections or not Config.Protections['Anti Unauthorized Entity Spawn'] then
        return
    end
    
    local protection = Config.Protections['Anti Unauthorized Entity Spawn']
    if not protection.Enabled then
        return
    end
    
    -- Log the unauthorized attempt
    local pName = (GetPlayerName and GetPlayerName(sid)) or "Unknown Player"
    print(("^1[VexShield Entity Encryption] ----------------------------------------------------^0"))
    print(("^1[VexShield Entity Encryption] UNAUTHORIZED ENTITY SPAWN DETECTED!^0"))
    print(("^1[VexShield Entity Encryption] Player: [%d] %s^0"):format(sid, tostring(pName)))
    print(("^3[VexShield Entity Encryption] Entity Type: '%s'^0"):format(tostring(entityType or "unknown")))
    print(("^3[VexShield Entity Encryption] Model Hash: %s^0"):format(tostring(modelHash or "unknown")))
    print(("^1[VexShield Entity Encryption] ----------------------------------------------------^0"))
    
    local reason = ("Attempted unauthorized entity spawn: %s (Hash: %s)"):format(tostring(entityType or "unknown"), tostring(modelHash or "unknown"))
    banPlayer(sid, reason, entityType, modelHash)
end)

-- =============================================================================
-- VexShield ENTERPRISE CRYPTOGRAPHIC EVENT PROTECTION SYSTEM
-- =============================================================================
local VexShieldServerMasterSecret = randomString(32)
local playerSessionKeys = {}
local consumedNonces = {}
local playerEventRates = {}

-- Clean up expired Nonces every 60 seconds (O(1) table cleanup)
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for src, nonces in pairs(consumedNonces) do
            for nonce, timestamp in pairs(nonces) do
                if (now - timestamp) > 30 then
                    nonces[nonce] = nil
                end
            end
        end
    end
end)

AddEventHandler("playerJoining", function()
    local src = source
    if src and src > 0 then
        local sessionSeed = tostring(src) .. ":" .. tostring(os.time()) .. ":" .. randomString(16)
        playerSessionKeys[src] = GetHashKey(sessionSeed .. ":" .. VexShieldServerMasterSecret)
        consumedNonces[src] = {}
        playerEventRates[src] = {}
    end
end)

AddEventHandler("playerDropped", function()
    local src = source
    if src then
        playerSessionKeys[src] = nil
        consumedNonces[src] = nil
        playerEventRates[src] = nil
    end
end)

function GetEventCategory(eventName)
    if not eventName then return "Public" end
    local registry = Config['Event Registry'] or {}
    if registry.Public and registry.Public[eventName] then return "Public" end
    if registry.Sensitive and registry.Sensitive[eventName] then return "Sensitive" end
    if registry.Protected and registry.Protected[eventName] then return "Protected" end
    return "Protected"
end

function VexShieldVerifyEventHMAC(src, eventName, nonce, timestamp, argsDigest, signature)
    if not VexShieldIsProtectionEnabled('Anti Event Token Bypass') then
        return true, "DISABLED"
    end

    local secConfig = Config['Event Security'] or {}
    if not secConfig.Enabled then
        return true, "DISABLED"
    end

    local category = GetEventCategory(eventName)
    if category == "Public" then
        return true, "PUBLIC"
    end

    src = tonumber(src)
    if not src or not playerSessionKeys[src] then
        print("^1[VEXSHIELD] >> TRIGGER BLOCKED: Event: '" .. tostring(eventName) .. "' | Reason: NO_SESSION_KEY | Player: " .. tostring(src))
        return false, "NO_SESSION_KEY"
    end

    -- 1. Check TTL Window
    local nowMs = GetGameTimer()
    timestamp = tonumber(timestamp) or 0
    local ttl = secConfig.TokenTTLMs or 5000
    if math.abs(nowMs - timestamp) > ttl then
        print("^1[VEXSHIELD] >> TRIGGER BLOCKED: Event: '" .. tostring(eventName) .. "' | Reason: EXPIRED_TTL | Player: " .. tostring(src) .. " | TimeDiff: " .. math.abs(nowMs - timestamp) .. "ms")
        return false, "EXPIRED_TTL"
    end

    -- 2. Check Replay Cache (Single-Use Nonce)
    nonce = tostring(nonce or "")
    if nonce == "" then
        print("^1[VEXSHIELD] >> TRIGGER BLOCKED: Event: '" .. tostring(eventName) .. "' | Reason: MISSING_NONCE | Player: " .. tostring(src))
        return false, "MISSING_NONCE"
    end

    consumedNonces[src] = consumedNonces[src] or {}
    if consumedNonces[src][nonce] then
        print("^1[VEXSHIELD] >> TRIGGER BLOCKED: Event: '" .. tostring(eventName) .. "' | Reason: REPLAY_ATTACK | Player: " .. tostring(src) .. " | Nonce: " .. nonce)
        return false, "REPLAY_ATTACK"
    end

    -- 3. Rate Limit Check
    playerEventRates[src] = playerEventRates[src] or {}
    local rateData = playerEventRates[src][eventName] or { count = 0, lastReset = nowMs }
    if (nowMs - rateData.lastReset) > 1000 then
        rateData.count = 1
        rateData.lastReset = nowMs
    else
        rateData.count = rateData.count + 1
        local maxRate = secConfig.RateLimitPerSec or 10
        if rateData.count > maxRate then
            print("^1[VEXSHIELD] >> TRIGGER BLOCKED: Event: '" .. tostring(eventName) .. "' | Reason: RATE_LIMIT_EXCEEDED | Player: " .. tostring(src) .. " | Count: " .. rateData.count .. "/" .. maxRate)
            return false, "RATE_LIMIT_EXCEEDED"
        end
    end
    playerEventRates[src][eventName] = rateData

    -- 4. Calculate Signature
    local playerKey = playerSessionKeys[src]
    local rawString = eventName .. ":" .. nonce .. ":" .. tostring(timestamp) .. ":" .. tostring(playerKey)
    if category == "Sensitive" and argsDigest then
        rawString = rawString .. ":" .. tostring(argsDigest)
    end

    local expectedHash = GetHashKey(rawString)
    if tonumber(signature) ~= tonumber(expectedHash) and tostring(signature) ~= tostring(expectedHash) then
        print("^1[VEXSHIELD] >> TRIGGER BLOCKED: Event: '" .. tostring(eventName) .. "' | Reason: INVALID_SIGNATURE | Player: " .. tostring(src) .. " | Expected: " .. tostring(expectedHash) .. " | Got: " .. tostring(signature))
        return false, "INVALID_SIGNATURE"
    end

    -- Mark Nonce as consumed
    consumedNonces[src][nonce] = os.time()
    print("^2[VEXSHIELD] >> Trigger Authorized: Event: '" .. tostring(eventName) .. "' | Player: " .. tostring(src) .. " | Category: " .. category)
    return true, "VALID"
end

function VexShieldHandleSecurityViolation(src, eventName, reasonCode)
    local mode = (Config['Event Security'] and Config['Event Security'].Mode) or "enforce"
    local pName = GetPlayerName(src) or "Unknown"
    local msg = string.format("[Event Security] Player %s (%d) violation on '%s': %s (Mode: %s)", pName, src, tostring(eventName), reasonCode, mode)

    if mode == "log" then
        print("^3[VexShield Anti-Trigger LOG MODE]^7 " .. msg)
    elseif mode == "warn" then
        print("^1[VexShield Anti-Trigger WARN MODE]^7 " .. msg)
        TriggerClientEvent("chat:addMessage", src, { color = {255, 0, 0}, args = {"VexShield", "Security Warning: Event validation failed (" .. reasonCode .. ")"} })
    elseif mode == "enforce" then
        print("^1[VexShield Anti-Trigger ENFORCE MODE - DROPPING PLAYER]^7 " .. msg)
        DropPlayer(src, "[VexShield Protection] Event Security Violation: " .. reasonCode)
    end
end

exports("VerifyEventHMAC", function(src, eventName, nonce, timestamp, argsDigest, signature)
    return VexShieldVerifyEventHMAC(src, eventName, nonce, timestamp, argsDigest, signature)
end)

exports("InspectEventTrigger", function(src, eventName, nonce, timestamp, argsDigest, signature)
    local isValid, reason = VexShieldVerifyEventHMAC(src, eventName, nonce, timestamp, argsDigest, signature)
    if not isValid then
        VexShieldHandleSecurityViolation(src, eventName, reason)
    end
    return isValid
end)

-- Handle Resource Stop Attempt (from injected air.lua)
local resourceStoppedEvent = GetEncryptedEventName("VexShield:Security:ResourceStopped")
RegisterNetEvent(resourceStoppedEvent, function(sigOrResource, maybeResource)
    local src = source
    if not src then return end
    local stoppedResource = type(sigOrResource) == "table" and maybeResource or sigOrResource
    
    print("^1[VEXSHIELD] >> TAMPER ALERT: Client " .. GetPlayerName(src) .. " attempted to stop resource: " .. stoppedResource .. "^7")
    DropPlayer(src, "Attempted to stop protected resource")
end)

-- Vehicle/Entity Spawn Tracking (initialized early to prevent nil errors)
local vehicleSpawnTracking = {} -- Track spawns per player
local vehicleSpawnCounters = {}
local propSpawnCounters = {}
local pedSpawnCounters = {}
local playerVehicleSessions = {} -- Total vehicles per player session
local globalVehicleCount = 0 -- Global vehicle count
local vehicleModelCount = {} -- Count per model

function getServerIP(callback)
    PerformHttpRequest("https://api.ipify.org?format=json", function(status, response, headers)
        if status == 200 then
            local data = json.decode(response)
            if data and data.ip then
                callback(data.ip)
            else
                callback("Unknown")
            end
        else
            callback("Unknown")
        end
    end, "GET", "")
end

function random_string(length)
    local charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local str = ""
    for i = 1, length do
        local rand = math.random(1, #charset)
        str = str .. charset:sub(rand, rand)
    end
    return str
end

local tosFile = LoadResourceFile(GetCurrentResourceName(), "html/important_accepted.json")
local acceptedList = tosFile and json.decode(tosFile) or {}
if not acceptedList then acceptedList = {} end

function KillServer(reason)
    LICENSE_VALIDATED = false
    local lic = (Config and Config.LicenseKey) or "NONE"
    reason = reason or "License verification failed."
    
    print("\n^3" .. string.rep("=", 78))
    print("^1[VexShield] LICENSE NOTICE: ^7" .. tostring(reason))
    print("^1[VexShield] Configured License: ^3'" .. tostring(lic) .. "'")
    print("^3[VexShield] STATUS: Anticheat protection is DISABLED. Cheater detection is inactive.^0")
    print("^3" .. string.rep("=", 78) .. "^0\n")
    
    -- Notify all connected clients to deactivate anticheat protection loops
    pcall(function()
        TriggerClientEvent("VexShield:setProtectionActive", -1, false)
    end)
end

function stopOnCriticalError(message)
    print("^1[VexShield Error]^0 " .. tostring(message))
    KillServer(message)
end

function verifyDataIntegrity(responseBody, expectedSignature)
    -- Controleer of de API response is ondertekend met een geheime sleutel
    local computedSignature = GetResourceKvpString("Vex_secure_signature") or GetResourceKvpString("Air_secure_signature")  -- Haal de laatste signature op
    if computedSignature ~= expectedSignature then
        stopOnCriticalError("Data Integrity Check Failed: Possible tampering detected!")
    end
end

function antiDebugCheck()
    -- Controleer of debuginformatie beschikbaar is
    local debugInfo = debug.getinfo(1, "S")
    
    -- Als de code geen informatie kan verkrijgen over de huidige functie, is het waarschijnlijk gecrackt
    if not debugInfo then
        stopOnCriticalError("Debugger detected! Stopping the resource to prevent tampering.")
        return
    end
    
    -- Specifieke bekende debugger functies controleren
    local blockedFunctions = {"os.execute", "io.popen"}
    for _, blockedFunc in ipairs(blockedFunctions) do
        if _G[blockedFunc] then
            stopOnCriticalError("Suspicious function detected: " .. blockedFunc)
            return
        end
    end

    -- Stack trace controleren zonder debug functies
    local suspiciousStackTrace = debug.traceback()
    if string.match(suspiciousStackTrace, "debug") then
        stopOnCriticalError("Debugging detected in stack trace. Stopping the resource to prevent tampering.")
        return
    end

    -- Blokkeer specifieke functies die verdacht zijn
    local blockedFunctions = {"os.execute", "io.popen", "debug"}
    for _, blockedFunc in ipairs(blockedFunctions) do
        if _G[blockedFunc] then
            -- stopOnCriticalError("Suspicious function detected: " .. blockedFunc)
            return
        end
    end
end

LICENSE_VALIDATED = false

function IsVexShieldLicenseActive()
    return LICENSE_VALIDATED == true
end
local COLORS = "^5"  -- Cyan color for banner

-- Official hard-link license list (must match server/index.js + nginx / Cloudflare proxy)
local LICENSE_PATH = "/api/v1/verification/config/hard-link-server-verification-lvkWoc9AgIxFoWLTc8hCC52AOMB3ZhPkZRvQFsg.json"

--[[
  Outbound HTTP from this game server to your Node API only (PerformHttpRequest).
  Leave "" so all API calls use https://vexshield.net (same as the public dashboard).
  Set to your VPS base, e.g. "http://YOUR_PUBLIC_IP:5000", when FiveM gets HTTP 0 on HTTPS.
  You can obfuscate this string in shipped builds. Prefer this over a separate text file.
]]
VexShield_ConnectionApiBase = "https://vexshield.site"

function licenseApiOrigin()
    local b = GetConvar("VexShield_api_base", "")
    if b and b ~= "" then return (b:gsub("/$", "")) end
    if Config and Config.LicenseApiDirectBase and Config.LicenseApiDirectBase ~= "" then
        return (Config.LicenseApiDirectBase:gsub("/$", ""))
    end
    if type(VexShield_ConnectionApiBase) == "string" and VexShield_ConnectionApiBase ~= "" then
        return VexShield_ConnectionApiBase:gsub("/$", "")
    end
    return "https://vexshield.site"
end

function collectLicenseVerifyUrls()
    local seen = {}
    local urls = {}
    local function push(u)
        if type(u) ~= "string" or u == "" or seen[u] then return end
        seen[u] = true
        urls[#urls + 1] = u
    end

    -- Priority 1: Official VexShield Cloud API & Static JSON Verification
    push("https://vexshield.site/licenses-secret-x8f9v2m4p1q7z3w5.json")
    push("https://vexshield.site/api/db/servers")
    push("https://vexshield-website.vercel.app/licenses-secret-x8f9v2m4p1q7z3w5.json")
    push("https://vexshield-website.vercel.app/api/db/servers")

    -- Priority 2: Direct Base (convar / config / VexShield_ConnectionApiBase)
    local base = licenseApiOrigin()
    if base ~= "" then
        local b = base:gsub("/$", "")
        push(b .. "/licenses-secret-x8f9v2m4p1q7z3w5.json")
        push(b .. "/api/db/servers")
        push(b .. LICENSE_PATH)
    end

    -- Priority 3: Custom config URL & convar
    if Config and Config.LicenseVerifyUrl and Config.LicenseVerifyUrl ~= "" then
        push(Config.LicenseVerifyUrl)
    end
    local cv = GetConvar("VexShield_license_verify_url", "")
    if cv ~= "" then push(cv) end

    -- Priority 4: Fallback URLs from Config
    if Config and type(Config.LicenseVerifyFallbackUrls) == "table" then
        for _, u in ipairs(Config.LicenseVerifyFallbackUrls) do push(u) end
    end

    -- Priority 5: Local development fallbacks
    push("http://127.0.0.1:5001/licenses-secret-x8f9v2m4p1q7z3w5.json")
    push("http://localhost:5001/licenses-secret-x8f9v2m4p1q7z3w5.json")
    return urls
end

function performLicenseCheck()
    if not Config or type(Config) ~= "table" then
        print("^1[VexShield] License check failed: Config table missing^0")
        KillServer("Configuration table is missing or corrupt.")
        return
    end
    if not Config.LicenseKey or Config.LicenseKey == "" then
        print("^1[VexShield] License check failed: Config.LicenseKey is empty^0")
        KillServer("Config.LicenseKey is empty. Set your valid license in vex_config.lua.")
        return
    end

    if Config.BypassLicense == true then
        LICENSE_VALIDATED = true
        SetConvar("VexShield_server_ip", "127.0.0.1")
        SetConvar("VexShield_license_key", tostring(Config.LicenseKey))
        print("^3[VexShield] WARNING: Config.BypassLicense is enabled. Cloud handshake bypassed.^7")
        return
    end

    local licenseUrls = collectLicenseVerifyUrls()
    if #licenseUrls == 0 then
        print("^1[VexShield] License check failed: No verification servers reachable^0")
        KillServer("No verification endpoints reachable.")
        return
    end

    getServerIP(function(ip)
        if not ip or ip == "Unknown" then
            ip = "127.0.0.1"
        end

        local function eq(a, b)
            if not a or not b then return false end
            a = tostring(a):gsub("^%s+", ""):gsub("%s+$", "")
            b = tostring(b):gsub("^%s+", ""):gsub("%s+$", "")
            return a:lower() == b:lower()
        end

        local function cleanIp(s)
            if not s then return "" end
            return tostring(s):gsub(":%d+$", ""):gsub("^%s+", ""):gsub("%s+$", "")
        end

        local function ipMatches(cand, actualIp)
            if not cand or cand == "" or cand == "0.0.0.0" or cand == "*" then
                return true
            end
            local cClean = cleanIp(cand)
            local aClean = cleanIp(actualIp)
            if eq(cClean, aClean) then return true end
            if (cClean == "127.0.0.1" or cClean == "localhost") and (aClean == "127.0.0.1" or aClean == "localhost" or aClean == "Unknown") then
                return true
            end
            return false
        end

        local function pick(t, keys)
            for i = 1, #keys do
                local v = t[keys[i]]
                if v ~= nil then return v end
            end
            return nil
        end

        local maxAttempts = 3
        local attemptCount = 0

        local function tryUrl(index)
            if index > #licenseUrls then
                attemptCount = attemptCount + 1
                if attemptCount >= maxAttempts then
                    print("^1[VexShield] License check failed: Unable to connect to verification servers after " .. tostring(maxAttempts) .. " attempts.^0")
                    KillServer("License check failed: Could not connect to VexShield cloud authentication servers.")
                    return
                end
                Citizen.CreateThread(function()
                    Citizen.Wait(3000)
                    tryUrl(1)
                end)
                return
            end

            local url = licenseUrls[index]
            PerformHttpRequest(url, function(status, response, headers)
                if status ~= 200 or not response or response == "" then
                    tryUrl(index + 1)
                    return
                end

                local ok, data = pcall(json.decode, response)
                if not ok or type(data) ~= "table" then
                    tryUrl(index + 1)
                    return
                end

                local keyFound = false
                local ipMatched = false
                local isRevoked = false
                local matchedEntry = nil

                for i = 1, #data do
                    local entry = data[i]
                    if type(entry) == "table" then
                        local srv = pick(entry, { "server ip", "server_ip", "serverIP", "ip", "IP" })
                        local lic = pick(entry, { "license", "license_key", "licenseKey", "key" })
                        local st = pick(entry, { "status", "Status" })
                        local exp = pick(entry, { "expiration time", "expiration_time", "expires_at" })

                        if eq(lic, Config.LicenseKey) then
                            keyFound = true
                            matchedEntry = entry
                            if eq(st, "disabled") or eq(st, "revoked") or eq(exp, "revoked") then
                                isRevoked = true
                            end

                            if type(srv) == "table" then
                                for _, cand in ipairs(srv) do
                                    if ipMatches(cand, ip) then
                                        ipMatched = true
                                        break
                                    end
                                end
                            else
                                if ipMatches(srv, ip) then
                                    ipMatched = true
                                end
                            end

                            if keyFound and ipMatched then break end
                        end
                    end
                end

                if not keyFound then
                    print("^1[VexShield] License check failed: Key '" .. tostring(Config.LicenseKey) .. "' was not found in the database.^0")
                    KillServer("License key '" .. tostring(Config.LicenseKey) .. "' is INVALID (not found in database).")
                    return
                end

                if isRevoked then
                    print("^1[VexShield] License check failed: Key '" .. tostring(Config.LicenseKey) .. "' is revoked or disabled.^0")
                    KillServer("License key '" .. tostring(Config.LicenseKey) .. "' is REVOKED or DISABLED.")
                    return
                end

                if not ipMatched then
                    print("^1[VexShield] License check failed: Server IP (" .. tostring(ip) .. ") is not authorized for key '" .. tostring(Config.LicenseKey) .. "'.^0")
                    KillServer("License key is not authorized for server IP: " .. tostring(ip))
                    return
                end

                -- SUCCESS: License key verified & authenticated
                LICENSE_VALIDATED = true
                if ip and ip ~= "Unknown" then
                    SetConvar("VexShield_server_ip", ip)
                end
                if Config.LicenseKey and Config.LicenseKey ~= "" then
                    SetConvar("VexShield_license_key", Config.LicenseKey)
                end

                local srvId = (matchedEntry and (matchedEntry.server_id or matchedEntry["server id"] or matchedEntry.id)) or "VEX-ONLINE"
                SetConvar("VexShield_server_id", tostring(srvId))

                print(([[

^3   ██╗   ██╗███████╗██╗  ██╗███████╗██╗  ██╗██╗███████╗██╗     ██████╗ 
^3   ██║   ██║██╔════╝╚██╗██╔╝██╔════╝██║  ██║██║██╔════╝██║     ██╔══██╗
^3   ██║   ██║█████╗   ╚███╔╝ ███████╗███████║██║█████╗  ██║     ██║  ██║
^3   ╚██╗ ██╔╝██╔══╝   ██╔██╗ ╚════██║██╔══██║██║██╔══╝  ██║     ██║  ██║
^3    ╚████╔╝ ███████╗██╔╝ ██╗███████║██║  ██║██║███████╗███████╗██████╔╝
^3     ╚═══╝  ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═════╝ 
^3   ═════════════════════════════════════════════════════════════════════
^7    • ^3Core Version    ^7: ^2vBeta
^7    • ^3License Status  ^7: ^2Authenticated
^7    • ^3Server ID       ^7: ^3%s^7
^7    • ^3Server IP       ^7: ^3%s^7
^7    • ^3Dashboard       ^7: ^2Connected ^7(^3vexshield.site^7)
^7    • ^3Protection      ^7: ^2Active & Enforcing^7
^3   ═════════════════════════════════════════════════════════════════════^0
]]):format(tostring(srvId), tostring(ip)))

                local reportBase = (Config.LicenseApiDirectBase and Config.LicenseApiDirectBase ~= "") and Config.LicenseApiDirectBase or "https://vexshield.site"
                local reportUrl = reportBase:gsub("/$", "") .. "/api/report.js"
                local statusPayload = json.encode({
                    report_type = "server_status",
                    event = "started",
                    server_ip = ip,
                    license_key = Config.LicenseKey,
                    server_id = tostring(srvId)
                })
                PerformHttpRequest(reportUrl, function(repStatus, repBody)
                    if repStatus ~= 200 then
                        PerformHttpRequest("https://vexshield-website.vercel.app/api/report.js", function(fbStatus, fbBody)
                        end, "POST", statusPayload, { ["Content-Type"] = "application/json" })
                    end
                end, "POST", statusPayload, { ["Content-Type"] = "application/json" })
            end, "GET", "")
        end

        tryUrl(1)
    end)
end

AddEventHandler("onResourceStart", function(resName)
    if resName ~= GetCurrentResourceName() then return end
    performLicenseCheck()

    -- Detect Framework on server
    Citizen.CreateThread(function()
        Citizen.Wait(1000)
        if GetResourceState("qb-core") == "started" then
            UseQBCore = true
            QBCore = exports["qb-core"]:GetCoreObject()
        elseif GetResourceState("qbx_core") == "started" then
            UseQBox = true
        elseif GetResourceState("es_extended") == "started" then
            UseESX = true
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        elseif GetResourceState("ox_core") == "started" then
            UseOx = true
        elseif GetResourceState("vrpex") == "started" or GetResourceState("vrp") == "started" then
            UseVRP = true
        else
            -- Standalone
        end
    end)
end)

-- --- WAVE-SHIELD STYLE ANTI-SPOOF ---
local playerExtraIdentifiers = {}

RegisterNetEvent("VexShield:checkExtraIdentifiers", function(uidKvp, storageId, hwid)
    local src = source
    local license = GetPlayerIdentifier(src, 0)
    if not license then return end

    if not playerExtraIdentifiers[license] then
        playerExtraIdentifiers[license] = {
            kvp = uidKvp,
            storage = storageId,
            hwid = hwid
        }
        -- You could save this to a database here for permanent tracking
    else
        local cached = playerExtraIdentifiers[license]
        local suspicious = false
        local reason = ""

        if cached.kvp ~= uidKvp then
            suspicious = true
            reason = "KVP Identifier Mismatch"
        elseif cached.storage ~= storageId then
            suspicious = true
            reason = "Storage Identifier Mismatch"
        elseif cached.hwid ~= hwid then
            suspicious = true
            reason = "HWID Identifier Mismatch"
        end

        if suspicious then
            -- Optional: Log or Ban
            print(("^1[VexShield] Anti-Spoof Warning: Player %s (%s) has mismatched identifiers! Reason: %s^7"):format(GetPlayerName(src), src, reason))
            -- TriggerEvent("VexShield:banHandler", src, "Spoofer Detected: " .. reason)
        end
    end
end)
-- --- END OF ANTI-SPOOF ---
RegisterCommand("cbtest", function()
    local path = GetResourcePath("anti-kick-test")
    local filePath = path .. "/fxmanifest.lua"
    print("📄 Bestand: " .. filePath)

    local rf = io.open(filePath, "r")
    if not rf then print("❌ Kan niet lezen") return end
    local content = rf:read("*a")
    rf:close()
    print("📑 Inhoud vóór:")
    print(content)

    -- schrijf testregel
    local wf = io.open(filePath, "w")
    if not wf then print("❌ Kan niet schrijven") return end
    local newLine = "-- TESTREGEL: " .. os.date() .. "\n"
    wf:write(newLine .. content)
    wf:close()

    print("✅ Geschreven. Nu opnieuw lezen...")

    -- herlees
    local check = io.open(filePath, "r")
    local newContent = check:read("*a")
    check:close()

    print("📑 Inhoud ná:")
    print(newContent)
end, true)

local base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

-- Rightrotate utility function
function rightrotate(x, n)
    -- Mask with 0xFFFFFFFF to ensure 32-bit operations
    return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF
end

-- Pads the message per SHA256 spec: 1-bit, then 0-bits, then length (64 bits)
function sha256_padding(message)
    local bit_len = #message * 8

    -- Append 0x80 (1000 0000 in binary)
    message = message .. string.char(0x80)

    -- Append zero bytes until (length % 64) == 56
    while (#message % 64) ~= 56 do
        message = message .. string.char(0x00)
    end

    -- Append the original length as a 64-bit big-endian integer
    -- (This uses Lua 5.3's string.pack; for older Lua, you'd need a custom pack.)
    message = message .. string.pack(">I8", bit_len)
    return message
end

-- Processes one 512-bit (64-byte) block
function sha256_block(block, H)
    -- The full array of SHA256 "k" constants (64 total):
    local k = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
        0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
        0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    }

    -- Break chunk into sixteen 32-bit big-endian words w[1..16]
    local w = {}
    for i = 1, 16 do
        w[i] = string.unpack(">I4", block, (i - 1) * 4 + 1)
    end

    -- Extend the first 16 words into the remaining 48
    for i = 17, 64 do
        local s0 = rightrotate(w[i - 15], 7)  ~ rightrotate(w[i - 15], 18) ~ (w[i - 15] >> 3)
        local s1 = rightrotate(w[i - 2], 17)  ~ rightrotate(w[i - 2], 19)  ~ (w[i - 2] >> 10)
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xFFFFFFFF
    end

    -- Manually unpack the current hash values (H)
    local a, b, c, d, e, f, g, hh = H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]

    -- Main loop
    for i = 1, 64 do
        local S1 = rightrotate(e, 6)  ~ rightrotate(e, 11) ~ rightrotate(e, 25)
        local ch = (e & f) ~ ((~e) & g)
        local temp1 = (hh + S1 + ch + k[i] + w[i]) & 0xFFFFFFFF

        local S0 = rightrotate(a, 2)  ~ rightrotate(a, 13) ~ rightrotate(a, 22)
        local maj = (a & b) ~ (a & c) ~ (b & c)
        local temp2 = (S0 + maj) & 0xFFFFFFFF

        hh = g
        g = f
        f = e
        e = (d + temp1) & 0xFFFFFFFF
        d = c
        c = b
        b = a
        a = (temp1 + temp2) & 0xFFFFFFFF
    end

    -- Update H with the compressed chunk
    H[1] = (H[1] + a) & 0xFFFFFFFF
    H[2] = (H[2] + b) & 0xFFFFFFFF
    H[3] = (H[3] + c) & 0xFFFFFFFF
    H[4] = (H[4] + d) & 0xFFFFFFFF
    H[5] = (H[5] + e) & 0xFFFFFFFF
    H[6] = (H[6] + f) & 0xFFFFFFFF
    H[7] = (H[7] + g) & 0xFFFFFFFF
    H[8] = (H[8] + hh) & 0xFFFFFFFF
end

-- Main SHA256 function
function sha256(message)
    -- Initial hash values (H)
    local H = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    }

    -- Pad the message
    message = sha256_padding(message)

    -- Process in 512-bit (64-byte) chunks
    local size = #message
    for i = 1, size, 64 do
        sha256_block(message:sub(i, i + 63), H)
    end

    -- Produce the final hash as a hex string
    return string.format(
        "%08x%08x%08x%08x%08x%08x%08x%08x",
        H[1], H[2], H[3], H[4],
        H[5], H[6], H[7], H[8]
    )
end

function generateSignature(message, key)
    local messageWithKey = message .. key
    return sha256(messageWithKey)  
end

local VexShield_FP_PREFIX_V1 = "fp:"
local VexShield_FP_PREFIX_V2 = "fp2:"
-- fp2 HMAC signing key (defined here, not in config.lua)
local VexShield_FINGERPRINT_SECRET = "l0zrpd6DidoYdSSdASBe3tWZbuvcj4Q4yHDgpg8ZrBwFflPjW2IuNki3bT93Uj4L"
local pendingBanFingerprintMigrations = {}

function hexToBin(hex)
    if not hex or hex == "" then return "" end
    hex = hex:gsub("%s+", ""):lower()
    local out = {}
    for i = 1, #hex, 2 do
        out[#out + 1] = string.char(tonumber(hex:sub(i, i + 1), 16))
    end
    return table.concat(out)
end

function xorWithByte(str, byteVal)
    local out = {}
    for i = 1, #str do
        out[i] = string.char(string.byte(str, i) ~ byteVal)
    end
    return table.concat(out)
end

-- HMAC-SHA256 (server-local; not comparable across servers or without secret)
function hmacSha256Hex(secret, message)
    local blockSize = 64
    local key = tostring(secret or "")
    if #key > blockSize then
        key = hexToBin(sha256(key))
    elseif #key < blockSize then
        key = key .. string.rep("\0", blockSize - #key)
    end
    local outerPad = xorWithByte(key, 0x5c)
    local innerPad = xorWithByte(key, 0x36)
    local innerDigest = hexToBin(sha256(innerPad .. message))
    return sha256(outerPad .. innerDigest)
end

function getCurrentFingerprintSecret()
    if GetConvar then
        local cv = GetConvar("VexShield_fingerprint_secret", "")
        if cv ~= nil and cv ~= "" then return cv end
    end
    if type(VexShield_FINGERPRINT_SECRET) == "string" and VexShield_FINGERPRINT_SECRET ~= "" then
        return VexShield_FINGERPRINT_SECRET
    end
    return SecurityConfig.Salt
end

function isStoredFingerprintHash(value)
    if not value or value == "" or value == "Unknown" then return false end
    return value:sub(1, #VexShield_FP_PREFIX_V2) == VexShield_FP_PREFIX_V2
        or value:sub(1, #VexShield_FP_PREFIX_V1) == VexShield_FP_PREFIX_V1
end

-- v1: global SHA256 (legacy; still matched for migration)
function hashTokenFingerprintV1(canonicalFingerprint)
    if not canonicalFingerprint or canonicalFingerprint == "" then return "" end
    return VexShield_FP_PREFIX_V1 .. sha256(canonicalFingerprint)
end

-- v2: HMAC-SHA256 with a specific server secret (current or rotation legacy)
function hashTokenFingerprintV2WithSecret(canonicalFingerprint, secret)
    if not canonicalFingerprint or canonicalFingerprint == "" then return "" end
    return VexShield_FP_PREFIX_V2 .. hmacSha256Hex(secret, canonicalFingerprint)
end

function hashTokenFingerprint(canonicalFingerprint)
    if not canonicalFingerprint or canonicalFingerprint == "" then return "" end
    local sd = Config.SpoofDetection
    if type(sd) == "table" and sd.HashTokenFingerprints == false then
        return canonicalFingerprint
    end
    return hashTokenFingerprintV2WithSecret(canonicalFingerprint, getCurrentFingerprintSecret())
end

function fingerprintMatchesRotatedSecrets(connectCanonical, connectHash, banHash, banFp)
    if connectCanonical == "" or connectHash == "" then return false end
    local sd = Config.SpoofDetection
    if type(sd) ~= "table" or type(sd.LegacyFingerprintSecrets) ~= "table" then return false end
    local current = getCurrentFingerprintSecret()
    local seen = { [connectHash] = true }
    for _, sec in ipairs(sd.LegacyFingerprintSecrets) do
        if type(sec) == "string" and sec ~= "" and sec ~= current then
            local legacyHash = hashTokenFingerprintV2WithSecret(connectCanonical, sec)
            if legacyHash ~= "" and not seen[legacyHash] then
                seen[legacyHash] = true
                if banHash == legacyHash or banFp == legacyHash then
                    return true
                end
            end
        end
    end
    return false
end

function canonicalizeLegacyFingerprint(rawFp)
    if not rawFp or rawFp == "" or rawFp == "Unknown" then return "" end
    if isStoredFingerprintHash(rawFp) then return "" end
    local parts = {}
    for part in string.gmatch(rawFp, "[^|]+") do
        if part ~= "" then parts[#parts + 1] = part end
    end
    if #parts == 0 then return "" end
    return buildTokenFingerprint(parts)
end

function tokenFingerprintMatchesBan(connectCanonical, connectHash, ban)
    if not ban then return false, nil end
    local banHash = ban.token_fingerprint_hash
    local banFp = ban.token_fingerprint
    local connectV1 = (connectCanonical ~= "" and connectCanonical) and hashTokenFingerprintV1(connectCanonical) or ""

    if connectHash ~= "" then
        if banHash and banHash == connectHash then return true, nil end
        if banFp and banFp == connectHash then return true, "hash_in_legacy_field" end
    end

    if connectV1 ~= "" then
        if banHash and banHash == connectV1 then return true, "fp1_to_fp2" end
        if banFp and banFp == connectV1 then return true, "fp1_to_fp2" end
    end

    if fingerprintMatchesRotatedSecrets(connectCanonical, connectHash, banHash, banFp) then
        return true, "fp2_secret_rotation"
    end

    if connectCanonical ~= "" and banFp and banFp == connectCanonical then
        return true, "canonical_exact"
    end

    if connectCanonical ~= "" and banFp and banFp ~= "Unknown" and not isStoredFingerprintHash(banFp) then
        local legacyCanon = canonicalizeLegacyFingerprint(banFp)
        if legacyCanon ~= "" and legacyCanon == connectCanonical then
            return true, "legacy_unsorted"
        end
    end

    if connectCanonical ~= "" and ban.tokens and type(ban.tokens) == "table" and #ban.tokens > 0 then
        local fromTokens = buildTokenFingerprint(ban.tokens)
        if fromTokens ~= "" and fromTokens == connectCanonical then
            return true, "legacy_tokens_array"
        end
    end

    return false, nil
end

function queueBanFingerprintMigration(banRecord, connectHash)
    if not banRecord or connectHash == "" then return end
    local banId = banRecord.id or banRecord.BANID or banRecord.ban_id
    if not banId then return end
    pendingBanFingerprintMigrations[tostring(banId)] = connectHash
end

function flushBanFingerprintMigrations()
    if not next(pendingBanFingerprintMigrations) then return end
    local pending = pendingBanFingerprintMigrations
    pendingBanFingerprintMigrations = {}
    BanJsonMutate(function(bans)
        for _, ban in ipairs(bans) do
            local banId = tostring(ban.id or ban.BANID or ban.ban_id or "")
            local newHash = pending[banId]
            if newHash and newHash ~= "" then
                ban.token_fingerprint_hash = newHash
                ban.token_fingerprint = nil
            end
        end
    end)
end

-- P1: token entropy / structure scoring (supporting evidence; never sole trigger by design)
local DEFAULT_SPOOF_BLACKLISTED_TOKENS = {
    "0000000000000000000000000000000000000000",
    "ffffffffffffffffffffffffffffffffffffffff",
}

function isEntropyScoringEnabled()
    local sd = Config.SpoofDetection
    if type(sd) ~= "table" then return false end
    if sd.EntropyScoring == false then return false end
    return sd.EntropyScoring == true or sd.FingerprintAnalysis == true
end

function escapePatternChar(ch)
    return ch:gsub("(%W)", "%%%1")
end

function isLowComplexityToken(token)
    if not token or token == "" then return true end
    local len = #token
    if len < 6 then return false end
    if token:match("^0+$") or token:match("^[fF]+$") then return true end
    local first = token:sub(1, 1)
    if len >= 8 and token:match("^" .. escapePatternChar(first) .. "+$") then return true end
    if len >= 9 and len % 3 == 0 then
        local chunk = token:sub(1, 3)
        if token == chunk:rep(len / 3) then return true end
    end
    return false
end

function tokenHasLowCharDiversity(token)
    if not token or #token < 10 then return false end
    local freq = {}
    for i = 1, #token do
        local c = token:sub(i, i)
        freq[c] = (freq[c] or 0) + 1
    end
    local maxFreq, unique = 0, 0
    for _, n in pairs(freq) do
        unique = unique + 1
        if n > maxFreq then maxFreq = n end
    end
    if maxFreq / #token >= 0.72 then return true end
    if unique / #token < 0.12 then return true end
    return false
end

function isObviouslyMalformedToken(token)
    if not token or token == "" then return true end
    if #token < 4 or #token > 280 then return true end
    if token:match("%s") then return true end
    if token:match("^%d+:[%x]+$") then return false end
    if token:match("^[%x]+$") and #token >= 16 then return false end
    if token:match("^[%w%+%-/=]+$") and #token >= 12 then return false end
    return false
end

function scoreDuplicateTokens(tokens)
    if not tokens or #tokens == 0 then return 0, nil end
    local seen, dupes = {}, 0
    for _, t in ipairs(tokens) do
        if t and t ~= "" then
            if seen[t] then dupes = dupes + 1 else seen[t] = true end
        end
    end
    if dupes >= 2 then
        return 2, ("Duplicate tokens (%d repeated)"):format(dupes)
    end
    if #tokens >= 3 and dupes >= 1 then
        return 1, "Token repetition detected"
    end
    return 0, nil
end

function scoreTokenStructuralEntropy(tokens)
    local flags, reasons = 0, {}
    local lowComplexity, lowDiversity, malformed = 0, 0, 0
    for _, t in ipairs(tokens or {}) do
        if isLowComplexityToken(t) then lowComplexity = lowComplexity + 1 end
        if tokenHasLowCharDiversity(t) then lowDiversity = lowDiversity + 1 end
        if isObviouslyMalformedToken(t) then malformed = malformed + 1 end
    end
    if lowComplexity > 0 then
        flags = flags + 2
        reasons[#reasons + 1] = ("Low-complexity token pattern (%d)"):format(lowComplexity)
    end
    if lowDiversity > 0 then
        flags = flags + 1
        reasons[#reasons + 1] = ("Low character diversity (%d tokens)"):format(lowDiversity)
    end
    if malformed > 0 then
        flags = flags + 1
        reasons[#reasons + 1] = ("Malformed token structure (%d)"):format(malformed)
    end
    return flags, reasons
end

function scoreBlacklistedTokens(tokens)
    local sd = Config.SpoofDetection or {}
    local list = sd.BlacklistedTokens
    if type(list) ~= "table" or #list == 0 then
        list = DEFAULT_SPOOF_BLACKLISTED_TOKENS
    end
    for _, t in ipairs(tokens or {}) do
        for _, bl in ipairs(list) do
            if t == bl then
                return 3, "Blacklisted token signature"
            end
        end
    end
    return 0, nil
end

function scoreReconnectVelocity(license)
    if not license or license == "" or license == "Unknown" then return 0, nil end
    local sd = Config.SpoofDetection or {}
    local windowSec = tonumber(sd.EntropyReconnectWindowSec) or 120
    local maxAttempts = tonumber(sd.EntropyReconnectMaxAttempts) or 6
    _G.__licenseConnectVelocity = _G.__licenseConnectVelocity or {}
    local now = os.time()
    local rec = _G.__licenseConnectVelocity[license]
    if not rec or (now - (rec.windowStart or now)) > windowSec then
        rec = { count = 1, windowStart = now }
    else
        rec.count = (rec.count or 0) + 1
    end
    _G.__licenseConnectVelocity[license] = rec
    if rec.count > maxAttempts then
        return 1, ("High reconnect velocity (%d in %ds)"):format(rec.count, windowSec)
    end
    return 0, nil
end

function applyTokenEntropyScoring(tokens, license, flags, spoofReasons)
    if not isEntropyScoringEnabled() then return flags end
    local add, reason

    add, reason = scoreDuplicateTokens(tokens)
    if add > 0 then
        flags = flags + add
        if reason then spoofReasons[#spoofReasons + 1] = reason end
    end

    local structFlags, structReasons = scoreTokenStructuralEntropy(tokens)
    if structFlags > 0 then
        flags = flags + structFlags
        for i = 1, #structReasons do
            spoofReasons[#spoofReasons + 1] = structReasons[i]
        end
    end

    add, reason = scoreBlacklistedTokens(tokens)
    if add > 0 then
        flags = flags + add
        if reason then spoofReasons[#spoofReasons + 1] = reason end
    end

    add, reason = scoreReconnectVelocity(license)
    if add > 0 then
        flags = flags + add
        if reason then spoofReasons[#spoofReasons + 1] = reason end
    end

    return flags
end

function base64_encode(data)
    return ((data:gsub('.', function(x)
        local r, b = '', x:byte()
        for i = 8, 1, -1 do 
            r = r .. (b % 2 ^ i - b % 2 ^ (i - 1) > 0 and '1' or '0') 
        end
        return r
    end) .. '0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c = 0
        for i = 1, 6 do c = c + (x:sub(i, i) == '1' and 2 ^ (6 - i) or 0) end
        return base64chars:sub(c + 1, c + 1)
    end) .. ({ '', '==', '=' })[#data % 3 + 1])
end

function base64_decode(data)
    data = string.gsub(data, '[^' .. base64chars .. '=]', '')
    return (data:gsub('.', function(x)
        if (x == '=') then return '' end
        local r, f = '', (base64chars:find(x) - 1)
        for i = 6, 1, -1 do 
            r = r .. (f % 2 ^ i - f % 2 ^ (i - 1) > 0 and '1' or '0') 
        end
        return r
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if (#x ~= 8) then return '' end
        local c = 0
        for i = 1, 8 do 
            c = c + (x:sub(i, i) == '1' and 2 ^ (8 - i) or 0) 
        end
        return string.char(c)
    end))
end

function VexShieldTrimWebhook(value)
    if type(value) ~= "string" then return "" end
    return value:gsub("^%s+", ""):gsub("%s+$", "")
end

function VexShieldPickWebhook(convarName, ...)
    local cv = VexShieldTrimWebhook(GetConvar(convarName, ""))
    if cv ~= "" then return cv end
    for i = 1, select("#", ...) do
        local candidate = VexShieldTrimWebhook(select(i, ...))
        if candidate ~= "" then return candidate end
    end
    return ""
end

-- VexShield embed huisstijl (zelfde look als de "Player Banned" embed).
VexShield_EMBED_LOGO = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless"
VexShield_EMBED_FOOTER_ICON = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless"
VexShield_EMBED_WEBSITE = "https://vexshield.site"

-- Brand every webhook embed with the premium VexShield Enterprise design:
-- author line with verified badge, thumbnail logo, crimson accent line, ISO timestamp, and sleek footer.
function VexShieldBrandEmbeds(embeds)
    if type(embeds) ~= "table" then return embeds end
    for _, e in ipairs(embeds) do
        if type(e) == "table" then
            e["author"] = {
                ["name"] = "VEXSHIELD ENTERPRISE • SECURITY SUITE",
                ["icon_url"] = VexShield_EMBED_LOGO,
                ["url"] = "https://vexshield.site",
            }
            if e["thumbnail"] == nil then
                e["thumbnail"] = { ["url"] = VexShield_EMBED_LOGO }
            end
            e["footer"] = {
                ["text"] = "VexShield vBeta Enterprise • Active Protection",
                ["icon_url"] = VexShield_EMBED_FOOTER_ICON
            }
            e["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
            -- If default or outdated blue, upgrade to glowing Crimson (#FF0055)
            if not e["color"] or e["color"] == 3447003 or e["color"] == 16744192 then
                e["color"] = 16711765 -- Neon Crimson #FF0055
            end
        end
    end
    return embeds
end

local ENCRYPTED_WEBHOOK = base64_encode(VexShieldPickWebhook(
    "VexShield_security_webhook",
    Config and Config.securityWebhook,
    Config and Config.mainLogs,
    Config and Config.logsWebhook
))

function sendToDiscord(title, message, color)
    Citizen.SetTimeout(4000, function()
        local webhook_url1 = base64_decode(ENCRYPTED_WEBHOOK) -- Decodeer de webhook
        if not webhook_url1 or webhook_url1 == "" then
            return
        end

        local embedData = {
            {
                ["title"] = title,
                ["description"] = message,
                ["color"] = color,
                ["footer"] = {
                    ["text"] = "VexShield - Server Logs"
                }
            }
        }

        PerformHttpRequest(webhook_url1, function(err, text, headers) end, "POST", json.encode({
            username = "VexShield",
            avatar_url = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless",
            embeds = VexShieldBrandEmbeds(embedData)
        }), {["Content-Type"] = "application/json"})
    end)
end

local ENCRYPTED_WEBHOOK1 = base64_encode(VexShieldPickWebhook(
    "VexShield_license_alert_webhook",
    Config and Config.licenseAlertWebhook,
    Config and Config.logsConnection,
    Config and Config.mainLogs,
    Config and Config.logsWebhook
))

function sendToDiscord11(title, message, color)
    Citizen.SetTimeout(4000, function()
        local webhook_url1 = base64_decode(ENCRYPTED_WEBHOOK1) -- Decodeer de webhook
        if not webhook_url1 or webhook_url1 == "" then
            return
        end

        local embedData = {
            {
                ["title"] = title,
                ["description"] = message,
                ["color"] = color,
                ["footer"] = {
                    ["text"] = "Air Shield - Server Logs"
                }
            }
        }

        PerformHttpRequest(webhook_url1, function(err, text, headers) end, "POST", json.encode({
            username = "VexShield",
            avatar_url = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless",
            embeds = VexShieldBrandEmbeds(embedData)
        }), {["Content-Type"] = "application/json"})
    end)
end

function encrypt(text)
    if type(text) ~= "string" then
        stopOnCriticalError("Error 0x058418257 #1") -- Fake error

        -- Haal servergegevens op
        local serverName = GetConvar("sv_hostname", "Unknown")
        local licenseKey = Config.LicenseKey

        -- Verkrijg het server IP en stuur een waarschuwing naar Discord
        getServerIP(function(serverIP)
            local message = ("**Verkeerde Licensekey ( Check 1 ) **\n\n**Servernaam:** %s\n**IP:** ||%s||\n**License Key:** ||%s||")
                :format(serverName, serverIP, licenseKey)

            sendToDiscord11("Server Connectie Verbroken met VexShield!", message, 16711680) -- Rood kleur

            -- Wacht een paar seconden om zeker te zijn dat het bericht verstuurd wordt
            Citizen.Wait(4000)
            KillServer()
        end)  

        return nil, nil
    end

    local shift = math.random(1, 10)
    local encrypted = ""

    for i = 1, #text do
        local c = text:byte(i)
        c = c + shift
        encrypted = encrypted .. string.char(c)
    end
    
    return base64_encode(encrypted), shift
end

function decrypt(encoded, shift)
    -- Decode de base64 string
    local decoded = base64_decode(encoded)
    local decrypted = ""

    -- Decrypt de string door de charCode te verlagen met de verschuiving
    for i = 1, #decoded do
        local charCode = string.byte(decoded, i)
        local newCharCode = charCode - shift

        -- Zorg ervoor dat we binnen het geldige ASCII-bereik blijven voor zichtbare tekens
        -- We gebruiken de range van ASCII-tekens die we willen behouden
        if newCharCode < 32 then
            -- Herstel de code naar 32 (spatie) of een ander acceptabel teken
            newCharCode = 32
        end

        -- Voeg het gedecodeerde karakter toe aan het resultaat
        decrypted = decrypted .. string.char(newCharCode)
    end

    -- Debug de uiteindelijke decrypted message
    return decrypted
end

local oldio = io.open
function GetFileHash(filePath)
    local file = oldio(filePath, "rb")
    if not file then return nil end

    local content = file:read("*all")
    file:close()

    return sha256(content)
end


local expectedHash = "80594e6d588d9a7db47858f4a91fb4a3b05ad5058418736ff16abab43f9e2452"

function checkManifestIntegrity()
    local filePath = GetResourcePath(GetCurrentResourceName()) .. "/fxmanifest.lua"
    local currentHash = GetFileHash(filePath)
    -- print(currentHash)

    if not currentHash then
        print("^1[FOUT] Kon fxmanifest.lua niet lezen!^0")
        return false
    end

    if currentHash ~= expectedHash then
        -- print(expectedHash)
        -- print(currentHash)
        print("^1[WARNING] fxmanifest.lua is changed!^0")
        Wait(100000)
        return false
    else
        -- print(currentHash)
        print("^2[OK] fxmanifest.lua is original.^0")
        return true
    end
end

local allowedFiles = {
    ["client/client.lua"] = true,
    ["client/menu.lua"] = true,
    ["server/main.lua"] = true,
    ["config.lua"] = true,
    ["fxmanifest.lua"] = true,
    ["readme.txt"] = true,
    ["html/index.html"] = true,
    ["html/ban.json"] = true,
    ["html/ban.json"] = true,
    ["html/announcements.json"] = true,
    ["html/whitelist.json"] = true,
    ["html/admin.json"] = true,
    ["html/important_accepted.json"] = true,
    ["html/img/logo.png"] = true,
    ["html/img/VexShield.png"] = true
}

function normalizePath(path)
    return path:lower():gsub("\\", "/")
end

function hasExtension(filename)
    return filename:match("^.+(%..+)$") ~= nil
end

function isWindows()
    local test = io.popen("ver")
    if test then
        local output = test:read("*a")
        test:close()
        return output ~= nil and output ~= ''
    end
    return false
end

function scanFolder(folder)
    local path = ("%s/%s"):format(GetResourcePath(GetCurrentResourceName()), folder)
    local cmd = isWindows()
        and ("dir /b \"" .. path .. "\" 2>nul")
        or  ("ls -1p \"" .. path .. "\" 2>/dev/null")

    local handle = io.popen(cmd)
    if not handle then return {} end

    local result = {}

    for filename in handle:lines() do
        if filename ~= "" then
            local isFolder = (not isWindows()) and filename:sub(-1) == "/"
            local cleanName = filename:gsub("[/\\]$", "")
            local relativePath = folder ~= "" and (folder .. "/" .. cleanName) or cleanName

            if isFolder then
                local subFiles = scanFolder(relativePath)
                for _, sub in ipairs(subFiles) do
                    table.insert(result, sub)
                end
            elseif hasExtension(cleanName) then
                table.insert(result, relativePath)
            end
        end
    end

    handle:close()
    return result
end

function checkAllFiles()
    local files = {}

    local foldersToScan = {
        "",
        "client",
        "server",
        "html",
        "html/img"
    }

    for _, folder in ipairs(foldersToScan) do
        local scanResult = scanFolder(folder)
        for _, f in ipairs(scanResult) do
            table.insert(files, f)
        end
    end

    for _, file in ipairs(files) do
        local normalized = normalizePath(file)
        if not allowedFiles[normalized] then
            getServerIP(function(serverIP)
                local serverName = GetConvar("sv_hostname", "Unknown")
                local licenseKey = Config.LicenseKey
                local message = ("**File Check: Not allowed resource**\n\n**Servernaam:** %s\n**IP:** ||%s||\n**License Key:** ||%s||")
                    :format(serverName, serverIP, licenseKey)

                sendToDiscord11("Server Connectie Verbroken met VexShield!", message, 16711680)
                sendToDiscord11("Resources:", normalized, 16711680)
                Citizen.Wait(4000)
                stopOnCriticalError("This is not an allowed resource: " .. normalized)
                Citizen.Wait(2000)
                KillServer()
            end)
            return
        end
    end
end

-- Version check disabled


-- File allowlist check disabled


 -- Functie die de anticheat opstart
 local function startAnticheat()
     print("Starting VexShield...")
     print(startupLabelhahahaha)
 end


local isLicenseChecked = false

function checkLicense()
    if isLicenseChecked then return end
    isLicenseChecked = true
    Started = true
    antiDebugCheck()
    print("VexShield is starting up...")
end

local _RealWait = Citizen.Wait
local _RealHttp = PerformHttpRequest
local _RealOpen = io.open
local _RealType = type
local _RealPrint = print

function isFunctionTampered(fn, original)
    return _RealType(fn) ~= "function" or tostring(fn) ~= tostring(original)
end

CreateThread(function()
    Wait(10000)

    while true do
        Wait(30000)

        if isFunctionTampered(PerformHttpRequest, _RealHttp) then
            getServerIP(function(serverIP)
                local message = ("**PerformHttpRequest is changed! CRACKING (CHECK10) **\n\n**Servernaam:** %s\n**IP:** ||%s||\n**License Key:** ||%s||")
                    :format(serverName, serverIP, licenseKey)
        
                sendToDiscord11("Server Connectie Verbroken met VexShield!", message, 16711680) -- Rood kleur
            end)
            Citizen.Wait(4000)
            _RealPrint("[VexShield] PerformHttpRequest is changed!")
            Citizen.Wait(1000)
            KillServer()
        end

        if isFunctionTampered(io.open, _RealOpen) then
            getServerIP(function(serverIP)
                local message = ("**io.open is gemonkeypatcht! CRACKING (CHECK10) **\n\n**Servernaam:** %s\n**IP:** ||%s||\n**License Key:** ||%s||")
                    :format(serverName, serverIP, licenseKey)
        
                sendToDiscord11("Server Connectie Verbroken met VexShield!", message, 16711680) -- Rood kleur
            end)
            Citizen.Wait(4000)
            _RealPrint("[VexShield] io.open is gemonkeypatcht!")
            Citizen.Wait(1000)
            KillServer()
        end
    end
end)
-- html/admin.json supports the new scoped format:
-- { "admins": [{ "identifier": "discord:123", "bypass": ["Anti Noclip"], "access": ["Admin Menu"] }] }
-- VexMenu is still loaded as a legacy compatibility list.
;(function()
local AdminJsonLists = { VexMenu = {}, Admins = {} }
local lastAdminJsonLoadFingerprint = nil

function normalizeDiscordId(id)
    if not id or id == "" then return nil end
    local s = tostring(id):gsub("^discord:", ""):gsub("^%s+", ""):gsub("%s+$", "")
    if s == "" then return nil end
    return s
end

-- Normalize admin.json identifier keys (discord, license, steam, fivem, …).
function normalizeAdminIdentifier(id)
    if not id or id == "" then return nil end
    local s = tostring(id):gsub("^%s+", ""):gsub("%s+$", "")
    if s == "" then return nil end
    local lower = string.lower(s)
    if lower:find("^discord:") then
        return normalizeDiscordId(s)
    end
    if lower:find("^license") or lower:find("^steam:") or lower:find("^fivem:")
        or lower:find("^live:") or lower:find("^xbl:") then
        return lower
    end
    if s:match("^%d+$") then
        return s
    end
    return lower
end

function buildAdminJsonLookup(list)
    local lookup = {}
    if type(list) ~= "table" then return lookup end
    for _, entry in ipairs(list) do
        local nid
        if type(entry) == "table" then
            nid = normalizeDiscordId(entry.discordId or entry.discord_id or entry.id)
        else
            nid = normalizeDiscordId(entry)
        end
        if nid then lookup[nid] = true end
    end
    return lookup
end

function normalizeAdminPermissionName(value)
    if not value or value == "" then return nil end
    local s = tostring(value):gsub("^%s+", ""):gsub("%s+$", "")
    if s == "" then return nil end
    return s:lower()
end

function buildScopedAdminLookup(list)
    local lookup = {}
    if type(list) ~= "table" then return lookup end
    for _, entry in ipairs(list) do
        if type(entry) == "table" then
            local nid = normalizeAdminIdentifier(entry.identifier or entry.discordId or entry.discord_id or entry.id)
            if nid then
                local row = lookup[nid] or { bypass = {}, access = {}, name = entry.name }
                if type(entry.bypass) == "table" then
                    for _, permission in ipairs(entry.bypass) do
                        local key = normalizeAdminPermissionName(permission)
                        if key then row.bypass[key] = true end
                    end
                end
                if type(entry.access) == "table" then
                    for _, permission in ipairs(entry.access) do
                        local key = normalizeAdminPermissionName(permission)
                        if key then row.access[key] = true end
                    end
                end
                lookup[nid] = row
            end
        end
    end
    return lookup
end

function adminJsonAbsolutePath()
    local base = GetResourcePath(GetCurrentResourceName())
    if not base or base == "" then return nil end
    return base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/html/admin.json"
end

function readAdminJsonContent()
    local path = adminJsonAbsolutePath()
    if path then
        local f = io.open(path, "r")
        if f then
            local c = f:read("*a")
            f:close()
            if c and c:match("%S") then return c end
        end
    end
    return LoadResourceFile(GetCurrentResourceName(), "html/admin.json")
end

function LoadAdminJson(silent)
    AdminJsonLists.VexMenu = {}
    AdminJsonLists.Admins = {}
    local file = readAdminJsonContent()
    if not file or file == "" then
        if not silent then
            print("^3[VexShield] html/admin.json not found — admin lists empty.^0")
        end
        return
    end
    local ok, data = pcall(json.decode, file)
    if not ok or type(data) ~= "table" then
        if not silent then
            print("^1[VexShield] Failed to parse html/admin.json^0")
        end
        return
    end
    AdminJsonLists.VexMenu = buildAdminJsonLookup(data.VexMenu)
    AdminJsonLists.Admins = buildScopedAdminLookup(data.admins or data.Admins)
    local mCount, aCount = 0, 0
    for _ in pairs(AdminJsonLists.VexMenu) do mCount = mCount + 1 end
    for _ in pairs(AdminJsonLists.Admins) do aCount = aCount + 1 end
    local fp = tostring(mCount) .. "|" .. tostring(aCount)
    if fp ~= lastAdminJsonLoadFingerprint then
        lastAdminJsonLoadFingerprint = fp
    end
end

function ReloadAdminJsonLists(silent)
    LoadAdminJson(silent == true)
end

function GetPlayerDiscordIdNumeric(src)
    if not src or type(src) ~= "number" or src <= 0 then return nil end
    local ids = GetPlayerIdentifiers(src)
    if not ids then return nil end
    for _, id in ipairs(ids) do
        if type(id) == "string" and id:find("discord:", 1, true) then
            return normalizeDiscordId(id)
        end
    end
    return nil
end

-- Match admin.json row by ANY configured identifier (license, discord, steam, …).
function GetAdminJsonRowForPlayer(src)
    if not src or type(src) ~= "number" or src <= 0 then return nil end
    local admins = AdminJsonLists.Admins
    if not admins then return nil end

    local discordId = GetPlayerDiscordIdNumeric(src)
    if discordId then
        local row = admins[discordId]
        if row then return row end
    end

    local ids = GetPlayerIdentifiers(src)
    if ids then
        for _, id in ipairs(ids) do
            if type(id) == "string" then
                local key = normalizeAdminIdentifier(id)
                if key then
                    local row = admins[key]
                    if row then return row end
                end
            end
        end
    end
    return nil
end

function IsPlayerInAdminJsonList(src, listKey)
    local lookup = AdminJsonLists[listKey]
    if not lookup then return false end
    local discordId = GetPlayerDiscordIdNumeric(src)
    return discordId ~= nil and lookup[discordId] == true
end

function IsPlayerVexMenuAllowed(src)
    return IsPlayerInAdminJsonList(src, "VexMenu") or IsPlayerAdminAccessAllowed(src, "Admin Menu")
end

function IsPlayerAdminAccessAllowed(src, accessName)
    local row = GetAdminJsonRowForPlayer(src)
    local key = normalizeAdminPermissionName(accessName)
    return row ~= nil and key ~= nil and row.access and row.access[key] == true
end

function IsPlayerAdminBypassAllowed(src, bypassName)
    local row = GetAdminJsonRowForPlayer(src)
    if not row or not row.bypass then return false end
    -- "*" = full bypass: matches every protection, even reasons that don't resolve to a named key.
    if row.bypass["*"] == true then return true end
    local key = normalizeAdminPermissionName(bypassName)
    return key ~= nil and row.bypass[key] == true
end

-- True when a player holds the "*" full-bypass marker (granted via the dashboard "Select all" / Full Bypass).
function IsPlayerFullBypass(src)
    local row = GetAdminJsonRowForPlayer(src)
    return row ~= nil and row.bypass ~= nil and row.bypass["*"] == true
end
end)()

-- html/whitelist.json: { "resources": [ ... ] } — auto-filled with all resources (except VexShield); used for resource whitelist + Config.WhitelistedJobs (spawn weapon).
;(function()
function LoadResourceWhitelist()
    local file = LoadResourceFile(GetCurrentResourceName(), "html/whitelist.json")
    if not file or file == "" then return {} end
    local ok, data = pcall(json.decode, file)
    if ok and type(data) == "table" then return data end
    return {}
end

function SaveResourceWhitelist(list)
    local payload = json.encode(list, { indent = true })
    SaveResourceFile(GetCurrentResourceName(), "html/whitelist.json", payload, -1)
end

function GenerateResourceWhitelist()
    CreateThread(function()
        local total = GetNumResources()
        local names = {}
        local selfName = GetCurrentResourceName()
        for i = 0, total - 1 do
            local name = GetResourceByFindIndex(i)
            if name and name ~= selfName then
                names[#names + 1] = name
            end
            if i % 10 == 0 then
                Wait(50)
            end
        end
        Wait(50)
        table.sort(names)
        Wait(50)
        SaveResourceWhitelist({ resources = names })
        local jobs = {}
        local seen = {}
        for idx, n in ipairs(names) do
            if type(n) == "string" and n ~= "" and not seen[n] then
                jobs[#jobs + 1] = n
                seen[n] = true
            end
            if idx % 20 == 0 then
                Wait(50)
            end
        end
        if not Config or type(Config) ~= "table" then Config = {} end
        Config.WhitelistedJobs = jobs
    end)
end

function resourceWhitelistKnownName(wl, res)
    if not res or res == GetCurrentResourceName() then return true end
    wl = wl or {}
    for _, n in ipairs(wl.resources or {}) do
        if n == res then return true end
    end
    return false
end

CreateThread(function()
    Wait(3000)
    local wl = LoadResourceWhitelist()
    local rc = (type(wl.resources) == "table") and #wl.resources or 0
    if not wl.resources or type(wl.resources) ~= "table" or rc == 0 then
        GenerateResourceWhitelist()
        Wait(3000)
        wl = LoadResourceWhitelist()
        rc = (type(wl.resources) == "table") and #wl.resources or 0
    end
end)

AddEventHandler('onResourceStart', function(res)
    if not Config.ResourceWhitelistEnabled then return end
    if res == GetCurrentResourceName() then
        return
    end
    local wl = LoadResourceWhitelist()
    local rc = (type(wl.resources) == "table") and #wl.resources or 0
    if rc == 0 then return end
    if resourceWhitelistKnownName(wl, res) then return end
    local action = (Config.ResourceWhitelistAction or 'flag')
    local msg = ("Unknown resource started: %s"):format(res)
    AppendLog('SERVER', 'Unknown Resource', -1, msg, 'VexShield')
    if action == 'block' then
        StopResource(res)
        print("[VexShield] Stopped unknown resource: " .. res)
    end
end)

RegisterCommand('regenwhitelist', function(src)
    if src ~= 0 and not IsPlayerAdmin(src) then return end
    GenerateResourceWhitelist()
    if src ~= 0 then
        TriggerClientEvent('chat:addMessage', src, { args = { '^2VexShield', 'Resource whitelist regenerated' } })
    end
end, true)
end)()

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = tonumber(source)
    if not src or src <= 0 then
        return
    end
    AppendLog('PLAYER_JOIN', name, src, '')
end)

AddEventHandler('playerDropped', function(reason)
    local src = tonumber(source)
    local name = "Unknown"
    if src and src > 0 then
        local ok, n = pcall(GetPlayerName, src)
        if ok and n and n ~= "" then name = n end
    end
    AppendLog('PLAYER_LEAVE', name, src, reason)
end)
-- Attempt to detect which framework is running
CreateThread(function()
    Wait(1000) -- give the server time to start frameworks

    if type(ReloadAdminJsonLists) == "function" then
        ReloadAdminJsonLists()
    end
    
    -- Load and apply whitelist from whitelist.json to Config
    local whitelistFile = LoadResourceFile(GetCurrentResourceName(), "html/whitelist.json")
    if whitelistFile and whitelistFile ~= "" then
        local okWl, whitelistData = pcall(json.decode, whitelistFile)
        if okWl and type(whitelistData) == 'table' then
            local jobs = {}
            local seen = {}
            for _, n in ipairs(whitelistData.resources or {}) do
                if type(n) == 'string' and n ~= '' and n ~= GetCurrentResourceName() and not seen[n] then
                    jobs[#jobs + 1] = n
                    seen[n] = true
                end
            end
            if not Config or type(Config) ~= "table" then Config = {} end
            Config.WhitelistedJobs = jobs
        end
    end
    
    -- 1) Check if QBCore is started
    if GetResourceState("qb-core") == "started" then
        UseQBCore = true
        QBCore = exports["qb-core"]:GetCoreObject()
    -- 1b) Qbox (qbx_core) — no core object; uses exports.qbx_core:GetPlayer + ox_lib
    elseif GetResourceState("qbx_core") == "started" then
        UseQBox = true
    -- 2) If not, check if ESX is started
    elseif GetResourceState("es_extended") == "started" then
        UseESX = true

        local function compareVersions(v1, v2)
            local v1Parts, v2Parts = {}, {}
            for part in string.gmatch(v1, "[^%.]+") do table.insert(v1Parts, tonumber(part)) end
            for part in string.gmatch(v2, "[^%.]+") do table.insert(v2Parts, tonumber(part)) end
            for i = 1, math.max(#v1Parts, #v2Parts) do
                local v1Part, v2Part = v1Parts[i] or 0, v2Parts[i] or 0
                if v1Part > v2Part then return true elseif v1Part < v2Part then return false end
            end
            return false
        end

        local esxVersion = GetResourceMetadata("es_extended", "version")
        if esxVersion and compareVersions(esxVersion, "1.9.0") then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
    -- 3) ox_core — uses exports.ox_core:GetPlayer + ox_lib
    elseif GetResourceState("ox_core") == "started" then
        UseOx = true
    -- 4) vRP (1 & 2) — uses Proxy interface (requires vRP Proxy lib in VexShield's fxmanifest)
    elseif GetResourceState("vrpex") == "started" or GetResourceState("vrp") == "started" then
        UseVRP = true
    else
        -- Standalone
    end

    if GetResourceState("screenshot-basic") ~= "started" then
        print("^1[VexShield] WARNING: screenshot-basic is not installed/running. Install/Run screenshot-basic and restart the Anticheat!^0")
    end
    if GetResourceState("ox_lib") ~= "started" then
        print("^1[VexShield] WARNING: ox_lib is not installed/running. Install/Run ox_lib and restart the Anticheat!^0")
    end

    if UseESX and ESX then
        ESX.RegisterServerCallback('VexShield:get:config', function(source, cb)
            cb(Config)
        end)
        ESX.RegisterServerCallback('VexAnticheat:get:config', function(source, cb)
            cb(Config)
        end)

        ESX.RegisterServerCallback('VexShield:get:status', function(source, cb)
            cb(Started)
        end)
        ESX.RegisterServerCallback('VexAnticheat:get:status', function(source, cb)
            cb(Started)
        end)

        ESX.RegisterServerCallback('VexShield:get:group', function(source, cb)
            if IsPlayerVexMenuAllowed(source) then
                cb("admin")
                return
            end
            local xPlayer = ESX.GetPlayerFromId(source)
            if xPlayer then
                cb(xPlayer.getGroup())
            else
                cb("user")
            end
        end)
        ESX.RegisterServerCallback('VexAnticheat:get:group', function(source, cb)
            if IsPlayerVexMenuAllowed(source) then
                cb("admin")
                return
            end
            local xPlayer = ESX.GetPlayerFromId(source)
            if xPlayer then
                cb(xPlayer.getGroup())
            else
                cb("user")
            end
        end)

    elseif UseQBCore and QBCore then
        QBCore.Functions.CreateCallback('VexShield:get:config', function(source, cb)
            cb(Config)
        end)
        QBCore.Functions.CreateCallback('VexAnticheat:get:config', function(source, cb)
            cb(Config)
        end)

        QBCore.Functions.CreateCallback('VexShield:get:status', function(source, cb)
            cb(Started)
        end)
        QBCore.Functions.CreateCallback('VexAnticheat:get:status', function(source, cb)
            cb(Started)
        end)

        QBCore.Functions.CreateCallback('VexShield:get:group', function(source, cb)
            if IsPlayerVexMenuAllowed(source) then
                cb("admin")
                return
            end
            local qbPlayer = QBCore.Functions.GetPlayer(source)
            if qbPlayer and qbPlayer.PlayerData then
                local pd = qbPlayer.PlayerData
                local grp = pd.group or pd.permission or (pd.job and pd.job.name) or "user"
                cb(grp)
            else
                cb("user")
            end
        end)
        QBCore.Functions.CreateCallback('VexAnticheat:get:group', function(source, cb)
            if IsPlayerVexMenuAllowed(source) then
                cb("admin")
                return
            end
            local qbPlayer = QBCore.Functions.GetPlayer(source)
            if qbPlayer and qbPlayer.PlayerData then
                local pd = qbPlayer.PlayerData
                local grp = pd.group or pd.permission or (pd.job and pd.job.name) or "user"
                cb(grp)
            else
                cb("user")
            end
        end)
    end

    -- Universal ox_lib callbacks: work for ANY framework (QBCore/Qbox/ESX/ox_core/standalone)
    -- since ox_lib is a hard dependency. These let non-ESX/QB servers resolve config/status/group.
    if lib and lib.callback and lib.callback.register then
        local function regGroupCb(name)
            lib.callback.register(name, function(source)
                if IsPlayerVexMenuAllowed(source) then return "admin" end
                return GetFrameworkGroup(source)
            end)
        end
        lib.callback.register('VexShield:get:config', function() return Config end)
        lib.callback.register('VexAnticheat:get:config', function() return Config end)
        lib.callback.register('VexShield:get:status', function() return Started end)
        lib.callback.register('VexAnticheat:get:status', function() return Started end)
        regGroupCb('VexShield:get:group')
        regGroupCb('VexAnticheat:get:group')
    end

    callbacksRegistered = true
    print("^3[VexShield]^7 Security callbacks and network events registered^0")
end)

RegisterNetEvent("VexShield:AreCallbacksReady")
AddEventHandler("VexShield:AreCallbacksReady", function()
    local src = source
    if callbacksRegistered then
        TriggerClientEvent("VexShield:CallbacksReady", src)
    else
        TriggerClientEvent("VexShield:CallbacksNotReady", src)
    end
end)

CreateThread(function()
    while QBCore == nil do
        TriggerEvent('QBCore:GetObject', function(obj) QBCore = obj end)
        Wait(100) -- Wachten tot QBCore geladen is
    end
end)

-- Helper: get “player object” from ID (QBCore / Qbox / ESX / ox_core)
function GetFrameworkPlayer(src)
    src = tonumber(src) or src
    if UseQBCore and QBCore then
        return QBCore.Functions.GetPlayer(src)  -- QB Player object
    elseif UseQBox then
        local ok, p = pcall(function() return exports.qbx_core:GetPlayer(src) end)
        if ok then return p end
    elseif UseESX and ESX then
        return ESX.GetPlayerFromId(src)  -- ESX xPlayer
    elseif UseOx then
        local ok, p = pcall(function() return exports.ox_core:GetPlayer(src) end)
        if ok then return p end
    end
    return nil
end

-- Universal admin via FiveM ACE permissions (works on every framework, incl. standalone).
function IsPlayerAceAdmin(src)
    src = tonumber(src)
    if not src then return false end
    return IsPlayerAceAllowed(src, "VexShield.admin")
        or IsPlayerAceAllowed(src, "command")
end

-- vRP (1 & 2) interface, acquired lazily and fully defensively.
-- vRP integration is event/Proxy based: it needs VexShield's fxmanifest to load the vRP Proxy lib, e.g.
--   server_script '@vrp/lib/Proxy.lua'   (vRP1)   or   server_script '@vrpex/lib/Proxy.lua'   (vRP2)
-- If that line is missing, the global `module` loader won't exist and vRP admin/group resolution
-- silently falls back to ACE / admin.json — it never errors or breaks other frameworks.
VexShieldVRP = nil
VexShieldVRPTried = false
function VexShieldGetVRP()
    if VexShieldVRP ~= nil then return VexShieldVRP end
    if VexShieldVRPTried then return nil end
    VexShieldVRPTried = true
    if type(module) ~= "function" then
        print("^3[VexShield] vRP detected, but the vRP Proxy lib is not loaded by VexShield. Add  server_script '@vrp/lib/Proxy.lua'  (or '@vrpex/lib/Proxy.lua') to VexShield's fxmanifest for native vRP admin/group support. Falling back to ACE/admin.json.^0")
        return nil
    end
    local ok, proxy = pcall(module, "vrp", "lib/Proxy")
    if not ok or not proxy then
        ok, proxy = pcall(module, "vrpex", "lib/Proxy")
    end
    if ok and proxy then
        local ok2, itf = pcall(function() return proxy.getInterface("vRP") end)
        if ok2 and itf then
            VexShieldVRP = itf
            return itf
        end
    end
    return nil
end

-- vRP1 wraps args in a table {source}; vRP2 uses positional args. Try both, never error.
function VexShieldVRPUserId(vrp, src)
    local ok, uid = pcall(function() return vrp.getUserId({ src }) end)
    if ok and uid then return uid end
    ok, uid = pcall(function() return vrp.getUserId(src) end)
    if ok and uid then return uid end
    return nil
end

function VexShieldVRPHasGroup(vrp, uid, group)
    local ok, has = pcall(function() return vrp.hasGroup({ uid, group }) end)
    if ok and has then return true end
    ok, has = pcall(function() return vrp.hasGroup(uid, group) end)
    if ok and has then return true end
    return false
end

-- Central group resolver: returns a group/job string for ANY framework.
function GetFrameworkGroup(src)
    src = tonumber(src)
    if not src then return "user" end

    if UseQBCore and QBCore then
        local p = QBCore.Functions.GetPlayer(src)
        if p and p.PlayerData then
            local pd = p.PlayerData
            return pd.group or pd.permission or (pd.job and pd.job.name) or "user"
        end
    elseif UseQBox then
        local ok, p = pcall(function() return exports.qbx_core:GetPlayer(src) end)
        if ok and p and p.PlayerData then
            local pd = p.PlayerData
            return (pd.job and pd.job.name) or pd.group or "user"
        end
    elseif UseESX and ESX then
        local p = ESX.GetPlayerFromId(src)
        if p and p.getGroup then return p.getGroup() or "user" end
    elseif UseOx then
        local ok, p = pcall(function() return exports.ox_core:GetPlayer(src) end)
        if ok and p and p.getGroup then
            -- ox_core getGroup needs a filter; probe configured admin then exempt groups.
            for grp in pairs(Config.ADMIN_GROUPS or {}) do
                local okk, grade = pcall(p.getGroup, grp)
                if okk and grade and grade > 0 then return grp end
            end
            for grp in pairs(Config.EXEMPT_GROUPS or {}) do
                local okk, grade = pcall(p.getGroup, grp)
                if okk and grade and grade > 0 then return grp end
            end
        end
    elseif UseVRP then
        local vrp = VexShieldGetVRP()
        if vrp then
            local uid = VexShieldVRPUserId(vrp, src)
            if uid then
                -- vRP has no single "group" getter via proxy across versions; probe configured groups.
                for grp in pairs(Config.ADMIN_GROUPS or {}) do
                    if VexShieldVRPHasGroup(vrp, uid, grp) then return grp end
                end
                for grp in pairs(Config.EXEMPT_GROUPS or {}) do
                    if VexShieldVRPHasGroup(vrp, uid, grp) then return grp end
                end
            end
        end
    end
    return "user"
end

-- Helper: retrieve identifier/‘license’ in a cross-framework manner
function GetPlayerIdentifierAnyFramework(src)
    if UseQBCore and QBCore then
        local qbPlayer = QBCore.Functions.GetPlayer(src)
        if qbPlayer and qbPlayer.PlayerData then
            return qbPlayer.PlayerData.license or "no-license-qb"
        end
    elseif UseQBox then
        local ok, p = pcall(function() return exports.qbx_core:GetPlayer(src) end)
        if ok and p and p.PlayerData then
            return p.PlayerData.license or "no-license-qbx"
        end
    elseif UseESX and ESX then
        local esxPlayer = ESX.GetPlayerFromId(src)
        if esxPlayer then
            return esxPlayer.identifier or "no-identifier-esx"
        end
    elseif UseOx then
        local ok, p = pcall(function() return exports.ox_core:GetPlayer(src) end)
        if ok and p then
            return p.identifier or (p.get and p.get("license")) or "no-identifier-ox"
        end
    end
    return "unknown-id"
end

---------------------------------------------------------------------------------
-- LANGUAGE
---------------------------------------------------------------------------------

Locales = {
    ['en'] = {
        banTitle = "You have been banned by the VexShield",
        banMessage = "You have been banned from",
        steamRequired = "You need to have your Steam open",
        vpnDetected = "You cannot join if you have a VPN enabled",
        blacklisted = "You have been blacklisted by Air Shield",
        tosHeader = "**Air Shield | IMPORTANT**",
        tosInfo = "Please make sure your NOT OPEN STEAM OVERLAY and make sure your ReShade settings are set to **'Pass On All Input'** to avoid visual issues and your fivem is full screen --> (https://i.postimg.cc/XqyrgNL1/image.png).",
        tosContinue = "Click the button below to continue joining.",
        reshadeConfirm = "Did you really read it and if not check below",
        connecting = "Connecting to server...",
        steamKick = "Connection rejected: Steam must be open to connect.",
        vpnKick = "Connection rejected: VPN detected.",
        blacklistKick = "Connection rejected: You have been blacklisted by Air Shield.",
        tosDecline = "You must accept the terms to join.",
        banKickHeader = "You have been banned by our automatic system",
        banKickDuration = "This ban never expires.",
        banKickReconnect = "Reconnect for the ban details"
    },
    ['nl'] = {
        banTitle = "Je bent verbannen door de VexShield",
        banMessage = "Je bent verbannen van",
        steamRequired = "Je moet Steam open hebben staan",
        vpnDetected = "Je kunt niet joinen met een VPN ingeschakeld",
        blacklisted = "Je bent geblacklist door Air Shield",
        tosHeader = "**Air Shield | BELANGRIJK**",
        tosInfo = "Zorg ervoor dat je STEAM OVERLAY NIET OPEND en ReShade-instellingen op **'Alle invoer doorgeven'** staan ​​om visuele problemen te voorkomen en dat je fivem op volledig scherm wordt weergegeven --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Klik op de knop hieronder om verder te gaan.",
        reshadeConfirm = "Heb je het echt gelezen? Zo niet, check hieronder.",
        connecting = "Verbinden met de server...",
        steamKick = "Verbinding geweigerd: Steam moet open zijn om te verbinden.",
        vpnKick = "Verbinding geweigerd: VPN gedetecteerd.",
        blacklistKick = "Verbinding geweigerd: Je bent geblacklist door Air Shield.",
        tosDecline = "Je moet akkoord gaan met de voorwaarden om te joinen.",
        banKickHeader = "Je bent verbannen door ons automatische systeem",
        banKickDuration = "Deze ban verloopt nooit.",
        banKickReconnect = "Reconnect voor baninformatie."
    },
    ['de'] = {
        banTitle = "Du wurdest vom VexShield gebannt",
        banMessage = "Du wurdest gebannt von",
        steamRequired = "Du musst Steam geoffnet haben",
        vpnDetected = "Du kannst nicht joinen, wenn ein VPN aktiviert ist",
        blacklisted = "Du wurdest von Air Shield geblacklistet",
        tosHeader = "**Air Shield | WICHTIG**",
        tosInfo = "Bitte stellen Sie sicher STEAM-OVERLAY oFFNET SICH NICHT und, dass Ihre ReShade-Einstellungen auf **'Alle Eingaben weitergeben'** eingestellt sind, um visuelle Probleme zu vermeiden, und dass Ihr Fivem im Vollbildmodus angezeigt wird --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Klicke auf den Button unten, um fortzufahren.",
        reshadeConfirm = "Hast du es wirklich gelesen? Wenn nicht, siehe unten.",
        connecting = "Verbindung zum Server wird hergestellt...",
        steamKick = "Verbindung abgelehnt: Steam muss geoffnet sein.",
        vpnKick = "Verbindung abgelehnt: VPN erkannt.",
        blacklistKick = "Verbindung abgelehnt: Du wurdest geblacklistet von Air Shield.",
        tosDecline = "Du musst den Bedingungen zustimmen, um beizutreten.",
        banKickHeader = "Du wurdest von unserem automatischen System gebannt",
        banKickDuration = "Dieser Ban lauft nie ab.",
        banKickReconnect = "Reconnecte fur weitere Ban-Informationen"
    },

    ['fr'] = {
        banTitle = "Vous avez ete banni par le VexShield",
        banMessage = "Vous avez ete banni de",
        steamRequired = "Vous devez avoir Steam ouvert",
        vpnDetected = "Vous ne pouvez pas rejoindre si un VPN est active",
        blacklisted = "Vous avez ete mis sur liste noire par Air Shield",
        tosHeader = "**Air Shield | IMPORTANT**",
        tosInfo = "isitikinkite, LE RECOUVREMENT DE VAPEUR NE SOUVRE PAS et kad ReShade nustatymai nustatyti kaip **Perduoti visa ivesti**, kad isvengtumete vaizdo problemu, ir kad jusu failas rodomas per visa ekrana --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Cliquez sur le bouton ci-dessous pour continuer.",
        reshadeConfirm = "L'avez-vous vraiment lu ? Sinon, regardez ci-dessous.",
        connecting = "Connexion au serveur...",
        steamKick = "Connexion refusee : Steam doit etre ouvert.",
        vpnKick = "Connexion refusee : VPN detecte.",
        blacklistKick = "Connexion refusee : Vous etes sur liste noire de Air Shield.",
        tosDecline = "Vous devez accepter les conditions pour rejoindre.",
        banKickHeader = "Vous avez ete banni par notre systeme automatique",
        banKickDuration = "Ce bannissement n expire jamais.",
        banKickReconnect = "Reconnectez-vous pour les details du bannissement"
    },

    ['sp'] = {
        banTitle = "Has sido baneado por el VexShield",
        banMessage = "Has sido baneado de",
        steamRequired = "Necesitas tener Steam abierto",
        vpnDetected = "No puedes unirte con un VPN activado",
        blacklisted = "Has sido incluido en la lista negra por Air Shield",
        tosHeader = "**Air Shield | IMPORTANTE**",
        tosInfo = "Asegurate de que LA CAPA DE VAPOR NO SE ABRE y la configuracioón de ReShade este establecida en **'Transmitir todas las entradas'** para evitar problemas visuales y que tu fivem este en pantalla completa --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Haz clic en el boton de abajo para continuar.",
        reshadeConfirm = "Realmente lo leiste? Si no, revisa abajo.",
        connecting = "Conectando al servidor...",
        steamKick = "Conexion rechazada: Steam debe estar abierto.",
        vpnKick = "Conexion rechazada: VPN detectado.",
        blacklistKick = "Conexion rechazada: Estas en la lista negra de Air Shield.",
        tosDecline = "Debes aceptar los terminos para unirte.",
        banKickHeader = "Has sido baneado por nuestro sistema automatico",
        banKickDuration = "Este baneo nunca expira.",
        banKickReconnect = "Reconectate para ver los detalles del baneo"
    },

    ['el'] = { -- Grieks (Greece)
        banTitle = "Ehete apokleistei apo to VexShield",
        banMessage = "Ehete apokleistei apo",
        steamRequired = "Prepei na echete anoikto to Steam",
        vpnDetected = "Den mporeite na syndetheite me energopoihmeno VPN",
        blacklisted = "Ehete mpei sti mavri lista apo to Air Shield",
        tosHeader = "**Air Shield | SIMPORTANTIKO**",
        tosInfo = "Vevaiotheite oóti Η ΕΠΙΚΑΛΥIΗ ΑΤΜΟΥ ΔΕΝ ΑΝΟΙΓΕΙ και oi rythmiseis ReShade echoun oristei se **'Metadosi olon ton eisropn'** gia na apofygete optika provlimata kai oti to fivem sas einai se pliri othoni --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Klikoste sto koumpi parakato gia na synexisete.",
        reshadeConfirm = "To diavasate pragmatika? An oxi, deite parakato.",
        connecting = "Syndesi me ton server...",
        steamKick = "Syndesi aporrifthike: Prepei na einai anoikto to Steam.",
        vpnKick = "Syndesi aporrifthike: VPN entopistike.",
        blacklistKick = "Syndesi aporrifthike: Eiste sti mavri lista tou Air Shield.",
        tosDecline = "Prepei na dechteite tous orous gia na synetheite.",
        banKickHeader = "Ehete apokleistei apo to automatopoihmeno systima mas",
        banKickDuration = "Auto to ban den leei pote.",
        banKickReconnect = "Synetheite xana gia leptomereies"
    },

    ['sv'] = { -- Zweeds (Sweden)
        banTitle = "Du har blivit bannad av VexShield",
        banMessage = "Du har blivit bannad fran",
        steamRequired = "Du maste ha Steam oppet",
        vpnDetected = "Du kan inte ga med om du har ett VPN aktiverat",
        blacklisted = "Du har blivit svartlistad av Air Shield",
        tosHeader = "**Air Shield | VIKTIGT**",
        tosInfo = "Se till att ANGOVERLAGET OPPNAS INTE och dina ReShade-installningar ar installda pa **'Pass On All Input'** for att undvika visuella problem och att din fivem ar i helskarm --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Klicka pa knappen nedan for att fortsatta.",
        reshadeConfirm = "Laste du verkligen det? Om inte, se nedan.",
        connecting = "Ansluter till servern...",
        steamKick = "Anslutning nekad: Steam maste vara oppet.",
        vpnKick = "Anslutning nekad: VPN upptackt.",
        blacklistKick = "Anslutning nekad: Du ar svartlistad av Air Shield.",
        tosDecline = "Du maste godkanna villkoren for att ga med.",
        banKickHeader = "Du har blivit bannad av vart automatiska system",
        banKickDuration = "Denna ban gar aldrig ut.",
        banKickReconnect = "Anslut igen for mer information"
    },

    ['tr'] = { -- Turks (Turkije)
        banTitle = "VexShield tarafindan banlandiniz",
        banMessage = "Sunucudan banlandiniz:",
        steamRequired = "Steam acik olmali",
        vpnDetected = "VPN acikken sunucuya katilamazsiniz",
        blacklisted = "Air Shield tarafindan kara listeye alindiniz",
        tosHeader = "**Air Shield | ONEMLI**",
        tosInfo = "Gorsel sorunlari onlemek BUHAR KAPLAMASI AILMIYOR ve icin lutfen ReShade ayarlarinizin **'Tum Girisleri Gecir'** olarak ayarlandigindan ve FiveM'inizin tam ekran oldugundan emin olun --> (https://i.postimg.cc/XqyrgNL1/image.png)",
        tosContinue = "Devam etmek icin asagidaki butona tiklayin.",
        reshadeConfirm = "Gercekten okudunuz mu? Okumadiysaniz asagiya bakin.",
        connecting = "Sunucuya baglaniyor...",
        steamKick = "Baglanti reddedildi: Steam acik olmali.",
        vpnKick = "Baglanti reddedildi: VPN tespit edildi.",
        blacklistKick = "Baglanti reddedildi: Kara listedesiniz.",
        tosDecline = "Sunucuya katilmak icin kurallari kabul etmelisiniz.",
        banKickHeader = "Otomatik sistem tarafindan banlandiniz",
        banKickDuration = "Bu ban sonsuzdur.",
        banKickReconnect = "Ban detaylari icin tekrar baglanin"
    }
}

function _L(key)
    local lang = (Config and Config.Language and Locales[Config.Language]) and Config.Language or "en"
    return Locales[lang][key] or key
end


---------------------------------------------------------------------------------
-- HEARTBEAT / STEALTH CHECK
---------------------------------------------------------------------------------
local activeClients = {}
local playerUUIDs = {}
local secretKeys = {}
local lastTokens = {}
local preloadRegistered = {}
local lastHeartbeatTokens = {}
local lastStealthTokens = {}

RegisterNetEvent('VexShield:registerUUID')
AddEventHandler('VexShield:registerUUID', function(clientUUID, secretKey, isPreload)
    local src = source
    if not clientUUID or not secretKey then
        DropPlayer(src, 'VexShield: Foute registratie!')
        return
    end

    playerUUIDs[src] = clientUUID
    secretKeys[src] = secretKey
    storedPlayerNames[src] = GetPlayerName(src)
    activeClients[src] = {
        lastHeartbeat = os.time(),
        lastStealthCheck = os.time(),
        lastHeartbeatMs = GetGameTimer(),
        lastStealthCheckMs = GetGameTimer(),
        suspiciousCount = 0,
        falseKickCount = 0,
        mismatchCount = 0,
        isPreload = isPreload
    }
end)

RegisterNetEvent('VexShield:heartbeat')
AddEventHandler('VexShield:heartbeat', function(resourceName, clientUUID, secretKey, token)
    local src = source
    local now = os.time()
    local nowMs = GetGameTimer()

    if resourceName ~= "VexShield" then
        banPlayer(src, "Attempted to stop VexShield")
        return
    end

    if not playerUUIDs[src] or not secretKeys[src] then
        -- DropPlayer(src, 'VexShield: Speler niet geregistreerd!')
        return
    end
    if not activeClients[src] then
        activeClients[src] = {
            lastHeartbeat = now,
            lastStealthCheck = now,
            lastHeartbeatMs = nowMs,
            lastStealthCheckMs = nowMs,
            suspiciousCount = 0,
            falseKickCount = 0,
            mismatchCount = 0,
            isPreload = false
        }
    end

    if tostring(clientUUID or "") ~= tostring(playerUUIDs[src]) or tostring(secretKey or "") ~= tostring(secretKeys[src]) then
        activeClients[src].mismatchCount = (activeClients[src].mismatchCount or 0) + 1
        return
    else
        activeClients[src].mismatchCount = 0
    end

    if token == lastHeartbeatTokens[src] then
        return
    end
    lastHeartbeatTokens[src] = token

    if nowMs - (activeClients[src].lastHeartbeatMs or 0) < 1500 then
        activeClients[src].suspiciousCount = activeClients[src].suspiciousCount + 1
        if activeClients[src].suspiciousCount >= 3 then
            -- DropPlayer(src, 'VexShield: Verdachte snelle heartbeats!')
            return
        end
    else
        activeClients[src].suspiciousCount = 0
    end

    activeClients[src].lastHeartbeat = now
    activeClients[src].lastHeartbeatMs = nowMs
end)

local registeredClients = {}

RegisterNetEvent("VexShield:registerClient", function(uuid)
    local src = source
    if uuid and type(uuid) == "string" then
        registeredClients[src] = uuid
        -- print(("[VexShield] Speler %s geregistreerd met UUID %s"):format(GetPlayerName(src), uuid))
    end
end)

RegisterNetEvent("VexShield:clientUnregistered", function()
    local src = source
    -- print(("[VexShield] Speler %s heeft de anticheat opnieuw opgestart zonder registratie."):format(GetPlayerName(src)))

    -- Optioneel: waarschuwing loggen, of actie nemen (maar niet direct kicken)
    -- Bijvoorbeeld: stuur melding naar admin dashboard
    -- TriggerEvent("VexShield:logSuspiciousEvent", src, "Herstart zonder registratie")
end)

AddEventHandler("playerDropped", function()
    local src = source
    registeredClients[src] = nil
    storedPlayerNames[src] = nil
end)


RegisterNetEvent('VexShield:stealthCheck')
AddEventHandler('VexShield:stealthCheck', function(clientUUID, secretKey, token)
    local src = source
    local now = os.time()
    local nowMs = GetGameTimer()

    if not playerUUIDs[src] or not secretKeys[src] then
        return
    end
    if not activeClients[src] then
        activeClients[src] = {
            lastHeartbeat = now,
            lastStealthCheck = now,
            lastHeartbeatMs = nowMs,
            lastStealthCheckMs = nowMs,
            suspiciousCount = 0,
            falseKickCount = 0,
            mismatchCount = 0,
            isPreload = false
        }
    end

    if tostring(clientUUID or "") ~= tostring(playerUUIDs[src]) or tostring(secretKey or "") ~= tostring(secretKeys[src]) then
        activeClients[src].mismatchCount = (activeClients[src].mismatchCount or 0) + 1
        return
    else
        activeClients[src].mismatchCount = 0
    end

    if token == lastStealthTokens[src] then
        return
    end
    lastStealthTokens[src] = token

    activeClients[src].lastStealthCheck = now
    activeClients[src].lastStealthCheckMs = nowMs
end)

-- Max seconds without a client heartbeat before treating as stopped/bypassed ("Stopping VexShield").
-- Client sends a heartbeat every ~5s (math.random(4500,6000)), so 60s = ~10-12 missed beats.
-- Override with: setr VexShield_heartbeat_timeout_sec 90  (min 60, max 300; default 60 = fast but safe)
function VexShieldHeartbeatMissTimeoutSec()
    local w = tonumber(GetConvar("VexShield_heartbeat_timeout_sec", "") or "")
    if not w then w = 60 end

    if w < 60 then w = 60 end
    if w > 300 then w = 300 end

    return math.floor(w)
end

-- Heartbeat monitoring
function VexShieldCleanupClient(playerId)
    activeClients[playerId] = nil
    playerUUIDs[playerId] = nil
    secretKeys[playerId] = nil
    lastTokens[playerId] = nil
end

CreateThread(function()
    while true do
        local now = os.time()
        local missSec = VexShieldHeartbeatMissTimeoutSec()
        for playerId, data in pairs(activeClients) do
            if now - (data.lastHeartbeat or 0) > missSec then
                -- Distinguish a real resource stop/bypass from a temporary internet
                -- disconnection. A player who lost connection also stops sending
                -- heartbeats, but their game connection is dead (no name / no ping)
                -- and FiveM will drop them on its own -- they must NOT be banned.
                -- Only a player still actively connected (valid name + live ping)
                -- while VexShield is silent is treated as a genuine stop/bypass,
                -- and only after being confirmed across two consecutive cycles.
                local stillConnected = GetPlayerName(playerId) ~= nil
                local ping = stillConnected and (GetPlayerPing(playerId) or 0) or 0

                if stillConnected and ping > 0 then
                    data.heartbeatMissStrikes = (data.heartbeatMissStrikes or 0) + 1
                    if data.heartbeatMissStrikes >= 2 then
                        banPlayer(playerId, 'Attempted to stop VexShield')
                        VexShieldCleanupClient(playerId)
                    end
                else
                    -- Connection is gone/unresponsive: internet drop, not a bypass.
                    VexShieldCleanupClient(playerId)
                end
            else
                if data.heartbeatMissStrikes then data.heartbeatMissStrikes = 0 end
            end
        end
        Wait(2500)
    end
end)

-- Anti Spoof Name Monitoring
CreateThread(function()
    while true do
        Wait(10000)
        if Config.Protections['Anti Spoof Name'] then
            for src, originalName in pairs(storedPlayerNames) do
                local currentName = GetPlayerName(src)
                if currentName then
                    -- Check if name changed
                    if currentName ~= originalName then
                        banPlayer(src, 'Attempted name spoofing: ' .. currentName)
                        storedPlayerNames[src] = nil
                    else
                        -- Check for blacklisted words or characters
                        local nameLower = string.lower(currentName)
                        local detected = false
                        if Config.BlacklistedNames then
                            for _, word in ipairs(Config.BlacklistedNames) do
                                if nameLower:find(string.lower(word), 1, true) then
                                    banPlayer(src, 'Attempted to use blacklisted name: ' .. currentName)
                                    detected = true
                                    break
                                end
                            end
                        end
                        
                        if not detected and (nameLower:find("<") or nameLower:find(">") or nameLower:find("img") or nameLower:find("script")) then
                            banPlayer(src, 'Attempted name injection: ' .. currentName)
                        end
                    end
                end
            end
        end
    end
end)

-- Cleanup
AddEventHandler('playerDropped', function()
    local src = source
    activeClients[src] = nil
    playerUUIDs[src] = nil
    secretKeys[src] = nil
    lastTokens[src] = nil
    lastHeartbeatTokens[src] = nil
    lastStealthTokens[src] = nil
    preloadRegistered[src] = nil
    storedPlayerNames[src] = nil
    playersReady[src] = nil
    clearRuntimeSpoofState(src)
    
    -- Cleanup vehicle spawn tracking
    if Config.MaxSpawn and Config.MaxSpawn.ResetOnDisconnect then
        vehicleSpawnTracking[src] = nil
        vehicleSpawnCounters[src] = nil
        playerVehicleSessions[src] = nil
        propSpawnCounters[src] = nil
        pedSpawnCounters[src] = nil
    end
    entitySpamTrackers[src] = nil
    if vehicleSpamTrackers then vehicleSpamTrackers[src] = nil end
    __AS_PedCreateTracker[src] = nil
end)




-- function isExempt(playerId)
--     local framework = nil

--     if ESX ~= nil and type(ESX.GetPlayerFromId) == "function" then
--         framework = "esx"
--     elseif QBCore ~= nil and type(QBCore.Functions.GetPlayer) == "function" then
--         framework = "qbcore"
--     else
--         print("Framework is niet gesupport door Air Shield")
--         return false
--     end

--     local playerGroup = nil

--     if framework == "esx" then
--         local xPlayer = ESX.GetPlayerFromId(playerId)
--         if xPlayer then
--             playerGroup = xPlayer.getGroup() or 'user'
--         end
--     elseif framework == "qbcore" then
--         local qbPlayer = QBCore.Functions.GetPlayer(playerId)
--         if qbPlayer and qbPlayer.PlayerData then
--             playerGroup = qbPlayer.PlayerData.group or 'user'
--         end
--     end

--     if playerGroup then
--         for i = 1, #Config.EXEMPT_GROUPS do
--             if playerGroup == Config.EXEMPT_GROUPS[i] then
--                 return true
--             end
--         end
--     end

--     return false
-- end

-- -- Helper: check if player is admin
-- function IsPlayerAdmin(src)
--     if UseQBCore and QBCore then
--         local qbPlayer = QBCore.Functions.GetPlayer(src)
--         if not qbPlayer then return false end
--         -- Example check: you might store admin status in job name or in metadata. Adjust as needed:
--         -- if qbPlayer.PlayerData.job.name == "admin" then
--         --     return true
--         -- end
--         -- or if you have a group system:
--         -- local group = qbPlayer.PlayerData.group
--         -- return (group == "admin" or group == "god")
--         return false

--     elseif UseESX and ESX then
--         local esxPlayer = ESX.GetPlayerFromId(src)
--         if not esxPlayer then return false end
--         local group = esxPlayer.getGroup()
--         if group == "admin" or group == "_dev" then
--             return true
--         end
--         return false
--     end
--     return false
-- end

-- -- Helper: ban function used throughout
-- function banPlayer(playerId, reason)
--     -- (unchanged from your script)
--     local numericPlayerId = tonumber(playerId)
--     if not numericPlayerId then
--         return
--     end

--     if not loadedPlayers[numericPlayerId] then
--         return
--     end

--     if isExempt(playerId) then 
--         return 
--     end

--     local identifiers = GetPlayerIdentifiers(playerId)
--     local steam, license, ip, hwid = "Unknown", "Unknown", "Unknown", "Unknown"

--     for _, id in ipairs(identifiers) do
--         if string.match(id, "steam:") then steam = id end
--         if string.match(id, "license:") then license = id end
--         if string.match(id, "ip:") then ip = id end
--     end

--     hwid = GetPlayerToken(playerId, 0) or "Unknown"
--     local name = GetPlayerName(playerId)

--     if not name then 
--         print('^2[VexShield]^1 | INVALID PLAYER ID')
--         return 
--     end

--     print('^2[VexShield]^1 | BANNED PLAYER '..name..' ('..playerId..') ^4WITH REASON '..reason..'')

--     local bansFile = LoadResourceFile(GetCurrentResourceName(), "html/ban.json")
--     local bans = {}

--     if bansFile then
--         bans = json.decode(bansFile) or {}
--     else
--         print("Warning: bans.json not found. A new one will be created.")
--     end

--     local highestId = 0
--     for _, ban in ipairs(bans) do
--         local idNumber = tonumber(ban.id:match("AIR%-(%d+)$"))
--         if idNumber and idNumber > highestId then
--             highestId = idNumber
--         end
--     end

--     local newBanId = 'AIR-' .. (highestId + 1)

--     local data = {
--         steam = steam,
--         license = license,
--         ip = ip,
--         hardware_id = hwid,
--         name = name,
--         reason = reason,
--         id = newBanId,
--     }

--     sendDiscordLog(tonumber(playerId), '**Player '..name..' ('..playerId..') has been banned \n\nBan ID: #'..data.id..' \nReason: '..data.reason..'**')

--     table.insert(bans, data)

--     SaveResourceFile(GetCurrentResourceName(), "html/ban.json", json.encode(bans, { indent = true }), -1)

--     local kickMessage = string.format(
--         "\n[VexShield] You have been banned by our automatic system\n" ..
--         "This ban never expires.\n" ..
--         "Reconnect for the ban details"
--     )
--     DropPlayer(playerId, kickMessage)
-- end

-- sendDiscordLog = function(player, description)
--     local playerName = GetPlayerName(player)

--     function sendDiscordEmbedWithImage(player, imageUrl)
--         local embed = {
--             {
--                 ["color"] = 0x000fff,
--                 ["title"] = "Player has been banned",
--                 ["description"] = description,
--                 ["fields"] = {
--                     { ["name"] = "Player ID", ["value"] = tostring(player), ["inline"] = true },
--                     { ["name"] = "Name", ["value"] = playerName or "Unknown", ["inline"] = true },
--                     { ["name"] = "License", ["value"] = GetPlayerIdentifierByType(player, 'license') or "Unknown", ["inline"] = true }
--                 },
--                 ["image"] = {
--                     ["url"] = imageUrl
--                 },
--                 ["footer"] = {
--                     ["text"] = "© VexShield System",
--                     ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
--                 }
--             }
--         }

--         sendToDiscord(embed)
--     end

--     function sendDiscordEmbedWithoutImage(player)
--         local embed = {
--             {
--                 ["color"] = 0xFF0000,
--                 ["title"] = "Player has been banned",
--                 ["description"] = description,
--                 ["fields"] = {
--                     { ["name"] = "Player ID", ["value"] = tostring(player), ["inline"] = true },
--                     { ["name"] = "Name", ["value"] = playerName or "Unknown", ["inline"] = true },
--                     { ["name"] = "License", ["value"] = GetPlayerIdentifierByType(player, 'license') or "Unknown", ["inline"] = true },
--                     { ["name"] = "Note", ["value"] = "Screenshot capture failed", ["inline"] = false }
--                 },
--                 ["footer"] = {
--                     ["text"] = "© VexShield System",
--                     ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
--                 }
--             }
--         }

--         sendToDiscord(embed)
--     end

--     function sendToDiscord(embed)
--         PerformHttpRequest(Config.logsBans,
--             function(err, text, headers)
--                 if err ~= 204 then
--                     print('Discord webhook error:', err)
--                 end
--             end,
--             'POST',
--             json.encode({ embeds = embed }),
--             { ['Content-Type'] = 'application/json' }
--         )
--     end

--     print('Starting screenshot capture...')

--     local screenshotTaken = false

--     -- Set a timeout to send the embed without an image if no screenshot is received within 30 seconds
--     Citizen.SetTimeout(15000, function()
--         if not screenshotTaken then
--             print('Screenshot timeout reached. Sending embed without image...')
--             sendDiscordEmbedWithoutImage(player)
--         end
--     end)

--     -- Capture screenshot
--     exports['screenshot-basic']:requestClientScreenshot(player, {
--         fileName = 'screenshot.jpg'
--     }, function(err, data)
--         if err then
--             print('Screenshot error:', err)
--             sendDiscordEmbedWithoutImage(player)
--         else
--             screenshotTaken = true
--             print('Screenshot captured successfully')

--             -- Upload to Imgur
--             PerformHttpRequest('https://api.imgur.com/3/image', function(uploadErr, uploadData, headers)
--                 if uploadErr ~= 200 then
--                     print('Imgur upload error:', uploadErr)
--                     sendDiscordEmbedWithoutImage(player)
--                 else
--                     print('Imgur Upload Response received')

--                     local jsonResponse = json.decode(uploadData)
--                     if jsonResponse and jsonResponse.success then
--                         local imageUrl = jsonResponse.data.link
--                         print('Imgur upload successful. Image URL:', imageUrl)
--                         sendDiscordEmbedWithImage(player, imageUrl)
--                     else
--                         print('Failed to parse Imgur response or upload unsuccessful')
--                         sendDiscordEmbedWithoutImage(player)
--                     end
--                 end
--             end, 'POST', json.encode({ image = data }), {
--                 ['Authorization'] = 'dc2c09afbc91976',
--                 ['Content-Type'] = 'application/json'
--             })
--         end
--     end)
-- end

-- RegisterCommand("testbanlog", function()
--     sendDiscordLog(1, "Test ban log")
-- end)



function VexShieldExtractPlayerIdentity(playerId, fallbackLicense)
    local info = {
        id = tostring(playerId or "Unknown"),
        name = (playerId and GetPlayerName(playerId)) or "Unknown",
        license = fallbackLicense or "Unknown",
        steam = "no linked",
        discord = "no linked",
        xbl = "no linked",
        live = "no linked",
        ip = "Unknown",
    }

    local ids = {}
    if playerId and tonumber(playerId) and GetPlayerName(tonumber(playerId)) then
        ids = GetPlayerIdentifiers(tonumber(playerId)) or {}
    end

    for _, identifier in ipairs(ids) do
        if identifier:find("^license:") and info.license == "Unknown" then
            info.license = identifier
        elseif identifier:find("^steam:") then
            info.steam = identifier
        elseif identifier:find("^discord:") then
            local did = identifier:sub(9)
            info.discord = "<@" .. did .. "> | discord:" .. did
        elseif identifier:find("^xbl:") then
            info.xbl = identifier
        elseif identifier:find("^live:") then
            info.live = identifier
        elseif identifier:find("^ip:") then
            info.ip = identifier:sub(4)
        end
    end

    if info.ip == "Unknown" and playerId and tonumber(playerId) then
        local ok, endpoint = pcall(GetPlayerEndpoint, tonumber(playerId))
        if ok and endpoint and endpoint ~= "" then
            info.ip = endpoint:match("(%d+%.%d+%.%d+%.%d+)") or endpoint
        end
    end

    return info
end

-- Classify a ban/detection reason into a high-level Type + a short Details phrase
-- for the Discord embed (Reason | Type | Details layout).
function VexShieldClassifyReason(reason)
    local r = string.lower(tostring(reason or ""))
    if r == "" then return "Detection", "Unknown" end

    local rtype = "Detection"
    if r:find("vehicle") or r:find("car ") or r:find("veh ") or r:find("plate") then
        rtype = "Vehicle"
    elseif r:find("teleport") or r:find(" tp ") or r:find("tp to") or r:find("waypoint") then
        rtype = "Teleport"
    elseif r:find("aim") or r:find("recoil") or r:find("reload") or r:find("ammo")
        or r:find("bullet") or r:find("weapon") or r:find("damage") or r:find("headshot")
        or r:find("punch") or r:find("taze") or r:find("kill") then
        rtype = "Weapon"
    elseif r:find("noclip") or r:find("freecam") or r:find("speed") or r:find("jump")
        or r:find("fly") or r:find("fling") or r:find("stamina") or r:find("invisible")
        or r:find("spectate") or r:find("fast run") or r:find("force fall") then
        rtype = "Movement"
    elseif r:find("explosion") or r:find("explode") or r:find("bomb") then
        rtype = "Explosion"
    elseif r:find("prop") or r:find("object") or r:find("ped") or r:find("entity")
        or r:find("spawn") or r:find("particle") or r:find("rain") then
        rtype = "Spawn"
    elseif r:find("menu") or r:find("inject") or r:find("lua") or r:find("executor")
        or r:find("hook") or r:find("susano") or r:find("tzx") or r:find("nui")
        or r:find("devtools") or r:find("cipher") or r:find("bytecode") or r:find("dll")
        or r:find("loadstring") or r:find("skript") then
        rtype = "Cheat Menu"
    elseif r:find("godmode") or r:find("god mode") or r:find("health") or r:find("armour")
        or r:find("armor") or r:find("heal") or r:find("ragdoll") or r:find("revive") then
        rtype = "Player"
    elseif r:find("spoof") or r:find("vpn") or r:find("resource") or r:find("trigger")
        or r:find("voice") or r:find("event") or r:find("stop") or r:find("name") then
        rtype = "Network/System"
    elseif r:find("clipboard") or r:find("trigger injection") then
        rtype = "Clipboard Exploit"
    end

    local details
    if r:find("trigger injection") then details = "Trigger Injection Attempt"
    elseif r:find("clipboard") then details = "Blacklisted Cheat Content"
    elseif r:find("spawn") or r:find("rain") then details = "Unauthorized Spawn"
    elseif r:find("teleport") or r:find(" tp ") or r:find("waypoint") then details = "Illegal Teleport"
    elseif r:find("noclip") then details = "Noclip"
    elseif r:find("freecam") then details = "Freecam"
    elseif r:find("aim") then details = "Aimbot / Silent Aim"
    elseif r:find("recoil") then details = "No Recoil"
    elseif r:find("reload") then details = "No Reload"
    elseif r:find("ammo") then details = "Infinite Ammo"
    elseif r:find("damage") then details = "Weapon Damage Modification"
    elseif r:find("explosion") or r:find("explode") then details = "Illegal Explosion"
    elseif r:find("godmode") or r:find("god mode") then details = "God Mode"
    elseif r:find("inject") then details = "Code Injection"
    elseif r:find("menu") then details = "Cheat Menu Detected"
    elseif r:find("speed") then details = "Speed Hack"
    elseif r:find("spoof") then details = "Identifier Spoofing"
    end
    if not details then
        local after = tostring(reason):match(":%s*(.+)$")
        details = after or tostring(reason)
    end
    details = tostring(details):gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 120)
    if details == "" then details = "Detection" end

    return rtype, details
end

function VexShieldFormatReason(reason)
    if not reason or reason == "" then return "No reason provided" end
    local r = tostring(reason):gsub("^%s+", ""):gsub("%s+$", "")
    
    local lowerR = r:lower()
    -- If reason already has a proper action prefix or status word, return as-is
    if lowerR:find("^attempting") or lowerR:find("^tried to") or lowerR:find("^bad native")
        or lowerR:find("^unauthorized") or lowerR:find("^illegal") or lowerR:find("detected")
        or lowerR:find("^cheat menu") then
        return r
    end

    -- Strip leading "Anti " or "Anti-" prefix if present
    if lowerR:sub(1, 5) == "anti " then
        r = r:sub(6):gsub("^%s+", "")
        lowerR = r:lower()
    elseif lowerR:sub(1, 5) == "anti-" then
        r = r:sub(6):gsub("^%s+", "")
        lowerR = r:lower()
    end

    -- Clean up redundant "Object Spawn:" into "Spawn:"
    if lowerR:find("^object spawn:") then
        r = r:gsub("^[O|o]bject [S|s]pawn:", "Spawn:")
        lowerR = r:lower()
    end

    -- Professional ban reason prefixes based on protection type
    if lowerR:find("noclip") or lowerR:find("freecam") or lowerR:find("godmode") or lowerR:find("teleport")
        or lowerR:find("speed") or lowerR:find("fly") or lowerR:find("superjump") or lowerR:find("infinite")
        or lowerR:find("aim") or lowerR:find("recoil") or lowerR:find("weapon") or lowerR:find("damage")
        or lowerR:find("menu") or lowerR:find("inject") or lowerR:find("executor") or lowerR:find("lua")
        or lowerR:find("hook") or lowerR:find("devtools") or lowerR:find("cipher") or lowerR:find("bytecode")
        or lowerR:find("dll") or lowerR:find("loadstring") or lowerR:find("skript") or lowerR:find("susano")
        or lowerR:find("tzx") or lowerR:find("nui") or lowerR:find("health") or lowerR:find("armour")
        or lowerR:find("armor") or lowerR:find("heal") or lowerR:find("ragdoll") or lowerR:find("revive")
        or lowerR:find("invisible") or lowerR:find("spectate") or lowerR:find("fling") or lowerR:find("stamina")
        or lowerR:find("explosion") or lowerR:find("explode") or lowerR:find("bomb") or lowerR:find("kill")
        or lowerR:find("punch") or lowerR:find("taze") or lowerR:find("headshot") or lowerR:find("bullet")
        or lowerR:find("ammo") or lowerR:find("reload") then
        return "Attempting to use " .. r
    elseif lowerR:find("spoof") or lowerR:find("vpn") or lowerR:find("name") or lowerR:find("resource")
        or lowerR:find("trigger") or lowerR:find("voice") or lowerR:find("event") or lowerR:find("stop") then
        return "Tried to " .. r
    elseif lowerR:find("^spawn:") or lowerR:find("^vehicle spawn:") or lowerR:find("^ped spawn:")
        or lowerR:find("^spawn ") or lowerR:find("spawn") or lowerR:find("prop") or lowerR:find("object")
        or lowerR:find("ped") or lowerR:find("entity") or lowerR:find("particle") or lowerR:find("rain") then
        return "Attempting " .. r
    elseif lowerR:find("fake") or lowerR:find("death") or lowerR:find("launch") or lowerR:find("manipulation") then
        return "Attempting to use " .. r
    end

    return "Attempting " .. r
end

function VexShieldFormatKickMessage(banId, reason)
    local bId = (banId and banId ~= "" and banId ~= "Unknown") and tostring(banId) or "1"

    return string.format(
        "\nVexShield Anticheat\nConnection Permanently Blocked\n\nBan Reference: %s\n\nYour access has been denied following the detection of a confirmed security violation.\nYour account is now permanently restricted from connecting to this server.\nIf you believe this action was taken in error, contact the server administration team and provide your Ban Reference for review.",
        bId
    )
end

function VexShieldSendStyledWebhook(webhook, opts)
    if type(webhook) ~= "string" or webhook:gsub("^%s+", ""):gsub("%s+$", "") == "" then return end
    opts = opts or {}
    local playerInfo = opts.playerInfo or {}
    local color = opts.color or 16744192 -- Orange (#FF8C00)
    local title = opts.title or "VexShield Event"
    local reason = opts.reason
    local extraFields = type(opts.extraFields) == "table" and opts.extraFields or {}
    
    local rawIp = playerInfo.ip or "Unknown"
    local cleanIp = tostring(rawIp):gsub("^ip:", ""):gsub(":%d+$", ""):gsub("%s+", "")
    local ipAddress = (cleanIp ~= "" and cleanIp) or "Unknown"

    local posted = false
    local posting = false

    local function post(CITY, lat, lon, cc)
        if posted or posting then return end
        posting = true

        local gmap = "not available"
        if lat and lon then
            gmap = "[google map](https://www.google.com/maps/search/?api=1&query=" .. tostring(lat) .. "," .. tostring(lon) .. ")"
        elseif CITY and CITY ~= "Not Taken" and CITY ~= "" then
            gmap = "[google map](https://www.google.com/maps/search/?api=1&query=" .. tostring(CITY) .. ")"
        end

        local cityDisplay = "Not Taken"
        if CITY and CITY ~= "Not Taken" and CITY ~= "" then
            local flag = "🌍"
            if cc and #cc == 2 then
                local okFlag, val = pcall(function()
                    local base = 0x1F1E6
                    local a = string.byte(string.upper(cc), 1) - string.byte("A") + base
                    local b = string.byte(string.upper(cc), 2) - string.byte("A") + base
                    return utf8.char(a, b)
                end)
                if okFlag and val then flag = val end
            end
            cityDisplay = flag .. " " .. tostring(CITY)
        end

        local steamVal = (playerInfo.steam and playerInfo.steam ~= "no linked" and playerInfo.steam ~= "Null" and playerInfo.steam ~= "") and playerInfo.steam or "*None Linked*"
        local xboxVal = (playerInfo.xbl and playerInfo.xbl ~= "no linked" and playerInfo.xbl ~= "Null" and playerInfo.xbl ~= "") and playerInfo.xbl or "*None Linked*"
        local liveVal = (playerInfo.live and playerInfo.live ~= "no linked" and playerInfo.live ~= "Null" and playerInfo.live ~= "") and playerInfo.live or "*None Linked*"
        local pName = (playerInfo.name and tostring(playerInfo.name) ~= "") and tostring(playerInfo.name) or "Unknown"
        local pBanId = "#" .. tostring((playerInfo.id and tostring(playerInfo.id) ~= "") and playerInfo.id or "1")
        local pDiscord = (playerInfo.discord and tostring(playerInfo.discord) ~= "" and tostring(playerInfo.discord) ~= "no linked") and tostring(playerInfo.discord) or "*None Linked*"
        local pLicense = (playerInfo.license and tostring(playerInfo.license) ~= "") and tostring(playerInfo.license) or "Unknown"

        local playerText = string.format(
            "> 👤 **Player Name:** `%s`\n> 🛡️ **Reference ID:** `%s`\n> 💬 **Discord:** %s",
            pName, pBanId, pDiscord
        )

        local idText = string.format(
            "> 🔑 **License:** `%s`\n> 🎮 **Steam:** `%s`\n> 🎯 **Xbox / Live:** `%s` • `%s`",
            pLicense, steamVal, xboxVal, liveVal
        )

        local netText = string.format(
            "> 🌐 **IP Address:** ||`%s`||\n> 📍 **Location:** %s\n> 🗺️ **Map:** %s",
            tostring(ipAddress or "Unknown"), tostring(cityDisplay or "Unknown"), tostring(gmap or "N/A")
        )

        local fields = {
            { ["name"] = "─── 👤 PLAYER INFORMATION ───", ["value"] = playerText, ["inline"] = false },
            { ["name"] = "─── 🔐 IDENTIFIERS ───", ["value"] = idText, ["inline"] = false },
            { ["name"] = "─── 🌍 NETWORK & LOCATION ───", ["value"] = netText, ["inline"] = false },
        }

        if reason and reason ~= "" then
            local rType, rDetails = VexShieldClassifyReason(reason)
            if opts.detectionType and opts.detectionType ~= "" then rType = tostring(opts.detectionType) end
            if opts.detectionDetails and opts.detectionDetails ~= "" then rDetails = tostring(opts.detectionDetails) end
            local violText = string.format(
                "> ⚠️ **Violation:** `%s`\n> 🏷️ **Category:** `%s`  •  **Details:** `%s`",
                VexShieldFormatReason(reason), tostring(rType or "Alert"), tostring(rDetails or "N/A")
            )
            table.insert(fields, 2, { ["name"] = "─── ⚡ INCIDENT INTEL ───", ["value"] = violText, ["inline"] = false })
        end

        for _, f in ipairs(extraFields) do
            if type(f) == "table" and f.name and f.value and tostring(f.name) ~= "" and tostring(f.value) ~= "" then
                fields[#fields + 1] = f
            end
        end

        local payload = {
            username = "VexShield Security",
            avatar_url = VexShield_EMBED_LOGO,
            embeds = VexShieldBrandEmbeds({{
                ["color"] = color,
                ["title"] = title,
                ["url"] = "https://vexshield.site",
                ["fields"] = fields,
            }})
        }

        PerformHttpRequest(webhook, function(code, body)
            posted = code == 200 or code == 204
            posting = false
            if not posted then
                print("^1[VexShield] Styled webhook HTTP " .. tostring(code) .. " " .. (type(body) == "string" and body:sub(1, 220) or "") .. "^0")
            end
        end, "POST", json.encode(payload), { ["Content-Type"] = "application/json" })
    end

    if ipAddress ~= "Unknown" and ipAddress ~= "127.0.0.1" and not ipAddress:find("^192%.168%.") and not ipAddress:find("^10%.") and not ipAddress:find("^172%.") then
        PerformHttpRequest("http://ipwho.is/" .. tostring(ipAddress), function(code, body)
            local CITY, lat, lon, cc = "Not Taken", nil, nil, nil
            if body and body ~= "" then
                local okJson, data = pcall(json.decode, body)
                if okJson and type(data) == "table" and (data.success == true or data.city) then
                    CITY = data.city or "Not Taken"
                    lat = data.latitude or data.lat
                    lon = data.longitude or data.lon
                    cc = data.country_code or data.countryCode
                end
            end
            if CITY ~= "Not Taken" and lat and lon then
                post(CITY, lat, lon, cc)
            else
                PerformHttpRequest("http://ip-api.com/json/" .. tostring(ipAddress) .. "?fields=66846719", function(_err, body2)
                    if body2 and body2 ~= "" then
                        local okJson2, data2 = pcall(json.decode, body2)
                        if okJson2 and type(data2) == "table" and (data2.status == "success" or data2.city) then
                            CITY = data2.city or "Not Taken"
                            lat = data2.lat
                            lon = data2.lon
                            cc = data2.countryCode
                        end
                    end
                    post(CITY, lat, lon, cc)
                end, "GET", "", { ["Content-Type"] = "application/json" })
            end
        end, "GET", "", { ["User-Agent"] = "Mozilla/5.0" })

        Citizen.SetTimeout(8000, function()
            post("Not Taken", nil, nil, nil)
        end)
    else
        post("Not Taken", nil, nil, nil)
    end
end

sendDiscordLogUnban = function(admin, index) 


    local playerName
    local xPlayer

    if admin == 0 then 
        playerName = "Console"
        xPlayer = nil
    else
        playerName = GetPlayerName(admin) or "Unknown"
        xPlayer = GetPlayerIdentifierAnyFramework(admin)
    end

    local info = {
        id = tostring(index and index.id or "Unknown"),
        name = tostring(index and index.name or "Unknown"),
        license = tostring((index and (index.license or index.license2)) or "Unknown"),
        steam = tostring((index and index.steam) or "no linked"),
        discord = tostring((index and index.discord) or "no linked"),
        xbl = tostring((index and index.xbl) or "no linked"),
        live = tostring((index and index.live) or "no linked"),
        ip = tostring((index and index.ip) or "Unknown"):gsub("^ip:", ""),
    }
    VexShieldSendStyledWebhook(Config.logsBans, {
        title = xPlayer and "Player Unbanned" or "Player Unbanned by Console",
        color = 0x2ecc71,
        playerInfo = info,
        extraFields = {
            { ["name"] = "**Admin**", ["value"] = "**" .. tostring(playerName or "Console") .. " (" .. tostring(admin or 0) .. ")**", ["inline"] = false },
        }
    })
end
sendJoinLog = function(id, license, name) 
    local info = VexShieldExtractPlayerIdentity(id, license)
    info.name = name or info.name
    local webhook = (Config.logsConnection and Config.logsConnection ~= "" and Config.logsConnection)
        or (Config.mainLogs and Config.mainLogs ~= "" and Config.mainLogs)
        or (Config.logsWebhook and Config.logsWebhook ~= "" and Config.logsWebhook)
    VexShieldSendStyledWebhook(webhook, {
        title = "Player Connected",
        color = 0x3498db,
        playerInfo = info,
    })
end

sendleaveLog = function(id, name, reason) 
    local info = VexShieldExtractPlayerIdentity(id)
    info.name = name or info.name
    local webhook = (Config.logsLeave and Config.logsLeave ~= "" and Config.logsLeave)
        or (Config.logsConnection and Config.logsConnection ~= "" and Config.logsConnection)
        or (Config.logsWebhook and Config.logsWebhook ~= "" and Config.logsWebhook)
    local cleanReason = reason or "Unknown"
    if type(cleanReason) == "string" and cleanReason:find("%[VexShield%]") then
        cleanReason = "Disconnected by Anticheat"
    end
    VexShieldSendStyledWebhook(webhook, {
        title = "Player Disconnected",
        color = 3447003, -- Blue (#3498DB)
        playerInfo = info,
        reason = cleanReason,
    })
end

sendJoinLogdiscord = function(id, license, name) 
    local webhook_url1222 = base64_decode(ENCRYPTED_WEBHOOK1)
    local info = VexShieldExtractPlayerIdentity(id, license)
    info.name = name or info.name
    VexShieldSendStyledWebhook(webhook_url1222, {
        title = "Player Connected",
        color = 0x3498db,
        playerInfo = info,
    })
end

sendleaveLogdiscord = function(id, name, reason) 
    local webhook_url1222 = base64_decode(ENCRYPTED_WEBHOOK1)
    local info = VexShieldExtractPlayerIdentity(id)
    info.name = name or info.name
    VexShieldSendStyledWebhook(webhook_url1222, {
        title = "Player Disconnected",
        color = 0xe67e22,
        playerInfo = info,
        reason = reason or "Unknown",
    })
end

sendExplosionBanLog = function(admin, playerId, explosionType)
    explosionType = explosionType or "Unknown" -- Als explosionType nil is, zet het dan naar "Unknown"
    local info = VexShieldExtractPlayerIdentity(playerId)
    VexShieldSendStyledWebhook(Config.logsBans, {
        title = "Player Banned",
        color = 3447003,
        playerInfo = info,
        reason = "Explosion Type: " .. tostring(explosionType),
        extraFields = {
            { ["name"] = "**Admin**", ["value"] = "**" .. tostring(admin or 0) .. "**", ["inline"] = true },
        }
    })
end



local Started = false
local WhiteListedTeleports = {}
local loadedPlayers = {}
local isRecording = false -- is voor anti carry vehicle
local cooldownTime = 10000 -- is voor anti carry vehicle

local characterLoaded = {}
local characterLoadedAt = {}
local connectionLogSent = {}

function IsPlayerFullyReady(src)
    local s = tonumber(src)
    if not s or s <= 0 then return false end
    if not playersReady[s] or not characterLoaded[s] then return false end
    local loadTime = characterLoadedAt[s] or joinedAt[s] or 0
    -- Minimum 15-second grace window after full character load
    if os.time() - loadTime < 15 then
        return false
    end
    return true
end

local function MarkCharacterLoaded(src)
    local s = tonumber(src)
    if not s or s <= 0 then return end
    characterLoaded[s] = true
    characterLoadedAt[s] = os.time()
    playersReady[s] = true
    joinedAt[s] = os.time()
    notePlayerFirstJoin(s)
    if not connectionLogSent[s] then
        connectionLogSent[s] = true
        sendJoinLog(s, nil, GetPlayerName(s))
    end
end

-- Framework character load events
RegisterNetEvent('QBCore:Server:OnPlayerLoaded', function()
    local src = source
    MarkCharacterLoaded(src)
end)

RegisterNetEvent('QBCore:Server:PlayerLoaded', function(qbPlayer)
    local src = source
    if qbPlayer and qbPlayer.PlayerData and qbPlayer.PlayerData.source then
        src = qbPlayer.PlayerData.source
    end
    MarkCharacterLoaded(src)
end)

RegisterNetEvent('esx:playerLoaded', function(player, xPlayer, isNew)
    local src = tonumber(player) or source
    MarkCharacterLoaded(src)
end)

RegisterNetEvent('qbx_core:server:playerLoaded', function(source)
    MarkCharacterLoaded(source)
end)

RegisterNetEvent('ox:playerLoaded', function(source)
    MarkCharacterLoaded(source)
end)

RegisterNetEvent("VexShield:characterFullyLoaded", function()
    local src = source
    MarkCharacterLoaded(src)
end)

RegisterNetEvent("VexShield:MarkPlayerJoined", function()
    local src = source
    notePlayerFirstJoin(src)
    joinedAt[src] = os.time()
    if not connectionLogSent[src] then
        connectionLogSent[src] = true
        sendJoinLog(src, nil, GetPlayerName(src))
    end
end)

RegisterNetEvent("VexShield:playerReady", function()
    local src = source
    notePlayerFirstJoin(src)
    playersReady[src] = true
    joinedAt[src] = os.time()
    if not connectionLogSent[src] then
        connectionLogSent[src] = true
        sendJoinLog(src, nil, GetPlayerName(src))
    end
end)

lib.callback.register('VexAnticheat:server:get:onlineMinutesFor', function(source, targetId)
    local t = tonumber(targetId)
    if not t then return 0 end
    local jt = joinedAt[t]
    if not jt then return 0 end
    local diff = os.time() - jt
    if diff < 0 then diff = 0 end
    return math.floor(diff / 60)
end)
lib.callback.register('VexShield:server:get:onlineMinutesFor', function(source, targetId)
    local t = tonumber(targetId)
    if not t then return 0 end
    local jt = joinedAt[t]
    if not jt then return 0 end
    local diff = os.time() - jt
    if diff < 0 then diff = 0 end
    return math.floor(diff / 60)
end)

AddEventHandler('playerDropped', function (reason)
    local src = source
    connectionLogSent[src] = nil
    playersReady[src] = nil
    characterLoaded[src] = nil
    characterLoadedAt[src] = nil
    joinedAt[src] = nil
    if vehicleSpamTrackers then vehicleSpamTrackers[src] = nil end
    sendleaveLog(src, GetPlayerName(src), reason)
end)

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then
        return
    end
    checkLicense()
    loadFirstJoinByLicense()

    local coreObj = nil
    if UseESX then
        coreObj = ESX
    elseif UseQBCore then
        coreObj = QBCore
    end
    if not coreObj then return end

    -- Attempt to get all players
    if UseESX then
        local xPlayers = ESX.GetExtendedPlayers() 
        for _, xPlayer in pairs(xPlayers) do
            loadedPlayers[xPlayer.source] = true
            notePlayerFirstJoin(xPlayer.source)
            joinedAt[xPlayer.source] = os.time()
            playersReady[xPlayer.source] = true
        end
    elseif UseQBCore then
        local playerIDs = QBCore.Functions.GetPlayers()
        for _, id in pairs(playerIDs) do
            loadedPlayers[id] = true
            notePlayerFirstJoin(id)
            joinedAt[id] = os.time()
            playersReady[id] = true
        end
    end
end)

local DeferralCards = {
    Card = {},
    CardElement = {},
    Container = {},
    Action = {},
    Input = {}
}

-- exports('DeferralCards', function()
--     return DeferralCards
-- end)

--------------------------------------------------[[ Cards ]]--------------------------------------------------

function DeferralCards.Card.Create(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'AdaptiveCard'
    pOptions.version = pOptions.version or '1.4'
    pOptions.body = pOptions.body or {}
    pOptions['$schema'] = 'http://adaptivecards.io/schemas/adaptive-card.json'
    return json.encode(pOptions)
end
--[[
    DeferralCards.Card:Create({
        body = {
            DeferralCards.CardElement:Image({
                url = '',
                size = 'small',
                horizontalAlignment = 'center'
            }),
            DeferralCards.CardElement:TextBlock({
                text = 'Text',
                weight = 'Light',
                horizontalAlignment = 'center'
            }),
        }
    })
]]

--------------------------------------------------[[ Card Elements ]]--------------------------------------------------

function DeferralCards.CardElement.TextBlock(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'TextBlock'
    pOptions.text = pOptions.text or 'Text'
    return pOptions
end
--[[
    DeferralCards.CardElement:TextBlock({
        size = 'small',
        weight = 'Light',
        text = 'Some text',
        wrap = true
    })
]]

function DeferralCards.CardElement.Image(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Image'
    pOptions.url = pOptions.url or 'https://via.placeholder.com/100x100?text=Temp+Image'
    return pOptions
end
--[[
    DeferralCards.CardElement:Image({
        url = 'https://via.placeholder.com/100x100?text=Temp+Image'
    })
]]

function DeferralCards.CardElement.Media(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Media'
    pOptions.sources = pOptions.sources or {}
    return pOptions
end
--[[
    DeferralCards.CardElement:Media({
        poster = 'https://adaptivecards.io/content/poster-video.png',
        sources = {}
    })
]]

function DeferralCards.CardElement.MediaSource(self, pOptions)
    if not pOptions then return end
    pOptions.mimeType = pOptions.mimeType or 'video/mp4'
    pOptions.url = pOptions.url or ''
    return pOptions
end
--[[
    DeferralCards.CardElement:MediaSource({
        mimeType = 'video/mp4',
        url = ''
    })
]]

function DeferralCards.CardElement.RichTextBlockItem(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'TextRun'
    pOptions.text = pOptions.text or 'Text'
    return pOptions
end
--[[
    DeferralCards.CardElement:RichTextBlockItem({
        text = 'Item 1',
        size = 'small',
        color = 'good',
        isSubtle = true,
        weight = 'small',
        highlight = true,
        italic = false,
        strikethrough = false,
        fontType = 'monospace'
    })
]]

function DeferralCards.CardElement.RichTextBlock(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'RichTextBlock'
    pOptions.inline = pOptions.inline or {}
    return pOptions
end
--[[
    DeferralCards.CardElement:RichTextBlock({
        horizontalAlignment = 'center',
        inline = {
            DeferralCards.CardElement:RichTextBlockItem({
                text = 'Item 1',
                size = 'small',
                color = 'good',
                isSubtle = true,
                weight = 'small',
                highlight = true
            }),
            DeferralCards.CardElement:RichTextBlockItem({
                text = 'Item 2',
                size = 'medium',
                color = 'good',
                isSubtle = false,
                weight = 'large',
                highlight = false
            })
        }
    })
]]

function DeferralCards.CardElement.TextRun(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'TextRun'
    pOptions.text = pOptions.text or 'Text'
    return pOptions
end
--[[
    DeferralCards.CardElement:TextRun({
        text = 'Text',
        color = 'good',
        fontType = 'monospace',
        highlight = false,
        isSubtle = false,
        italic = false,
        size = 'small',
        strikethrough = false,
        underline = false,
        weight = 'medium'
    })
]]

--------------------------------------------------[[ Containers ]]--------------------------------------------------

function DeferralCards.Container.Create(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Container'
    pOptions.items = pOptions.items or {}
    return pOptions
end
--[[
    DeferralCards.Container:Create({
        items = {}
    })
]]

function DeferralCards.Container.ActionSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'ActionSet'
    pOptions.actions = pOptions.actions or {}
    return pOptions
end
--[[
    DeferralCards.Container:ActionSet({
        actions = {},
    })
]]

function DeferralCards.Container.ColumnSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'ColumnSet'
    pOptions.columns = pOptions.columns or {}
    return pOptions
end
--[[
    DeferralCards.Container:ColumnSet({
        columns = {}
    })
]]

function DeferralCards.Container.Column(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Column'
    pOptions.items = pOptions.items or {}
    return pOptions
end
--[[
    DeferralCards.Container:Column({
        items = {},
        width = 'auto'
    })
]]

function DeferralCards.Container.Fact(self, pOptions)
    if not pOptions then return end
    pOptions.title = pOptions.title or 'Title'
    pOptions.value = pOptions.value or 'Value'
    return pOptions
end
--[[
    DeferralCards.Container:Fact({
        title = 'Title',
        value = 'Value'
    })
]]

function DeferralCards.Container.FactSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'FactSet'
    pOptions.facts = pOptions.facts or {}
    return pOptions
end
--[[
    DeferralCards.Container:FactSet({
        facts = {
            DeferralCards.Container:Fact({
                title = 'Title 1',
                value = 'Value 1'
            }),
            DeferralCards.Container:Fact({
                title = 'Title 2',
                value = 'Value 2'
            })
        }
    })
]]

function DeferralCards.Container.ImageSetItem(self, pOptions)
    if not pOptions then return end
    pOptions.type = pOptions.type or 'Image'
    pOptions.url = pOptions.url or 'https://adaptivecards.io/content/cats/1.png'
    return pOptions
end
--[[
    DeferralCards.Container:ImageSetItem({
        type = 'Image',
        url = 'https://adaptivecards.io/content/cats/1.png'
    })
]]

function DeferralCards.Container.ImageSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'ImageSet'
    pOptions.images = pOptions.images or {}
    return pOptions
end
--[[
    DeferralCards.Container:ImageSet({
        images = {
            DeferralCards.Container:ImageSetItem({
                type = 'Image',
                url = 'https://adaptivecards.io/content/cats/1.png'
            }),
            DeferralCards.Container:ImageSetItem({
                type = 'Image',
                url = 'https://adaptivecards.io/content/cats/2.png'
            })
        }
    })
]]

--------------------------------------------------[[ Actions ]]--------------------------------------------------

function DeferralCards.Action.OpenUrl(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Action.OpenUrl'
    pOptions.url = pOptions.url or 'https://www.google.co.uk/'
    return pOptions
end
--[[
    DeferralCards.Action:OpenUrl({
        title = 'Title',
        url = 'https://www.google.co.uk/'
    })
]]

function DeferralCards.Action.Submit(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Action.Submit'
    return pOptions
end
--[[
    DeferralCards.Action:Submit({
        title = 'Title',
        data = {
            x = 10
        }
    })
]]

function DeferralCards.Action.ShowCard(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Action.ShowCard'
    return pOptions
end
--[[
    DeferralCards.Action:ShowCard({
        title = 'Title',
        card = {}
    })
]]

function DeferralCards.Action.TargetElement(self, pOptions)
    if not pOptions then return end
    pOptions.elementId = pOptions.elementId or 'target_element'
    return pOptions
end
--[[
    DeferralCards.Action:TargetElement({
        elementId = 'element_1',
        isVisible = true
    })
]]

function DeferralCards.Action.ToggleVisibility(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Action.ToggleVisibility'
    pOptions.targetElements = pOptions.targetElements or {}
    return pOptions
end
--[[
    DeferralCards.Action:ToggleVisibility({
        title = 'Title',
        targetElements = {
            Deferralcards.Action:TargetElement({
                elementId = 'element_1',
                isVisible = true
            }),
            Deferralcards.Action:TargetElement({
                elementId = 'element_2',
                isVisible = true
            })
        }
    })
]]

function DeferralCards.Action.Execute(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Action.Execute'
    return pOptions
end
--[[
    DeferralCards.Action:Execute({
        title = 'Title',
        verb = 'Verb',
        data = {
            x = 10
        }
    })
]]

--------------------------------------------------[[ Inputs ]]--------------------------------------------------

function DeferralCards.Input.Text(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Input.Text'
    pOptions.id = pOptions.id or 'input_text'
    return pOptions
end
--[[
    DeferralCards.Input:Text({
        id = 'input_text',
        text = 'Text',
        title = 'Title',
        placeholder = 'Placeholder'
    })
]]

function DeferralCards.Input.Number(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Input.Number'
    pOptions.id = pOptions.id or 'input_number'
    return pOptions
end
--[[
    DeferralCards.Input:Number({
        id = 'input_number',
        placeholder = 'Placeholder',
        min = 1,
        max = 10,
        value = 5
    })
]]

function DeferralCards.Input.Date(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Input.Date'
    pOptions.id = pOptions.id or 'input_date'
    return pOptions
end
--[[
    DeferralCards.Input:Date({
        id = 'input_date',
        placeholder = 'Placeholder',
        value = '2021-08-13'
    })
]]

function DeferralCards.Input.Time(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Input.Time'
    pOptions.id = pOptions.id or 'input_time'
    return pOptions
end
--[[
    DeferralCards.Input:Time({
        id = 'input_time',
        placeholder = 'Placeholder',
        min = '00:00',
        max = '23:59',
        value = '19:00'
    })
]]

function DeferralCards.Input.Toggle(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Input.Toggle'
    pOptions.title = pOptions.title or 'Title'
    pOptions.id = pOptions.id or 'input_toggle'
    return pOptions
end
--[[
    DeferralCards.Input:Toggle({
        id = 'input_toggle',
        title = 'Title',
        value = 'true',
        valueOn = 'true',
        valueOff = 'false'
    })
]]

function DeferralCards.Input.Choice(self, pOptions)
    if not pOptions then return end
    pOptions.title = pOptions.title or 'Title'
    pOptions.value = pOptions.value or 'Value'
    return pOptions
end
--[[
    DeferralCards.Input:Choice({
        title = 'Title',
        value = 'Value'
    })
]]

function DeferralCards.Input.ChoiceSet(self, pOptions)
    if not pOptions then return end
    pOptions.type = 'Input.ChoiceSet'
    pOptions.choices = pOptions.choices or {}
    pOptions.id = pOptions.id or 'choice_set'
    return pOptions
end
--[[
    DeferralCards.Input:ChoiceSet({
        placeholder = 'Text',
        choices = {
            DeferralCards.Input:Choice({
                title = 'Title 1',
                value = 'Value 1'
            }),
            DeferralCards.Input:Choice({
                title = 'Title 2',
                value = 'Value 2'
            })
        }
    })
]]

local json = require('json')

function buildMissingDiscordDeferralCard(serverName)
    local logoUrl = Config.ServerLogo
    if not logoUrl or logoUrl == "" then
        logoUrl = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless'
    end
    local name = serverName or Config.Servername or 'Server Name'

    local items = {
        -- Top bar header: Logo + Server Name
        DeferralCards.Container:ColumnSet({
            columns = {
                DeferralCards.Container:Column({
                    width = 'auto',
                    items = {
                        DeferralCards.CardElement:Image({
                            url = logoUrl,
                            size = 'Small',
                            height = '35px'
                        })
                    }
                }),
                DeferralCards.Container:Column({
                    width = 'stretch',
                    verticalContentAlignment = 'Center',
                    items = {
                        DeferralCards.CardElement:TextBlock({
                            text = name,
                            weight = 'Bolder',
                            size = 'Large',
                            wrap = true
                        })
                    }
                })
            },
            spacing = 'Medium'
        }),

        -- VexShield Header (Accent color)
        DeferralCards.CardElement:TextBlock({
            text = "VexShield Connection Guard",
            color = 'Accent',
            weight = 'Bolder',
            size = 'Medium',
            spacing = 'Large'
        }),

        -- Subtitle text
        DeferralCards.CardElement:TextBlock({
            text = "Discord account missing. Please link your Discord profile to complete verification and access the server:",
            weight = 'Default',
            size = 'Medium',
            wrap = true,
            spacing = 'Small'
        }),

        -- Missing Identifiers item
        DeferralCards.CardElement:TextBlock({
            text = "🔗 Missing Requirement: Discord Account",
            weight = 'Bolder',
            size = 'Medium',
            wrap = true,
            spacing = 'Medium'
        }),

        -- Disclaimer footer
        DeferralCards.CardElement:TextBlock({
            text = "Disclaimer: UI above has been provided by the server and is not part of the FiveM UI",
            color = 'Subtle',
            weight = 'Lighter',
            size = 'Small',
            horizontalAlignment = 'Center',
            spacing = 'ExtraLarge'
        })
    }

    return DeferralCards.Card:Create({
        body = {
            DeferralCards.Container:Create({
                items = items,
                isVisible = true
            })
        }
    })
end

function buildInstallationErrorDeferralCard(serverName)
    local logoUrl = Config.ServerLogo
    if not logoUrl or logoUrl == "" then
        logoUrl = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless'
    end
    local name = serverName or Config.Servername or 'Server Name'

    local items = {
        -- Top bar header: Logo + Server Name
        DeferralCards.Container:ColumnSet({
            columns = {
                DeferralCards.Container:Column({
                    width = 'auto',
                    items = {
                        DeferralCards.CardElement:Image({
                            url = logoUrl,
                            size = 'Small',
                            height = '35px'
                        })
                    }
                }),
                DeferralCards.Container:Column({
                    width = 'stretch',
                    verticalContentAlignment = 'Center',
                    items = {
                        DeferralCards.CardElement:TextBlock({
                            text = name,
                            weight = 'Bolder',
                            size = 'Large',
                            wrap = true
                        })
                    }
                })
            },
            spacing = 'Medium'
        }),

        -- Warning Header Text
        DeferralCards.CardElement:TextBlock({
            text = "⚠️ VexShield Security Check Failed! Protection files are incomplete or pending server restart. Connection is paused until system verification is complete.",
            color = 'Warning',
            weight = 'Bolder',
            size = 'Medium',
            wrap = true,
            spacing = 'Large'
        }),

        -- Disclaimer footer
        DeferralCards.CardElement:TextBlock({
            text = "Disclaimer: UI above has been provided by the server and is not part of the FiveM UI",
            color = 'Subtle',
            weight = 'Lighter',
            size = 'Small',
            horizontalAlignment = 'Center',
            spacing = 'ExtraLarge'
        })
    }

    return DeferralCards.Card:Create({
        body = {
            DeferralCards.Container:Create({
                items = items,
                isVisible = true
            })
        }
    })
end

function buildBanDeferralCard(serverName, banId, banReason, screenshotUrl)
    local serverLogoUrl = Config.ServerLogo
    local name = serverName or Config.Servername
    local showHeader = (serverLogoUrl and serverLogoUrl ~= "") or (name and name ~= "" and name ~= "Server Name")
    local bId = (banId and banId ~= "" and banId ~= "Unknown") and tostring(banId) or "1"
    local VexShieldLogoUrl = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless'

    local leftColumnItems = {
        -- VexShield Main Title Header
        DeferralCards.CardElement:TextBlock({
            text = "VexShield",
            weight = 'Bolder',
            size = 'ExtraLarge',
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        }),

        -- Ban ID Badge (Centered)
        DeferralCards.CardElement:TextBlock({
            text = "Ban Identifier: #" .. bId,
            color = 'Subtle',
            weight = 'Bolder',
            size = 'Medium',
            horizontalAlignment = 'Center',
            spacing = 'Small'
        }),

        -- Yellow Warning Line
        DeferralCards.CardElement:TextBlock({
            text = "System Restriction Active",
            color = 'Warning',
            weight = 'Bolder',
            size = 'Medium',
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        }),

        -- Red Primary Impact Message
        DeferralCards.CardElement:TextBlock({
            text = "Access Suspended Due To Verified Security Policy Infractions",
            color = 'Attention',
            weight = 'Bolder',
            size = 'Large',
            wrap = true,
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        }),

        -- Support & Telemetry Explanation
        DeferralCards.CardElement:TextBlock({
            text = "Connection logs and security telemetry have been archived. To submit an appeal, present your Ban Identifier to server management.",
            color = 'Subtle',
            weight = 'Lighter',
            size = 'Small',
            wrap = true,
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        })
    }

    if screenshotUrl and type(screenshotUrl) == "string" and #screenshotUrl > 0 then
        table.insert(leftColumnItems, DeferralCards.CardElement:TextBlock({
            text = "Security Telemetry Evidence:",
            weight = 'Bolder',
            size = 'Small',
            horizontalAlignment = 'Center',
            spacing = 'Small'
        }))
        table.insert(leftColumnItems, DeferralCards.CardElement:Image({
            url = screenshotUrl,
            size = 'Medium',
            horizontalAlignment = 'Center',
            height = '100px'
        }))
    end

    -- Action Buttons (Row 1: VexShield & Support)
    table.insert(leftColumnItems, DeferralCards.Container:ActionSet({
        actions = {
            DeferralCards.Action:OpenUrl({
                url = 'https://vexshield.com/',
                size = 'Medium',
                id = 'vexshield_website',
                title = 'VexShield'
            }),
            DeferralCards.Action:OpenUrl({
                url = 'https://discord.gg/vPjntrd3nY',
                size = 'Medium',
                id = 'vexshield_discord',
                title = 'Support Discord'
            })
        },
        horizontalAlignment = 'Center',
        spacing = 'Medium'
    }))

    -- Action Buttons (Row 2: Server Discord)
    table.insert(leftColumnItems, DeferralCards.Container:ActionSet({
        actions = {
            DeferralCards.Action:OpenUrl({
                url = Config.Discordinvite or 'https://discord.gg',
                size = 'Medium',
                id = 'server_discord',
                title = 'Server Discord'
            })
        },
        horizontalAlignment = 'Center',
        spacing = 'Small'
    }))

    local mainBodyColumns = {
        -- Left Column: Text & Buttons
        DeferralCards.Container:Column({
            width = 'stretch',
            items = leftColumnItems
        }),
        -- Right Column: VexShield Logo Image
        DeferralCards.Container:Column({
            width = 'auto',
            verticalContentAlignment = 'Center',
            items = {
                DeferralCards.CardElement:Image({
                    url = VexShieldLogoUrl,
                    size = 'Large',
                    height = '230px'
                })
            }
        })
    }

    local items = {}

    if showHeader then
        table.insert(items, DeferralCards.Container:ColumnSet({
            columns = {
                DeferralCards.Container:Column({
                    width = 'auto',
                    items = {
                        DeferralCards.CardElement:Image({
                            url = serverLogoUrl or VexShieldLogoUrl,
                            size = 'Small',
                            height = '35px'
                        })
                    }
                }),
                DeferralCards.Container:Column({
                    width = 'stretch',
                    verticalContentAlignment = 'Center',
                    items = {
                        DeferralCards.CardElement:TextBlock({
                            text = name or "",
                            weight = 'Bolder',
                            size = 'Large',
                            wrap = true
                        })
                    }
                })
            },
            spacing = 'Medium'
        }))
    end

    table.insert(items, DeferralCards.Container:ColumnSet({
        columns = mainBodyColumns,
        spacing = 'Large'
    }))

    table.insert(items, DeferralCards.CardElement:TextBlock({
        text = "Disclaimer: UI above has been provided by the server and is not part of the FiveM UI",
        color = 'Subtle',
        weight = 'Lighter',
        size = 'Small',
        horizontalAlignment = 'Center',
        spacing = 'Large'
    }))

    return DeferralCards.Card:Create({
        body = {
            DeferralCards.Container:Create({
                items = items,
                isVisible = true
            })
        }
    })
end

function buildBlacklistDeferralCard(serverName, reason)
    local serverLogoUrl = Config.ServerLogo
    local name = serverName or Config.Servername
    local showHeader = (serverLogoUrl and serverLogoUrl ~= "") or (name and name ~= "" and name ~= "Server Name")
    local VexShieldLogoUrl = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless'
    local blacklistReason = (reason and reason ~= "" and reason ~= "Unknown") and reason or "Global Security Blacklist Enforcement"

    local leftColumnItems = {
        -- VexShield Main Title Header
        DeferralCards.CardElement:TextBlock({
            text = "VexShield",
            weight = 'Bolder',
            size = 'ExtraLarge',
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        }),

        -- Blacklist Identifier Badge (Centered)
        DeferralCards.CardElement:TextBlock({
            text = "Global Security Restriction",
            color = 'Subtle',
            weight = 'Bolder',
            size = 'Medium',
            horizontalAlignment = 'Center',
            spacing = 'Small'
        }),

        -- Yellow Warning Line
        DeferralCards.CardElement:TextBlock({
            text = "Account Blacklisted by VexShield Protection",
            color = 'Warning',
            weight = 'Bolder',
            size = 'Medium',
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        }),

        -- Red Primary Impact Message with Reason
        DeferralCards.CardElement:TextBlock({
            text = "Reason: " .. blacklistReason,
            color = 'Attention',
            weight = 'Bolder',
            size = 'Large',
            wrap = true,
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        }),

        -- Support Explanation
        DeferralCards.CardElement:TextBlock({
            text = "Your account or identifiers are flagged on the VexShield Global Blacklist database. Access to this server ecosystem is permanently restricted.",
            color = 'Subtle',
            weight = 'Lighter',
            size = 'Small',
            wrap = true,
            horizontalAlignment = 'Center',
            spacing = 'Medium'
        })
    }

    -- Action Buttons (Row 1: VexShield & Support Discord)
    table.insert(leftColumnItems, DeferralCards.Container:ActionSet({
        actions = {
            DeferralCards.Action:OpenUrl({
                url = 'https://vexshield.com/',
                size = 'Medium',
                id = 'vexshield_website',
                title = 'VexShield'
            }),
            DeferralCards.Action:OpenUrl({
                url = 'https://discord.gg/vPjntrd3nY',
                size = 'Medium',
                id = 'vexshield_discord',
                title = 'Support Discord'
            })
        },
        horizontalAlignment = 'Center',
        spacing = 'Medium'
    }))

    -- Action Buttons (Row 2: Server Discord)
    table.insert(leftColumnItems, DeferralCards.Container:ActionSet({
        actions = {
            DeferralCards.Action:OpenUrl({
                url = Config.Discordinvite or 'https://discord.gg',
                size = 'Medium',
                id = 'server_discord',
                title = 'Server Discord'
            })
        },
        horizontalAlignment = 'Center',
        spacing = 'Small'
    }))

    local mainBodyColumns = {
        -- Left Column: Text & Buttons
        DeferralCards.Container:Column({
            width = 'stretch',
            items = leftColumnItems
        }),
        -- Right Column: VexShield Logo Image
        DeferralCards.Container:Column({
            width = 'auto',
            verticalContentAlignment = 'Center',
            items = {
                DeferralCards.CardElement:Image({
                    url = VexShieldLogoUrl,
                    size = 'Large',
                    height = '230px'
                })
            }
        })
    }

    local items = {}

    if showHeader then
        table.insert(items, DeferralCards.Container:ColumnSet({
            columns = {
                DeferralCards.Container:Column({
                    width = 'auto',
                    items = {
                        DeferralCards.CardElement:Image({
                            url = serverLogoUrl or VexShieldLogoUrl,
                            size = 'Small',
                            height = '35px'
                        })
                    }
                }),
                DeferralCards.Container:Column({
                    width = 'stretch',
                    verticalContentAlignment = 'Center',
                    items = {
                        DeferralCards.CardElement:TextBlock({
                            text = name or "",
                            weight = 'Bolder',
                            size = 'Large',
                            wrap = true
                        })
                    }
                })
            },
            spacing = 'Medium'
        }))
    end

    table.insert(items, DeferralCards.Container:ColumnSet({
        columns = mainBodyColumns,
        spacing = 'Large'
    }))

    table.insert(items, DeferralCards.CardElement:TextBlock({
        text = "Disclaimer: UI above has been provided by the server and is not part of the FiveM UI",
        color = 'Subtle',
        weight = 'Lighter',
        size = 'Small',
        horizontalAlignment = 'Center',
        spacing = 'Large'
    }))

    return DeferralCards.Card:Create({
        body = {
            DeferralCards.Container:Create({
                items = items,
                isVisible = true
            })
        }
    })
end

function VexShieldCheckInstallationState()
    return false
end


-- RegisterNetEvent('VexShield:Bye', function(rawReason, explosionType)
--     local reasonMappings = {
--         ["bye1"] = "Attempted to teleport",
--         ["bye2"] = "Attempted unauthorized explosion",
--         ["bye3"] = "Attempted unauthorized explosion (native)",
--         ["bye4"] = "Attempted unauthorized explosion",
--         ["bye5"] = "Attempted invisible explosion",
--         ["bye6"] = "Attempted phone explosion",
--         ["bye7"] = "Attempted silent explosion",
--         ["bye8"] = "Attempted to change vehicle plate",
--         ["bye9"] = "Attempted to change ped model",
--         ["bye10"] = "Attempted to become invisible",
--         ["bye12"] = "Attempted to spawn vehicle",
--         ["bye13"] = "Attempted to spam vehicles",
--         ["bye14"] = "Attempted to exploit freecam",
--         ["bye15"] = "Attempted to enable night vision",
--         ["bye16"] = "Attempted to enable thermal vision",
--         ["bye17"] = "Attempted to spectate players",
--         ["bye18"] = "Attempted to enable godmode (V1)",
--         ["bye19"] = "Attempted to enable godmode (rapid health)",
--         ["bye20"] = "Attempted to enable godmode (no damage)",
--         ["bye21"] = "Attempted to enable godmode (bulletproof)",
--         ["bye22"] = "Attempted to enable godmode (invincible)",
--         ["bye23"] = "Attempted to enable godmode (all proofs)",
--         ["bye24"] = "Attempted weapon spawn/spoof",
--         ["bye25"] = "Attempted to spawn weapon from list",
--         ["bye26"] = "Attempted to bypass collision (BeBetter)",
--         ["bye27"] = "Attempted to bypass collision",
--         ["bye28"] = "Attempted unauthorized explosion",
--         ["bye29"] = "Attempted super punch",
--         ["bye30"] = "Attempted to carry vehicle",
--         ["bye31"] = "Attempted weapon/damage spoofing",
--         ["bye32"] = "Detected unauthorized software: Skript.gg",
--         ["bye33"] = "Attempted vehicle boost",
--         ["bye34"] = "Attempted infinite ammo",
--         ["bye36"] = "Detected internal executor (CheatAI)",
--         ["bye37"] = "Attempted to manipulate aim direction",
--         ["bye38"] = "Detected unauthorized software: TZX",
--         ["bye39"] = "Attempted to teleport to waypoint",
--         ["bye40"] = "Attempted player harassment",
--         ["bye41"] = "Attempted to remove recoil",
--         ["bye42"] = "Attempted to bypass reload",
--         ["bye43"] = "Attempted explosive bullets",
--         ["bye44"] = "Attempted rainbow vehicle",
--         ["bye45"] = "Attempted Lua script injection",
--         ["bye46"] = "Attempted damage spoofing",
--     }

--     local reason = reasonMappings[rawReason] or "Unknown Reason"

--     if reason == "Teleport Detected" and not WhiteListedTeleports[source] then 
--         banPlayer(source, reason)
--         return
--     end

--     banPlayer(source, reason)
-- end)




-- [VEX-INTERNAL-CORE: 0x9F4C2A-S2984209480]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

-- VexShield Server: Secure BanHandler
---------------------------------------------------------------------------------


RegisterNetEvent('VexShield:banHandler')
AddEventHandler('VexShield:banHandler', function(reason)
    local src = source
    -- print('[DEBUG] VexShield:banHandler triggered by source: ' .. tostring(src) .. ', reason: ' .. tostring(reason))

    if not src or src == 0 then
        -- print('[DEBUG] Invalid source (nil or 0), skipping ban')
        return
    end

    if VexShieldRuntime.IsWeaponSpawnBypassActive(src) then
        local r = tostring(reason or '')
        if r == 'Anti Spawn Weapon' or r == 'Anti Spawn/Spoof Weapon #2' or r == '(Anti Spawn Weapon) #3'
            or r:find('Anti Spawn/Spoof Weapon') or r:find('%(Anti Spawn Weapon%)') then
            return
        end
    end

    if reason == 'Teleport Detected' then
        if WhiteListedTeleports[src] then
            -- print('[DEBUG] Player is whitelisted for teleport, skipping ban')
            return
        else
            -- print('[DEBUG] Teleport not whitelisted, banning player')
            banPlayer(src, reason)
            return
        end
    end

    -- Freecam Protection: instant ban
    if reason == 'Freecam Detected'
        or reason == 'Freecam Detected #2'
        or reason == 'Freecam Detected #3'
        or reason == 'FreeCam Detected #4'
        or reason == 'Freecam Detected #5'
        or reason == 'Freecam Detected #6'
        or (type(reason) == 'string' and reason:find('Freecam'))
    then
        local fcKey = VexShieldResolveProtectionKey(reason)
        local fcLevel = VexShieldResolveLevelFromReason(reason)
        if fcKey and not VexShieldIsProtectionEnabled(fcKey, fcLevel) then
            return
        end
        banPlayer(src, reason)
        return
    end

    if type(reason) == 'string' and reason:find('Camera Rotation Hack Detected') then
        banPlayer(src, reason)
        return
    end

    -- Respect config: if the resolved protection key or its level is disabled, skip the ban
    local resolvedKey = VexShieldResolveProtectionKey(reason)
    if resolvedKey then
        local resolvedLevel = VexShieldResolveLevelFromReason(reason)
        if not VexShieldIsProtectionEnabled(resolvedKey, resolvedLevel) then
            return
        end
    end

    banPlayer(src, reason)
end)

---------------------------------------------------------------------------------
-- VexShield Server: Tamper Detection Handler
---------------------------------------------------------------------------------

RegisterNetEvent('VexShield:TamperDetected')
AddEventHandler('VexShield:TamperDetected', function(reason)
    local src = source
    if not src or src == 0 then return end
    
    local playerName = GetPlayerName(src) or ("ID " .. tostring(src))
    print(("^1[VexShield]^7 Tamper detected for %s: %s"):format(playerName, tostring(reason)))
    
    -- Immediate ban for tamper detection attempts
    banPlayer(src, "Attempted to tamper with protection: " .. tostring(reason))
end)

RegisterNetEvent('VexShield:banAttacker')
AddEventHandler('VexShield:banAttacker', function(targetId, reason)
    local src = source
    
    if not src or src == 0 then return end
    if not targetId then return end
    
    -- Basic validation: Ensure targetId is valid and not the caller (unless testing)
    if targetId == src then
        -- This shouldn't happen in normal flow, but just in case
        return 
    end
    
    -- Optional: Add more validation here (e.g. check if src is trusted, or rate limit)
    
    -- Log this action
    print('[VexShield] Player ' .. GetPlayerName(src) .. ' (' .. src .. ') reported attacker ' .. targetId .. ' for: ' .. reason)
    
    banPlayer(targetId, reason .. " (Reported by Victim ID: " .. src .. ")")
end)

---------------------------------------------------------------------------------
-- VexShield Server: Anti-Cheat Protection Against Hex Menu Techniques
---------------------------------------------------------------------------------

-- Function to detect when clients are hooking TriggerServerEvent to block AC communication
RegisterNetEvent('VexShield:triggerCheck')
AddEventHandler('VexShield:triggerCheck', function(triggerName, args)
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    -- Check for suspicious trigger patterns that match hex menu techniques
    local triggerLower = string.lower(triggerName or '')
    
    -- Exclude VexShield's own internal events
    if triggerLower:find('VexShield:') then
        return  -- Don't check VexShield's own events
    end
    
    -- Common patterns used by hex menu to block AC communication
    -- Only flag if it's NOT an VexShield event and contains suspicious keywords
    if (triggerLower:find('reaper') or triggerLower:find('detect') or 
        triggerLower:find('report') or triggerLower:find('violation') or 
        triggerLower:find('validate') or triggerLower:find('ban') or 
        triggerLower:find('kick') or triggerLower:find('log')) and
       not triggerLower:find('VexShield') then
        
        -- Repeated suspicious trigger probes indicate attempts to block AC communication.
        VexShieldRecordStrike(src, 'TriggerServerEventHooking', 2, 30000, 'TriggerServerEvent Hooking Detected - Attempting to block anti-cheat communication')
        return
    end
    
    -- Additional checks for other suspicious patterns
    if (triggerLower:find('anticheat') or triggerLower:find('ac_') or 
        triggerLower:find('security')) and
       not triggerLower:find('VexShield') then
        
        VexShieldRecordStrike(src, 'AntiCheatCommunicationInterference', 2, 30000, 'Anti-Cheat Communication Interference Detected')
        return
    end
end)

-- Function to detect when clients are manipulating event registration
RegisterNetEvent('VexShield:eventRegistrationCheck')
AddEventHandler('VexShield:eventRegistrationCheck', function(eventName)
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    local eventLower = string.lower(eventName or '')
    
    -- Check for attempts to register or manipulate AC-related events
    if eventLower:find('reaper') or eventLower:find('detect') or 
       eventLower:find('report') or eventLower:find('VexShield') or 
       eventLower:find('anticheat') or eventLower:find('ac_') then
        
        VexShieldRecordStrike(src, 'EventRegistrationManipulation', 2, 30000, 'Event Registration Manipulation Detected - Attempting to interfere with anti-cheat events')
        return
    end
end)

-- Function to monitor for clients that stop sending heartbeat/ping
RegisterNetEvent('VexShield:clientAliveCheck')
AddEventHandler('VexShield:clientAliveCheck', function()
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    -- This is called regularly by legitimate clients
    -- Suspicious if clients stop calling this (indicating AC bypass)
    -- We can track client activity here if needed
end)

-- Function to detect when clients are hooking AddEventHandler/RegisterNetEvent to bypass AC
RegisterNetEvent('VexShield:eventHookCheck')
AddEventHandler('VexShield:eventHookCheck', function(eventType, eventName)
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    local eventLower = string.lower(eventName or '')
    
    -- Check for attempts to hook AC-related events
    if eventLower:find('reaper') or eventLower:find('detect') or 
       eventLower:find('report') or eventLower:find('VexShield') or 
       eventLower:find('anticheat') or eventLower:find('ac_') or
       eventLower:find('ban') or eventLower:find('kick') or eventLower:find('log') then
        
        VexShieldRecordStrike(src, 'EventHookingInterference', 2, 30000, 'Event Hooking Detected - Attempting to interfere with anti-cheat event handling')
        return
    end
end)

-- Function to detect when clients are trying to enumerate or manipulate resource files
RegisterNetEvent('VexShield:resourceScanCheck')
AddEventHandler('VexShield:resourceScanCheck', function(resourceName, fileName)
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    local resourceLower = string.lower(resourceName or '')
    local fileLower = string.lower(fileName or '')
    
    -- Check for attempts to scan resources for anti-cheat files
    if resourceLower:find('VexShield') or resourceLower:find('anticheat') or resourceLower:find('ac_') or
       fileLower:find('VexShield') or fileLower:find('anticheat') or fileLower:find('ac_') or
       fileLower:find('reaper') or fileLower:find('waveshield') or fileLower:find('anticheat') or
       fileLower:find('shared_fg-obfuscated') or fileLower:find('fg-') then
        
        VexShieldRecordStrike(src, 'ResourceScanning', 2, 30000, 'Resource Scanning Detected - Attempting to enumerate anti-cheat files')
        return
    end
end)

-- Function to detect common cheat event patterns (money, vehicle, weapon, etc.)
RegisterNetEvent('VexShield:commonCheatDetection')
AddEventHandler('VexShield:commonCheatDetection', function(eventName, ...)
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    local eventLower = string.lower(eventName or '')
    local args = {...}
    
    -- Money exploits detection
    if eventLower:find('money') or eventLower:find('pay') or eventLower:find('give') or 
       eventLower:find('bank') or eventLower:find('cash') or eventLower:find('wallet') or
       eventLower:find('transfer') or eventLower:find('deposit') or eventLower:find('withdraw') or
       eventLower:find('dirty') or eventLower:find('wash') then
        
        -- Check for common money exploit patterns
        for _, arg in ipairs(args) do
            if type(arg) == 'number' and arg > 100000 then  -- Suspiciously high amounts
                banPlayer(src, 'Attempted money exploit (abnormal amount)')
                return
            end
        end
    end
    
    -- Vehicle spawn detection
    if eventLower:find('vehicle') or eventLower:find('car') or eventLower:find('spawn') or 
       eventLower:find('delete') or eventLower:find('remove') then
        
        for _, arg in ipairs(args) do
            if type(arg) == 'string' and string.len(arg) > 0 then
                local argLower = string.lower(tostring(arg))
                -- Check for high-end/suspicious vehicle models
                if argLower:find('oppressor') or argLower:find('deluxo') or argLower:find('zentorno') or
                   argLower:find('insurgent') or argLower:find('kuruma') or argLower:find('buzzard') or
                   argLower:find('akula') or argLower:find('annihilator') or argLower:find('savage') then
                    banPlayer(src, 'Attempted unauthorized vehicle spawn')
                    return
                end
            end
        end
    end
    
    -- Weapon spawn detection
    if eventLower:find('weapon') or eventLower:find('give') or eventLower:find('add') or 
       eventLower:find('ammo') or eventLower:find('bullet') or eventLower:find('fire') then
        
        for _, arg in ipairs(args) do
            if type(arg) == 'string' then
                local argLower = string.lower(tostring(arg))
                -- Check for prohibited weapons
                if argLower:find('weapon_') then
                    if argLower:find('minigun') or argLower:find('railgun') or argLower:find('rpg') or
                       argLower:find('grenadelauncher') or argLower:find('compactlauncher') or
                       argLower:find('homing') or argLower:find('firework') then
                        banPlayer(src, 'Attempted to spawn prohibited weapon')
                        return
                    end
                end
            end
        end
    end
    
    -- Admin/staff menu detection
    if eventLower:find('admin') or eventLower:find('staff') or eventLower:find('mod') or 
       eventLower:find('troll') or eventLower:find('bring') or eventLower:find('tp') or
       eventLower:find('teleport') or eventLower:find('slap') or eventLower:find('kill') or
       eventLower:find('invisible') or eventLower:find('god') or eventLower:find('noclip') or
       eventLower:find('revive') or eventLower:find('heal') or eventLower:find('freeze') or
       eventLower:find('unjail') or eventLower:find('set') or eventLower:find('setjob') or
       eventLower:find('setgroup') or eventLower:find('setmoney') or eventLower:find('setcoords') then
        
        -- Check if the player has appropriate permissions
        local isAllowed = false
        -- In a real implementation, you would check the player's permissions here
        -- For now, we'll just log this as suspicious if it's not coming from a legitimate admin
        
        -- Check if player is actually an admin
        if not IsPlayerAdmin(src) then
            banPlayer(src, 'Attempted unauthorized admin access')
            return
        end
    end
    
    -- Exploit prevention for common frameworks
    if eventLower:find('esx') or eventLower:find('qb') or eventLower:find('qbx') then
        -- Check for framework manipulation
        if eventLower:find('give') or eventLower:find('add') or eventLower:find('set') then
             -- Logic to check permissions would go here
        end
    end
end)

-- =============================================================================
--  PORTED DETECTIONS
-- =============================================================================

-- [Anti Sound Exploit]
if GetResourceState("interact-sound") == "started" then
    RegisterNetEvent("InteractSound_SV:PlayWithinDistance", function(maxDistance, soundFile, volume)
        local src = source
        if not src then return end
        
        -- Suspicious sound files and distances
        local suspicious = false
        if maxDistance == 10000 and soundFile == "handcuff" then suspicious = true end
        if maxDistance == 1000 and soundFile == "Cuff" then suspicious = true end
        if maxDistance == 103232 and soundFile == "lock" then suspicious = true end
        if maxDistance == 10 and soundFile == "szajbusek" then suspicious = true end
        if maxDistance == 5 and soundFile == "alarm" then suspicious = true end
        if maxDistance == 13232 and soundFile == "pasysound" then suspicious = true end
        if maxDistance == 5000 and soundFile == "demo" then suspicious = true end
        
        if suspicious then
            CancelEvent()
            TriggerEvent("VexShield:banHandler", src, "Anti Sound Exploit: " .. soundFile .. " (Dist: " .. maxDistance .. ")")
        end
    end)
end

-- [Anti Specific Menu / Event Exploits]
function BanForMenu(src, reason)
    TriggerEvent("VexShield:banHandler", src, "Anti Menu: " .. reason)
end

RegisterNetEvent("esx_license:addLicense", function(name, plate)
    local src = source
    local suspiciousPlates = {
        "YARRAe YEDNNNN", "YAGO SIKER!!!", "SUCK MY DICK!",
        "RIP Your SQL Faggot", "Make sure to wipe all tables ;)", "YAGO Was Here"
    }
    for _, suspiciousPlate in pairs(suspiciousPlates) do
        if plate == suspiciousPlate then
            BanForMenu(src, "Malicious License Plate")
        end
    end
end)

RegisterNetEvent("esx:triggerServerCallback", function(name)
    local src = source
    local blacklistedPatterns = {
        "^r^You just got fucked by Falcon", "d0pamine.xyz", "RocMenu", "LynxMenu"
    }
    for _, pattern in pairs(blacklistedPatterns) do
        if string.find(name, pattern) then
            BanForMenu(src, "Malicious Callback Trigger")
        end
    end
end)

RegisterNetEvent("esx_addons_gcphone:startCall", function(name, message)
    local src = source
    if message == "Absolute" or message == "Lumia" then
        BanForMenu(src, "Phone Exploit (Absolute/Lumia)")
    end
end)

RegisterNetEvent("kashactersS:DeleteCharacter", function(query)
    local src = source
    if string.find(query, "permission_level") or string.find(query, "TRUNCATE TABLE") or
       string.find(query or "", "DROP TABLE") or string.find(query or "", "UPDATE users") then
        BanForMenu(src, "SQL Injection Attempt")
    end
end)

RegisterNetEvent("DiscordBot:playerDied", function(name, reason)
    local src = source
    if name == "Absolute Menu" or reason == "1337" then
        BanForMenu(src, "Discord Bot Exploit")
    end
end)

-- [Entity Spam] handled in unified entityCreating handler (see blacklisted prop section)


-- Function to handle client integrity checks
RegisterNetEvent('VexShield:clientIntegrityCheck')
AddEventHandler('VexShield:clientIntegrityCheck', function(checkType, data)
    local src = source
    
    if not src or src == 0 then
        return
    end
    
    -- Log the integrity check for monitoring purposes
    -- This helps track if clients are regularly performing self-checks
    -- If a client stops sending these checks, it might indicate AC bypass
end)


RegisterNetEvent('VexShield:banHandler:Admin', function(playerID, reason, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:banHandler:Admin', 6, 10000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) and source ~= 0 then 
        banPlayer(source, 'Tried to impersonate admin (banHandler)')
        return 
    end

    banPlayertrigger(playerID, reason, 'ADMIN', true)
    local adminName = GetPlayerName(source)
    local targetName = GetPlayerName(playerID)
    AppendLog('BAN_PLAYER', targetName, playerID, reason, adminName)

    if VexShieldAwardPoints then VexShieldAwardPoints(source, 'ban', 3) end
    VexShieldBroadcastBansToAdmins()
end)

RegisterNetEvent('VexShield:unbanHandler:Admin', function(banID, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:unbanHandler:Admin', 6, 10000, token, seq) then
        return
    end
    if source ~= 0 and not IsPlayerAdmin(source) then
        banPlayer(source, 'Tried to impersonate admin (unbanHandler)')
        return 
    end

    tryUnban(source, banID)
    if VexShieldAwardPoints then VexShieldAwardPoints(source, 'unban', 2) end
end)

RegisterNetEvent('VexShield:unbanAll:Admin', function(token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:unbanAll:Admin', 1, 60000, token, seq) then
        return
    end
    if source ~= 0 and not IsPlayerAdmin(source) then
        banPlayer(source, 'Tried to impersonate admin (unbanAll)')
        return 
    end
    BanJsonMutate(function(bans)
        for i = #bans, 1, -1 do
            table.remove(bans, i)
        end
    end)
    VexShieldBroadcastBansToAdmins()
    AppendLog('UNBAN_PLAYER', 'All', -1, 'Unban All', GetPlayerName(source))
end)


function isExempt(playerId)
    if not playerId or tonumber(playerId) == nil then return false end
    playerId = tonumber(playerId)

    -- 1. Check Dashboard / Website / html/admin.json permissions (Vexwhitelist / Airwhitelist / Full Bypass)
    if (IsPlayerInAdminJsonList and (IsPlayerInAdminJsonList(playerId, "Vexwhitelist") or IsPlayerInAdminJsonList(playerId, "Airwhitelist"))) 
        or (IsPlayerFullBypass and IsPlayerFullBypass(playerId)) 
        or (IsPlayerVexMenuAllowed and IsPlayerVexMenuAllowed(playerId)) then
        return true
    end

    -- 2. Check Framework Groups (owner, admin, staff in Config.EXEMPT_GROUPS)
    local group = GetFrameworkGroup(playerId)
    if group and Config.EXEMPT_GROUPS[group] then
        return true
    end

    -- 3. Check ACE Permissions (VexShield.admin / txadmin.noclip)
    if IsPlayerAceAdmin(playerId) or IsPlayerAceAllowed(playerId, "txadmin.noclip") or IsPlayerAceAllowed(playerId, "command.txadmin") then
        return true
    end

    return false
end

RegisterNetEvent('VexShield:isExempt', function()
    local src = source
    local exempt = isExempt(src)
    TriggerClientEvent('VexShield:returnExemptStatus', src, exempt)
end)

function isExemptserver(scr)
    if not scr or tonumber(scr) == nil then return false end
    scr = tonumber(scr)
    -- Check if invoking resource is full whitelisted (like admin)
    local invokingResource = GetInvokingResource()
    if invokingResource and isResourceFullWhitelisted(invokingResource) then
        return true
    end

    return isExempt(scr)
end

function IsPlayerAdmin(scr)
    if scr and type(scr) == "number" and IsPlayerVexMenuAllowed(scr) then
        return true
    end
    if IsPlayerAceAdmin(scr) then
        return true
    end
    local group = GetFrameworkGroup(scr)
    if group and Config.ADMIN_GROUPS[group] then
        return true
    end
    return false
end

---------------------------------------------------------------------------------
-- VexShield Ban System
---------------------------------------------------------------------------------
-- Internal reason code mapping
local reasonToConfigKey = {
    ["Noclip Detected"] = "Anti Noclip",
    ["Attempted to bypass collision"] = "Anti Noclip",
    ["Noclip Detected #2"] = "Anti Noclip2",
    ["Noclip Detected #3"] = "Anti Noclip3",
    ["Bebetter Noclip Detected"] = "ANTI NOCLIP V3",
    ["Parachute Noclip Detected"] = "Anti Parachute Noclip",
    ["Armour Detection"] = "Armour Detection",
    ["Invisible Detection"] = "Anti invisible",
    ["Invisible Detection #2"] = "Anti invisible2",
    ["Teleport Detected"] = "Anti Teleport",
    ["Teleport to the waypoint detected"] = "Anti TP To Waypoint",
    ["Speed Hack/Noclip Detected"] = "Anti Speedhack",
    ["Attempted to bypass movement restrictions"] = "Anti Speedhack",
    ["SuperJump/Noclip Detected"] = "Anti SuperJump",
    ["Night Vision Detected"] = "Anti Night/ThermalVision",
    ["Infinite Stamina Detected"] = "Anti Infinite Stamina",
    ["Attempted to bypass stamina limit"] = "Anti Infinite Stamina",
    ["Model changed"] = "Anti Model Changer",
    ["Rape Player detected"] = "Anti Rape Player",
    ["Lua Freeze Detected"] = "Anti Lua Freeze",
    ["Suspicious fire trigger detected"] = "Anti Player On Fire",
    ["NPC Hijack Detected"] = "Anti Npc Hijack",
    ["Anti Spawn Weapon"] = "Anti Spawn Weapon",
    ["Attempted to spawn weapon"] = "Anti Spawn Weapon",
    ["Anti Spawn/Spoof Weapon #2"] = "Anti Spawn Weapon2",
    ["(Anti Spawn Weapon) V2"] = "Anti Spawn Weapon2",
    ["(Anti Spawn Weapon) #3"] = "Anti Spawn Weapon3",
    ["Spoofed Damage/Weapon Detected"] = "Anti Spoofed Damage/Weapon",
    ["Attempted weapon/damage spoofing"] = "Anti Spoofed Damage/Weapon",
    ["Player tried to use disable recoil"] = "Anti NoRecoil",
    ["NoReload Detected"] = "Anti NoReload",
    ["Attempted to bypass reload"] = "Anti NoReload",
    ["Explosive Bullets detected"] = "Anti Explosion Bullet",
    ["Infinite Ammo Detection"] = "Anti Infinite Ammo",
    ["Suspicious Money Increase Detected"] = "Anti Give Money",
    ["Aimlock Detected"] = "Anti Aimlock",
    ["Carry Vehicle Detected"] = "Anti Carry Vehicle",
    ["Throw Vehicle Detected"] = "Anti Throw Vehicle",
    ["Throw Vehicle: Slingshot Attempt"] = "Anti Throw Vehicle",
    ["Throw Vehicle: Unnatural Impulse Detected"] = "Anti Throw Vehicle",
    ["Throw Vehicle: Vertical Launch Detected"] = "Anti Throw Vehicle",
    ["Vehicle Boost Detected"] = "Anti Boost vehicle",
    ["Vehicle Spam Detected"] = "Anti Vehicle Spam",
    ["Bring Vehicle Detected"] = "Anti Bring Vehicle",
    ["Bring All Vehicles Detected"] = "Anti Bring All Vehicles",
    ["Force Fall Player Detected"] = "Anti Force Fall",
    ["Clone Player Detected"] = "Anti Clone Player",
    ["Attempted to duplicate player entity"] = "Anti Clone Player",
    ["Spawn Random Props Detected"] = "Anti Object Spawn",
    ["Punch Player Detected"] = "Anti Kill Punch",
    ["Repair Vehicle Detected"] = "Anti Repair Vehicle",
    ["Delete Vehicle Detected"] = "Anti Delete Vehicle",
    ["Bug Vehicle Detected"] = "Anti Bug Vehicle",
    ["Vehicle Spawn Detected"] = "Anti Spawn Vehicle",
    ["Vehicle Spawn Detected #2"] = "Anti Spawn Vehicle",
    ["Vehicle Weapon Detected"] = "Anti Vehicle Weapon",
    ["Plate Changer Detected"] = "Anti Plate Changer",
    ["Spawned blacklisted prop"] = "Anti Object Spawn",
    ["Attempted to spawn blacklisted object"] = "Anti Object Spawn",
    ["Fly Vehicle Detected"] = "Anti Launch/Fly Vehicle",
    ["Aggressive Peds Detected"] = "Anti Aggresive Peds",
    ["Explosion detected"] = "Anti Ai Explosion",
    ["Explosion Detected"] = "Anti Explosion",
    ["Silent Explosion Detected"] = "Anti Silent Explosion",
    ["Phone Explosion Detected"] = "Anti Phone Explosion",
    ["Invisible Explosion Detected"] = "Anti Invisible Explosion",
    ["Freecam Detected"] = "Anti Freecam",
    ["Freecam Detected #2"] = "Anti Freecam2",
    ["Freecam Detected #3"] = "Anti Freecam3",
    ["Freecam Detected #4"] = "Anti Freecam #4",
    ["Freecam Detected #5"] = "Anti Freecam #5",
    ["Freecam Detected #6"] = "Anti Freecam #6",
    ["Look Around Detected"] = "Anti Look Around",
    ["Spectate detected"] = "Anti Spectate",
    ["Attempted to spectate players"] = "Anti Spectate",
    ["Internal Executor Detected (CheatAI)"] = "Cheat Ai Detection",
    ["Block Input Detected"] = "Anti Block Input",
    ["LUA Input Detected"] = "Anti LUA Input",
    ["Lua script Injection detected"] = "Anti Lua Menu",
    ["Anti Kill"] = "Anti Kill",
    ["Attempted to kill player"] = "Anti Kill",
    ["Anti Kill #2"] = "Anti Kill2",
    ["Attempted to kill player (V2)"] = "Anti Kill2",
    ["Fake Taze Detected"] = "Anti Taze",
    ["Attempted to fake taze state"] = "Anti Taze",
    ["Inventory Exploit gedetecteerd"] = "Anti Inventory Exploit",
    ["Attempted inventory exploit"] = "Anti Inventory Exploit",
    ["Blacklist particle"] = "Blacklisted Particles",
    ["Entity spawn bypass (Type 1)"] = "Anti Spawn Vehicle/Entity",
    ["Entity spawn bypass (Type 2)"] = "Anti Spawn Vehicle/Entity",
    ["Entity spawn bypass (Type 3)"] = "Anti Spawn Vehicle/Entity",
    ["Entity spawn bypass (Type 4)"] = "Anti Spawn Vehicle/Entity",
    ["Entity spawn bypass (Type 5)"] = "Anti Spawn Vehicle/Entity",
    ["[Anti-Punch/Kill] Fake Punch detected"] = "Anti Kill Punch",
    ["[Anti-Punch/Kill] Suspicious melee damage pattern (Code 2)"] = "Anti Kill Punch",
    ["[Anti-Punch/Kill] Silent kill attempt (Code 3)"] = "Anti Kill Punch",
    ["[Anti-Punch/Kill] Silent kill attempt (Code 4)"] = "Anti Kill Punch",
    ["[Anti-Punch/Kill] Silent kill attempt (Code 5)"] = "Anti Kill Punch",
    ["[Anti-Punch/Kill] Suspicious high-damage hit (Code 6"] = "Anti Kill Punch",
    ["Anti Shoot Without Weapon"] = "Anti Shoot Without Weapon",
    ["Attempted to fire without weapon"] = "Anti Shoot Without Weapon",
    ["Give Armour Detected"] = "Armour Detection",
    ["Warp to vehicle detected"] = "Anti Teleport2",
    ["Teleport detected #2"] = "Anti Teleport2",
    ["antisolosession"] = "Anti Solo Session",
    ["Car Speed Hack Detected"] = "Anti Car Speed Hack",
    ["Attempted vehicle speed manipulation"] = "Anti Car Speed Hack",

    ["Noclip Detected #4"] = "Anti Noclip4",
    ["Noclip Detected #5"] = "Anti Noclip5",
    ["Susano Noclip Detected"] = "Anti Noclip5",
    ["Attempted to bypass collision (Susano)"] = "Anti Noclip5",
    ["Weapon Damage Change"] = "Anti Weapon Damage Changer",
    ["Explosion Bullet detected #2"] = "Anti Explosion Bullet2",
    ["Player Blip Detected"] = "Anti Player Blips",
    ["Fake Fast Run Detected"] = "Anti Fast Run",
    ["Attempted to fake sprint speed"] = "Anti Fast Run",
    ["Super Jump Detected #2"] = "Anti SuperJump2",
    ["Attempted to bypass jump limits"] = "Anti SuperJump2",
    ["Vehicle Spawn Detected #3"] = "Anti Spawn Vehicle3",
    ["Player have tried to use nui devtools"] = "Anti DevTools",
    ["NUI Blocker Detected"] = "Anti NUI Blocker",
    ["Resource Injection Detected"] = "Anti Resource Injection",
    ["Clear Tasks Detected"] = "Anti Clear Tasks",
    ["Global Voice Detected"] = "Anti Global Voice",
    ["Voice Exploit Detected"] = "Anti Voice Exploits",
    ["OCR Attempt Detected"] = "Anti OCR",
    ["Player tried to tiny his ped"] = "Anti Tiny Ped",
    ["Ai Modification Detected: Hitbox Modified"] = "Anti Ai HitBox Changer",
    ["Ai Modification Detected: Hitbox Modified (XL)"] = "Anti Ai HitBox Changer",
    ["Ai Modification Detected: Hitbox Modified (XXL)"] = "Anti Ai HitBox Changer",
    ["Ai Modification Detected: Hitbox Modified (S, L, M)"] = "Anti Ai HitBox Changer",
    ["Player tried to disable Headshot"] = "Anti No Headshot",
    ["No Headshot Detection Bypass Attempt"] = "Anti No Headshot",
    ["Anti No Headshot: Headshots Disabled"] = "Anti No Headshot",
    ["Player tried to modify the hitbox"] = "Anti Bigger Hitbox",
    ["Player tried to teleport an Vehicle to him (Probably HX)"] = "Anti TPVehicleToPlayer",
    ["Player tried to use an Anti AFK injection"] = "Anti Bypass Afk Injection",
    ["Teleport to waypoint Detected"] = "Anti Teleport To Waypoint",
    ["Magic Bullet Detected"] = "Anti Magic Bullet",
    ["Stop Resource Detected"] = "Anti Stop Resource",
    ["Attempted to stop resource"] = "Anti Stop Resource",
    ["Stopping VexShield"] = "Anti Stop Resource",
    ["Attempted to stop VexShield"] = "Anti Stop Resource",
    ["Identifier Spoofing Detected"] = "Anti Spoof",
    ["Attempted identifier spoofing"] = "Anti Spoof",
    ["VPN/Proxy Detected"] = "Anti Vpn",
    ["Unknown resource started"] = "Anti Unknown Resource"
}

reasonToConfigKey["Progress Props Crash Attempt"] = "Anti Object Spawn"
reasonToConfigKey["Object Spam Crash Attempt"] = "Anti Object Spawn"
reasonToConfigKey["Anti Object Spawn"] = "Anti Object Spawn"
reasonToConfigKey["Attempted unauthorized object spawn"] = "Anti Object Spawn"
reasonToConfigKey["Unencrypted Net Event Trigger (Executor Detected)"] = "Anti Trigger Event"
reasonToConfigKey["Anti-Trigger Event"] = "Anti Trigger Event"
reasonToConfigKey["Attempted unauthorized event trigger"] = "Anti Trigger Event"
reasonToConfigKey["Spawned blacklisted vehicle"] = "Anti Blacklisted Vehicle"
reasonToConfigKey["Entered blacklisted vehicle"] = "Anti Blacklisted Vehicle"
reasonToConfigKey["Spawned blacklisted ped"] = "Anti Blacklisted Ped"
reasonToConfigKey["Changed to blacklisted ped"] = "Anti Blacklisted Ped"
reasonToConfigKey["Held blacklisted weapon"] = "Anti Blacklisted Weapon"
reasonToConfigKey["Fast Run Detected"] = "Anti Fast Run"
reasonToConfigKey["Rapid Fire Detected"] = "Anti Rapid Fire"
reasonToConfigKey["Infinite Combat Roll Detected"] = "Anti Infinite Combat Roll"

reasonToConfigKey["Object Spawn Limit Exceeded"] = "Anti Object Spawn"
reasonToConfigKey["Cage Player Attempt"] = "Anti Object Spawn"
reasonToConfigKey["Vehicle Spawn Limit Exceeded"] = "Anti Spawn Vehicle"
reasonToConfigKey["Unauthorized Vehicle Spawn Resource"] = "Anti Spawn Vehicle"
reasonToConfigKey["Stealth Vehicle Spawn (No Owner)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Vehicle Spawn Too Far From Owner"] = "Anti Spawn Vehicle"
reasonToConfigKey["Vehicle Spawn Rate Limit Exceeded"] = "Anti Spawn Vehicle"
reasonToConfigKey["Vehicle Spawn Session Limit Exceeded"] = "Anti Spawn Vehicle"
reasonToConfigKey["Global Vehicle Limit Exceeded"] = "Anti Spawn Vehicle"
reasonToConfigKey["Same Vehicle Model Limit Exceeded"] = "Anti Spawn Vehicle"
reasonToConfigKey["Anti Spawn Vehicle (Ramming Attack)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Anti Spawn Vehicle (On-Top Spawn)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Anti Spawn Vehicle (No Script)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Anti Spawn Vehicle (Distance/Speed)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Attempted to spawn vehicle outside range"] = "Anti Spawn Vehicle"
reasonToConfigKey["Anti Spawn Vehicle (Invalid Heading)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Anti Spawn Vehicle (Spawned & Ignored Vehicle)"] = "Anti Spawn Vehicle"
reasonToConfigKey["Explode Player Car Detected"] = "Anti Ai Explosion"
reasonToConfigKey["Cipher Menu Detected"] = "Anti Cipher"
reasonToConfigKey["FreeCam Detected #4"] = "Anti Advanced Freecam"
reasonToConfigKey["Anti Ped Spawn Detected (Unauthorized Ped Creation)"] = "Anti Spawn Ped"
reasonToConfigKey["Anti Ped Spawn Detected (Server Cleanup)"] = "Anti Spawn Ped"
reasonToConfigKey["BEBETTER Noclip Detected"] = "ANTI NOCLIP V3"
reasonToConfigKey["Susano Noclip Detected #5"] = "Anti Noclip5"
reasonToConfigKey["Noclip test Detected"] = "Anti Noclip5"
reasonToConfigKey["Anti Remove Weapons"] = "Anti Spawn Weapon"
reasonToConfigKey["Blacklisted Projectile Detected"] = "Anti Spawn Weapon"
reasonToConfigKey["Exceeded Projectile Spawn Rate"] = "Anti Spawn Weapon"
reasonToConfigKey["Particle Scale Limit Exceeded"] = "Blacklisted Particles"
reasonToConfigKey["Particle Attached To Other Entity"] = "Blacklisted Particles"
reasonToConfigKey["Anti Kill: silent zero-damage exploit"] = "Anti Kill"
reasonToConfigKey["Anti Kill: tranquilizer exploit"] = "Anti Kill"
reasonToConfigKey["Anti Kill: malformed weapon damage event"] = "Anti Kill"
reasonToConfigKey["[Anti-Punch/Kill] Suspicious melee damage pattern (TZ fists)"] = "Anti Kill Punch"
reasonToConfigKey["[Anti-Punch/Kill] Suspicious melee damage pattern (Keyser fists)"] = "Anti Kill Punch"
reasonToConfigKey["[Anti-Punch/Kill] Suspicious high-damage hit (Eulen fists)"] = "Anti Kill Punch"
reasonToConfigKey["Super Punch Detected"] = "Anti Super Punch"
reasonToConfigKey["Illegal Native Execution"] = "Anti Native Hook"
reasonToConfigKey["Teleportation Detected (Native Hook)"] = "Anti Teleport"
reasonToConfigKey["Ped Model Change Detected (Native Hook)"] = "Anti Model Changer"
reasonToConfigKey["Health Refill Detected (Native Hook)"] = "Anti Heal Spam"
reasonToConfigKey["Player Revived Detected (Native Hook)"] = "Anti Native Hook"
reasonToConfigKey["Proofs Enabled (Native Hook)"] = "Anti Godmode"
reasonToConfigKey["GodMode Detected (canBeDamaged: false)"] = "Anti Godmode"
reasonToConfigKey["GodMode Detected (isInvincible: true)"] = "Anti Godmode"
reasonToConfigKey["Invisibility Detected (Native Hook)"] = "Anti invisible2"
reasonToConfigKey["Infinite Stamina Detected (Native Hook)"] = "Anti Infinite Stamina"
reasonToConfigKey["Vehicle Speed Hack (Native Hook)"] = "Anti Car Speed Hack"
reasonToConfigKey["Vehicle Torque Hack (Native Hook)"] = "Anti Boost vehicle"
reasonToConfigKey["Vehicle Gravity Hack (Native Hook)"] = "Anti Launch/Fly Vehicle"
reasonToConfigKey["Weapon Damage Hack (Native Hook)"] = "Anti Weapon Damage Changer"
reasonToConfigKey["Ammo Hack Detected (Native Hook)"] = "Anti Infinite Ammo"
reasonToConfigKey["Weapon Spawn Detected (Native Hook)"] = "Anti Spawn Weapon"
reasonToConfigKey["Vehicle Plate Hack (Native Hook)"] = "Anti Plate Changer"
reasonToConfigKey["Attempted to manipulate aim direction"] = "Anti Silent Aim"
reasonToConfigKey["Attempted to bypass hit validation (zero impact angle)"] = "Anti Silent Aim"
reasonToConfigKey["Clipboard Scanner: Blacklisted Content Detected"] = "Clipboard Scanner"
reasonToConfigKey["Clipboard Scanner: Blacklisted Cheat Content Detected"] = "Clipboard Scanner"
reasonToConfigKey["Clipboard Scanner: Trigger Injection Detected"] = "Clipboard Scanner"

--- Resolve ban reason -> Config.Protections key (exact + noclip variants).
function VexShieldResolveProtectionKey(reason)
    if reason == nil then return nil end
    local key = reasonToConfigKey[reason]
    if key then return key end
    local r = tostring(reason)
    if r:find("Clipboard Scanner", 1, true) or r:find("Blacklisted Clipboard", 1, true) or r:find("Trigger Injection", 1, true) then return "Clipboard Scanner" end
    if r:find("^Cheat Spawn Functions", 1, false) or r:find("^Attempted item spawn", 1, false) then return "Anti Cheat Spawn Functions" end
    if r:find("^Cheat Teleport Functions", 1, false) then return "Anti Cheat Teleport Functions" end
    if r:find("^Cheat Weapon Functions", 1, false) then return "Anti Cheat Weapon Functions" end
    if r:find("^Cheat Vehicle Functions", 1, false) then return "Anti Cheat Vehicle Functions" end
    if r:find("^Cheat Ped Functions", 1, false) then return "Anti Cheat Ped Functions" end
    if r:find("^Cheat Object Functions", 1, false) then return "Anti Cheat Object Functions" end
    if r:find("^Cheat Explosion Functions", 1, false) then return "Anti Cheat Explosion Functions" end
    if r:find("^Cheat Freecam", 1, false) then return "Anti Cheat Freecam" end
    if r:find("^Cheat Spectate", 1, false) then return "Anti Cheat Spectate" end
    if r:find("^Cheat Force Functions", 1, false) then return "Anti Cheat Force Functions" end
    if r:find("^Cheat Clone Functions", 1, false) then return "Anti Cheat Clone Functions" end
    if r:find("^Cheat Cage Functions", 1, false) then return "Anti Cheat Cage Functions" end
    if r:find("^Cheat Inventory", 1, false) or r:find("^Attempted inventory", 1, false) then return "Anti Cheat Inventory Exploit" end
    if r:find("Illegal Native Execution", 1, true) or r:find("Native Hook", 1, true) then return "Anti Native Hook" end
    if r:find("Parachute Noclip", 1, true) or r:find("parachute noclip", 1, true) then return "Anti Parachute Noclip" end
    if r:find("Object Spawn", 1, true) or r:find("Object Spam", 1, true) or r:find("Entity Spam", 1, true) or r:find("object spawn", 1, true) or r:find("object spam", 1, true) then return "Anti Object Spawn" end
    if r:find("Susano Noclip", 1, true) or r:find("Noclip Detected #5", 1, true) or r:find("Noclip test", 1, true) then return "Anti Noclip5" end
    if r:find("Noclip Detected #4", 1, true) then return "Anti Noclip4" end
    if r:find("Noclip Detected #3", 1, true) then return "Anti Noclip3" end
    if r:find("Noclip Detected #2", 1, true) then return "Anti Noclip2" end
    if r:find("BEBETTER", 1, true) or r:find("Bebetter Noclip", 1, true) then return "ANTI NOCLIP V3" end
    if r:find("TZ Noclip", 1, true) or r:find("Noclip detected", 1, true) or r == "Noclip Detected" or r:find("bypass collision", 1, true) or r:find("bypass collision", 1, true) then return "Anti Noclip" end
    if r:find("Camera Rotation Hack Detected", 1, true) then return "Anti Camera Rotation" end
    return nil
end

--- Resolve the detection level (L1/L2/L3) from a ban reason string.
--- Returns "L1", "L2", or "L3".
function VexShieldResolveLevelFromReason(reason)
    if not reason or type(reason) ~= "string" then return "L1" end
    local r = reason

    -- 1. Explicit brackets like [L1], [L2], [L3], (L1), (L2), (L3), [LV1], (Lv2)
    local bracketMatch = r:match("[%[%(_]%s*[Ll][Vv]?(%d)%s*[%]%)_]")
    if bracketMatch then
        local d = tonumber(bracketMatch)
        if d and d >= 1 and d <= 3 then return "L" .. d end
    end

    -- 2. Explicit word like "Level 1", "Level 2", "Level 3", "Lv 2", "Lv1"
    local levelText = r:match("[Ll]evel%s*:?%s*(%d)") or r:match("[Ll][Vv]%s*(%d)")
    if levelText then
        local d = tonumber(levelText)
        if d and d >= 1 and d <= 3 then return "L" .. d end
    end

    -- 3. Version pattern like (V2), (V3), V2, V3
    local vMatch = r:match("%([Vv](%d)%)") or r:match("%s+[Vv](%d)")
    if vMatch then
        local d = tonumber(vMatch)
        if d and d >= 1 and d <= 3 then return "L" .. d end
    end

    -- 4. Hash number suffix like "#1", "#2", "#3", "#4", "#5", "#6"
    local hashMatch = r:match("#%s*(%d)")
    if hashMatch then
        local d = tonumber(hashMatch)
        if d == 1 or d == 4 then return "L1" end
        if d == 2 or d == 5 then return "L2" end
        if d == 3 or d == 6 then return "L3" end
    end

    -- 5. Trailing digits in reason or protection name like "Teleport2", "Noclip2", "Spawn Weapon3"
    local trailDigit = r:match("(%d+)%s*$") or r:match("(%d+)%s*%(")
    if trailDigit then
        local d = tonumber(trailDigit)
        if d and d >= 1 and d <= 3 then return "L" .. d end
    end

    -- 6. Default to Level 1 for any base detection
    return "L1"
end

VexShieldRuntime.AdminBypassProtectionMap = {
    ["Anti Rapid Fire"] = "Rapid Fire",
    ["Anti Weapon Damage Changer"] = "Damage Boost",
    ["Anti Spawn Vehicle"] = "Custom Vehicle",
    ["Anti Spawn Vehicle2"] = "Custom Vehicle",
    ["Anti Spawn Vehicle3"] = "Custom Vehicle",
    ["Anti Spawn Vehicle/Entity"] = "Custom Vehicle",
    ["Anti Blacklisted Vehicle"] = "Custom Vehicle",
    ["Anti Spectate"] = "Spectate",
    ["Anti Spawn Weapon"] = "Spawn Weapon",
    ["Anti Spawn Weapon2"] = "Spawn Weapon",
    ["Anti Spawn Weapon3"] = "Spawn Weapon",
    ["Anti Blacklisted Weapon"] = "Spawn Weapon",
    ["Anti Model Changer"] = "Change Clothing/Ped",
    ["Anti Blacklisted Ped"] = "Change Clothing/Ped",
    ["Anti NoRecoil"] = "No-Recoil",
    ["Anti Infinite Ammo"] = "Ammo Hack",
    ["Anti NoReload"] = "Ammo Hack",
    ["Anti Ai HitBox Changer"] = "HitBox",
    ["Anti Bigger Hitbox"] = "HitBox",
    ["Anti Teleport"] = "Teleport",
    ["Anti Teleport2"] = "Teleport",
    ["Anti TP To Waypoint"] = "Teleport",
    ["Anti Teleport To Waypoint"] = "Teleport",
    ["Anti TPVehicleToPlayer"] = "Teleport",
    ["Anti Heal Spam"] = "Heal",
    ["Armour Detection"] = "Heal",
    ["Anti Noclip"] = "NoClip",
    ["Anti Noclip2"] = "NoClip",
    ["Anti Noclip3"] = "NoClip",
    ["Anti Noclip4"] = "NoClip",
    ["Anti Noclip5"] = "NoClip",
    ["ANTI NOCLIP V3"] = "NoClip",
    ["Anti Parachute Noclip"] = "NoClip",
    ["Anti Freecam"] = "FreeCam",
    ["Anti Freecam2"] = "FreeCam",
    ["Anti Freecam3"] = "FreeCam",
    ["Anti Advanced Freecam"] = "FreeCam",
    ["Anti Global Voice"] = "Voice Hack",
    ["Anti Voice Exploits"] = "Voice Hack",
    ["Anti Speedhack"] = "Fast Move",
    ["Anti Fast Run"] = "Fast Move",
    ["Anti Car Speed Hack"] = "Fast Move",
    ["Anti DevTools"] = "Nui-DevTools",
    ["Anti NUI Blocker"] = "Nui-DevTools",
    ["Anti Godmode"] = "God-Mode",
    ["Anti invisible"] = "Invisible",
    ["Anti invisible2"] = "Invisible",
    ["Anti Infinite Stamina"] = "Stamina",
    ["Anti Aim Bot"] = "Aim-Bot",
    ["Anti Silent Aim"] = "Aim-Bot",
    ["Anti Aimlock"] = "Aim-Bot",
    ["Anti Magic Bullet"] = "Aim-Bot",
    ["Anti Night/ThermalVision"] = "Night/Thermal Vision",
    ["Anti Ragdoll Abuse"] = "No-Ragdoll",
    ["Anti Clear Tasks"] = "No-Ragdoll",
    ["Anti Tiny Ped"] = "Tiny-Ped",
    ["Anti SuperJump"] = "Ability",
    ["Anti SuperJump2"] = "Ability",
    ["Anti Infinite Combat Roll"] = "Ability",
}

function VexShieldResolveAdminBypassName(reason)
    local key = VexShieldResolveProtectionKey(reason)
    if key then return key end
    local r = tostring(reason or "")
    if r:find("^Anti Silent Aim") then return "Anti Silent Aim" end
    if r:find("^Anti Aim Bot") then return "Anti Aim Bot" end
    if r:find("Object Spawn", 1, true) or r:find("Object Spam", 1, true) or r:find("Entity Spam", 1, true) then return "Anti Object Spawn" end
    if r:find("Illegal Explosion spam") or r:find("Explosion", 1, true) then return "Anti Explosion" end
    if r:find("Native Hook", 1, true) then return "Anti Native Hook" end
    return nil
end

local function VexShieldParseLevelServer(level)
    if not level then return nil end
    if type(level) == "number" then return "L" .. math.floor(level) end
    local s = tostring(level):upper()
    if s == "1" or s == "L1" or s == "LV1" then return "L1" end
    if s == "2" or s == "L2" or s == "LV2" then return "L2" end
    if s == "3" or s == "L3" or s == "LV3" then return "L3" end
    return nil
end

function VexShieldIsProtectionEnabled(protectionKey, level)
    if not protectionKey then return true end
    if not Config or not Config.Protections then return false end

    local entry = Config.Protections[protectionKey]
    local reqLevel = VexShieldParseLevelServer(level)

    -- If key has a trailing digit (e.g., 'Anti Teleport2', 'Anti Noclip3')
    if not reqLevel and type(protectionKey) == "string" then
        local baseName, digit = protectionKey:match("^(.-)%s*(%d+)$")
        if baseName and digit then
            local parsedDigit = tonumber(digit)
            if parsedDigit and parsedDigit >= 1 and parsedDigit <= 3 then
                reqLevel = "L" .. parsedDigit
                if Config.Protections[baseName] ~= nil then
                    entry = Config.Protections[baseName]
                end
            end
        end
    end

    if entry == nil then return false end

    if type(entry) == "boolean" then
        return entry
    end

    if type(entry) == "table" then
        if entry.Enabled == false then return false end
        if reqLevel then
            local lUpper = reqLevel:upper()
            local lDigit = lUpper:sub(2)
            return entry[lUpper] == true 
                or entry["Lv" .. lDigit] == true 
                or entry["LV" .. lDigit] == true
                or entry["level" .. lDigit] == true
        else
            -- If no level was specified, check if L1 is enabled
            if entry.L1 ~= nil or entry.Lv1 ~= nil or entry.LV1 ~= nil then
                return entry.L1 == true or entry.Lv1 == true or entry.LV1 == true
            end
            return entry.Enabled ~= false
        end
    end

    return false
end
 


-- Haalt de actie op: 'ban', 'kick', of 'logs'
function getEnforcementAction(reason)
    local defaultAction = "ban"
    local r = tostring(reason or "")
    local configKey = VexShieldResolveProtectionKey(reason)
    if not configKey then
        if r:find("^Anti Silent Aim") then
            configKey = "Anti Silent Aim"
        elseif r:find("^Anti Aim Bot") then
            configKey = "Anti Aim Bot"
        elseif r:find("Object Spawn", 1, true) or r:find("Object Spam", 1, true) or r:find("Entity Spam", 1, true) then
            configKey = "Anti Object Spawn"
        elseif r:find("Illegal Explosion spam") then
            configKey = "Anti Explosion"
        end
    end
    local out = defaultAction
    if configKey and Config.EnforcementActions and Config.EnforcementActions[configKey] then
        out = Config.EnforcementActions[configKey]
    elseif Config.EnforcementActions and Config.EnforcementActions[reason] then
        out = Config.EnforcementActions[reason]
    end
    local a = string.lower(tostring(out or defaultAction):match("^%s*(.-)%s*$") or defaultAction)
    if a == "log" then a = "logs" end
    return a
end

function shouldBan(playerId, src, reason)
    -- Full bypass ("*") overrides EVERY detection (including the skip-time-check reasons below
    -- and any detection whose reason does not resolve to a named protection). This guarantees
    -- staff granted "Full Bypass" on the dashboard are never auto-banned.
    if IsPlayerFullBypass and (IsPlayerFullBypass(playerId) or IsPlayerFullBypass(src)) then
        return false
    end

    local whitelistskipTimeCheckReasons = {
        ["Susano Menu Detected"] = true,
        ["Anti Ai Explosion"] = true
    }

    if whitelistskipTimeCheckReasons[reason] then
        return true
    end

    -- Check if invoking resource is full whitelisted (like admin)
    local invokingResource = GetInvokingResource()
    if invokingResource and isResourceFullWhitelisted(invokingResource) then
        return false -- Full whitelisted resource, bypass all checks like admin
    end

    local adminBypass = VexShieldResolveAdminBypassName(reason)
    if adminBypass then
        if IsPlayerAdminBypassAllowed(playerId, adminBypass) then return false end
        if IsPlayerAdminBypassAllowed(src, adminBypass) then return false end
        local legacyBypass = VexShieldRuntime.AdminBypassProtectionMap and VexShieldRuntime.AdminBypassProtectionMap[adminBypass]
        if legacyBypass then
            if IsPlayerAdminBypassAllowed(playerId, legacyBypass) then return false end
            if IsPlayerAdminBypassAllowed(src, legacyBypass) then return false end
        end
    end

    if isExempt(playerId) then return false end
    if isExemptserver(src) then return false end
    return true
end

-- Keep new helpers out of the main-chunk local limit (200): store on a single global table.
VexShieldRuntime = VexShieldRuntime or {}

VexShieldRuntime.WeaponSpawnBypassUntil = VexShieldRuntime.WeaponSpawnBypassUntil or {}

function VexShieldRuntime.IsWeaponSpawnBypassActive(src)
    local sid = tonumber(src)
    if not sid or sid <= 0 then return false end
    local t = VexShieldRuntime.WeaponSpawnBypassUntil[sid]
    return t ~= nil and GetGameTimer() < t
end

function VexShieldRuntime.SetWeaponSpawnBypass(src, durationMs)
    local sid = tonumber(src)
    if not sid or sid <= 0 then return end
    durationMs = tonumber(durationMs) or 8000
    if durationMs < 500 then durationMs = 500 end
    if durationMs > 120000 then durationMs = 120000 end
    VexShieldRuntime.WeaponSpawnBypassUntil[sid] = GetGameTimer() + durationMs
end

function VexShieldRuntime.IsResourceWhitelistedWeaponSpawn(inv)
    if not inv or type(inv) ~= 'string' then return false end
    local invLower = string.lower(inv)

    -- Check configured allowed resources in AntiGiveWeapon
    if Config.AntiGiveWeapon and type(Config.AntiGiveWeapon.AllowedResources) == 'table' then
        for _, n in ipairs(Config.AntiGiveWeapon.AllowedResources) do
            if string.lower(tostring(n)) == invLower then return true end
        end
    end

    -- Whitelisted standard inventories & frameworks
    local trustedInventories = {
        ['qb-core'] = true,
        ['qb-inventory'] = true,
        ['qb-weapons'] = true,
        ['ox_inventory'] = true,
        ['es_extended'] = true,
        ['qs-inventory'] = true,
        ['core_inventory'] = true,
        ['mf-inventory'] = true,
        ['inventory'] = true,
        ['esx_policejob'] = true,
        ['esx_weaponshop'] = true,
        ['vexshield'] = true
    }
    if trustedInventories[invLower] then
        return true
    end

    if type(Config.WhitelistedJobs) == 'table' then
        for _, n in ipairs(Config.WhitelistedJobs) do
            if string.lower(tostring(n)) == invLower then return true end
        end
    end
    return false
end

-- Cache ban context so Discord embed can be posted even if the player disconnects
-- (e.g. due to hitches / slow DB / clip relay). Keyed by banId string.
VexShieldRuntime.BanContext = VexShieldRuntime.BanContext or {}

function VexShieldRuntime.SetBanContext(banId, ctx)
    local bid = tostring(banId or ""):gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 64)
    if bid == "" or type(ctx) ~= "table" then
        return
    end
    VexShieldRuntime.BanContext[bid] = ctx
    Citizen.SetTimeout(10 * 60 * 1000, function()
        -- best-effort cleanup
        VexShieldRuntime.BanContext[bid] = nil
    end)
end

function VexShieldRuntime.GetBanContext(banId)
    local bid = tostring(banId or ""):gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 64)
    if bid == "" then return nil end
    return VexShieldRuntime.BanContext[bid]
end

-- Track if a ban clip upload is in progress (telemetry only — does not block DropPlayer).
VexShieldRuntime.BanClipPendingBySrc = VexShieldRuntime.BanClipPendingBySrc or {}

function VexShieldRuntime.SetBanClipPending(src, requestId, ttlMs)
    local sid = tonumber(src)
    if not sid then return end
    local rid = type(requestId) == "string" and requestId:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 96) or ""
    if rid == "" then return end
    ttlMs = tonumber(ttlMs) or 60000
    if ttlMs < 10000 then ttlMs = 10000 end
    if ttlMs > 180000 then ttlMs = 180000 end
    VexShieldRuntime.BanClipPendingBySrc[sid] = {
        rid = rid,
        expires = GetGameTimer() + math.floor(ttlMs),
    }
end

function VexShieldRuntime.ClearBanClipPending(src, requestId)
    local sid = tonumber(src)
    if not sid then return end
    local cur = VexShieldRuntime.BanClipPendingBySrc[sid]
    if not cur then return end
    if type(requestId) == "string" and requestId ~= "" and cur.rid ~= requestId then
        return
    end
    VexShieldRuntime.BanClipPendingBySrc[sid] = nil
end

VexShieldRuntime.PendingBanKickBySrc = VexShieldRuntime.PendingBanKickBySrc or {}

function VexShieldRuntime.ScheduleBanKick(src, kickMessage)
    local sid = tonumber(src)
    if not sid or type(kickMessage) ~= "string" or kickMessage == "" then return end
    VexShieldRuntime.PendingBanKickBySrc[sid] = kickMessage
end

function VexShieldRuntime.TryKickAfterBanClip(src)
    local sid = tonumber(src)
    if not sid or not GetPlayerName(sid) then return end
    local msg = VexShieldRuntime.PendingBanKickBySrc[sid]
    if not msg then return end
    VexShieldRuntime.PendingBanKickBySrc[sid] = nil
    DropPlayer(sid, msg)
end

function VexShieldRuntime.HasPendingBanClip(src)
    local sid = tonumber(src)
    if not sid then return false end
    local cur = VexShieldRuntime.BanClipPendingBySrc[sid]
    if not cur then return false end
    if cur.expires and GetGameTimer() > cur.expires then
        VexShieldRuntime.BanClipPendingBySrc[sid] = nil
        return false
    end
    return true
end

-- Drop the player; optional brief wait only when setr VexShield_banclip_drop_max_wait_ms > 0.
function VexShieldRuntime.DropPlayerWhenReady(src, kickMessage, startedAtMs, attempts)
    local sid = tonumber(src)
    if not sid then return end
    attempts = tonumber(attempts) or 0
    startedAtMs = tonumber(startedAtMs) or GetGameTimer()
    local maxWait = tonumber(GetConvar("VexShield_banclip_drop_max_wait_ms", "0")) or 0
    if maxWait < 0 then maxWait = 0 end
    if maxWait > 30000 then maxWait = 30000 end

    if maxWait > 0 and GetPlayerName(sid) and VexShieldRuntime.HasPendingBanClip(sid) and (GetGameTimer() - startedAtMs) < maxWait then
        Citizen.SetTimeout(250, function()
            VexShieldRuntime.DropPlayerWhenReady(sid, kickMessage, startedAtMs, attempts + 1)
        end)
        return
    end

    DropPlayer(sid, kickMessage)
end

--- Delay before DropPlayer on ban (ms). Keep enough time for 4s clip capture + upload.
--- Clip-complete path may still drop earlier once the clip URL is ready.
--- Use setr VexShield_ban_kick_after_ms to override (server + client).
function VexShieldRuntime.BanKickDelayMs()
    local raw = tostring(GetConvar("VexShield_ban_kick_after_ms", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local w = tonumber(raw)
    if not w then w = 0 end
    if w < 0 then w = 0 end
    if w > 60000 then w = 60000 end
    return math.floor(w)
end

AS_KnownModelHashes = AS_KnownModelHashes or {}

local function toUnsigned32(val)
    local n = tonumber(val)
    if not n then return nil end
    if n < 0 then
        n = n + 4294967296
    end
    return math.floor(n)
end

function VexShieldRegisterModelName(name)
    if type(name) == "string" and name ~= "" then
        local key = string.lower(name)
        local hSigned = GetHashKey(name)
        local hUnsigned = toUnsigned32(hSigned)
        AS_KnownModelHashes[hSigned] = key
        AS_KnownModelHashes[tostring(hSigned)] = key
        if hUnsigned then
            AS_KnownModelHashes[hUnsigned] = key
            AS_KnownModelHashes[tostring(hUnsigned)] = key
        end
    end
end

-- Pre-populate comprehensive GTA V vehicles, weapons, peds, and props
do
    local commonModels = {
        -- Super / Sports / Muscle / Tuning
        "adder", "zentorno", "t20", "osiris", "entityxf", "cheetah", "turismor", "fmj", "re7b", "pfister811",
        "prototipo", "xa21", "vagner", "autarch", "tyrant", "tezeract", "entity2", "deveste", "krieger", "emerus",
        "ignus", "lm87", "weaponizedignus", "turismo2", "zorrusso", "thrax", "furia", "italirsx", "toreador",
        "cyclone", "cyclone2", "visione", "scramjet", "vigilante", "oppressor", "oppressor2", "deluxo", "stromberg",
        "tempesta", "gp1", "infernus", "infernus2", "bullet", "vacca", "voltic", "banshee", "banshee2", "sultan",
        "sultanrs", "elegy", "elegy2", "jester", "jester2", "jester3", "jester4", "massacro", "massacro2", "comet",
        "comet2", "comet3", "comet4", "comet5", "feltzer", "feltzer2", "surano", "ninef", "ninef2", "coquette",
        "coquette2", "coquette3", "coquette4", "alpha", "bestiagts", "pariah", "neo", "jugular", "italigto",
        "schlagen", "drafter", "komoda", "imorgon", "paragon", "paragon2", "vectre", "calico", "cypher", "growler",
        "s2", "s2cabrio", "dominator", "dominator2", "dominator3", "dominator7", "dominator8", "gauntlet", "gauntlet2",
        "gauntlet3", "gauntlet4", "gauntlet5", "buffalo", "buffalo2", "buffalo3", "buffalo4", "sabregt", "sabregt2",
        "phoenix", "ruiner", "ruiner2", "ruiner3", "dukes", "dukes2", "slamvan", "slamvan2", "slamvan3", "hermes",
        "yosemite", "yosemite2", "yosemite3", "hustler", "faction", "faction2", "faction3", "voodoo", "voodoo2",
        "blade", "buccaneer", "buccaneer2", "chino", "chino2", "deviant", "ellie", "clique", "tulip", "vamos", "impaler",

        -- Aircraft / Military / Helicopters
        "cargoplane", "lazer", "hydra", "alkonost", "raiju", "avenger", "avenger2", "bombushka", "volatol", "titan",
        "b11", "pyros", "starling", "nokota", "molotok", "rogue", "tula", "seabreeze", "besra", "strikeforce",
        "jet", "miljet", "luxor", "luxor2", "nimbus", "shamal", "velum", "velum2", "duster", "cuban800", "mammatus",
        "alphaz1", "howard", "microlight", "blimp", "blimp2", "blimp3", "buzzard", "buzzard2", "akula", "annihilator",
        "annihilator2", "savage", "hunter", "valkyrie", "valkyrie2", "cargobob", "cargobob2", "cargobob3", "cargobob4",
        "sparrow", "seasparrow", "seasparrow2", "seasparrow3", "frogger", "frogger2", "maverick", "polmav", "swift",
        "swift2", "supervolito", "supervolito2", "volatus", "havok", "skylift",

        -- Offroad / Military Vehicles
        "rhino", "khanjali", "apc", "chernobog", "halftrack", "scarab", "scarab2", "scarab3", "insurgent", "insurgent2",
        "insurgent3", "nightshark", "menace", "technical", "technical2", "technical3", "barrage", "caracara", "caracara2",
        "brutus", "brutus2", "brutus3", "cerberus", "cerberus2", "cerberus3", "zr380", "zr3802", "zr3803", "deathbike",
        "deathbike2", "deathbike3", "zaba", "zhaba", "minitank", "rcbandito", "rctank", "thruster", "dump", "dubsta",
        "dubsta2", "dubsta3", "kamacho", "freecrawler", "brawler", "trophytruck", "trophytruck2", "marshall", "monster",
        "monster4", "monster5", "sandking", "sandking2", "everon", "outlaw", "vagrant", "verus", "winky",

        -- Sedans / SUVs / Trucks / Industrial / Emergency
        "kuruma", "kuruma2", "schafter", "schafter2", "schafter3", "schafter4", "schafter5", "schafter6", "cognoscenti",
        "cognoscenti2", "baller", "baller2", "baller3", "baller4", "baller5", "baller6", "baller7", "cavalcade",
        "cavalcade2", "granger", "granger2", "rocoto", "fq2", "habanero", "serrano", "gresley", "landstalker",
        "landstalker2", "toros", "rebla", "astron", "astron2", "jubilee", "iwagen", "cinquemila", "deity", "phantom",
        "phantom2", "phantom3", "hauler", "hauler2", "packer", "pounder", "pounder2", "mule", "mule2", "mule3", "mule4",
        "stockade", "stockade3", "flatbed", "biff", "rubble", "tipper", "tipper2", "mixer", "mixer2", "cutter", "bulldozer",
        "handler", "docktug", "forklift", "tractor", "tractor2", "tractor3", "police", "police2", "police3", "police4",
        "policeb", "policet", "policeold1", "policeold2", "sheriff", "sheriff2", "pranger", "fbi", "fbi2", "ambulan",
        "firet", "pbus", "riot", "riot2", "bus", "coach", "trash", "trash2", "dinghy", "dinghy2", "dinghy3", "dinghy4",
        "speeder", "speeder2", "jetmax", "squalo", "suntrap", "tropic", "tropic2", "marquis", "seashark", "seashark2",
        "seashark3", "toro", "toro2", "kraken", "submersible", "submersible2", "kosatka", "longfin", "patrolboat",
        "bati", "bati2", "hakuchou", "hakuchou2", "shotaro", "shinobi", "reaver", "powersurge", "sanctus", "gargoyle",
        "cliffhanger", "bf400", "enduro", "sanchez", "sanchez2", "manchez", "manchez2",

        -- Weapons
        "weapon_minigun", "weapon_railgun", "weapon_rpg", "weapon_grenadelauncher", "weapon_compactlauncher",
        "weapon_hominglauncher", "weapon_firework", "weapon_raypistol", "weapon_raycarbine", "weapon_rayminigun",
        "weapon_hazardcan", "weapon_pipebomb", "weapon_stickybomb", "weapon_proximitymine", "weapon_grenade",
        "weapon_molotov", "weapon_smg", "weapon_combatpdw", "weapon_assaultrifle", "weapon_carbinerifle",
        "weapon_advancedrifle", "weapon_specialcarbine", "weapon_bullpuprifle", "weapon_heavyrifle",
        "weapon_militaryrifle", "weapon_tacticalrifle", "weapon_sniperrifle", "weapon_heavysniper",
        "weapon_marksmanrifle", "weapon_precisionrifle", "weapon_pumpshotgun", "weapon_sawnoffshotgun",
        "weapon_bullpupshotgun", "weapon_assaultshotgun", "weapon_musket", "weapon_heavyshotgun", "weapon_dbshotgun",
        "weapon_autoshotgun", "weapon_combatshotgun"
    }
    for _, mName in ipairs(commonModels) do
        VexShieldRegisterModelName(mName)
    end
end

function VexShieldResolveModelName(entityHash, entityType)
    if not entityHash or entityHash == "Unknown" or entityHash == "Multiple" then
        return nil, nil
    end

    local rawStr = tostring(entityHash)
    -- If entityHash is already a model string name (e.g. "cargoplane" or "oppressor")
    if not rawStr:match("^%-?%d+$") and not rawStr:match("^0x%x+$") then
        local uHash = toUnsigned32(GetHashKey(rawStr))
        return rawStr, uHash
    end

    local numHash = tonumber(rawStr)
    if not numHash then return rawStr, nil end

    local uHash = toUnsigned32(numHash)
    local name = AS_KnownModelHashes[numHash]
              or (uHash and AS_KnownModelHashes[uHash])
              or AS_KnownModelHashes[rawStr]
              or (uHash and AS_KnownModelHashes[tostring(uHash)])
    return name, uHash
end

function FormatVexBanReason(rawReason)
    if not rawReason or rawReason == "" then return "[SECURITY] Policy Violation" end
    local r = tostring(rawReason)

    if r:match("^%[[%w%s]+%]") then
        return r
    end

    local rl = r:lower()

    -- 1. Vehicle spawn flood & mass spams
    local vehCount, vehSecs = r:match("Vehicle Spawn Flood:?%s*(%d+)%s*vehicles in%s*(%d+)s")
    if vehCount and vehSecs then
        return string.format("[VEHICLE] Vehicle Spawn Flood: %s vehicles in %ss", vehCount, vehSecs)
    end
    if rl:find("vehicle spawn flood", 1, true) or rl:find("vehicle spam", 1, true) then
        return "[VEHICLE] Vehicle Spawn Flood Violation"
    end

    -- 2. Combat / Aim / Weapons
    if rl:find("silent aim", 1, true) then return "[COMBAT] Silent Aim Anomaly" end
    if rl:find("aimlock", 1, true) or rl:find("lock aim", 1, true) then return "[COMBAT] Aimlock Anomaly" end
    if rl:find("hit validation", 1, true) or rl:find("impact angle", 1, true) then return "[COMBAT] Hitbox Angle Manipulation" end
    if rl:find("aim direction", 1, true) or rl:find("aim vector", 1, true) then return "[COMBAT] Aim Vector Manipulation" end
    if rl:find("recoil", 1, true) then return "[COMBAT] No Recoil Modification" end
    if rl:find("noreload", 1, true) or rl:find("bypass reload", 1, true) then return "[COMBAT] Infinite Ammo / No-Reload Exploit" end
    if rl:find("infinite ammo", 1, true) then return "[COMBAT] Infinite Ammo Exploit" end
    if rl:find("explosion bullet", 1, true) or rl:find("explosive bullets", 1, true) then return "[COMBAT] Explosive Ammunition Injection" end
    if rl:find("damage spoof", 1, true) or rl:find("spoofed damage", 1, true) then return "[COMBAT] Damage Spoofing Anomaly" end
    if rl:find("fake taze", 1, true) then return "[COMBAT] Fake Taze State Injection" end
    if rl:find("kill punch", 1, true) or rl:find("punch player", 1, true) then return "[COMBAT] Super Punch / One-Hit Exploit" end
    if rl:find("kill player", 1, true) then return "[COMBAT] Remote Player Kill Exploit" end

    -- 3. Movement / Teleport / Freecam / Noclip
    if rl:find("freecam", 1, true) or rl:find("free cam", 1, true) then return "[MOVEMENT] Unauthorized Freecam / Spectate" end
    if rl:find("noclip", 1, true) then return "[MOVEMENT] Noclip Physics Decoupling" end
    if rl:find("teleport to waypoint", 1, true) or rl:find("waypoint teleport", 1, true) then return "[MOVEMENT] Waypoint Teleportation Exploit" end
    if rl:find("fast run", 1, true) or rl:find("sprint speed", 1, true) then return "[MOVEMENT] Speedhack Sprint Velocity" end
    if rl:find("fast swim", 1, true) then return "[MOVEMENT] Speedhack Swim Velocity" end
    if rl:find("super jump", 1, true) then return "[MOVEMENT] Super Jump Physics Modification" end
    if rl:find("spectate", 1, true) then return "[MOVEMENT] Unauthorized Player Spectate" end

    -- 4. Vehicles
    if rl:find("teleport an vehicle", 1, true) or rl:find("bring vehicle", 1, true) then return "[VEHICLE] Unauthorized Vehicle Teleportation" end
    if rl:find("bring all vehicles", 1, true) then return "[VEHICLE] Mass Vehicle Teleportation Exploit" end
    if rl:find("throw vehicle", 1, true) or rl:find("slingshot", 1, true) then return "[VEHICLE] Vehicle Slingshot / Launch Exploit" end
    if rl:find("rocket boost", 1, true) or rl:find("vehicle boost", 1, true) then return "[VEHICLE] Illegal Rocket Boost Manipulation" end
    if rl:find("fly vehicle", 1, true) or rl:find("launch/fly vehicle", 1, true) then return "[VEHICLE] Vehicle Flight / Levitation Exploit" end
    if rl:find("blacklisted vehicle", 1, true) then return "[VEHICLE] Blacklisted Vehicle Spawn Attempt" end
    if rl:find("plate changer", 1, true) then return "[VEHICLE] Vehicle Plate Spoofing Exploit" end
    if rl:find("repair vehicle", 1, true) then return "[VEHICLE] Remote Vehicle Repair Injection" end
    if rl:find("delete vehicle", 1, true) then return "[VEHICLE] Remote Vehicle Deletion Exploit" end

    -- 5. Entities & Props
    if rl:find("blacklisted object", 1, true) or rl:find("blacklisted prop", 1, true) then return "[ENTITY] Blacklisted Prop Spawn Attempt" end
    if rl:find("crash entity", 1, true) or rl:find("crash model", 1, true) then return "[ENTITY] Server Crash Entity Spawn Attempt" end
    if rl:find("unauthorized entity spawn", 1, true) or rl:find("manual entity injection", 1, true) or rl:find("stealth entity", 1, true) then return "[ENTITY] Unauthorized Entity Creation Exploit" end
    if rl:find("clone player", 1, true) or rl:find("duplicate player", 1, true) then return "[ENTITY] Player Entity Clone Exploit" end
    if rl:find("object spawn", 1, true) or rl:find("object spam", 1, true) then return "[ENTITY] Mass Object Spawn Flood" end

    -- 6. Injection, DevTools & Executions
    if rl:find("nui devtools", 1, true) then return "[INJECTION] NUI DevTools DOM Inspector" end
    if rl:find("ocr", 1, true) then return "[INJECTION] Screen OCR / Overlay Capture" end
    if rl:find("nui blocker", 1, true) then return "[INJECTION] NUI Focus Hijacking Exploit" end
    if rl:find("anti afk", 1, true) then return "[INJECTION] Automated Anti-AFK Injection" end
    if rl:find("lua menu", 1, true) or rl:find("lua script injection", 1, true) or rl:find("lua input", 1, true) then return "[INJECTION] External Lua Menu Injection" end
    if rl:find("executor detected", 1, true) or rl:find("cheatai", 1, true) then return "[INJECTION] Internal Cheat Executor Injection" end
    if rl:find("stop resource", 1, true) or rl:find("stop vexshield", 1, true) then return "[INJECTION] Resource Stop / Evasion Exploit" end
    if rl:find("unencrypted", 1, true) or rl:find("anti-trigger", 1, true) then return "[INJECTION] Unauthorized Remote Event Trigger" end
    if rl:find("scan anticheat", 1, true) or rl:find("file scan", 1, true) then return "[INJECTION] Anticheat Memory Inspection" end

    -- 7. Explosions & Particles
    if rl:find("silent explosion", 1, true) then return "[EXPLOIT] Silent Explosion Injection" end
    if rl:find("invisible explosion", 1, true) then return "[EXPLOIT] Invisible Explosion Injection" end
    if rl:find("phone explosion", 1, true) then return "[EXPLOIT] Phone Explosion Exploit" end
    if rl:find("explosion", 1, true) then return "[EXPLOIT] Unauthorized Explosion Trigger" end
    if rl:find("blacklist particle", 1, true) then return "[EXPLOIT] Blacklisted Crash Particle Trigger" end

    -- 8. Player State & Exploits
    if rl:find("tiny his ped", 1, true) or rl:find("tiny ped", 1, true) then return "[EXPLOIT] Ped Scale Modification (Tiny Ped)" end
    if rl:find("godmode", 1, true) then return "[EXPLOIT] Godmode / Damage Immunity Exploit" end
    if rl:find("player blip", 1, true) then return "[EXPLOIT] Player Radar Blip ESP Hack" end
    if rl:find("inventory exploit", 1, true) then return "[EXPLOIT] Inventory State Manipulation" end
    if rl:find("money", 1, true) then return "[EXPLOIT] Currency Manipulation Exploit" end
    if rl:find("spoofer", 1, true) or rl:find("spoof", 1, true) or rl:find("license", 1, true) then return "[EXPLOIT] Identifier / License Spoofing" end
    if rl:find("force animation", 1, true) then return "[EXPLOIT] Remote Animation Injection" end

    return "[SECURITY] " .. r
end

function banPlayer(playerId, reason, entityType, entityHash)
    if not LICENSE_VALIDATED then return end
    local numericPlayerId = tonumber(playerId)
    if not numericPlayerId then return end
    if VexShieldRuntime and VexShieldRuntime.IsStopping then return end

    local rLower = tostring(reason or ""):lower()
    local isSpawnReason = rLower:find("spawn", 1, true) ~= nil 
                       or rLower:find("object", 1, true) ~= nil 
                       or rLower:find("ped", 1, true) ~= nil 
                       or rLower:find("vehicle", 1, true) ~= nil
                       or rLower:find("weapon", 1, true) ~= nil

    if (not entityType or entityType == "Unknown") and isSpawnReason then
        if rLower:find("ped", 1, true) then
            entityType = "Ped"
        elseif rLower:find("object", 1, true) or rLower:find("prop", 1, true) then
            entityType = "Object/Prop"
        elseif rLower:find("weapon", 1, true) then
            entityType = "Weapon"
        elseif rLower:find("vehicle", 1, true) then
            entityType = "Vehicle"
        end
    end
    
    -- Store entity information for webhook
    local entityInfo = {
        type = entityType or (isSpawnReason and "Entity" or "Unknown"),
        hash = entityHash or (isSpawnReason and "Unknown" or "Unknown")
    }

    local protectionKey = VexShieldResolveProtectionKey(reason)
    if protectionKey then
        local resolvedLevel = VexShieldResolveLevelFromReason(reason)
        if not VexShieldIsProtectionEnabled(protectionKey, resolvedLevel) then
            return
        end
    end

    -- Format and modernize the reason
    reason = FormatVexBanReason(reason)

    -- CRITICAL: ALWAYS allow these reasons even during spawn/loading
    local criticalReasons = {
        ["Detected unauthorized software: Susano"] = true,
        ["Attempted unauthorized explosion"] = true,
        ["Attempted scripted explosion"] = true,
        ["Attempted to stop resource"] = true,
        ["Attempted to stop VexShield"] = true,
        ["Attempted identifier spoofing"] = true,
        ["Attempted to spawn prohibited weapon"] = true,
        ["Attempted money exploit"] = true,
        ["Attempted Lua script injection"] = true,
        ["Attempted resource injection"] = true,
        ["Attempted event hook injection"] = true,
        ["Attempted unencrypted event trigger"] = true,
        ["Attempted unauthorized event trigger"] = true,
        ["Attempted silent mass elimination"] = true
    }
    local reasonLower = string.lower(tostring(reason or ""))
    local isCritical = criticalReasons[reason]
        or reasonLower:find("anti-trigger", 1, true) ~= nil
        or reasonLower:find("unencrypted", 1, true) ~= nil
        or reasonLower:find("executor detected", 1, true) ~= nil
        or reasonLower:find("stop resource", 1, true) ~= nil
        or reasonLower:find("stop vexshield", 1, true) ~= nil

    -- 1. Check if player is fully loaded / ready (protect multicharacter, character creator, apartment, initial grace)
    if not isCritical and not IsPlayerFullyReady(numericPlayerId) then
        return
    end

    -- 2. Check if player is in the activeClients list
    if not activeClients[numericPlayerId] and not isCritical then
        return
    end

    local action = getEnforcementAction(reason)

    if not shouldBan(numericPlayerId, numericPlayerId, reason) then
        if not (reasonLower:find("anti-trigger", 1, true) or reasonLower:find("executor detected", 1, true) or reasonLower:find("unencrypted", 1, true)) then
            return
        end
    end

    if action == "logs" then
        local name = GetPlayerName(playerId) or "Unknown"
        print('^2[VEXSHIELD]^7 >> TELEMETRY DETECTED | Target: ^3' .. tostring(name) .. '^7 | Flag: ^4' .. tostring(reason) .. '^0')
        sendLogsOnlyWebhook(playerId, reason)
        return
    end

    if action == "kick" then
        local name = GetPlayerName(playerId) or "Unknown"
        sendLogsOnlyWebhook(playerId, reason, "kick")
        DropPlayer(playerId, "[VexShield] You were kicked for: " .. reason)
        print('^3[VEXSHIELD]^7 >> ^3SECURITY KICK^7 | Target: ^3' .. tostring(name) .. '^7 (ID: ^3' .. tostring(playerId) .. '^7) | Reason: ^3' .. tostring(reason) .. '^0')
        return
    end

    if recentBans[playerId] and os.time() - recentBans[playerId] < 6 then
         return
    end
     recentBans[playerId] = os.time()

    local isBanned, existingBanId, existingReason = IsPlayerAlreadyBanned(playerId)
    if isBanned then
        print('^3[VEXSHIELD]^7 >> ENFORCEMENT SKIPPED | Target: ^3' .. (GetPlayerName(playerId) or "Unknown") .. '^7 (Already Banned: ^6#' .. tostring(existingBanId) .. '^7)^0')
        DropPlayer(playerId, VexShieldFormatKickMessage(existingBanId, existingReason))
        return
    end

    local src = numericPlayerId

    local identifiers = GetPlayerIdentifiers(playerId)
    local steam, license, ip, hwid = "Unknown", "Unknown", "Unknown", "Unknown"
    local license2, discord, live, xbl, guid, seed, gameid = "Unknown", "Unknown", "Unknown", "Unknown", "Unknown", "Unknown", "Unknown"
    local fivem, thor, redm, license3, twitch = "Unknown", "Unknown", "Unknown", "Unknown", "Unknown"
    local vbl, ros, license4, license5 = "Unknown", "Unknown", "Unknown", "Unknown"    

    for _, id in ipairs(identifiers) do
        if string.match(id, "steam:") then steam = id end
        if string.match(id, "license:") then license = id end
        if string.match(id, "license2:") then license2 = id end
        if string.match(id, "license3:") then license3 = id end
        if string.match(id, "license4:") then license4 = id end
        if string.match(id, "license5:") then license5 = id end
        if string.match(id, "ip:") then ip = id end
        if string.match(id, "discord:") then discord = id end
        if string.match(id, "live:") then live = id end
        if string.match(id, "xbl:") then xbl = id end
        if string.match(id, "guid:") then guid = id end
        if string.match(id, "seed:") then seed = id end
        if string.match(id, "gameid:") then gameid = id end
        if string.match(id, "fivem:") then fivem = id end
        if string.match(id, "thor:") then thor = id end
        if string.match(id, "redm:") then redm = id end
        if string.match(id, "twitch:") then twitch = id end
        if string.match(id, "vbl:") then vbl = id end
        if string.match(id, "ros:") then ros = id end
    end    

    hwid = GetPlayerToken(playerId, 0) or "Unknown"

    local tokens = {}
    for i = 0, GetNumPlayerTokens(playerId) - 1 do
        table.insert(tokens, GetPlayerToken(playerId, i))
    end

    local name = GetPlayerName(playerId)
    local tokenFingerprint = buildTokenFingerprint(tokens)
    if not name then 
        print('^2[VexShield]^1 | INVALID PLAYER ID')
        return 
    end

    -- print('^2[VexShield]^1 | BANNED PLAYER '..name..' '..newBanId..' ('..playerId..') ^4WITH REASON '..reason..'')

    local okSave, newBanId = BanJsonMutate(function(bans)
        local nid = VexNextBanId(bans)
        local sessionJoined = joinedAt[numericPlayerId] or os.time()
        local firstJoinTs = firstJoinUnixForLicense(license)
        local banRow = {
            steam = steam,
            license = license,
            license2 = license2,
            license3 = license3,
            license4 = license4,
            license5 = license5,
            discord = discord,
            live = live,
            xbl = xbl,
            ip = ip,
            guid = guid,
            seed = seed,
            gameid = gameid,
            fivem = fivem,
            redm = redm,
            thor = thor,
            twitch = twitch,
            vbl = vbl,
            ros = ros,
            hardware_id = hwid,
            tokens = tokens,
            token_fingerprint_hash = hashTokenFingerprint(tokenFingerprint),
            name = name,
            reason = reason,
            id = nid,
            screenshot_url = nil,
            joined_at = sessionJoined,
            banned_at = os.time(),
        }
        if firstJoinTs then banRow.first_join_at = firstJoinTs end
        table.insert(bans, banRow)
        return nid
    end)

    if not okSave or not newBanId then
        print("^1[VexShield] Failed to write ban to ban.json for " .. tostring(name) .. "^0")
        recentBans[playerId] = nil
        return
    end

    -- Store context immediately so later webhook sending doesn't depend on player still being online.
    VexShieldRuntime.SetBanContext(newBanId, {
        banId = tostring(newBanId),
        name = name,
        reason = reason,
        createdAt = os.time(),
        identifiers = identifiers, -- raw GetPlayerIdentifiers() array
        steam = steam,
        license = license,
        license2 = license2,
        discord = discord,
        live = live,
        xbl = xbl,
        ip = ip,
        entityType = entityInfo.type,
        entityHash = entityInfo.hash,
    })

    -- Screenshot + ban embed: only TakeScreenshot → VexShield:ScreenshotTaken (avoid duplicate raw uploads from TakeScreenshot2).

    print('^1[VEXSHIELD]^7 >> ^2BAN EXECUTED^7 | ^3Target:^7 ^7' .. tostring(name) .. ' ^3(ID: ^7' .. tostring(playerId) .. '^3)^7 | ^3BanId:^7 ^6#' .. tostring(newBanId) .. '^7 | ^3Reason:^7 ^1' .. tostring(reason) .. '^0')

    local r = tostring(reason or ''):lower()
    local logType = nil
    if r:find('explosion') then logType = 'EXPLOSION'
    elseif r:find('teleport') then logType = 'TELEPORT'
    elseif r:find('entity') then logType = 'ENTITY'
    elseif r:find('kill') then logType = 'KILL'
    elseif r:find('weapon') or r:find('unregistered weapon') then logType = 'WEAPON'
    elseif r:find('blacklisted') then logType = 'BLACKLIST' end
    if logType then
        AppendLog(logType, name, playerId, reason, GetPlayerName(src))
    end
    AppendLog('BAN_PLAYER', name, playerId, reason, GetPlayerName(src))

    local reasonTrim = tostring(reason or ""):match("^%s*(.-)%s*$") or ""
    local stoppingVexShield = string.lower(reasonTrim) == "stopping VexShield"
    sendDiscordLog(playerId, reason, newBanId, stoppingVexShield)

    -- Isolate in empty bucket INSTANTLY (0ms delay) so the banned player cannot interact with anyone else
    if GetPlayerName(playerId) then
        pcall(SetPlayerRoutingBucket, playerId, 999)
    end

    local kickMessage = VexShieldFormatKickMessage(newBanId, reason)

    if VexShieldRuntime and VexShieldRuntime.ScheduleBanKick then
        VexShieldRuntime.ScheduleBanKick(playerId, kickMessage)
    end

    local kickDelayMs = VexShieldRuntime.BanKickDelayMs()
    if stoppingVexShield then
        kickDelayMs = 0
    end

    if kickDelayMs <= 0 then
        if VexShieldRuntime and VexShieldRuntime.PendingBanKickBySrc then
            VexShieldRuntime.PendingBanKickBySrc[playerId] = nil
        end
        DropPlayer(playerId, kickMessage)
        recentBans[playerId] = nil
    else
        Citizen.SetTimeout(kickDelayMs, function()
            if VexShieldRuntime and VexShieldRuntime.PendingBanKickBySrc then
                VexShieldRuntime.PendingBanKickBySrc[playerId] = nil
            end
            DropPlayer(playerId, kickMessage)
            recentBans[playerId] = nil
        end)
    end
end

-- Function to check if a player is already banned
function IsPlayerAlreadyBanned(playerId)
    local bans = LoadBans()
    if not bans or #bans == 0 then
        return false
    end

    local identifiers = GetPlayerIdentifiers(playerId)
    if not identifiers or #identifiers == 0 then
        return false
    end

    local steam, license, ip = "Unknown", "Unknown", "Unknown"
    local license2, license3, license4, license5 = "Unknown", "Unknown", "Unknown", "Unknown"
    local discord, live, xbl, guid, seed, gameid = "Unknown", "Unknown", "Unknown", "Unknown", "Unknown", "Unknown"
    local fivem, thor, redm, twitch, vbl, ros = "Unknown", "Unknown", "Unknown", "Unknown", "Unknown", "Unknown"
    for _, v in ipairs(identifiers) do
        if v:find("steam:") then steam = v end
        if v:find("license:") then license = v end
        if v:find("license2:") then license2 = v end
        if v:find("license3:") then license3 = v end
        if v:find("license4:") then license4 = v end
        if v:find("license5:") then license5 = v end
        if v:find("ip:") then ip = v end
        if v:find("discord:") then discord = v end
        if v:find("live:") then live = v end
        if v:find("xbl:") then xbl = v end
        if v:find("guid:") then guid = v end
        if v:find("seed:") then seed = v end
        if v:find("gameid:") then gameid = v end
        if v:find("fivem:") then fivem = v end
        if v:find("thor:") then thor = v end
        if v:find("redm:") then redm = v end
        if v:find("twitch:") then twitch = v end
        if v:find("vbl:") then vbl = v end
        if v:find("ros:") then ros = v end
    end

    local tokenCount = GetNumPlayerTokens(playerId)
    local tokens = {}
    for i = 0, tokenCount - 1 do
        tokens[#tokens+1] = GetPlayerToken(playerId, i)
    end
    local hardware_id = GetPlayerToken(playerId, 0) or "Unknown"
    local token_fingerprint = buildTokenFingerprint(tokens)
    local token_fingerprint_hash = hashTokenFingerprint(token_fingerprint)

    for _, ban in ipairs(bans) do
        local matches = 0
        if ban.steam and ban.steam ~= "Unknown" and ban.steam == steam then matches = matches + 1 end
        if ban.license and ban.license ~= "Unknown" and ban.license == license then matches = matches + 1 end
        if ban.license2 and ban.license2 ~= "Unknown" and ban.license2 == license2 then matches = matches + 1 end
        if ban.license3 and ban.license3 ~= "Unknown" and ban.license3 == license3 then matches = matches + 1 end
        if ban.license4 and ban.license4 ~= "Unknown" and ban.license4 == license4 then matches = matches + 1 end
        if ban.license5 and ban.license5 ~= "Unknown" and ban.license5 == license5 then matches = matches + 1 end
        if ban.ip and ban.ip ~= "Unknown" and ban.ip == ip then matches = matches + 1 end
        if ban.discord and ban.discord ~= "Unknown" and ban.discord == discord then matches = matches + 1 end
        if ban.live and ban.live ~= "Unknown" and ban.live == live then matches = matches + 1 end
        if ban.xbl and ban.xbl ~= "Unknown" and ban.xbl == xbl then matches = matches + 1 end
        if ban.guid and ban.guid ~= "Unknown" and ban.guid == guid then matches = matches + 1 end
        if ban.seed and ban.seed ~= "Unknown" and ban.seed == seed then matches = matches + 1 end
        if ban.gameid and ban.gameid ~= "Unknown" and ban.gameid == gameid then matches = matches + 1 end
        if ban.fivem and ban.fivem ~= "Unknown" and ban.fivem == fivem then matches = matches + 1 end
        if ban.thor and ban.thor ~= "Unknown" and ban.thor == thor then matches = matches + 1 end
        if ban.redm and ban.redm ~= "Unknown" and ban.redm == redm then matches = matches + 1 end
        if ban.twitch and ban.twitch ~= "Unknown" and ban.twitch == twitch then matches = matches + 1 end
        if ban.vbl and ban.vbl ~= "Unknown" and ban.vbl == vbl then matches = matches + 1 end
        if ban.ros and ban.ros ~= "Unknown" and ban.ros == ros then matches = matches + 1 end
        if ban.hardware_id and ban.hardware_id ~= "Unknown" and ban.hardware_id == hardware_id then matches = matches + 1 end
        do
            local fpMatched = tokenFingerprintMatchesBan(token_fingerprint, token_fingerprint_hash, ban)
            if fpMatched then matches = matches + 1 end
        end
        if ban.tokens and type(ban.tokens) == "table" and #ban.tokens > 0 then
            for _, t in ipairs(tokens) do
                for _, bt in ipairs(ban.tokens) do
                    if t == bt then matches = matches + 1 break end
                end
            end
        end
        if matches >= 2 then
            return true, ban.id, ban.reason
        end
    end

    return false, nil, nil
end

function banPlayertrigger(playerId, reason, banId, override)
    if not LICENSE_VALIDATED then return end
    local numericPlayerId = tonumber(playerId)
    if not numericPlayerId then return end

    -- Check if protection + level is enabled (same logic as banPlayer)
    local protectionKey = VexShieldResolveProtectionKey(reason)
    if protectionKey then
        local resolvedLevel = VexShieldResolveLevelFromReason(reason)
        if not VexShieldIsProtectionEnabled(protectionKey, resolvedLevel) then
            return
        end
    end

    local action = getEnforcementAction(reason)

    if recentBans[playerId] and os.time() - recentBans[playerId] < 5 then
         return
    end
     recentBans[playerId] = os.time()

    local src = numericPlayerId

    if not override and not IsPlayerFullyReady(numericPlayerId) then
        return
    end

    if not override and not shouldBan(numericPlayerId, src, reason) then
        return
    end

    reason = FormatVexBanReason(reason)

    local identifiers = GetPlayerIdentifiers(playerId)
    local steam, license, ip, hwid = "Unknown", "Unknown", "Unknown", "Unknown"
    local license2, discord, live, xbl, guid, seed, gameid = "Unknown", "Unknown", "Unknown", "Unknown", "Unknown", "Unknown", "Unknown"
    local fivem, thor, redm, license3, twitch = "Unknown", "Unknown", "Unknown", "Unknown", "Unknown"
    local vbl, ros, license4, license5 = "Unknown", "Unknown", "Unknown", "Unknown"    

    for _, id in ipairs(identifiers) do
        if string.match(id, "steam:") then steam = id end
        if string.match(id, "license:") then license = id end
        if string.match(id, "license2:") then license2 = id end
        if string.match(id, "license3:") then license3 = id end
        if string.match(id, "license4:") then license4 = id end
        if string.match(id, "license5:") then license5 = id end
        if string.match(id, "ip:") then ip = id end
        if string.match(id, "discord:") then discord = id end
        if string.match(id, "live:") then live = id end
        if string.match(id, "xbl:") then xbl = id end
        if string.match(id, "guid:") then guid = id end
        if string.match(id, "seed:") then seed = id end
        if string.match(id, "gameid:") then gameid = id end
        if string.match(id, "fivem:") then fivem = id end
        if string.match(id, "thor:") then thor = id end
        if string.match(id, "redm:") then redm = id end
        if string.match(id, "twitch:") then twitch = id end
    end    

    if ip == "Unknown" or ip == "" or not ip:find("^%d") then
        local ep = GetPlayerEndpoint(playerId)
        if ep then
            ip = ep:match("(%d+%.%d+%.%d+%.%d+)") or ep
        end
    end

    hwid = GetPlayerToken(playerId, 0) or "Unknown"

    local tokens = {}
    for i = 0, GetNumPlayerTokens(playerId) - 1 do
        table.insert(tokens, GetPlayerToken(playerId, i))
    end

    local name = GetPlayerName(playerId)
    local tokenFingerprint = buildTokenFingerprint(tokens)

    if not name then 
        print('^2[VexShield]^1 | INVALID PLAYER ID') Config.LogIPInformation = true
        return 
    end

    -- print('^2[VexShield]^1 | BANNED PLAYER '..name..' '..newBanId..' ('..playerId..') ^4WITH REASON '..reason..'')

    local okSave, newBanId = BanJsonMutate(function(bans)
        local nid = VexNextBanId(bans)
        local sessionJoined = joinedAt[numericPlayerId] or os.time()
        local firstJoinTs = firstJoinUnixForLicense(license)
        local banRow = {
            steam = steam,
            license = license,
            license2 = license2,
            license3 = license3,
            license4 = license4,
            license5 = license5,
            discord = discord,
            live = live,
            xbl = xbl,
            ip = ip,
            guid = guid,
            seed = seed,
            gameid = gameid,
            fivem = fivem,
            redm = redm,
            thor = thor,
            twitch = twitch,
            vbl = vbl,
            ros = ros,
            hardware_id = hwid,
            tokens = tokens,
            token_fingerprint_hash = hashTokenFingerprint(tokenFingerprint),
            name = name,
            reason = reason,
            id = nid,
            screenshot_url = nil,
            joined_at = sessionJoined,
            banned_at = os.time(),
        }
        if firstJoinTs then banRow.first_join_at = firstJoinTs end
        table.insert(bans, banRow)
        return nid
    end)

    if not okSave or not newBanId then
        print("^1[VexShield] Failed to write ban to ban.json (trigger) for " .. tostring(name) .. "^0")
        recentBans[playerId] = nil
        return
    end

    print('^1[VEXSHIELD]^7 >> ^2BAN EXECUTED^7 | ^3Target:^7 ^7' .. tostring(name) .. ' ^3(ID: ^7' .. tostring(playerId) .. '^3)^7 | ^3BanId:^7 ^6#' .. tostring(newBanId) .. '^7 | ^3Reason:^7 ^1' .. tostring(reason) .. '^0')

    local r = tostring(reason or ''):lower()
    local logType = nil
    if r:find('explosion') then logType = 'EXPLOSION'
    elseif r:find('teleport') then logType = 'TELEPORT'
    elseif r:find('entity') then logType = 'ENTITY'
    elseif r:find('kill') then logType = 'KILL'
    elseif r:find('weapon') or r:find('unregistered weapon') then logType = 'WEAPON'
    elseif r:find('blacklisted') then logType = 'BLACKLIST' end
    if logType then
        AppendLog(logType, name, playerId, reason, GetPlayerName(src))
    end
    AppendLog('BAN_PLAYER', name, playerId, reason, GetPlayerName(src))

    VexShieldBroadcastBansToAdmins()

    local reasonTrimTrigger = tostring(reason or ""):match("^%s*(.-)%s*$") or ""
    local stoppingVexShieldTrigger = string.lower(reasonTrimTrigger) == "stopping VexShield"
    sendDiscordLog(playerId, reason, newBanId, stoppingVexShieldTrigger)

    local bucketDelayMs = tonumber(GetConvar("VexShield_ban_routing_bucket_delay_ms", "4000")) or 4000
    if bucketDelayMs < 0 then bucketDelayMs = 0 end
    if bucketDelayMs > 120000 then bucketDelayMs = 120000 end
    if stoppingVexShieldTrigger then
        bucketDelayMs = 0
    end
    Citizen.SetTimeout(bucketDelayMs, function()
        local pid = playerId
        if GetPlayerName(pid) then
            SetPlayerRoutingBucket(pid, 999)
        end
    end)

    local kickMessage = VexShieldFormatKickMessage(newBanId, reason)
    local kickDelayTrigger = VexShieldRuntime.BanKickDelayMs()
    if stoppingVexShieldTrigger then
        local fastT = tonumber(GetConvar("VexShield_ban_kick_stopping_VexShield_ms", "") or "")
        if not fastT then fastT = 3000 end
        if fastT < 1500 then fastT = 1500 end
        if fastT > 12000 then fastT = 12000 end
        kickDelayTrigger = math.floor(fastT)
    end
    Citizen.SetTimeout(kickDelayTrigger, function()
        DropPlayer(playerId, kickMessage)
        recentBans[playerId] = nil
    end)
end

RegisterServerEvent("VexShield:LogBlacklistedKey")
AddEventHandler("VexShield:LogBlacklistedKey", function(keyName, banId)
    local src = source
    local playerName = GetPlayerName(src)
    if not playerName then return end

    local reason = "Pressed Suspicious Key: **" .. (keyName or "Unknown") .. "**"
    TriggerClientEvent("VexShield:TakeScreenshot2", src, reason, Config.screenshotWebhook, banId)
end)

function VexShieldDiscordLinkButtonRowJson(clipUrl)
    if not clipUrl or clipUrl == "" then return nil end
    local esc = tostring(clipUrl):gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("%z", "")
    return '[{"type":1,"components":[{"type":2,"style":5,"label":"▶️ Watch Violation Clip","url":"' .. esc .. '"}]}]'
end

RegisterServerEvent("VexShield:ScreenshotTaken2")
AddEventHandler("VexShield:ScreenshotTaken2", function(screenshotUrl, reason, banId, clipUrl)
    local src = source
    local name = GetPlayerName(src)
    if not name then return end

    -- Identifiers
    local license, steamID, discord, playerip = "N/A", "N/A", "N/A", "N/A"
    for _, v in ipairs(GetPlayerIdentifiers(src)) do
        if v:find("license:") then license = v end
        if v:find("steam:") then steamID = v end
        if v:find("discord:") then
            local id = v:gsub("discord:", "")
            discord = "<@" .. id .. "> | discord:" .. id
        end
        if v:find("ip:") then playerip = v:gsub("ip:", "") end
    end

    -- IP API Lookup
    PerformHttpRequest("http://ip-api.com/json/"..GetPlayerEndpoint(src).."?fields=66846719", function(err, data)
        local ISP, CITY, COUNTRY, PROXY = "N/A", "N/A", "N/A", "OFF"
        if data then
            local d = json.decode(data)
            ISP = d.isp or ISP
            CITY = d.city or CITY
            COUNTRY = d.country or COUNTRY
            PROXY = (d.proxy == true and "ON" or "OFF")
        end

        -- Webhook embed
        local fields2 = {
            { name = "`Reason`", value = reason, inline = false },
            { name = "`Name`", value = name, inline = true },
            { name = "`Steam`", value = steamID, inline = true },
            { name = "`License`", value = license, inline = false },
            { name = "`Discord`", value = discord, inline = false },
            {
                name = "`IP Info`",
                value = ("IP: ||%s||\nISP: ||%s||\nCountry: ||%s||\nCity: ||%s||\nProxy: ||%s||"):format(
                    playerip, ISP, COUNTRY, CITY, PROXY
                ),
                inline = false
            },
        }
        if clipUrl and clipUrl ~= "" then
            table.insert(fields2, { name = "`Proof`", value = "[own clip](" .. clipUrl .. ")", inline = false })
        end

        local embed = {{
            color = 16744192,
            title = name .. " pressed a suspicious key",
            fields = fields2,
        }}

        if clipUrl and clipUrl ~= "" then
            embed[1].url = clipUrl
        end

        -- Update ban data with screenshot / clip URLs (locked RMW so concurrent bans are not lost)
        VexShieldPersistBanEvidence(banId, screenshotUrl, clipUrl)

        local detPayload = {
            username = "VexShield",
            avatar_url = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless",
            embeds = VexShieldBrandEmbeds(embed),
        }
        local detCompStr = VexShieldDiscordLinkButtonRowJson(clipUrl)
        if detCompStr then
            local okd, parsedDet = pcall(json.decode, detCompStr)
            if okd and type(parsedDet) == "table" then
                detPayload.components = parsedDet
            end
        end

        PerformHttpRequest(Config.detectionlogs, function(e, t, h)
            if e ~= 204 and e ~= 200 then
                print("^1[VexShield] Webhook failed: " .. tostring(e))
            end
        end, "POST", json.encode(detPayload), {
            ["Content-Type"] = "application/json"
        })
    end)
end)

-- Relay ban clip WebM from client (NUI base64 chunks) to Discord; direct NUI->Discord fetch often fails in FiveM CEF.
do
local BanClipRelayBuffers = {}

--- Set convar `setr VexShield_banclip_debug "1"` (or `set` on server) for extra BanClip relay logs.
function BanClipDbgEnabled()
    local v = tostring(GetConvar("VexShield_banclip_debug", "") or ""):gsub("^%s+", ""):gsub("%s+$", ""):lower()
    return v == "1" or v == "true" or v == "yes"
end

function BanClipLog(msg)
    if BanClipDbgEnabled() then
        print("^3[VexShield][BanClip]^0 " .. tostring(msg))
    end
end

function BanClipLogDbg(msg)
    if BanClipDbgEnabled() then
        print("^6[VexShield][BanClip][dbg]^0 " .. tostring(msg))
    end
end

function BanClipHttpSnippet(body, maxLen)
    if type(body) ~= "string" or body == "" then return "(empty body)" end
    local s = body:gsub("\r", " "):gsub("\n", " ")
    maxLen = maxLen or 220
    if #s > maxLen then return s:sub(1, maxLen) .. "..." end
    return s
end

--- Second Discord line when clip URL is ready after a slow pipeline (client may have already posted ban embed without clip).
VexShieldRuntime.BanClipFollowUpPosted = VexShieldRuntime.BanClipFollowUpPosted or {}
VexShieldRuntime.BanClipNeedsFollowUp = VexShieldRuntime.BanClipNeedsFollowUp or {}

function VexShieldRuntime.BanClipFollowUpClearKey(rid)
    Citizen.SetTimeout(600000, function()
        VexShieldRuntime.BanClipFollowUpPosted[rid] = nil
        VexShieldRuntime.BanClipNeedsFollowUp[rid] = nil
    end)
end

-- Mark that we posted the ban embed without a clip URL for this requestId.
function VexShieldRuntime.MarkClipFollowUpNeeded(requestId, banDisplayId)
    local rid = type(requestId) == "string" and requestId:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 96) or ""
    local bid = type(banDisplayId) == "string" and banDisplayId:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 48) or ""
    if rid == "" or bid == "" then return end
    if VexShieldRuntime.BanClipFollowUpPosted[rid] then return end
    VexShieldRuntime.BanClipNeedsFollowUp[rid] = bid
    VexShieldRuntime.BanClipFollowUpClearKey(rid)
end

-- Disabled second embed ("Ban clip (ready)"): only one single embed is posted containing all information and clip link.
function VexShieldRuntime.MaybeDiscordClipFollowUpNow(banDisplayId, clipUrl, requestId)
    return
end

function VexShieldRuntime.MaybeDiscordClipFollowUp(banDisplayId, clipUrl, requestId, flowStartMs)
    return
end

RegisterServerEvent("VexShield:BanClipClientFailLog")
AddEventHandler("VexShield:BanClipClientFailLog", function(reason)
    local src = source
    local nm = GetPlayerName(src) or "?"
    local r = type(reason) == "string" and reason:sub(1, 240) or tostring(reason)
    BanClipLog("NUI/client clip failed — player " .. nm .. " (" .. tostring(src) .. "): " .. r)
end)

RegisterServerEvent("VexShield:BanClipCefDiscordDiag")
AddEventHandler("VexShield:BanClipCefDiscordDiag", function(msg)
    local src = source
    local nm = GetPlayerName(src) or "?"
    local m = type(msg) == "string" and msg:sub(1, 320) or tostring(msg)
    BanClipLog("CEF→Discord clip diag (" .. nm .. " " .. tostring(src) .. "): " .. m)
end)

--- NUI uploaded clip directly to Discord (CEF fetch); bypasses FiveM Lua multipart / unreachable panel relay.
RegisterServerEvent("VexShield:BanClipNuiDirectClipUrl")
AddEventHandler("VexShield:BanClipNuiDirectClipUrl", function(requestId, clipUrl)
    local src = source
    local rid = type(requestId) == "string" and requestId:gsub("^%s+", ""):gsub("%s+$", "") or ""
    local url = type(clipUrl) == "string" and clipUrl:gsub("^%s+", ""):gsub("%s+$", "") or ""
    if rid == "" or url == "" then
        return
    end
    if #url > 2000 or url:find("%s") then
        return
    end
    local trusted = url:find("^https://cdn%.discordapp%.com/attachments/") == 1
        or url:find("^https://media%.discordapp%.net/attachments/") == 1
    if not trusted and Config and type(Config.BanClipTrustedClipUrlPrefixes) == "table" then
        for _, pr in ipairs(Config.BanClipTrustedClipUrlPrefixes) do
            if type(pr) == "string" and pr ~= "" and #pr <= 160 and url:sub(1, #pr) == pr then
                trusted = true
                break
            end
        end
    end
    -- Allow http://IPv4/... clip URLs when panel serves files from VPS IP (match BanClipHttpsUrl IPv4 rule).
    if not trusted and url:sub(1, 7) == "http://" then
        local host = url:match("^https?://([^/:?#]+)")
        host = host and string.lower(host) or ""
        if host ~= "" and host:match("^%d+%.%d+%.%d+%.%d+$") then
            trusted = true
        end
    end
    if not trusted then
        BanClipLog("Rejected NUI direct clip URL (not Discord CDN; add host to Config.BanClipTrustedClipUrlPrefixes) src=" .. tostring(src))
        return
    end
    BanClipLogDbg("NUI direct Discord clip OK requestId=" .. rid .. " src=" .. tostring(src))
    TriggerClientEvent("VexShield:BanClipUploadDone", src, rid, url)
    if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
        VexShieldRuntime.ClearBanClipPending(src, rid)
    end
    if VexShieldRuntime and VexShieldRuntime.TryKickAfterBanClip then
        VexShieldRuntime.TryKickAfterBanClip(src)
    end
end)

function BanClipRelayKey(src, requestId)
    return tostring(src) .. ":" .. tostring(requestId)
end

function IsDiscordWebhookUrl(u)
    if type(u) ~= "string" or #u > 500 then return false end
    return u:find("^https://discord%.com/api/webhooks/") ~= nil
        or u:find("^https://canary%.discord%.com/api/webhooks/") ~= nil
        or u:find("^https://ptb%.discord%.com/api/webhooks/") ~= nil
end

--- Panel / relay base: https://... or http://IPv4:port/... (FXServer often reaches VPS IP when public HTTPS domain fails).
function IsVexShieldBanClipHttpsUrl(u)
    if type(u) ~= "string" or #u > 900 then return false end
    if u:find("%s") then return false end
    if IsDiscordWebhookUrl(u) then return false end
    if u:sub(1, 8) == "https://" then
        return true
    end
    if u:sub(1, 7) == "http://" then
        local host = u:match("^https?://([^/:?#]+)")
        host = host and string.lower(host) or ""
        return host ~= "" and host:match("^%d+%.%d+%.%d+%.%d+$") ~= nil
    end
    return false
end

--- Optional override: setr VexShield_banclip_discord_relay_url "https://YOUR-API/.../discord-relay"
--- or "http://127.0.0.1:5000/api/VexShield/ban-clips/discord-relay" when Node runs on the same machine as FiveM.
function BanClipIsLocalDevRelayUrl(u)
    if type(u) ~= "string" or #u > 900 then return false end
    local low = u:lower()
    if low:find("%s") then return false end
    return low:match("^http://127%.0%.0%.1[:/]") ~= nil or low:match("^http://localhost[:/]") ~= nil
end

function BanClipUrlHost(u)
    if type(u) ~= "string" then return "" end
    u = u:gsub("^%s+", ""):gsub("%s+$", "")
    local h = u:match("^https?://([^/:?#]+)")
    return h and string.lower(h) or ""
end

function BanClipResolveDiscordRelayUrl()
    local c = (GetConvar("VexShield_banclip_discord_relay_url", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if c ~= "" and (IsVexShieldBanClipHttpsUrl(c) or BanClipIsLocalDevRelayUrl(c)) then
        return c
    end
    local raw = VexShieldBanClipUpload and type(VexShieldBanClipUpload.PanelApiUrl) == "string" and VexShieldBanClipUpload.PanelApiUrl:gsub("^%s+", ""):gsub("%s+$", "") or ""
    local suf = "/api/VexShield/ban-clips"
    if raw ~= "" and raw:sub(-#suf) == suf and IsVexShieldBanClipHttpsUrl(raw) then
        return raw .. "/discord-relay"
    end
    return ""
end

function BanClipBuildRelayAuthHeaders()
    local headers = { ["Content-Type"] = "application/json; charset=utf-8" }
    if VexShieldBanClipUpload and type(VexShieldBanClipUpload.UploadBearer) == "string" then
        local s = VexShieldBanClipUpload.UploadBearer:gsub("^%s+", ""):gsub("%s+$", "")
        if #s >= 8 then
            headers["Authorization"] = "Bearer " .. s
        end
    end
    local clipLic = (GetConvar("VexShield_license_key", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local clipIp = (GetConvar("VexShield_server_ip", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if clipLic ~= "" then
        headers["X-VexShield-License-Key"] = clipLic
    end
    if clipIp ~= "" then
        headers["X-VexShield-Server-Ip"] = clipIp
    end
    return headers
end

function BanClipBuildRelayAuthHeadersBinary(webhookUrl)
    local headers = { ["Content-Type"] = "video/webm" }
    if type(webhookUrl) == "string" and webhookUrl ~= "" then
        headers["X-Discord-Webhook"] = webhookUrl
    end
    if VexShieldBanClipUpload and type(VexShieldBanClipUpload.UploadBearer) == "string" then
        local s = VexShieldBanClipUpload.UploadBearer:gsub("^%s+", ""):gsub("%s+$", "")
        if #s >= 8 then
            headers["Authorization"] = "Bearer " .. s
        end
    end
    local clipLic = (GetConvar("VexShield_license_key", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local clipIp = (GetConvar("VexShield_server_ip", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if clipLic ~= "" then
        headers["X-VexShield-License-Key"] = clipLic
    end
    if clipIp ~= "" then
        headers["X-VexShield-Server-Ip"] = clipIp
    end
    return headers
end

--- Upload assembled WebM bytes to Discord: Lua multipart first, then Node discord-relay if needed (skipped when relay host = panel host and HTTP to panel is dead).
function BanClipUploadBinToDiscordWebhook(webhookUrl, bin, src, requestId, banDisplayId, flowStartMs)
    banDisplayId = type(banDisplayId) == "string" and banDisplayId:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 48) or ""
    flowStartMs = tonumber(flowStartMs) or GetGameTimer()
    local wh = webhookUrl
    if not wh or not IsDiscordWebhookUrl(wh) then
        BanClipLog("Discord clip upload skipped: invalid or non-Discord webhook URL for requestId=" .. tostring(requestId))
        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
        if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
            VexShieldRuntime.ClearBanClipPending(src, requestId)
        end
        return
    end
    if not bin or #bin < 32 then
        BanClipLog("Discord clip upload skipped: decoded binary too small (" .. tostring(bin and #bin or 0) .. " bytes) requestId=" .. tostring(requestId))
        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
        if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
            VexShieldRuntime.ClearBanClipPending(src, requestId)
        end
        return
    end
    BanClipLogDbg("POST clip to Discord webhook, bytes=" .. tostring(#bin) .. " requestId=" .. tostring(requestId))

    local hasNull = (bin:find("%z", 1, true) ~= nil)
    if hasNull then
        BanClipLogDbg("Clip payload contains null bytes — Lua multipart may fail; discord-relay (different host or http://127.0.0.1:PORT/...) is recommended.")
    end

    local whWait = wh
    if not whWait:find("wait=") then
        whWait = whWait .. (whWait:find("%?") and "&" or "?") .. "wait=true"
    end

    local function parseDiscordAttachmentUrl(code, resp)
        if (code == 200 or code == 201) and resp and resp ~= "" then
            local okj, j = pcall(json.decode, resp)
            if okj and type(j) == "table" and j.attachments and j.attachments[1] and type(j.attachments[1].url) == "string" and j.attachments[1].url ~= "" then
                return j.attachments[1].url
            end
        end
        return nil
    end

    local relayUsed = false

    -- Base64 encoding a ~500KB WebM in one go can hitch the server thread (txAdmin HB watchdog).
    -- Do it in a yielding loop so we don't stall svMain.
    local function base64EncodeYield(input)
        if type(input) ~= "string" or input == "" then
            return ""
        end
        local alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        local out = {}
        local outN = 0
        local len = #input
        local i = 1
        local yieldEvery = 24000 -- bytes (~8k 3-byte blocks)

        while i <= len do
            local a = input:byte(i) or 0
            local b = input:byte(i + 1)
            local c = input:byte(i + 2)
            local pad = 0
            if b == nil then
                b = 0
                pad = 2
            elseif c == nil then
                c = 0
                pad = 1
            end

            -- FiveM runtime typically provides Lua 5.4 bitwise operators, not bit32.*
            local triple = (a << 16) | (b << 8) | c
            local s1 = ((triple >> 18) & 63) + 1
            local s2 = ((triple >> 12) & 63) + 1
            local s3 = ((triple >> 6) & 63) + 1
            local s4 = (triple & 63) + 1

            outN = outN + 1; out[outN] = alphabet:sub(s1, s1)
            outN = outN + 1; out[outN] = alphabet:sub(s2, s2)
            if pad == 2 then
                outN = outN + 1; out[outN] = "="
                outN = outN + 1; out[outN] = "="
            elseif pad == 1 then
                outN = outN + 1; out[outN] = alphabet:sub(s3, s3)
                outN = outN + 1; out[outN] = "="
            else
                outN = outN + 1; out[outN] = alphabet:sub(s3, s3)
                outN = outN + 1; out[outN] = alphabet:sub(s4, s4)
            end

            i = i + 3
            if (i % yieldEvery) == 1 then
                Citizen.Wait(0)
            end
        end
        return table.concat(out, "")
    end

    local function tryNodeDiscordRelay(reasonTag)
        if relayUsed then
            return false
        end
        local relayUrl = BanClipResolveDiscordRelayUrl()
        if relayUrl == "" then
            return false
        end
        -- Default 0: same-host relay is still useful (Node multipart→Discord avoids Lua null-byte HTTP 400). Set to 1 only if you truly must skip.
        local skipSame = (GetConvar("VexShield_banclip_skip_same_host_relay", "0") or ""):gsub("^%s+", ""):gsub("%s+$", ""):lower()
        local relayConvarExplicit = (GetConvar("VexShield_banclip_discord_relay_url", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
        if skipSame ~= "0" and skipSame ~= "false" and skipSame ~= "no" and relayConvarExplicit == "" then
            local panelRaw = VexShieldBanClipUpload and type(VexShieldBanClipUpload.PanelApiUrl) == "string" and VexShieldBanClipUpload.PanelApiUrl:gsub("^%s+", ""):gsub("%s+$", "") or ""
            local hp = BanClipUrlHost(panelRaw)
            local hr = BanClipUrlHost(relayUrl)
            if hp ~= "" and hr ~= "" and hp == hr then
                BanClipLog("[BanClip] Skipping discord-relay: same hostname as PanelApiUrl (" .. hr .. ") — setr VexShield_banclip_skip_same_host_relay 0 (default) to allow, or set VexShield_banclip_discord_relay_url explicitly.")
                return false
            end
        end
        relayUsed = true
        Citizen.CreateThread(function()
            Citizen.Wait(0)
            local relayUrlBin = relayUrl:gsub("/discord%-relay$", "/discord-relay-bin")
            if not hasNull and relayUrlBin ~= relayUrl and relayUrlBin ~= "" then
                BanClipLogDbg("Trying Node discord-relay-bin (" .. tostring(reasonTag) .. ") → " .. BanClipHttpSnippet(relayUrlBin, 120))
                local headers = BanClipBuildRelayAuthHeadersBinary(wh)
                PerformHttpRequest(relayUrlBin, function(code, resp, _h)
                    local url = nil
                    if (code == 200 or code == 201) and resp and resp ~= "" then
                        local okj, j = pcall(json.decode, resp)
                        if okj and type(j) == "table" and type(j.url) == "string" and j.url ~= "" then
                            url = j.url
                        end
                    end
                    if url then
                        BanClipLog("discord-relay-bin OK requestId=" .. tostring(requestId))
                        TriggerEvent("VexShield:ScreenshotTaken", nil, nil, banDisplayId, url, requestId, src)
                        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, url)
                        if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                            VexShieldRuntime.ClearBanClipPending(src, requestId)
                        end
                        return
                    end
                    BanClipLog("discord-relay-bin failed HTTP " .. tostring(code) .. " body=" .. BanClipHttpSnippet(resp, 320))
                    TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
                    if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                        VexShieldRuntime.ClearBanClipPending(src, requestId)
                    end
                end, "POST", bin, headers)
                return
            end

            local okB64, b64clip = pcall(base64EncodeYield, bin)
            if not okB64 or type(b64clip) ~= "string" or b64clip == "" then
                BanClipLog("base64_encode_yield(clip) failed; cannot call discord-relay.")
                TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
                if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                    VexShieldRuntime.ClearBanClipPending(src, requestId)
                end
                return
            end
            BanClipLogDbg("Trying Node discord-relay (" .. tostring(reasonTag) .. ") → " .. BanClipHttpSnippet(relayUrl, 120))
            local body = json.encode({ webhookUrl = wh, clipB64 = b64clip })
            local headers = BanClipBuildRelayAuthHeaders()
            PerformHttpRequest(relayUrl, function(code, resp, _h)
                local url = nil
                if (code == 200 or code == 201) and resp and resp ~= "" then
                    local okj, j = pcall(json.decode, resp)
                    if okj and type(j) == "table" and type(j.url) == "string" and j.url ~= "" then
                        url = j.url
                    end
                end
                if url then
                    BanClipLog("discord-relay OK requestId=" .. tostring(requestId))
                    TriggerEvent("VexShield:ScreenshotTaken", nil, nil, banDisplayId, url, requestId, src)
                    TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, url)
                    if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                        VexShieldRuntime.ClearBanClipPending(src, requestId)
                    end
                    return
                end
                BanClipLog("discord-relay failed HTTP " .. tostring(code) .. " body=" .. BanClipHttpSnippet(resp, 320))
                TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
                if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                    VexShieldRuntime.ClearBanClipPending(src, requestId)
                end
            end, "POST", body, headers)
        end)
        return true
    end

    local function doDiscordLuaMultipart(flowTag)
        local boundary = "----VexShieldBanClip" .. tostring(GetGameTimer()) .. tostring(math.random(10000, 99999))
        local payloadJson = json.encode({
            content = "VexShield ban clip",
            attachments = {
                { id = 0, filename = "VexShield-ban.webm" },
            },
        })
        local body = "--" .. boundary .. "\r\nContent-Disposition: form-data; name=\"payload_json\"\r\nContent-Type: application/json\r\n\r\n"
            .. payloadJson
            .. "\r\n--" .. boundary .. "\r\nContent-Disposition: form-data; name=\"files[0]\"; filename=\"VexShield-ban.webm\"\r\nContent-Type: video/webm\r\n\r\n"
            .. bin
            .. "\r\n--" .. boundary .. "--\r\n"
        PerformHttpRequest(whWait, function(code, resp, _headers)
            local url = parseDiscordAttachmentUrl(code, resp)
            if url then
                BanClipLog("Discord multipart OK flow=" .. tostring(flowTag) .. " requestId=" .. tostring(requestId))
                TriggerEvent("VexShield:ScreenshotTaken", nil, nil, banDisplayId, url, requestId, src)
                TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, url)
                if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                    VexShieldRuntime.ClearBanClipPending(src, requestId)
                end
                return
            end
            if code == 0 then
                BanClipLog("Discord multipart HTTP 0 flow=" .. tostring(flowTag) .. " — check outbound HTTPS to discord.com (or body truncation).")
            else
                BanClipLog("Discord multipart failed flow=" .. tostring(flowTag) .. " HTTP " .. tostring(code) .. " body=" .. BanClipHttpSnippet(resp, 260))
            end
            if not relayUsed and (code == 400 or code == 403 or code == 413 or code == 0 or hasNull) then
                if tryNodeDiscordRelay("after_multipart_" .. tostring(flowTag) .. "_" .. tostring(code)) then
                    return
                end
            end
            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
            if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                VexShieldRuntime.ClearBanClipPending(src, requestId)
            end
        end, "POST", body, { ["Content-Type"] = "multipart/form-data; boundary=" .. boundary })
    end

    -- NUL bytes in WebM often break Lua multipart (Discord HTTP 400); Node relay uses a clean buffer upload.
    if hasNull and tryNodeDiscordRelay("before_multipart_null_bytes") then
        return
    end

    doDiscordLuaMultipart("primary")
end

function ResolveBanClipUploadTarget(webhookUrl)
    -- Discord webhook destination (website upload removed per user request)
    if IsDiscordWebhookUrl(webhookUrl) then
        return "discord", webhookUrl, nil
    end
    if Config and Config.logsBans and IsDiscordWebhookUrl(Config.logsBans) then
        return "discord", Config.logsBans, nil
    end
    if Config and Config.logsWebhook and IsDiscordWebhookUrl(Config.logsWebhook) then
        return "discord", Config.logsWebhook, nil
    end
    return nil, nil, nil
end

RegisterServerEvent("VexShield:BanClipUploadInit")
AddEventHandler("VexShield:BanClipUploadInit", function(requestId, totalChunks, webhookUrl, banDisplayId)
    local src = source
    local tot = tonumber(totalChunks)
    -- Many small chunks: each BanClipUploadChunk must stay under FiveM reliable event size (~16KB payload).
    if not tot or tot < 1 or tot > 15000 then
        BanClipLog("Init rejected: bad totalChunks=" .. tostring(totalChunks) .. " (need 1..15000) src=" .. tostring(src) .. " requestId=" .. tostring(requestId))
        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
        return
    end
    local mode, target, secret = ResolveBanClipUploadTarget(webhookUrl)
    if not mode then
        BanClipLog("Init rejected: no upload target (set PanelApiUrl or pass Discord screenshot webhook) src=" .. tostring(src) .. " requestId=" .. tostring(requestId))
        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
        return
    end
    local key = BanClipRelayKey(src, requestId)
    local clipLic = (GetConvar("VexShield_license_key", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local clipIp = (GetConvar("VexShield_server_ip", "") or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local fallbackWh = nil
    if type(webhookUrl) == "string" and IsDiscordWebhookUrl(webhookUrl) then
        fallbackWh = webhookUrl
    end
    local banDisp = ""
    if type(banDisplayId) == "string" then
        banDisp = banDisplayId:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 48)
    end
    BanClipRelayBuffers[key] = {
        total = tot,
        got = 0,
        mode = mode,
        webhook = (mode == "discord" and target or nil),
        customUrl = (mode == "custom" and target or nil),
        customSecret = (mode == "custom" and secret or nil),
        clipLicenseKey = clipLic,
        clipServerIp = clipIp,
        fallbackDiscordWebhook = (mode == "custom" and fallbackWh) or nil,
        parts = {},
        uploading = false,
        expires = GetGameTimer() + 300000,
        flowStartMs = GetGameTimer(),
        banDisplayId = banDisp,
    }
    -- Mark clip upload as pending so ban DropPlayer doesn't cut the upload off early.
    if VexShieldRuntime and VexShieldRuntime.SetBanClipPending then
        VexShieldRuntime.SetBanClipPending(src, requestId, 300000)
    end
    local licSet = (clipLic ~= "") and "yes" or "no"
    local ipSet = (clipIp ~= "") and "yes" or "no"
    local bearerSet = (type(secret) == "string" and #secret >= 8) and "yes" or "no"
    local fb = fallbackWh and "yes" or "no"
    -- NUI only calls BanClipUploadInit from uploadBanClipViaServerChunks *after* MediaRecorder.stop + WebM blob + base64 (see ac-air_index.html). chunks=N = N base64 parts to receive, not "recording not started".
    BanClipLog(
        "Init OK (NUI clip already captured; relay opened for "
            .. tostring(tot)
            .. " incoming base64 parts) mode="
            .. tostring(mode)
            .. " requestId="
            .. tostring(requestId)
            .. " src="
            .. tostring(src)
            .. " panel_bearer="
            .. bearerSet
            .. " convar_license="
            .. licSet
            .. " convar_server_ip="
            .. ipSet
            .. " discord_fallback="
            .. fb
    )
end)

RegisterServerEvent("VexShield:BanClipUploadChunk")
AddEventHandler("VexShield:BanClipUploadChunk", function(requestId, idx, chunkB64)
    local src = source
    local key = BanClipRelayKey(src, requestId)
    local buf = BanClipRelayBuffers[key]
    if not buf then
        BanClipLogDbg("Chunk ignored: no relay buffer (wrong requestId, init failed, or already uploading) src=" .. tostring(src) .. " requestId=" .. tostring(requestId) .. " idx=" .. tostring(idx))
        return
    end
    if buf.uploading then
        BanClipLogDbg("Chunk ignored: upload already in progress requestId=" .. tostring(requestId))
        return
    end
    if buf.expires and GetGameTimer() > buf.expires then
        BanClipRelayBuffers[key] = nil
        BanClipLog("Relay expired (5 min) before all chunks arrived; requestId=" .. tostring(requestId) .. " src=" .. tostring(src))
        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
        return
    end
    local i = tonumber(idx)
    if not i or i < 1 or i > buf.total then
        BanClipLog("Chunk rejected: bad idx=" .. tostring(idx) .. " (total=" .. tostring(buf.total) .. ") requestId=" .. tostring(requestId))
        return
    end
    -- NUI sends base64 slices; keep headroom under FiveM reliable event limit (overflow disconnects the client).
    if type(chunkB64) ~= "string" or #chunkB64 > 16384 then
        BanClipLog("Chunk rejected: empty or too large (len=" .. tostring(type(chunkB64) == "string" and #chunkB64 or 0) .. ") idx=" .. tostring(i))
        return
    end
    if not buf.parts[i] or buf.parts[i] == "" then
        buf.got = (tonumber(buf.got) or 0) + 1
    end
    buf.parts[i] = chunkB64

    local got = tonumber(buf.got) or 0
    if got > 0 and (got == buf.total or got % 200 == 0) then
        BanClipLogDbg("Relay progress " .. tostring(got) .. "/" .. tostring(buf.total) .. " requestId=" .. tostring(requestId))
    end
    if got < buf.total then return end

    -- IMPORTANT: Assembling + base64 decode can hitch the server thread (svMain watchdog).
    -- Offload heavy work into a yielding thread so Discord embed sending (ScreenshotTaken) isn't starved.
    buf.uploading = true
    local banForFu = buf.banDisplayId or ""
    local flowFu = buf.flowStartMs or GetGameTimer()
    local bufCopy = buf
    BanClipRelayBuffers[key] = nil

    Citizen.CreateThread(function()
        -- Yield a tick first so the event handler returns quickly.
        Citizen.Wait(0)

        local total = tonumber(bufCopy.total) or 0
        if total < 1 then
            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
            return
        end

        -- Fill missing parts safely and yield occasionally during copy.
        local b64parts = {}
        for j = 1, total do
            b64parts[j] = bufCopy.parts[j] or ""
            if (j % 50) == 0 then
                Citizen.Wait(0)
            end
        end

        local fullb64 = table.concat(b64parts, "")
        Citizen.Wait(0)
        if #fullb64 < 48 then
            BanClipLog("Assembled clip invalid (b64Len=" .. tostring(#fullb64) .. ", chunks=" .. tostring(total) .. ") requestId=" .. tostring(requestId))
            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
            return
        end
        local pad = 0
        if fullb64:sub(-2) == "==" then pad = 2 elseif fullb64:sub(-1) == "=" then pad = 1 end
        local approxBytes = math.max(0, math.floor((#fullb64 * 3) / 4) - pad)
        BanClipLog("Assembled WebM ready bytes=" .. tostring(approxBytes) .. " requestId=" .. tostring(requestId))
        local bin = nil
        local function ensureBinDecoded()
            if bin ~= nil then return bin end
            local b = base64_decode(fullb64)
            if not b or #b < 32 then
                return nil
            end
            bin = b
            return bin
        end

        if bufCopy.mode == "custom" and bufCopy.customUrl then
            local function parsePanelUrl(code, resp)
                if (code == 200 or code == 201 or code == 202) and type(resp) == "string" and resp ~= "" then
                    local okj, j = pcall(json.decode, resp)
                    if okj and type(j) == "table" then
                        local candidate = j.url or j.clip_url or j.clipUrl or j.link or j.clip_link or j.proof or j.proofUrl or j.proof_url
                        if type(candidate) == "string" and candidate:match("^https?://") then
                            return candidate
                        end
                        if type(j.data) == "table" then
                            local d = j.data
                            candidate = d.url or d.clip_url or d.clipUrl or d.link or d.clip_link or d.proof or d.proofUrl or d.proof_url
                            if type(candidate) == "string" and candidate:match("^https?://") then
                                return candidate
                            end
                        end
                    end
                end
                return nil
            end

            local function postPanelOk(url)
                BanClipLog("Panel clip upload OK requestId=" .. tostring(requestId))
                TriggerEvent("VexShield:ScreenshotTaken", nil, nil, banForFu, url, requestId, src)
                TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, url)
                if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                    VexShieldRuntime.ClearBanClipPending(src, requestId)
                end
                if VexShieldRuntime and VexShieldRuntime.TryKickAfterBanClip then
                    VexShieldRuntime.TryKickAfterBanClip(src)
                end
            end

            local function postPanelFail(code, resp)
                if code == 0 then
                    BanClipLog("Panel clip upload HTTP 0 — check FXServer→panel network. requestId=" .. tostring(requestId) .. " body=" .. BanClipHttpSnippet(resp, 200))
                else
                    BanClipLog("Panel clip upload failed HTTP " .. tostring(code) .. " requestId=" .. tostring(requestId) .. " body=" .. BanClipHttpSnippet(resp, 200))
                end
                if bufCopy.fallbackDiscordWebhook then
                    BanClipLogDbg("Panel failed — retrying clip upload via Discord webhook fallback.")
                    local b2 = ensureBinDecoded()
                    if not b2 then
                        BanClipLog("Assembled clip invalid after base64 decode (b64Len=" .. tostring(#fullb64) .. ", chunks=" .. tostring(total) .. ") requestId=" .. tostring(requestId))
                        TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
                        if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                            VexShieldRuntime.ClearBanClipPending(src, requestId)
                        end
                        return
                    end
                    BanClipUploadBinToDiscordWebhook(bufCopy.fallbackDiscordWebhook, b2, src, requestId, banForFu, flowFu)
                    return
                end
                TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
                if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                    VexShieldRuntime.ClearBanClipPending(src, requestId)
                end
            end

            local headersJson = {
                ["Content-Type"] = "application/json; charset=utf-8",
            }
            if bufCopy.customSecret and type(bufCopy.customSecret) == "string" and #bufCopy.customSecret >= 8 then
                headersJson["Authorization"] = "Bearer " .. bufCopy.customSecret
            end
            if bufCopy.clipLicenseKey and bufCopy.clipLicenseKey ~= "" then
                headersJson["X-VexShield-License-Key"] = bufCopy.clipLicenseKey
            end
            if bufCopy.clipServerIp and bufCopy.clipServerIp ~= "" then
                headersJson["X-VexShield-Server-Ip"] = bufCopy.clipServerIp
            end

            local b64Url = tostring(bufCopy.customUrl) .. "/b64"
            local bodyB64 = json.encode({ clipB64 = fullb64 })
            PerformHttpRequest(b64Url, function(code, resp, _headers)
                local url = parsePanelUrl(code, resp)
                if url then
                    postPanelOk(url)
                    return
                end
                Citizen.CreateThread(function()
                    Citizen.Wait(0)
                    if code == 404 or code == 405 then
                        local b2 = ensureBinDecoded()
                        if not b2 then
                            BanClipLog("Assembled clip invalid after base64 decode (b64Len=" .. tostring(#fullb64) .. ", chunks=" .. tostring(total) .. ") requestId=" .. tostring(requestId))
                            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
                            if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                                VexShieldRuntime.ClearBanClipPending(src, requestId)
                            end
                            return
                        end
                        local boundary = "----VexShieldBanClip" .. tostring(GetGameTimer()) .. tostring(math.random(10000, 99999))
                        local head = "--" .. boundary .. "\r\nContent-Disposition: form-data; name=\"clip\"; filename=\"VexShield-ban.webm\"\r\nContent-Type: video/webm\r\n\r\n"
                        local tail = "\r\n--" .. boundary .. "--\r\n"
                        local body = table.concat({ head, b2, tail }, "")

                        local headers = {
                            ["Content-Type"] = "multipart/form-data; boundary=" .. boundary,
                        }
                        if bufCopy.customSecret and type(bufCopy.customSecret) == "string" and #bufCopy.customSecret >= 8 then
                            headers["Authorization"] = "Bearer " .. bufCopy.customSecret
                        end
                        if bufCopy.clipLicenseKey and bufCopy.clipLicenseKey ~= "" then
                            headers["X-VexShield-License-Key"] = bufCopy.clipLicenseKey
                        end
                        if bufCopy.clipServerIp and bufCopy.clipServerIp ~= "" then
                            headers["X-VexShield-Server-Ip"] = bufCopy.clipServerIp
                        end

                        PerformHttpRequest(bufCopy.customUrl, function(code2, resp2, _headers2)
                            local url2 = parsePanelUrl(code2, resp2)
                            if url2 then
                                postPanelOk(url2)
                                return
                            end
                            Citizen.CreateThread(function()
                                Citizen.Wait(0)
                                postPanelFail(code2, resp2)
                            end)
                        end, "POST", body, headers)
                        return
                    end

                    postPanelFail(code, resp)
                end)
            end, "POST", bodyB64, headersJson)
            return
        end

        local wh = bufCopy.webhook
        if not wh or not IsDiscordWebhookUrl(wh) then
            wh = (Config and Config.screenshotWebhook) or (Config and Config.logsBans) or (Config and Config.logsWebhook)
        end
        if not wh or not IsDiscordWebhookUrl(wh) then
            BanClipLog("Discord-only mode but webhook missing/invalid after assembly requestId=" .. tostring(requestId))
            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
            return
        end
        BanClipLog("Uploading assembled clip via Discord direct Node relay requestId=" .. tostring(requestId))

        local uploadHandled = false
        local currentRes = GetCurrentResourceName()

        local function onUploadSuccess(clipUrl)
            if uploadHandled then return end
            uploadHandled = true
            BanClipLog("Direct Node Discord upload SUCCESS requestId=" .. tostring(requestId) .. " url=" .. tostring(clipUrl))
            TriggerEvent("VexShield:ScreenshotTaken", nil, nil, banForFu, clipUrl, requestId, src)
            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, clipUrl)
            if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                VexShieldRuntime.ClearBanClipPending(src, requestId)
            end
        end

        local function onUploadFail(errReason)
            if uploadHandled then return end
            uploadHandled = true
            BanClipLog("Direct Node Discord upload FAILED (" .. tostring(errReason) .. ") requestId=" .. tostring(requestId))
            TriggerClientEvent("VexShield:BanClipUploadDone", src, requestId, nil)
            if VexShieldRuntime and VexShieldRuntime.ClearBanClipPending then
                VexShieldRuntime.ClearBanClipPending(src, requestId)
            end
        end

        local evHandler = nil
        evHandler = AddEventHandler("VexShield:InternalUploadBanClipResult", function(resReqId, clipUrl, clipErr, resBanId, resSrc)
            if tostring(resReqId) == tostring(requestId) then
                if evHandler then
                    RemoveEventHandler(evHandler)
                    evHandler = nil
                end
                if clipUrl and clipUrl ~= "" then
                    onUploadSuccess(clipUrl)
                else
                    onUploadFail(clipErr)
                end
            end
        end)

        TriggerEvent("VexShield:InternalUploadBanClip", wh, fullb64, requestId, banForFu, src)

        for _, rName in ipairs({ currentRes, "VexShield", "VexShield_Resource" }) do
            if not uploadHandled then
                pcall(function()
                    if exports[rName] and exports[rName].UploadBanClipToDiscord then
                        exports[rName]:UploadBanClipToDiscord(wh, fullb64, function(cUrl, cErr)
                            if cUrl and cUrl ~= "" then
                                onUploadSuccess(cUrl)
                            end
                        end)
                    end
                end)
            end
        end

        SetTimeout(20000, function()
            if not uploadHandled then
                onUploadFail("timeout")
            end
        end)
    end)
end)


local pendingBanDiscordLogs = {}

sendDiscordLog = function(player, reason, newBanId, skipBanClip)
    local playerName = GetPlayerName(player)
    if not playerName then 
        print('^2[VexShield]^1 | INVALID PLAYER ID')
        return 
    end

    TriggerClientEvent("VexShield:TakeScreenshot", player, reason, Config.screenshotWebhook, newBanId, skipBanClip == true)

    if newBanId and newBanId ~= "" and newBanId ~= "Unknown" then
        local bId = tostring(newBanId)
        local rawIp = GetPlayerEndpoint(player)
        local cleanIp = rawIp and (rawIp:match("(%d+%.%d+%.%d+%.%d+)") or rawIp) or nil
        if VexShieldRuntime and VexShieldRuntime.GetBanContext then
            local ctx = VexShieldRuntime.GetBanContext(bId)
            if ctx then
                if cleanIp and (not ctx.ip or ctx.ip == "Unknown" or ctx.ip == "Unknown" or ctx.ip == "Null") then
                    ctx.ip = cleanIp
                end
            elseif VexShieldRuntime.SetBanContext then
                local ids = GetPlayerIdentifiers(player)
                if ids and #ids > 0 then
                    VexShieldRuntime.SetBanContext(bId, {
                        banId = bId,
                        name = playerName,
                        reason = reason,
                        createdAt = os.time(),
                        identifiers = ids,
                        ip = cleanIp,
                    })
                end
            end
        end
        pendingBanDiscordLogs[bId] = false
        local isClipActive = Config and Config.BanClipEnabled == true and not skipBanClip
        local timeoutMs = isClipActive and 18000 or 5000
        Citizen.SetTimeout(timeoutMs, function()
            if pendingBanDiscordLogs[bId] == false then
                print("^3[VexShield] Screenshot/Clip fallback — sending Discord ban embed for banId=" .. bId .. "^0")
                TriggerEvent("VexShield:InternalSendBanEmbedFallback", player, reason, bId)
            end
        end)
    end
end

local function VexShieldExtractLevel(reason)
    local r = tostring(reason or "")
    local digit = r:match("[#%s_vV](%d+)") or r:match("(%d+)$")
    if digit then
        local num = tonumber(digit)
        if num == 1 then return "L1"
        elseif num == 2 then return "L2"
        elseif num >= 3 then return "L3"
        end
    end
    if VexShieldResolveProtectionKey then
        local key = VexShieldResolveProtectionKey(reason)
        if key then
            local keyDigit = key:match("(%d+)$")
            if keyDigit then
                local num = tonumber(keyDigit)
                if num == 1 then return "L1"
                elseif num == 2 then return "L2"
                elseif num >= 3 then return "L3"
                end
            end
        end
    end
    return "L1"
end

RegisterServerEvent("VexShield:InternalSendBanEmbedFallback")
AddEventHandler("VexShield:InternalSendBanEmbedFallback", function(player, reason, newBanId)
    local targetSrc = tonumber(player)
    TriggerEvent("VexShield:ScreenshotTaken", nil, reason, newBanId, nil, "", targetSrc)
end)

-- Neue Funktion für Screenshot-Verarbeitung
RegisterNetEvent("VexShield:ScreenshotTaken", function(screenshotUrl, reason, newBanId, clipUrl, banClipRequestId, overrideSrc)
    local src = (source and tonumber(source) and tonumber(source) > 0) and tonumber(source) or (overrideSrc and tonumber(overrideSrc))
    
    if newBanId and newBanId ~= "" and newBanId ~= "Unknown" then
        local bId = tostring(newBanId)
        if pendingBanDiscordLogs[bId] == true then
            print("^3[VexShield] ScreenshotTaken: Ban embed already sent for banId=" .. bId .. " — skipping duplicate.^0")
            return
        end
        pendingBanDiscordLogs[bId] = true
    end

    local rid = type(banClipRequestId) == "string" and banClipRequestId:gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 96) or ""
    local ridLog = rid ~= "" and (" banClipReq=" .. rid) or ""
    print("^2[VexShield]^0 ScreenshotTaken from src=" .. tostring(src) .. " banId=" .. tostring(newBanId) .. " shot=" .. tostring(screenshotUrl and "yes" or "no") .. " clip=" .. tostring(clipUrl and "yes" or "no") .. ridLog)
    
    if (not clipUrl or clipUrl == "") and rid ~= "" then
        if VexShieldRuntime and VexShieldRuntime.MarkClipFollowUpNeeded then
            VexShieldRuntime.MarkClipFollowUpNeeded(rid, tostring(newBanId or ""))
        end
    end

    local ctx = VexShieldRuntime and VexShieldRuntime.GetBanContext and VexShieldRuntime.GetBanContext(newBanId) or nil

    if not reason or reason == "" or reason == "No reason provided" then
        if ctx and ctx.reason then reason = ctx.reason end
    end

    if not Config.logsBans or Config.logsBans == "" then
        print("^1[VexShield] Config.logsBans is empty — ban Discord webhook was not sent.^0")
        return
    end

    -- Collect player identifiers safely with pcall
    local license, steamID, liveid, xblid, discord, playerip = "Unknown", "no linked", "no linked", "no linked", "no linked", "Unknown"
    local ids = {}
    if ctx and type(ctx.identifiers) == "table" then
        ids = ctx.identifiers
    elseif src and type(src) == "number" and src > 0 then
        local okIds, resIds = pcall(GetPlayerIdentifiers, src)
        if okIds and type(resIds) == "table" then
            ids = resIds
        end
    end

    for _, v in ipairs(ids) do
        if type(v) == "string" then
            if string.sub(v, 1, 8) == "license:" then
                license = v
            elseif string.sub(v, 1, 6) == "steam:" then
                steamID = v
            elseif string.sub(v, 1, 5) == "live:" then
                liveid = v
            elseif string.sub(v, 1, 4) == "xbl:" then
                xblid = v
            elseif string.sub(v, 1, 8) == "discord:" then
                local did = string.sub(v, 9)
                discord = "<@" .. did .. ">"
            elseif string.sub(v, 1, 3) == "ip:" then
                playerip = string.sub(v, 4)
            end
        end
    end

    -- Fallback from cached BanContext if missing
    if ctx then
        if license == "Unknown" and ctx.license then license = ctx.license end
        if steamID == "no linked" and ctx.steam then steamID = ctx.steam end
        if discord == "no linked" and ctx.discord then discord = ctx.discord end
        if playerip == "Unknown" and ctx.ip then playerip = ctx.ip end
    end

    -- Get player name safely
    local playerName = "Unknown"
    if src and type(src) == "number" and src > 0 then
        local okName, resName = pcall(GetPlayerName, src)
        if okName and resName and resName ~= "" then
            playerName = resName
        end
    end
    if playerName == "Unknown" and ctx and ctx.name then
        playerName = ctx.name
    end

    -- If newBanId is not provided, try to retrieve it from ban.json
    if not newBanId or newBanId == "Unknown" then
        local bansFile = LoadResourceFile(GetCurrentResourceName(), "html/ban.json")
        if bansFile then
            local bans = json.decode(bansFile) or {}
            for i = #bans, 1, -1 do
                local ban = bans[i]
                if ban and (ban.license == license or ban.name == playerName) then
                    newBanId = ban.id
                    break
                end
            end
        end
    end

    if (not newBanId or newBanId == "Unknown" or newBanId == "") and ctx and ctx.banId then
        newBanId = ctx.banId
    end

    -- Clean IP address properly (strip "ip:" prefix and ports)
    local rawIp = (ctx and ctx.ip and ctx.ip ~= "" and ctx.ip ~= "Unknown") and ctx.ip or playerip
    local cleanIp = tostring(rawIp or ""):gsub("^ip:", ""):gsub(":%d+$", ""):gsub("%s+", "")
    local ipAddress = (cleanIp ~= "" and cleanIp ~= "Unknown" and cleanIp ~= "Null") and cleanIp or "Unknown"
    if ipAddress == "Unknown" and src and type(src) == "number" and src > 0 then
        local okEp, endpoint = pcall(GetPlayerEndpoint, src)
        if okEp and endpoint then
            ipAddress = tostring(endpoint):gsub("^ip:", ""):gsub(":%d+$", ""):gsub("%s+", "")
        end
    end

    local banDiscordPosted = false
    local banDiscordPosting = false
    local function postBanDiscordEmbed(CITY, lat, lon, cc)
        if banDiscordPosted or banDiscordPosting then
            return
        end

        local banIdDisplay = (newBanId and newBanId ~= "" and newBanId ~= "Unknown") and tostring(newBanId) or "1"
        local steamDisplay = (steamID and steamID ~= "Null" and steamID ~= "Unknown") and steamID or "no linked"
        local xboxDisplay = (xblid and xblid ~= "Null" and xblid ~= "Unknown" and xblid ~= "no linked") and xblid or "no linked"
        local liveDisplay = (liveid and liveid ~= "Null" and liveid ~= "Unknown" and liveid ~= "no linked") and liveid or "no linked"

        local gmap = "not available"
        if lat and lon then
            gmap = "[google map](https://www.google.com/maps/search/?api=1&query=" .. tostring(lat) .. "," .. tostring(lon) .. ")"
        elseif CITY and CITY ~= "Not Taken" and CITY ~= "" then
            gmap = "[google map](https://www.google.com/maps/search/?api=1&query=" .. tostring(CITY) .. ")"
        end
        
        local cityDisplay = "Not Taken"
        if CITY and CITY ~= "Not Taken" and CITY ~= "" then
            local flag = "🌍"
            if cc and #cc == 2 then
                local ok, v = pcall(function()
                    local base = 0x1F1E6
                    local a = string.byte(string.upper(cc), 1) - string.byte("A") + base
                    local b = string.byte(string.upper(cc), 2) - string.byte("A") + base
                    return utf8.char(a, b)
                end)
                if ok and v then flag = v end
            end
            cityDisplay = flag .. " " .. tostring(CITY)
        end

        local nameValue = (playerName and playerName ~= "") and tostring(playerName) or "Unknown"
        local banIdValue = "#" .. tostring((banIdDisplay and banIdDisplay ~= "" and banIdDisplay ~= "Unknown") and banIdDisplay or "1")
        local discordValue = (discord and discord ~= "Null" and discord ~= "" and discord ~= "no linked") and tostring(discord) or "*None Linked*"
        local licenseValue = (license and license ~= "Null" and license ~= "") and tostring(license) or "Unknown"
        local steamDisplay = (steamDisplay and steamDisplay ~= "" and steamDisplay ~= "no linked" and steamDisplay ~= "Null") and steamDisplay or "*None Linked*"
        local xboxDisplay = (xboxDisplay and xboxDisplay ~= "" and xboxDisplay ~= "no linked" and xboxDisplay ~= "Null") and xboxDisplay or "*None Linked*"
        local liveDisplay = (liveDisplay and liveDisplay ~= "" and liveDisplay ~= "no linked" and liveDisplay ~= "Null") and liveDisplay or "*None Linked*"

        local ipValue = (ipAddress and ipAddress ~= "" and ipAddress ~= "Unknown") and tostring(ipAddress) or "Unknown"
        local formattedReason = VexShieldFormatReason(reason)

        local banType, banDetails = VexShieldClassifyReason(reason)
        local banLevel = VexShieldExtractLevel(reason)

        local playerProfileText = string.format(
            "> 👤 **Player Name:** `%s` *(Server ID: `%s`)*\n> 🛡️ **Ban Reference:** `%s`\n> 💬 **Discord:** %s",
            nameValue, tostring(src or "?"), banIdValue, discordValue
        )

        local violationIntelText = string.format(
            "> ⚠️ **Violation:** `%s`\n> 🏷️ **Category:** `%s`  •  **Threat Tier:** `🔴 %s`\n> ⚙️ **Engine:** `VexShield Core vBeta (Kernel Mode)`",
            formattedReason, tostring(banType or "General Exploit"), tostring(banLevel or "L1")
        )

        local identifiersText = string.format(
            "> 🔑 **License:** `%s`\n> 🎮 **Steam:** `%s`\n> 🎯 **Xbox / Live:** `%s` • `%s`",
            licenseValue, steamDisplay, xboxDisplay, liveDisplay
        )

        local networkGeoText = string.format(
            "> 🌐 **IP Address:** ||`%s`||\n> 📍 **Location:** %s\n> 🗺️ **Map:** %s",
            ipValue, tostring(cityDisplay or "Unknown"), tostring(gmap or "N/A")
        )

        local embedFields = {
            { ["name"] = "─── 👤 TARGET PROFILE ───", ["value"] = playerProfileText, ["inline"] = false },
            { ["name"] = "─── ⚡ VIOLATION INTEL ───", ["value"] = violationIntelText, ["inline"] = false },
            { ["name"] = "─── 🔐 HARDWARE & IDENTIFIERS ───", ["value"] = identifiersText, ["inline"] = false },
            { ["name"] = "─── 🌍 NETWORK & LOCATION ───", ["value"] = networkGeoText, ["inline"] = false },
        }

        if ctx and type(ctx.extraFields) == "table" then
            for _, f in ipairs(ctx.extraFields) do
                table.insert(embedFields, f)
            end
        end

        -- Add entity information for all spawn detections and entity detections
        local reasonLower = tostring(reason or ""):lower()
        local isSpawnDetection = reasonLower:find("spawn", 1, true) ~= nil 
            or reasonLower:find("object", 1, true) ~= nil 
            or reasonLower:find("ped", 1, true) ~= nil 
            or reasonLower:find("vehicle", 1, true) ~= nil
            or reasonLower:find("weapon", 1, true) ~= nil

        local entType = (ctx and ctx.entityType and ctx.entityType ~= "Unknown") and ctx.entityType or nil
        if not entType and isSpawnDetection then
            if reasonLower:find("ped", 1, true) then entType = "Ped"
            elseif reasonLower:find("object", 1, true) or reasonLower:find("prop", 1, true) then entType = "Object/Prop"
            elseif reasonLower:find("weapon", 1, true) then entType = "Weapon"
            elseif reasonLower:find("vehicle", 1, true) then entType = "Vehicle"
            else entType = "Entity" end
        end

        local entHash = (ctx and ctx.entityHash and ctx.entityHash ~= "Unknown") and ctx.entityHash or nil
        local modelName, unsignedHash = VexShieldResolveModelName(entHash, entType)
        if entType or entHash then
            local modelDisplay = modelName or tostring(unsignedHash or entHash or "Unknown")
            if unsignedHash then
                modelDisplay = "[" .. modelDisplay .. "](https://gtahash.ru/car/?s=" .. tostring(unsignedHash) .. ")"
            end
            local entText = string.format(
                "> 📦 **Type:** `%s`  •  **Model:** %s\n> 🔢 **Entity Hash:** ||`%s`||",
                tostring(entType or "Entity"), modelDisplay, tostring(entHash or "Unknown")
            )
            table.insert(embedFields, { ["name"] = "─── 📦 INTERCEPTED ENTITY ───", ["value"] = entText, ["inline"] = false })
        end

        if clipUrl and clipUrl ~= "" then
            local u = tostring(clipUrl):gsub("%(", "%%28"):gsub("%)", "%%29")
            table.insert(embedFields, {
                ["name"] = "─── 📹 VIOLATION RECORDING ───",
                ["value"] = "> 🎬 **Automated Proof Clip:** [▶️ Watch In-Game WebM Recording](" .. u .. ")",
                ["inline"] = false,
            })
        end

        local embed = {{
            ["color"] = 16711765, -- Neon Crimson (#FF0055)
            ["title"] = "🛡️ Security Enforcement — Player Banned",
            ["description"] = "> 🚨 **Security breach neutralized by VexShield Engine.**\n> *The offending player has been permanently revoked from the server.*",
            ["url"] = "https://vexshield.site",
            ["fields"] = embedFields,
            ["footer"] = {
                ["text"] = "VexShield vBeta Enterprise • Active Protection",
                ["icon_url"] = VexShield_EMBED_FOOTER_ICON
            },
            ["thumbnail"] = {
                ["url"] = VexShield_EMBED_LOGO
            },
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }}

        if clipUrl and newBanId then
            VexShieldPersistBanEvidence(newBanId, nil, clipUrl)
        end

        local banDiscordPayload = {
            username = "VexShield Security",
            avatar_url = VexShield_EMBED_LOGO,
            embeds = VexShieldBrandEmbeds(embed),
        }

        if clipUrl and clipUrl ~= "" then
            local compStr = VexShieldDiscordLinkButtonRowJson(clipUrl)
            if compStr then
                local okComp, parsedComp = pcall(json.decode, compStr)
                if okComp and type(parsedComp) == "table" then
                    banDiscordPayload.components = parsedComp
                end
            end
        end

        local okEnc, payloadStr = pcall(json.encode, banDiscordPayload)
        if not okEnc or type(payloadStr) ~= "string" then
            print("^1[VexShield] Ban Discord payload json.encode failed.^0")
            return
        end

        local kickMessage = VexShieldFormatKickMessage(newBanId or banIdDisplay, reason)
        local function postBanDiscordFallback(statusCode, text)
            local snippet = type(text) == "string" and text:sub(1, 300) or ""
            print("^1[VexShield] Ban Discord webhook HTTP " .. tostring(statusCode) .. " " .. snippet .. "^0")

            local fbType, fbDetails = VexShieldClassifyReason(reason)
            local fbLevel = VexShieldExtractLevel(reason)
            local fallbackFields = {
                { ["name"] = "Name", ["value"] = tostring(playerName or "Unknown"), ["inline"] = true },
                { ["name"] = "Ban ID", ["value"] = tostring(banIdDisplay or "Unknown"), ["inline"] = true },
                { ["name"] = "Reason", ["value"] = tostring(reason or "No reason provided"):sub(1, 900), ["inline"] = true },
                { ["name"] = "Type", ["value"] = "||" .. fbLevel .. "||", ["inline"] = true },
                { ["name"] = "Category", ["value"] = "||" .. tostring(fbType) .. "||", ["inline"] = true },
                { ["name"] = "Details", ["value"] = "||" .. tostring(fbDetails) .. "||", ["inline"] = true },
            }
            if clipUrl and clipUrl ~= "" then
                table.insert(fallbackFields, { ["name"] = "Clip", ["value"] = "[open clip](" .. tostring(clipUrl):gsub("%(", "%%28"):gsub("%)", "%%29") .. ")", ["inline"] = false })
            end

            local fallbackPayload = {
                username = "VexShield",
                avatar_url = VexShield_EMBED_LOGO,
                embeds = VexShieldBrandEmbeds({{
                    color = 3447003,
                    title = "Player Banned",
                    fields = fallbackFields,
                }})
            }
            local okFallback, fallbackStr = pcall(json.encode, fallbackPayload)
            if okFallback and type(fallbackStr) == "string" then
                PerformHttpRequest(Config.logsBans, function(code2, body2)
                    if code2 ~= 204 and code2 ~= 200 then
                        print("^1[VexShield] Ban Discord fallback webhook HTTP " .. tostring(code2) .. " " .. (type(body2) == "string" and body2:sub(1, 300) or "") .. "^0")
                    end
                end, "POST", fallbackStr, { ["Content-Type"] = "application/json" })
            end
        end

        banDiscordPosting = true
        PerformHttpRequest(Config.logsBans, function(statusCode, text, headers)
            if statusCode ~= 204 and statusCode ~= 200 then
                postBanDiscordFallback(statusCode, text)
            else
                banDiscordPosted = true
            end
            banDiscordPosting = false
            local hasClip = (type(clipUrl) == "string" and clipUrl ~= "")
            local clipFlowDisabled = (rid == "")
            local allowKickNow = clipFlowDisabled or hasClip
            if allowKickNow and src and type(src) == "number" and src > 0 then
                local okName = pcall(GetPlayerName, src)
                if okName then
                    if VexShieldRuntime and VexShieldRuntime.PendingBanKickBySrc then
                        VexShieldRuntime.PendingBanKickBySrc[src] = nil
                    end
                    pcall(DropPlayer, src, kickMessage)
                end
            end
        end, "POST", payloadStr, {
            ["Content-Type"] = "application/json",
        })
    end

    if ipAddress ~= "Unknown" and ipAddress ~= "127.0.0.1" and not ipAddress:find("^192%.168%.") and not ipAddress:find("^10%.") and not ipAddress:find("^172%.") then
        PerformHttpRequest("http://ipwho.is/" .. tostring(ipAddress), function(code, body)
            local CITY, lat, lon, cc = "Not Taken", nil, nil, nil
            if body and body ~= "" then
                local okJson, data = pcall(json.decode, body)
                if okJson and type(data) == "table" and (data.success == true or data.city) then
                    CITY = data.city or "Not Taken"
                    lat = data.latitude or data.lat
                    lon = data.longitude or data.lon
                    cc = data.country_code or data.countryCode
                end
            end
            if CITY ~= "Not Taken" and lat and lon then
                postBanDiscordEmbed(CITY, lat, lon, cc)
            else
                PerformHttpRequest("http://ip-api.com/json/" .. tostring(ipAddress) .. "?fields=66846719", function(_err, DATA, _headers)
                    local CITY2, lat2, lon2, cc2 = "Not Taken", nil, nil, nil
                    if DATA ~= nil then
                        local okIp, TABLE = pcall(json.decode, DATA)
                        if okIp and type(TABLE) == "table" then
                            CITY2 = TABLE["city"] or "Not Taken"
                            lat2 = TABLE["lat"]
                            lon2 = TABLE["lon"]
                            cc2 = TABLE["countryCode"]
                        end
                    end
                    postBanDiscordEmbed(CITY2, lat2, lon2, cc2)
                end, "GET", "", { ["Content-Type"] = "application/json" })
            end
        end, "GET", "", { ["User-Agent"] = "Mozilla/5.0" })

        Citizen.SetTimeout(6000, function()
            postBanDiscordEmbed("Not Taken", nil, nil, nil)
        end)
    else
        postBanDiscordEmbed("Not Taken", nil, nil, nil)
    end
end)




local ENCRYPTED_WEBHOOK122 = base64_encode(VexShieldPickWebhook(
    "VexShield_legacy_ban_webhook",
    Config and Config.logsBans,
    Config and Config.logsWebhook,
    Config and Config.mainLogs
))

sendLogsOnlyWebhook = function(player, reason, kind)
    kind = kind or "logs"
    -- Enforcement "logs" / kick log lines must NOT use Config.logsBans (ban channel + rich ban embed flow).
    local function pickEnforcementLogWebhook()
        local function pick(s)
            if type(s) ~= "string" then return nil end
            s = s:gsub("^%s+", ""):gsub("%s+$", "")
            if s == "" then return nil end
            return s
        end
        return pick(Config.logsWebhook)
            or pick(Config.logsConnection)
            or pick(Config.logsBans)
    end
    local webhook = pickEnforcementLogWebhook()
    if not webhook or webhook == "" then
        print("^3[VexShield] Enforcement is set to logs/kick but no logs webhook is configured. "
            .. "Set Config.logsWebhook (recommended) or Config.mainLogs / TriggerResourceslogs / logsConnection — "
            .. "NOT Config.logsBans (that channel is for bans only).^0")
        return
    end
    local playerName = GetPlayerName(player) or "Unknown"
    local title = "Detection Logged (No Action)"
    local color = 3447003
    if kind == "kick" then
        title = "Player Kicked"
        color = 15105570
    end
    local info = VexShieldExtractPlayerIdentity(player)
    info.name = playerName
    VexShieldSendStyledWebhook(webhook, {
        title = title,
        color = color,
        playerInfo = info,
        reason = reason or "Unknown",
    })
end

sendDiscordLogbanlogs = function(player, reason)
    local playerName = GetPlayerName(player)
    if not playerName then 
        print('^2[VexShield]^1 | INVALID PLAYER ID')
        return 
    end

    -- Ban flow already posts the full embed to Config.logsBans via sendDiscordLog → VexShield:ScreenshotTaken.
    -- The old hard-coded ENCRYPTED_WEBHOOK122 often 404s; skip duplicate/minimal post when logsBans is configured.
    local lb = Config and Config.logsBans
    if type(lb) == "string" and lb:gsub("^%s+", ""):gsub("%s+$", "") ~= "" then
        return
    end

    local webhook_url122 = base64_decode(ENCRYPTED_WEBHOOK122)
    if not webhook_url122 or webhook_url122 == "" then
        print("^1[VexShield] sendDiscordLogbanlogs: Config.logsBans empty and no ENCRYPTED_WEBHOOK122 fallback.^0")
        return
    end

    -- Do not TriggerClientEvent("VexShield:TakeScreenshot") here: ban flow already calls
    -- sendDiscordLog → TakeScreenshot with ban id. A second TakeScreenshot invalidates the
    -- first client capture (banCaptureGen) so the embed webhook never runs while Discord still gets a raw upload.

    local embed = {
        {
            ["color"] = 3092790,
            ["title"] = "Player Banned",
            ["fields"] = {
                { ["name"] = "Name", ["value"] = playerName, ["inline"] = true },
                { ["name"] = "Reason", ["value"] = reason or "No reason provided", ["inline"] = false }
            },
        }
    }

    PerformHttpRequest(webhook_url122, function(err, text, headers)
        if err ~= 204 and err ~= 200 then
            print('^1[ERROR] Discord webhook fout:', err, '^7')
        end
    end, 'POST', json.encode({ 
        username = "VexShield",
        avatar_url = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless",
        embeds = VexShieldBrandEmbeds(embed)
    }), {
        ['Content-Type'] = 'application/json'
    })
end

RegisterCommand("testbanlog", function()
    print("send test")
    sendDiscordLog(1, "Anti Freecam #2")
end)

-- Test-Befehl für Screenshot ohne Ban
RegisterCommand("testscreenshot", function(source, args)
    local playerId = source
    if args[1] then
        playerId = tonumber(args[1])
    end
    
    if not playerId or playerId == 0 then
        print("^1[ERROR] Ungültige Spieler-ID^7")
        return
    end
    
    local playerName = GetPlayerName(playerId)
    if not playerName then
        print("^1[ERROR] Spieler nicht gefunden^7")
        return
    end
    
    print("^2[SCREENSHOT TEST]^7 Screenshot wird von " .. playerName .. " gemacht...")
    
    -- Screenshot ohne Ban machen
    TriggerClientEvent("VexShield:TakeScreenshot", playerId, "Screenshot Test - Kein Ban", Config.screenshotWebhook)
end, false)

-- Test-Befehl für Screenshot ohne Ban
RegisterCommand("testscreenshot2", function(source, args)
    local playerId = source
    if args[1] then
        playerId = tonumber(args[1])
    end
    
    if not playerId or playerId == 0 then
        print("^1[ERROR] Ungültige Spieler-ID^7")
        return
    end
    
    local playerName = GetPlayerName(playerId)
    if not playerName then
        print("^1[ERROR] Spieler nicht gefunden^7")
        return
    end
    
    print("^2[SCREENSHOT TEST]^7 Screenshot wird von " .. playerName .. " gemacht...")
    
    -- Screenshot ohne Ban machen
    sendDiscordLog(playerId, reason)
end, false)

-- Admin-Befehl für Screenshot-Test
RegisterCommand("adminscreenshot", function(source, args)
    if source == 0 then
        -- Console kann jeden Spieler testen
        if not args[1] then
            print("^1[ERROR] Bitte geben Sie eine Spieler-ID an^7")
            return
        end
        
        local playerId = tonumber(args[1])
        local playerName = GetPlayerName(playerId)
        if not playerName then
            print("^1[ERROR] Spieler nicht gefunden^7")
            return
        end
        
        print("^2[ADMIN SCREENSHOT]^7 Screenshot wird von " .. playerName .. " gemacht...")
        TriggerClientEvent("VexShield:TakeScreenshot", playerId, "Admin Screenshot Test", Config.screenshotWebhook)
    else
        -- Spieler können nur sich selbst testen
        local playerName = GetPlayerName(source)
        print("^2[ADMIN SCREENSHOT]^7 Screenshot wird von " .. playerName .. " gemacht...")
        TriggerClientEvent("VexShield:TakeScreenshot", source, "Admin Screenshot Test", Config.screenshotWebhook)
    end
end, false)


-- Locales = {
--     ['en'] = {
--         banTitle = "You have been banned by the VexShield",
--         banMessage = "You have been banned from",
--         steamRequired = "You need to have your Steam open",
--         vpnDetected = "You cannot join if you have a VPN enabled",
--         blacklisted = "You have been blacklisted by Air Shield",
--         tosHeader = "**Air Shield | IMPORTANT**",
--         tosInfo = "Please make sure your ReShade settings are set to **'All Input'** to avoid visual issues.",
--         tosContinue = "Click the button below to continue joining.",
--         reshadeConfirm = "Did you really read it and if not check below",
--         connecting = "Connecting to server...",
--         steamKick = "Connection rejected: Steam must be open to connect.",
--         vpnKick = "Connection rejected: VPN detected.",
--         blacklistKick = "Connection rejected: You have been blacklisted by Air Shield.",
--         tosDecline = "You must accept the terms to join."
--     },
--     ['nl'] = {
--         banTitle = "Je bent verbannen door de VexShield",
--         banMessage = "Je bent verbannen van",
--         steamRequired = "Je moet Steam open hebben staan",
--         vpnDetected = "Je kunt niet joinen met een VPN ingeschakeld",
--         blacklisted = "Je bent geblacklist door Air Shield",
--         tosHeader = "**Air Shield | BELANGRIJK**",
--         tosInfo = "Zorg dat je ReShade-instellingen op **'All Input'** staan om visuele problemen te voorkomen.",
--         tosContinue = "Klik op de knop hieronder om verder te gaan.",
--         reshadeConfirm = "Heb je het echt gelezen? Zo niet, check hieronder.",
--         connecting = "Verbinden met de server...",
--         steamKick = "Verbinding geweigerd: Steam moet open zijn om te verbinden.",
--         vpnKick = "Verbinding geweigerd: VPN gedetecteerd.",
--         blacklistKick = "Verbinding geweigerd: Je bent geblacklist door Air Shield.",
--         tosDecline = "Je moet akkoord gaan met de voorwaarden om te joinen."
--     },
--     -- Voeg hier 'de', 'fr', 'sp' toe als je wilt
-- }

-- function _L(key)
--     return Locales[Config.Language][key] or key
-- end

-- print("[DEBUG] Gekozen taal uit config: " .. tostring(Config.Language))
-- print("[DEBUG] Tekst voor 'banTitle': " .. tostring(Locales[Config.Language] and Locales[Config.Language].banTitle or "GEEN"))


-- Volledige playerConnecting event met taalondersteuning op basis van Config.Language
end

-- XSS Detection Function
function detectXSS(username)
    if not username or type(username) ~= "string" then
        return false
    end
    
    local nameLower = string.lower(username)
    local nameOriginal = username
    
    -- Check for HTML tags (case-insensitive)
    local htmlTags = {
        "<meta", "<script", "<iframe", "<img", "<svg", "<body", "<style", 
        "<link", "<embed", "<object", "<form", "<input", "<textarea", 
        "<select", "<button", "<frame", "<frameset", "<applet", "<base",
        "<div", "<span", "<p", "<a", "<html", "<head", "<title"
    }
    
    for _, tag in ipairs(htmlTags) do
        if nameLower:find(string.lower(tag), 1, true) then
            return true
        end
    end
    
    -- Check for HTML attributes with event handlers
    local eventHandlers = {
        "onerror", "onload", "onclick", "onmouseover", "onmouseout",
        "onfocus", "onblur", "onchange", "onsubmit", "onreset",
        "onselect", "onunload", "ondblclick", "onkeydown", "onkeyup",
        "onkeypress", "onmousedown", "onmouseup", "onmousemove",
        "http-equiv", "content", "src", "href", "action"
    }
    
    for _, handler in ipairs(eventHandlers) do
        if nameLower:find(string.lower(handler), 1, true) then
            return true
        end
    end
    
    -- Check for JavaScript URLs
    if nameLower:find("javascript:", 1, true) then
        return true
    end
    
    -- Check for HTML entities (encoded XSS attempts)
    local htmlEntities = {
        "&lt;", "&gt;", "&#60;", "&#62;", "&#x3c;", "&#x3e;",
        "&quot;", "&#34;", "&#x22;", "&#39;", "&#x27;",
        "&amp;", "&#38;", "&#x26;"
    }
    
    for _, entity in ipairs(htmlEntities) do
        if nameLower:find(string.lower(entity), 1, true) then
            return true
        end
    end
    
    -- Check for specific XSS patterns
    local xssPatterns = {
        "http-equiv.*refresh",  -- Meta refresh redirects
        "http-equiv.*content",  -- Meta content attribute
        "<meta.*refresh",       -- Meta refresh tag
        "expression%(",         -- CSS expression
        "url%(",                -- CSS url()
        "import",               -- CSS @import
        "document%.cookie",     -- JavaScript cookie access
        "document%.write",      -- JavaScript document.write
        "window%.location",     -- JavaScript redirect
        "eval%(",               -- JavaScript eval
        "fromcharcode",         -- String.fromCharCode
        "unescape",             -- JavaScript unescape
        "decodeuri",            -- JavaScript decodeURI
        "<svg.*onload",         -- SVG onload
        "<img.*onerror",        -- Image onerror
        "alert%(",              -- JavaScript alert
        "prompt%(",             -- JavaScript prompt
        "confirm%("             -- JavaScript confirm
    }
    
    for _, pattern in ipairs(xssPatterns) do
        if nameLower:find(pattern) then
            return true
        end
    end
    
    -- Check for angle brackets and potentially dangerous characters
    if nameOriginal:find("[<>]") then
        return true
    end
    
    return false
end

function safeGetPlayerIdentifiers(playerSrc)
    local pid = tonumber(playerSrc)
    if not pid or pid <= 0 then return {} end
    local ok, result = pcall(GetPlayerIdentifiers, pid)
    if ok and type(result) == "table" then return result end
    return {}
end

function safeBuildPlayerTokens(playerSrc)
    local pid = tonumber(playerSrc)
    if not pid or pid <= 0 then return {}, 0 end
    local okN, n = pcall(GetNumPlayerTokens, pid)
    local tokenCount = (okN and type(n) == "number" and n >= 0) and math.floor(n) or 0
    local tokens = {}
    for i = 0, tokenCount - 1 do
        local okT, t = pcall(GetPlayerToken, pid, i)
        if okT and t then
            tokens[#tokens + 1] = t
        end
    end
    sortPlayerTokens(tokens)
    return tokens, tokenCount
end

local CONNECT_UNKNOWN_ID = "Unknown"

function connectIdentifier(identifiers, exactPrefix)
    for _, id in ipairs(identifiers) do
        if id:sub(1, #exactPrefix) == exactPrefix then
            return id
        end
    end
    return CONNECT_UNKNOWN_ID
end

function isKnownConnectIdentifier(value)
    return value and value ~= "" and value ~= CONNECT_UNKNOWN_ID
end

-- Match bans by license/steam first; never flag on shared IP/token overlap alone.
function findMatchingBanRecord(bans, identifiers, license, steam, hwid, connectTokenFingerprint)
    local license2 = connectIdentifier(identifiers, "license2:")
    local discord = connectIdentifier(identifiers, "discord:")
    local fivem = connectIdentifier(identifiers, "fivem:")
    local xbl = connectIdentifier(identifiers, "xbl:")

    local function matchesPrimary(ban)
        if isKnownConnectIdentifier(license) and ban.license and ban.license == license then return true end
        if isKnownConnectIdentifier(license2) and ban.license2 and ban.license2 == license2 then return true end
        if isKnownConnectIdentifier(license) and ban.player_id and ban.player_id == license then return true end
        local pid = ban.player_id
        if pid and pid ~= "" and not tostring(pid):match("^%d+$") then
            if isKnownConnectIdentifier(license) and pid == license then return true end
            if isKnownConnectIdentifier(license2) and pid == license2 then return true end
        end
        if isKnownConnectIdentifier(steam) and ban.steam and ban.steam == steam then return true end
        return false
    end

    local function matchesSecondary(ban)
        if isKnownConnectIdentifier(discord) and ban.discord and ban.discord == discord then return true end
        if isKnownConnectIdentifier(fivem) and ban.fivem and ban.fivem == fivem then return true end
        if isKnownConnectIdentifier(xbl) and ban.xbl and ban.xbl == xbl then return true end
        return false
    end

    local connectTokenHash = hashTokenFingerprint(connectTokenFingerprint)

    local function matchesHardware(ban)
        if isKnownConnectIdentifier(hwid) and ban.hardware_id and ban.hardware_id == hwid then return true end
        local matched, migrateReason = tokenFingerprintMatchesBan(connectTokenFingerprint, connectTokenHash, ban)
        if matched then
            if migrateReason then
                queueBanFingerprintMigration(ban, connectTokenHash)
            end
            return true
        end
        return false
    end

    for _, ban in ipairs(bans) do
        if matchesPrimary(ban) then return ban end
    end
    for _, ban in ipairs(bans) do
        if matchesSecondary(ban) then return ban end
    end
    for _, ban in ipairs(bans) do
        if matchesHardware(ban) then
            flushBanFingerprintMigrations()
            return ban
        end
    end
    flushBanFingerprintMigrations()
    return nil
end

AddEventHandler('playerConnecting', function(pName, pKickReason, pDeferrals)
    local src = tonumber(source)
    if not src or src <= 0 then
        return
    end
    if not pDeferrals then
        return
    end

    pDeferrals.defer()

    if not LICENSE_VALIDATED then
        -- License is invalid/inactive: anticheat does not block player connections, do nothing
        pDeferrals.done()
        return
    end

    local identifiers = safeGetPlayerIdentifiers(src)
    local steam, license, ip, hwid = "Unknown", "Unknown", "Unknown", "Unknown"

    local hasCfxLink = false
    local hasDiscord = false
    local discordId = nil
    for _, id in ipairs(identifiers) do
        if string.match(id, "steam:") then steam = id end
        if id:match("^license:") and not id:match("^license%d:") then license = id end
        if string.match(id, "ip:") then ip = id end
        if string.match(id, "^discord:") then
            hasDiscord = true
            discordId = id
        end
        -- Check for CFX account linking identifiers (license2, license3, etc. are only present when account is linked)
        if string.match(id, "license2:") or string.match(id, "license3:") or string.match(id, "license4:") or string.match(id, "license5:") then
            hasCfxLink = true
        end
    end
    
    -- If player doesn't have CFX account linked and the feature is enabled, reject connection
    if Config.RequireCfxLink and not hasCfxLink then
        pDeferrals.done("You must link your CFX account to FiveM before joining this server. Please visit https://cfx.re/link and follow the instructions to link your account.")
        return
    end


    -- If player doesn't have Discord linked and RequireDiscord is enabled, reject connection with VexShield UI card
    local requireDiscordEnabled = Config.RequireDiscord
    if requireDiscordEnabled == nil and Config.SpoofDetection then
        requireDiscordEnabled = Config.SpoofDetection.RequireDiscord
    end
    if (requireDiscordEnabled == true or requireDiscordEnabled == nil) and not hasDiscord then
        local card = buildMissingDiscordDeferralCard(Config.Servername or "Server Name")
        pDeferrals.presentCard(card)
        CreateThread(function()
            for i = 1, 600 do
                Wait(500)
                pcall(function()
                    pDeferrals.presentCard(card)
                end)
            end
        end)
        return
    end

    do
        local okH, tok0 = pcall(GetPlayerToken, src, 0)
        hwid = (okH and tok0) and tok0 or "Unknown"
    end

    Wait(500)

    -- XSS Detection Check
    if Config.Protections['Anti Xss'] and detectXSS(pName) then
        pDeferrals.done("XSS DETECTED please change your user name to join")
        return
    end

    local nameLower = string.lower(pName or "")
    if Config.BlacklistedNames and type(Config.BlacklistedNames) == "table" then
        for i = 1, #Config.BlacklistedNames do
            local w = Config.BlacklistedNames[i]
            if type(w) == "string" and w ~= "" then
                if nameLower:find(string.lower(w), 1, true) then
                    pDeferrals.done("Your name contains a blacklisted word. Change your name to join.")
                    return
                end
            end
        end
    end

    if isAntiSpoofEnabled() then
        local endpoint = nil
        do
            local okE, ep = pcall(GetPlayerEndpoint, src)
            endpoint = (okE and ep) and ep or nil
        end
        local tokens, tokenCount = safeBuildPlayerTokens(src)
        local tokenFingerprint = buildTokenFingerprint(tokens)
        local tokenFingerprintHash = hashTokenFingerprint(tokenFingerprint)

        local function isPrivateIP(ipaddr)
            if not ipaddr then return true end
            if ipaddr:match("^10%.") then return true end
            if ipaddr:match("^127%.") then return true end
            if ipaddr:match("^192%.168%.") then return true end
            local a,b = ipaddr:match("^(%d+)%.(%d+)")
            a = tonumber(a); b = tonumber(b)
            if a == 172 and b and b >= 16 and b <= 31 then return true end
            return false
        end

        local flags = 0
        local spoofReasons = {}

        -- 1. Check for basic identifier presence
        if (Config.SpoofDetection and Config.SpoofDetection.RequireLicense) and license == "Unknown" then 
            flags = flags + 1 
            table.insert(spoofReasons, "Missing License")
        end
        if (Config.SpoofDetection and Config.SpoofDetection.RequireSteam) and steam == "Unknown" then 
            flags = flags + 1 
            table.insert(spoofReasons, "Missing Steam")
        end

        -- 2. Deep Token Analysis (Powerful like Electron AC)
        local minTokens = (Config.SpoofDetection and Config.SpoofDetection.MinTokens) or 3
        if tokenCount < minTokens then 
            flags = flags + 2 -- High weight for low token count
            table.insert(spoofReasons, "Suspicious Token Count (" .. tokenCount .. ")")
        end

        local allowPrivate = (Config.SpoofDetection and Config.SpoofDetection.AllowPrivateIPs) ~= false
        if (not allowPrivate) and isPrivateIP(endpoint) then 
            flags = flags + 1 
            table.insert(spoofReasons, "Private IP Detected")
        end

        -- 3. Persistent Fingerprinting & Token Recycling Detection
        _G.__fingerprints = _G.__fingerprints or {}
        _G.__tokenHistory = _G.__tokenHistory or {} -- Maps fingerprint -> license
        _G.__ipHistory = _G.__ipHistory or {} -- Maps fingerprint -> last IP

        if tokenFingerprintHash ~= "" then
            -- Token Recycling: Same fingerprint used by multiple licenses
            if _G.__tokenHistory[tokenFingerprintHash] and _G.__tokenHistory[tokenFingerprintHash] ~= license then
                flags = flags + 2
                table.insert(spoofReasons, "Token Recycling Detected (Fingerprint match with different license)")
            else
                _G.__tokenHistory[tokenFingerprintHash] = license
            end

            -- IP Consistency: Check if IP changed drastically for this fingerprint
            if Config.SpoofDetection.CheckIPConsistency and _G.__ipHistory[tokenFingerprintHash] then
                if _G.__ipHistory[tokenFingerprintHash] ~= endpoint then
                    -- Simple IP mismatch check (can be expanded to subnet check)
                    -- For now, we just log it as suspicious
                    -- table.insert(spoofReasons, "IP Inconsistency Detected")
                end
            end
            _G.__ipHistory[tokenFingerprintHash] = endpoint

            -- Generic fingerprint collision
            if _G.__fingerprints[tokenFingerprintHash] and _G.__fingerprints[tokenFingerprintHash] ~= src then
                -- This session collision
                flags = flags + 1
                table.insert(spoofReasons, "Fingerprint Collision (Multiple sessions)")
            else
                _G.__fingerprints[tokenFingerprintHash] = src
            end
        end

        -- 4. P1: Token entropy / structure / reconnect velocity (supporting evidence)
        flags = applyTokenEntropyScoring(tokens, license, flags, spoofReasons)

        local sd = Config.SpoofDetection or {}
        local minFlagsBlock = tonumber(sd.MinFlagsToBlock) or tonumber(sd.MinFlagsToBan) or 2
        local minFlagsBan = tonumber(sd.MinFlagsToBan) or 2
        if minFlagsBan < minFlagsBlock then
            minFlagsBan = minFlagsBlock
        end
        local reasonStr = table.concat(spoofReasons, ", ")
        if flags >= minFlagsBan then
            banPlayertrigger(src, "Identifier Spoofing Detected: " .. reasonStr, "SPOOF-")
            pDeferrals.done("Connection blocked due to identifier spoofing detection (" .. reasonStr .. ").")
            return
        elseif flags >= minFlagsBlock then
            print(("^3[VexShield] Anti-Spoof: blocked connection for %s (flags=%d): %s^7"):format(pName or tostring(src), flags, reasonStr))
            pDeferrals.done("Connection blocked due to identifier verification (" .. reasonStr .. ").")
            return
        end
    end

    local bans = LoadBans()
    if not bans then
        pDeferrals.done("[ERROR] Unable to load bans.json.")
        return
    end

    local connectTokens, _connectTokenCount = safeBuildPlayerTokens(src)
    local connectTokenFingerprint = buildTokenFingerprint(connectTokens)
    local matchedBan = findMatchingBanRecord(bans, identifiers, license, steam, hwid, connectTokenFingerprint)
    local isBanned = matchedBan ~= nil
    local banReason = isBanned and (matchedBan.reason or matchedBan.details or matchedBan.REASON or "Onbekende reden") or "Onbekende reden"
    local banId = isBanned and (matchedBan.id or matchedBan.BANID or matchedBan.ban_id or "0000") or "0000"

    local serverName = Config.Servername or 'Server Naam'

if isBanned then
    print(pName .. ' tried to join but is banned | Ban ID: ' .. banId)
    local screenshotUrl = matchedBan and matchedBan.screenshot_url
    local card = buildBanDeferralCard(serverName, banId, banReason, screenshotUrl)

    pDeferrals.presentCard(card)
    CreateThread(function()
        for i = 1, 600 do
            Wait(500)
            pcall(function()
                pDeferrals.presentCard(card)
            end)
        end
    end)
    return
end

    if Config.RequireSteam and (pName == "Gebruiker" or pName == "user") then
        local card = DeferralCards.Card:Create({
            body = {
                DeferralCards.Container:Create({
                    items = {
                        DeferralCards.CardElement:Image({
                            url = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless',
                            size = 'medium',
                            horizontalAlignment = 'center'
                        }),
                        DeferralCards.CardElement:TextBlock({
                            text = _L("steamRequired"),
                            weight = 'Bolder',
                            size = 'Large',
                            horizontalAlignment = 'center'
                        })
                    },
                    isVisible = true
                })
            }
        })

        pDeferrals.presentCard(card)
        CreateThread(function()
            for i = 1, 600 do
                Wait(500)
                pcall(function()
                    pDeferrals.presentCard(card)
                end)
            end
        end)
        return
    end

    if not legitIP(src) then
        local card = DeferralCards.Card:Create({
            body = {
                DeferralCards.Container:Create({
                    items = {
                        DeferralCards.CardElement:Image({
                            url = 'https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless',
                            size = 'medium',
                            horizontalAlignment = 'center'
                        }),
                        DeferralCards.CardElement:TextBlock({
                            text = _L("vpnDetected"),
                            weight = 'Bolder',
                            size = 'Large',
                            horizontalAlignment = 'center'
                        })
                    },
                    isVisible = true
                })
            }
        })
        pDeferrals.presentCard(card)
        CreateThread(function()
            for i = 1, 600 do
                Wait(500)
                pcall(function()
                    pDeferrals.presentCard(card)
                end)
            end
        end)
        return
    end

    if isBlacklisted(src) then
        local blacklistReason = _L("blacklisted") or "Flagged on VexShield Global Security Blacklist"
        local card = buildBlacklistDeferralCard(serverName, blacklistReason)
        pDeferrals.presentCard(card)
        CreateThread(function()
            for i = 1, 600 do
                Wait(500)
                pcall(function()
                    pDeferrals.presentCard(card)
                end)
            end
        end)
        return
    end


    pDeferrals.update(_L("connecting"))

    local resName = GetCurrentResourceName()
    local okExtras, blocked, kickMsg, deferralsHandled = pcall(function()
        return exports[resName]:CheckConnectingExtras(src, pName, pDeferrals)
    end)
    if not okExtras then
        print("^1[VexShield] CheckConnectingExtras failed: " .. tostring(blocked) .. "^0")
    elseif blocked then
        if not deferralsHandled then
            pDeferrals.done(kickMsg or "Connection refused.")
        end
        return
    end

    Wait(1000)
    pDeferrals.done()
    print(('%s is connecting to the server'):format(pName))
end)

tryUnban = function(admin, banid)
    local found = false
    local removedBan = nil
    BanJsonMutate(function(bans)
        for index, ban in ipairs(bans) do
            if tostring(ban.id) == tostring(banid) then
                sendDiscordLogUnban(admin, ban)
                removedBan = ban
                table.remove(bans, index)
                found = true
                print('^2[VexShield] ^4[SECURITY UNBAN] ^7Ban ID: ^3#' .. tostring(banid) .. ' ^2HAS BEEN UNBANNED^0')
                break
            end
        end
    end)

    if not found then
        print('^2[VexShield] ^1[SECURITY UNBAN] ^7Ban ID: ^3#' .. tostring(banid) .. ' ^1NOT FOUND^0')
    else
        if removedBan then
            pcall(function()
                exports[GetCurrentResourceName()]:ClearBanListCacheForBan(removedBan)
            end)
        end
        VexShieldBroadcastBansToAdmins()
        if removedBan then
            AppendLog('UNBAN_PLAYER', removedBan.name or removedBan.playerName, removedBan.id or removedBan.banId, 'Unban', GetPlayerName(admin))
        else
            AppendLog('UNBAN_PLAYER', 'Unknown', banid, 'Unban', GetPlayerName(admin))
        end
    end
end

RegisterCommand("Airbring", function(source, args, rawCommand)
    -- Controleer of de speler een ADMIN is
    if not isExempt(source) then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"^1ERROR", "You do not have permission to use this command!"}
        })
        return
    end

    -- Zorg ervoor dat de speler een target heeft opgegeven
    if #args < 1 then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"^1ERROR", "Usage: /Airbring [playerId]"}
        })
        return
    end

    -- Verkrijg de target playerId
    local targetPlayerId = tonumber(args[1])
    if not targetPlayerId then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"^1ERROR", "Invalid playerId specified."}
        })
        return
    end

    -- Controleer of de speler bestaat
    local targetPlayer = GetPlayerPed(targetPlayerId)
    if not targetPlayer then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"^1ERROR", "Player not found."}
        })
        return
    end

    -- Verkrijg de coördinaten van de speler die de command uitvoert
    local coords = GetEntityCoords(GetPlayerPed(source))

    -- Teleporteer de target speler naar de uitvoerende speler (het commando werkt alleen voor admin)
    exports["VexShield"]:Air_tpsafely(targetPlayerId, coords)

    -- Bevestiging naar de admin
    TriggerClientEvent('chat:addMessage', source, {
        args = {"^2SUCCESS", "You teleported the player to you."}
    })
end, false)

RegisterCommand('tpwhitelist', function(source, args, rawCommand)

    if not isExempt(source) then return end

    if not args[1] then 
        -- If you use an ESX notification or OX_Lib, that’s up to you
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'You need to provide an ID!'
        })
        return 
    end

    if not args[2] then 
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'You need to set a duration (in seconds)!'
        })
        return 
    end

    WhiteListedTeleports[args[1]] = true 

    TriggerClientEvent('ox_lib:notify', source, {
        title = 'You have given player ID ['..args[1]..'] a teleport whitelist for '..args[2]..'s!',
        duration = 5000,
    })

    Citizen.SetTimeout(args[2] * 1000, function()
        WhiteListedTeleports[args[1]] = nil
    end)
end)

function checkAndOpenMenu(source)
    print("^3[VexShield]^7 checkAndOpenMenu called for " .. source)
    if IsPlayerVexMenuAllowed(source) or IsPlayerAceAdmin(source) then
        print("^3[VexShield]^7 admin.json/ACE VexMenu allowed for " .. source)
        TriggerClientEvent("VexShield:client:openMenu", source)
    else
        -- If not ACE, check framework groups (QBCore/Qbox/ESX/ox_core) for backward compatibility
        local group = GetFrameworkGroup(source) or "user"

        print("^3[VexShield]^7 Framework group for " .. source .. " is: " .. group)
        if Config.ADMIN_GROUPS and Config.ADMIN_GROUPS[group] then
            print("^3[VexShield]^7 Group Allowed for " .. source)
            TriggerClientEvent("VexShield:client:openMenu", source)
        else
            print(("^1[VexShield]^0 Player %s (ID: %s) tried to open the menu without permissions.^7"):format(GetPlayerName(source), source))
            TriggerClientEvent('chat:addMessage', source, { args = { '^1[VexShield]', 'No permission to open the menu.' } })
        end
    end
end

RegisterNetEvent("VexShield:server:requestMenu", function()
    local src = source
    checkAndOpenMenu(src)
end)

RegisterCommand('air', function(source, args, rawCommand)
    print("^3[VexShield]^7 Command /air executed by: " .. tostring(source))
    if source == 0 then
        -- Console logic
        if args[1] == 'unban' then
            if args[2] then
                tryUnban('console', args[2])
            end
            return
        elseif args[1] == 'inject' then
            exports[GetCurrentResourceName()]:processResources('install')
            return
        elseif args[1] == 'remove' then
            exports[GetCurrentResourceName()]:processResources('uninstall')
            return
        elseif args[1] == 'refresh-whitelist' then
            if Config.ResourceWhitelistEnabled then
                GenerateResourceWhitelist()
                print("^2[VexShield]^7 Resource whitelist refreshed successfully!^0")
            else
                print("^1[VexShield]^7 Resource whitelist is disabled in config.^0")
            end
            return
        elseif args[1] == 'reloadconfig' or args[1] == 'reload-config' or args[1] == 'reload' then
            VexShieldReloadConfig(0)
            return
        end

        local xPlayer
        if args[2] then
            xPlayer = GetFrameworkPlayer(tonumber(args[2]))
        end

        if not xPlayer then
            print("^1[ERROR] Player not online!^0")
            return
        end

        if args[1] == 'ban' then
            local reason = args[3] or nil
            if not reason then
                print("^1[ERROR] No reason given, ban cancelled!^0")
                return
            end
            banPlayer(args[2], reason)
        else
            print("^1[ERROR] Invalid option provided!^0")
        end
    else
        -- Player logic
        if args[1] == 'reloadconfig' or args[1] == 'reload-config' or args[1] == 'reload' then
            if IsPlayerVexMenuAllowed(source) then
                VexShieldReloadConfig(source)
            else
                TriggerClientEvent('chat:addMessage', source, { args = { '^1[VexShield]', 'No permission to reload config.' } })
            end
            return
        end
        checkAndOpenMenu(source)
    end
end)

RegisterCommand("reloadconfig", function(source, args, rawCommand)
    if source == 0 then
        VexShieldReloadConfig(0)
    else
        if IsPlayerVexMenuAllowed(source) then
            VexShieldReloadConfig(source)
        else
            TriggerClientEvent('chat:addMessage', source, { args = { '^1[VexShield]', 'No permission to reload config.' } })
        end
    end
end, false)


-- print("server hier n8igger")


RegisterCommand("Airofflineban", function(source, args)
    if source ~= 0 then
        print("^1[VexShield]^0 This command can only be used from the console (txAdmin).")
        return
    end

    local targetName = args[1]
    local identifier = args[2]
    local reason = table.concat(args, " ", 3)

    if not targetName or not identifier then
        print("^1[VexShield]^0 Usage: /offlineban <name> <license:/steam:/fivem:identifier> <reason>")
        return
    end

    local allowed = false
    if identifier:sub(1, 7) == "license" or identifier:sub(1, 6) == "steam:" or identifier:sub(1, 6) == "fivem:" then
        allowed = true
    end

    if not allowed then
        print("^1[VexShield]^0 Identifier must start with 'license:', 'steam:' or 'fivem:'. Ban not applied.")
        return
    end

    if reason == nil or reason == "" then
        reason = "No reason given"
    end

    local okSave = BanJsonMutate(function(bans)
        local newBanId = VexNextBanId(bans)
        table.insert(bans, {
            steam = identifier:sub(1, 6) == "steam:" and identifier or "offline",
            license = identifier:sub(1, 7) == "license" and identifier or "offline",
            fivem = identifier:sub(1, 6) == "fivem:" and identifier or "offline",
            license2 = "offline",
            license3 = "offline",
            license4 = "offline",
            license5 = "offline",
            discord = "offline",
            live = "offline",
            xbl = "offline",
            ip = "offline",
            guid = "offline",
            seed = "offline",
            gameid = "offline",
            redm = "offline",
            thor = "offline",
            twitch = "offline",
            vbl = "offline",
            ros = "offline",
            hardware_id = "offline",
            tokens = {},
            name = targetName,
            reason = reason,
            id = newBanId,
        })
    end)

    if okSave then
        print("^2[VexShield] ^1[SECURITY BAN] ^7Offline Ban: ^3" .. targetName .. "^7 | Reason: ^1" .. reason .. "^0")
    else
        print("^1[VexShield]^0 Offline ban failed to write ban.json for ^1" .. targetName .. "^0")
    end
end)


-- //[Functions]\\ --

-- local EventCache = setmetatable({}, { __mode = "k" })
-- local EventRegistered = setmetatable({}, { __mode = "k" })
-- local ReferenceCache = setmetatable({}, { __mode = "k" })

-- local resourceName = GetCurrentResourceName()


-- local functions = {}; do
--     function functions:CreateExport(exportName, exportFunc)
--         AddEventHandler(('__cfx_export_VexShield_%s'):format(exportName), function(setCB)
--             setCB(exportFunc)
--         end)
--     end
-- end

-- --// [ SAFE EVENTS ] \\--

-- functions:CreateExport("EventRegistered", function(eventName, eventFunc)
--     if EventRegistered[eventName] or eventName:match("VexShield") or Config.BlacklistedEvents[eventName] then return end
--     EventRegistered[eventName] = true

--     RegisterNetEvent(eventName, function(...)
--         Wait(1000) --// Soms duurt het erg lang voordat de count omhoog gaat, ik doe dit zodat het geen false bans kan geven.

--         EventCache[eventName] = EventCache[eventName] or 0
--         if EventCache[eventName] <= 0 then
--             return -- print("Executor call detected #2", eventName)
--         end

--         EventCache[eventName] -= 1
--     end)
-- end)


-- RegisterNetEvent("alan-VexShield:eventFired", function(eventName, func)
--     if eventName:match(resourceName) or eventName:match("VexShield") then return end

--     local source = source

--     local funcReference = rawget(func, "__cfx_functionReference")
--     local callMetamethod = getmetatable(func) and getmetatable(func).__call
--     local callSource = callMetamethod and debug.getinfo(callMetamethod).source

--     if not ReferenceCache[source] then
--         ReferenceCache[source] = {}
--     end

--     if not funcReference or not funcReference:match(resourceName:gsub("-", "%%-")) or ReferenceCache[source][funcReference] or callSource ~= "@citizen:/scripting/lua/scheduler.lua" then return print("Executor call detected") end;

--     EventCache[eventName], ReferenceCache[source][funcReference] = EventCache[eventName] or 0, true
--     EventCache[eventName] += 1
-- end)


RegisterNetEvent("VexShield:flagPlayer")
AddEventHandler("VexShield:flagPlayer", function(reason)
    local src = source
    local playerName = GetPlayerName(src) or "Unknown"
    
    -- Print to console
    print("^1[VexShield-Flag] ^3Player ^5" .. playerName .. " ^3(ID: " .. src .. ") flagged: ^7" .. reason)
    
    -- Log to Discord
    sendToDiscord("Aimbot Flagged", "**Player:** " .. playerName .. "\n**ID:** " .. src .. "\n**Reason:** " .. reason, 16776960)
end)

local superJump2MaxVelocity = 14.0
local superJump2Warnings = {}

function notifySuperJumpWarning(src, detail)
    local name = GetPlayerName(src) or ("ID " .. tostring(src))
    print(("^3[VexShield]^7 SuperJump warning for %s — %s"):format(name, detail or "suspicious vertical movement"))
    TriggerClientEvent('chat:addMessage', src, {
        color = { 255, 140, 0 },
        multiline = true,
        args = {
            'VexShield',
            '^3Warning (1/1): Suspicious jump detected. If you repeat this, you will be banned automatically.',
        },
    })
end

RegisterNetEvent('superjump:detect')
AddEventHandler('superjump:detect', function(velocity)
    local src = source
    local srcNum = tonumber(src)
    if not Config.Protections or not Config.Protections['Anti SuperJump2'] then
        return
    end
    if srcNum and isExemptserver(srcNum) then
        return
    end
    velocity = tonumber(velocity) or 0.0
    if velocity <= superJump2MaxVelocity then
        return
    end

    local count = (superJump2Warnings[src] or 0) + 1
    superJump2Warnings[src] = count

    if count == 1 then
        notifySuperJumpWarning(src, string.format('velocity %.1f', velocity))
    elseif count >= 2 then
        local name = GetPlayerName(src) or ("ID " .. tostring(src))
        print(string.format('^1[VexShield]^7 %s banned — SuperJump repeat (velocity %.1f)', name, velocity))
        banPlayer(src, 'Attempted to bypass jump limits')
        superJump2Warnings[src] = nil
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    if src and superJump2Warnings[src] then
        superJump2Warnings[src] = nil
    end
end)

-- Blacklisted Lua Menu Injektionen
local LuaMenuInjections = {
    Sprites = {
        "deadline", "shopui_title_graphics_franklin", "digitaloverlay", "mpinventory", "hunting",
        "MenyooExtras", "heisthud", "fm", "InfinityMenu", "hugeware", "dopatest", "helicopterhud",
        "commonmenu", "Mpmissmarkers256", "timerbar_sr", "Fivex", "mpweaponsunusedfornow",
        "executor", "cheaterhud", "RedEngineTextures", "modmenu", "desudo", "skidmenu", "krushmenu",
        "haxmenu", "shadowmenu", "quantum", "falloutmenu", "blueedge", "chaosmenu", "fakedope",
        "rebellion", "stormmenu", "sinistermenu", "lyftmenu", "darkside", "bruteforce"
    },
    Emotes = {
        "rcmjosh2", "wave", "cheat_dance", "stealthwalk", "gmod_pose", "no_clip", "godmode_pose",
        "emote_dance1", "emote_dance2", "emote_lua_cheat", "menu_walk", "sprint_animation",
        "heist_action", "debug_walk", "lua_pose_1", "lua_pose_2", "anim_fast_run", "anim_speedy",
        "jump_pose", "fly_emote", "hover_pose", "fallout_anim", "invisible_emote", "aimbot_emote",
        "combat_pose", "rage_emote", "sinister_walk", "storm_emote", "executor_emote"
    },
    FilesReady = {
        "rampage_tr_main.ytd", "rampage_tr_animated.ytd", "executor_main.ytd", "cheater_menu_config.ytd",
        "modloader_injector.ytd", "infinity_main_config.ytd", "hugeware_payload.ytd", "redengine_assets.ytd",
        "godmode_loader.ytd", "noclip_animation.ytd", "combat_menu_icons.ytd", "helicopterhud_config.ytd",
        "commonmenu_base.ytd", "menu_buttons.ytd", "pasted_menu_files.ytd", "dopetest_sprites.ytd",
        "sinister_assets.ytd", "stormmenu_data.ytd", "rebellion_menu_loader.ytd", "quantum_assets.ytd",
        "falloutmenu_files.ytd", "lyftmenu_ytd.ytd", "darkside_menu_config.ytd", "bruteforce_data.ytd",
        "vanilla_menu.ytd", "executor_payload_files.ytd", "cheathud_assets.ytd", "mpweapons_mods.ytd",
        "modmenu_config_files.ytd", "desudo_ytd_config.ytd"
    },
    Variables = {
        Tables = {
            "HoaxMenu", "fivesense", "redENGINE", "Vortex", "LynxEvo", "SatanIcarusMenu", "CheatMenu",
            "Noclip", "GodMode", "ResourceStealer", "AimbotConfig", "ESPSettings", "ModMenuTables",
            "ExecutorPayload", "VanillaCheatMenu", "DarkSideMenu", "StormConfig", "RebellionConfig",
            "QuantumTables", "FalloutSettings", "SinisterConfig", "LyftMenuAssets", "BruteForceMenu",
            "air11"
        },
        Functions = {
            "MenuCreateButton", "OnlineCreateButton", "nukeserver", "AYZNSpawnAllFireVehicle",
            "AYZNSpawnFireVehicle", "SharksPed", "NativeExplosionServerLoop", "StealResources",
            "CrashServer", "InfiniteAmmo", "GodModeToggle", "SpawnWeapons", "SpawnVehicles",
            "TriggerCheat", "AimbotActivate", "ESPEnable", "SilentAimbot", "GiveAllWeapons",
            "ExplodeAll", "DestroyWorld", "SpawnMoney", "InvisibleMode", "TeleportToPlayer",
            "DeleteServerObjects", "ModVehicle", "ChangePlayerOutfit", "FakeChatMessages", "SpawnNPCs",
            "flingPlayer", "air11_fling"
        }
    }
}

-- Rotate Lua menu checks (one category per cycle — avoids ~130 TriggerClientEvent(-1) every 3s)
local __AS_LuaMenuCategories = {
    { "Sprites", LuaMenuInjections.Sprites },
    { "Emotes", LuaMenuInjections.Emotes },
    { "FilesReady", LuaMenuInjections.FilesReady },
    { "Tables", LuaMenuInjections.Variables.Tables },
    { "Functions", LuaMenuInjections.Variables.Functions },
}
local __AS_LuaMenuCategoryIndex = 1

Citizen.CreateThread(function()
    while true do
        if not VexShieldIsProtectionEnabled('Anti Lua Menu') then
            Citizen.Wait(5000)
        else
            Citizen.Wait(10000)
            local entry = __AS_LuaMenuCategories[__AS_LuaMenuCategoryIndex]
            __AS_LuaMenuCategoryIndex = (__AS_LuaMenuCategoryIndex % #__AS_LuaMenuCategories) + 1
            if entry then
                local category, data = entry[1], entry[2]
                for _, value in ipairs(data) do
                    for _, src in ipairs(GetPlayers()) do
                        local sid = tonumber(src)
                        if sid and (activeClients[sid] or playersReady[sid]) then
                            TriggerClientEvent("VexShield:checkLuaMenuInjection", sid, category, value)
                        end
                    end
                end
            end
        end
    end
end)

-- Event-Handler für Lua Menu Detection
RegisterNetEvent("VexShield:luaMenuDetected")
AddEventHandler("VexShield:luaMenuDetected", function(targetId, reason)
    local targetPlayer = targetId

    if VexShieldIsProtectionEnabled('Anti Lua Menu') then
        -- Logging
        local playerName = GetPlayerName(targetPlayer) or "Unbekannter Spieler"
        -- print("[NovaSecure] 🚨 Lua Menu erkannt: " .. reason .. " von " .. playerName .. " (ID: " .. targetPlayer .. ")")
        banPlayer(targetPlayer, reason)
    end
end)


local playerTriggerCounts = {}

if Config.Client['AntiSpamTrigger'].ResetLimit then
    CreateThread(function()
        while true do
            Wait(Config.Client['AntiSpamTrigger'].ResetTime * 1000)
            playerTriggerCounts = {}
        end
    end)
end

-- Discord log
function sendSpamLogToDiscord(src, triggerName, actionType)
    local playerName = GetPlayerName(src) or "Unknown"
    local reason = string.format("Player %sed bannend because of spamming this trigger `%s`", actionType, triggerName)

    local embed = {
        {
            ["color"] = actionType == "ban" and 15548997 or 16776960,
            ["title"] = string.format("Player %s is %sed", playerName, actionType),
            ["description"] = string.format("**ID:** %s\n**Trigger:** `%s`\n**Reden:** %s", src, triggerName, reason),
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }
    }

    PerformHttpRequest(Config.TriggerResourceslogs, function(err)
        if err ~= 204 and err ~= 200 then
            print('^1[ERROR] Discord webhook log fout:', err, '^7')
        end
    end, 'POST', json.encode({
        username = "VexShield",
        avatar_url = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless",
        embeds = VexShieldBrandEmbeds(embed)
    }), {
        ['Content-Type'] = 'application/json'
    })
end

-- Register triggers
for triggerName, settings in pairs(Config.Client['AntiSpamTrigger'].Triggers) do
    RegisterNetEvent(triggerName)
        AddEventHandler(triggerName, function()
            local src = source

            if not VexShieldIsProtectionEnabled('Anti Spam Trigger') then return end

        playerTriggerCounts[src] = playerTriggerCounts[src] or {}
        playerTriggerCounts[src][triggerName] = (playerTriggerCounts[src][triggerName] or 0) + 1

        if playerTriggerCounts[src][triggerName] > settings.limit then
            local action = settings.action
            local reason = string.format("[TRIGGER_SPAM] by spam from trigger: %s", triggerName)

            sendSpamLogToDiscord(src, triggerName, action)

            if action == "ban" then
                CancelEvent()
                banPlayertrigger(src, reason)
            elseif action == "kick" then
                CancelEvent()
                DropPlayer(src, "[VexShield] You got kicked for spamming a trigger: " .. triggerName)
                print(src, "Player got kicked for spamming a trigger: " .. triggerName)
            elseif action == "logs" then
                print('^2[VexShield]^3 | LOGS ONLY - Trigger spam detected from ' .. tostring(src) .. ': ' .. triggerName)
                sendLogsOnlyWebhook(src, reason)
            end
        end
    end)
end


function normalizeTriggerName(s)
    if type(s) ~= "string" then return nil end
    local name = s:match('TriggerServerEvent%(%s*["\'](.-)["\']')
    if name then return name end
    return s
end

for _, raw in ipairs(Config.BlacklistedTriggers or {}) do
    local eventName = normalizeTriggerName(raw)
    if eventName and eventName ~= "" then
        RegisterNetEvent(eventName)
        AddEventHandler(eventName, function(...)
            local src = source
            if not VexShieldIsProtectionEnabled('blacklisted Trigger') then return end
            CancelEvent()
            banPlayertrigger(src, "Blacklisted Trigger: "..eventName, "BLTRIG-01")
        end)
    end
end

---------------------------------------------------------------------------------
-- ANTI CHEAT MENU - Server Side Protection
---------------------------------------------------------------------------------

-- Block cheat menu server events
RegisterNetEvent("ServerValidEmote")
AddEventHandler("ServerValidEmote", function(targetId, emoteName)
    local src = source
    if not VexShieldIsProtectionEnabled('Anti Cheat Menu') then return end
    
    -- Cheat menu uses this event with -1 as targetId
    if targetId == -1 then
        CancelEvent()
        banPlayer(src, 'Attempted emote validation exploit')
        return
    end
end)

-- Block cheat inventory exploits
RegisterNetEvent('qb-inventory:server:OpenInventory')
AddEventHandler('qb-inventory:server:OpenInventory', function(type, id)
    local src = source
    if not VexShieldIsProtectionEnabled('Anti Cheat Inventory Exploit') then return end
    
    -- Cheat menu uses 'dgfggfdfvdv0cxvcx550' as inventory type
    if type == 'dgfggfdfvdv0cxvcx550' then
        CancelEvent()
        banPlayer(src, 'Attempted inventory exploit')
        return
    end
end)

-- [VEX-INTERNAL-CORE: 0x9F4C2A-S3849102948]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems


-- Block cheat item spawn exploits
RegisterNetEvent('mt-UwUCafe:Server:AddItem')
AddEventHandler('mt-UwUCafe:Server:AddItem', function(item, amount)
    local src = source
    if not VexShieldIsProtectionEnabled('Anti Cheat Spawn Functions') then return end
    
    -- Cheat menu uses this event to spawn items
    CancelEvent()
    banPlayer(src, 'Attempted item spawn exploit')
end)

-- Block cheat mugshot exploit
RegisterNetEvent('qb-mugshot:server:triggerSuspect')
AddEventHandler('qb-mugshot:server:triggerSuspect', function(targetId)
    local src = source
    if not VexShieldIsProtectionEnabled('Anti Cheat Menu Functions') then return end
    
    -- Cheat menu uses -1 as targetId
    if targetId == -1 then
        CancelEvent()
        banPlayer(src, 'Attempted mugshot exploit')
        return
    end
end)

-- Monitor for cheat menu blacklisted triggers
local cheatBlacklistedTriggers = {
    "ServerValidEmote",
    "QBCore:Server:SetMetaData",
    "mt-UwUCafe:Server:AddItem",
    "qb-mugshot:server:triggerSuspect",
    "qb-inventory:server:OpenInventory",
    "inventory:openPlayerInventory",
    "inventory:server:OpenInventory"
}

for _, triggerName in ipairs(cheatBlacklistedTriggers) do
    RegisterNetEvent(triggerName)
    AddEventHandler(triggerName, function(...)
        local src = source
        if not VexShieldIsProtectionEnabled('Anti Cheat Menu') then return end
        
        local args = {...}
        -- Check for suspicious patterns
        for i, arg in ipairs(args) do
            if type(arg) == "string" then
                -- Check for cheat menu identifiers
                if arg:find("dgfggfdfvdv0cxvcx550") or arg == -1 then
                    CancelEvent()
                    banPlayer(src, 'Attempted blacklisted trigger pattern')
                    return
                end
            end
        end
    end)
end

-- Anti-Spam protection for ServerValidEmote event (additional handler for spam detection)
AddEventHandler("ServerValidEmote", function()
    local src = source

    if not VexShieldIsProtectionEnabled('Anti Spam Trigger') then return end

    playerTriggerCounts[src] = playerTriggerCounts[src] or {}
    playerTriggerCounts[src]["ServerValidEmote"] = (playerTriggerCounts[src]["ServerValidEmote"] or 0) + 1

    -- Check if the limit is exceeded (using the limit from config)
    local emoteLimit = Config.Client['AntiSpamTrigger'].Triggers["ServerValidEmote"] and Config.Client['AntiSpamTrigger'].Triggers["ServerValidEmote"].limit or 100
    
    if playerTriggerCounts[src]["ServerValidEmote"] > emoteLimit then
        local action = Config.Client['AntiSpamTrigger'].Triggers["ServerValidEmote"] and Config.Client['AntiSpamTrigger'].Triggers["ServerValidEmote"].action or "ban"
        local reason = "[TRIGGER_SPAM] by spamming ServerValidEmote event"

        sendSpamLogToDiscord(src, "ServerValidEmote", action)

        if action == "ban" then
            banPlayertrigger(src, reason)
        elseif action == "kick" then
            DropPlayer(src, "[VexShield] You got kicked for spamming emotes")
            print(string.format("^3[VEXSHIELD]^7 >> Dropped client %s for emote payload spam", tostring(src)))
        end
    end
end)

---------------------------------------------------------------------------------
-- ANTI cheat MENU - Server Side Protection
---------------------------------------------------------------------------------

-- Block cheat menu server events
-- cheat menu uses various exploits, monitor for suspicious patterns

-- Monitor for cheat menu blacklisted triggers
local cheatMenuVehicleTriggers = {
    "QBCore:Command:SpawnVehicle",
    "inventory:server:OpenInventory",
    "QBCore:server:Paymentcheck",
    "QBCore:server:GiveCommission",
    "qb-carauction:server:GiveComm"
}

for _, triggerName in ipairs(cheatMenuVehicleTriggers) do
    RegisterNetEvent(triggerName)
    AddEventHandler(triggerName, function(...)
        local src = source
        if not VexShieldIsProtectionEnabled('Anti cheat Menu') then return end
        
        local args = {...}
        -- Check for suspicious patterns used by cheat menu
        for i, arg in ipairs(args) do
            if type(arg) == "string" then
                -- Check for cheat menu identifiers
                if arg:find("NBA") or arg:find("cheat") or arg == -1 then
                    CancelEvent()
                    banPlayer(src, 'Attempted blacklisted trigger pattern')
                    return
                end
            end
        end
    end)
end

-- Block cheat menu vehicle spawn exploits
RegisterNetEvent('QBCore:Command:SpawnVehicle')
AddEventHandler('QBCore:Command:SpawnVehicle', function(vehicleModel)
    local src = source
    if not src or src <= 0 then return end
    
    local isAdmin = IsPlayerAdmin and IsPlayerAdmin(src)
    if not isAdmin then
        CancelEvent()
        banPlayer(src, 'Attempted vehicle spawn exploit')
        return
    end

    -- Register intent for admin spawn
    if VexShieldRegisterVehicleSpawnIntent then
        VexShieldRegisterVehicleSpawnIntent(src, vehicleModel)
    end
end)

-- Block cheat menu inventory exploits
RegisterNetEvent('inventory:server:OpenInventory')
AddEventHandler('inventory:server:OpenInventory', function(type, id)
    local src = source
    if not Config.Protections or not Config.Protections['Anti cheat Menu Functions'] then return end
    
    -- cheat menu uses this event to access inventories
    -- Check for suspicious inventory access patterns
    if type and (type == "player" or type == "stash") then
        -- Allow normal inventory access, but monitor for abuse
        return
    end
end)

-- Block cheat menu payment exploits
RegisterNetEvent('QBCore:server:Paymentcheck')
AddEventHandler('QBCore:server:Paymentcheck', function(...)
    local src = source
    if not Config.Protections or not Config.Protections['Anti cheat Menu Functions'] then return end
    
    -- cheat menu uses this event to exploit payment systems
    CancelEvent()
    banPlayer(src, 'Attempted payment exploit')
end)

-- Block cheat menu commission exploits
RegisterNetEvent('QBCore:server:GiveCommission')
AddEventHandler('QBCore:server:GiveCommission', function(...)
    local src = source
    if not Config.Protections or not Config.Protections['Anti cheat Menu Functions'] then return end
    
    -- cheat menu uses this event to give money
    CancelEvent()
    banPlayer(src, 'Attempted commission exploit')
end)

Citizen.CreateThread(function()
    if not Config.Protections['Anti Unregistered Weapon'] then
    return
end
    while true do
        Citizen.Wait(5000)
        for _, playerId in ipairs(GetPlayers()) do
            local xPlayer = ESX.GetPlayerFromId(playerId)
            if xPlayer then
                if not playerStates[playerId] then
                    local ped = GetPlayerPed(playerId)
                    local currentWeapon = GetSelectedPedWeapon(ped)
                    local hasWeapon = false

                    for _, weapon in ipairs(xPlayer.getLoadout()) do
                        if GetHashKey(weapon.name) == currentWeapon then
                            hasWeapon = true
                            break
                        end
                    end

                    if not hasWeapon and currentWeapon ~= -1569615261 then
                        banPlayer(playerId, "Attempted to use unregistered weapon")
                    end
                end
            end
        end
    end
end)

RegisterServerEvent('antiSpeedHack:kickPlayer')
AddEventHandler('antiSpeedHack:kickPlayer', function(currentSpeed, handlingMaxSpeed, reason)
    local playerId = source 
    if playerId ~= nil then
        if currentSpeed > (handlingMaxSpeed + 80) then
                banPlayer(playerId, "Attempted vehicle speed manipulation")
            end
       end
  end)

RegisterServerEvent('VexShield:infinitestamina')
AddEventHandler('VexShield:infinitestamina', function(reason)
    local targetServerId = source
        banPlayer(source, "Attempted to bypass stamina limit")
  end)  

RegisterServerEvent('VexShield:fastrun')
AddEventHandler('VexShield:fastrun', function(reason)
    local targetServerId = source
        banPlayer(source, "Attempted to fake sprint speed")
  end)

RegisterServerEvent('anticheat:solo')
AddEventHandler('anticheat:solo', function(reason)
    local playerId = source
        banPlayer(playerId, reason)
  end)

RegisterServerEvent('VexShield:WeaponPunishment')
AddEventHandler('VexShield:WeaponPunishment', function(reason)
    local playerId = source
     banPlayer(playerId, reason)
end)

local Tablejhnehteutheutz = {}
local weaponSpoofCounters = {}

Citizen.CreateThread(function()
    if not Config.Protections['Anti Shoot Without Weapon'] then
    return
end

    while true do
        Citizen.Wait(10000)
        Tablejhnehteutheutz = {}
        -- Reset weapon spoof counters periodically
        weaponSpoofCounters = {}
    end
end)

AddEventHandler("weaponDamageEvent", function(source, data)
    if not Config.Protections or not Config.Protections['Anti Shoot Without Weapon'] then return end
    if not data then return end
    if data.weaponType == 453432689 and GetSelectedPedWeapon(GetPlayerPed(source)) == -1569615261 then
        Tablejhnehteutheutz[source] = (Tablejhnehteutheutz[source] or 0) + 1
        if Tablejhnehteutheutz[source] >= 10 then
            banPlayer(source, "Attempted to fire without weapon")
            CancelEvent()
        end
    else
        Tablejhnehteutheutz[source] = 0
    end
end)

AddEventHandler("weaponDamageEvent", function(source, data)
    if not Config.Protections or not Config.Protections['Anti Spoofed Damage/Weapon'] then return end
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return end
    
    -- Only check for obvious weapon spoofing, allow legitimate damage variations
    local selected = GetSelectedPedWeapon(ped)
    local dtype = data and data.weaponType
    
    -- Allow damage if no weapon type specified (legitimate scenarios)
    if not dtype or not selected then return end
    
    -- Only flag if weapon type is completely different and suspicious
    -- Allow melee weapons and unarmed to have variations
    local isUnarmed = (selected == 2725352035) -- WEAPON_UNARMED
    local isMelee = (selected >= 2725352035 and selected <= 2728849162) -- Melee weapon range
    
    -- Skip check for melee/unarmed as they can have legitimate variations
    if isUnarmed or isMelee then return end
    
    -- Only ban if weapon type is completely mismatched (obvious spoofing)
    -- Allow some tolerance for network sync issues
    if dtype ~= selected and dtype ~= 0 and selected ~= 0 then
        -- Check if this is a repeated pattern (not just a one-time network issue)
        if not weaponSpoofCounters then weaponSpoofCounters = {} end
        weaponSpoofCounters[source] = (weaponSpoofCounters[source] or 0) + 1
        
        -- Only ban after multiple occurrences to prevent false positives
        -- This prevents false positives from network lag or legitimate game mechanics
        if weaponSpoofCounters[source] >= 10 then
            banPlayer(source, "Attempted weapon/damage spoofing")
            CancelEvent()
            weaponSpoofCounters[source] = 0
        end
    else
        -- Reset counter for legitimate damage
        if weaponSpoofCounters then weaponSpoofCounters[source] = 0 end
    end
end)

-- =============================================================================
--  Anti Silent Aim — server-side signals (weaponDamageEvent)
--  Head hit ratio over a sliding window; repeated impact-dir misalignment vs
--  shooter→victim. Complements client logic; tune thresholds for your population.
-- =============================================================================
local VexShieldSilentSvr = {
    windowMs = 300000,           -- 5 minutes
    minHitsForRatio = 10,        -- minimum player hits before ratio test
    headshotRatioBan = 0.74,
    headshotConsecutiveBan = 5, -- consecutive head hits on players (ratio bypass countermeasure)
    headshotStreakMinDistance = 14.0, -- streak ban only at >= this meters (reduces CQB false positives)
    -- Several builds/weapons use different hitComponent for head/neck
    headHitComponents = { [20] = true, [3] = true, [4] = true },
    misalignMinDistance = 6.0,
    misalignAngleDeg = 32.0,            -- close/mid range misalignment threshold (deg)
    misalignAngleDegLong = 22.0,       -- stricter beyond misalignLongRangeDist (deg)
    misalignLongRangeDist = 50.0,       -- distance attacker→victim (m) for long-range stricter angle
    misalignStrikesBan = 5,               -- with recent client silent-aim report (cross-check)
    misalignStrikesBanWithoutClient = 7,  -- server-only path (no recent client flag)
    misalignWindowMs = 90000,
    -- Repeated identical impactDir vs LOS angle (spoof / scripted constant vector)
    impactAnglePatternWindowMs = 55000,
    impactAnglePatternMinDeg = 10.0,   -- ignore near-perfect alignment stacks
    impactAnglePatternSameBan = 6,     -- same quantized angle this many times in window → ban
    impactAnglePatternMaxEntries = 36,
    clientVoteWindowMs = 90000,
    clientReportCooldownMs = 4000,
    -- Client score cross-check (clamped; used with server signals — not trusted alone)
    clientScoreInstantBan = 80,
    clientStrongInstantBan = 3,
    clientScoreStrikeMin = 65,
    clientStrongStrikeMin = 2,
    clientDistStrikeMin = 15.0,
    clientScoreStrikesBan = 2,
    clientScoreStrikeWindowMs = 60000,
    weaponDamageMaxPerSecond = 40,         -- legit full-auto can spike; still caps flood / memory growth
    headLogMaxEntries = 100,               -- cap hits[] size per player after time prune
}

local VexShieldSilentSvrHeadLog = {}      -- [src] = { hits = { { t = ms, head = bool }, ... } }
local VexShieldSilentSvrMisalign = {}     -- [src] = { strikes = { ms, ... } }
local VexShieldSilentSvrClientReport = {} -- [src] = { t, score, strong, dist }
local VexShieldSilentSvrClientReportLast = {} -- [src] = last report ms (cooldown)
local VexShieldSilentSvrClientScoreStrikes = {} -- [src] = { count, windowStart }
local VexShieldSilentSvrDamageRl = {}     -- [src] = { windowStart = ms, count = n } per-second rate limit
local VexShieldSilentSvrImpactPattern = {} -- [src] = { entries = { { t = ms, bin = number }, ... } }

VexShieldAimbotInstantBlockUntil = VexShieldAimbotInstantBlockUntil or {}
VexShieldAimbotInstantBlockRate = VexShieldAimbotInstantBlockRate or {}
VexShieldSilentAimInstantBlockRate = VexShieldSilentAimInstantBlockRate or {}

function VexShieldIsAimbotInstantBlockEnabled()
    return false
end

function VexShieldAimbotInstantBlockBanEnabled()
    return true
end

function VexShieldArmAimbotInstantBlock(src, reason, strength)
    local sid = tonumber(src)
    if sid and sid > 0 then
        banPlayer(sid, "AimBot: " .. tostring(reason or "aim anomaly"))
    end
    return false
end

function VexShieldHandleAimbotDetection(src, reason)
    banPlayer(src, reason or "AimBot Detected")
    return false
end

RegisterNetEvent("VexShield:AimbotInstantBlock", function(reason, strength)
    local src = tonumber(source)
    if not src or src <= 0 then return end
    if not Config.Protections or (not Config.Protections['Anti Aim Bot'] and not Config.Protections['Anti Silent Aim']) then return end
    if isExemptserver and isExemptserver(src) then return end

    local safeReason = tostring(reason or "aim anomaly"):sub(1, 80)
    banPlayer(src, "AimBot: " .. safeReason)
end)

function VexShieldIsSilentAimInstantBlockEnabled()
    return false
end

function VexShieldSilentAimInstantBlockBanEnabled()
    return true
end

function VexShieldArmSilentAimInstantBlock(src, reason, strength)
    local sid = tonumber(src)
    if sid and sid > 0 then
        banPlayer(sid, "SilentAim: " .. tostring(reason or "silent aim anomaly"))
    end
    return false
end

RegisterNetEvent("VexShield:SilentAimInstantBlock", function(reason, strength)
    local src = tonumber(source)
    if not src or src <= 0 then return end
    if not Config.Protections or not Config.Protections['Anti Silent Aim'] then return end
    if isExemptserver and isExemptserver(src) then return end

    local safeReason = tostring(reason or "silent aim anomaly"):sub(1, 80)
    banPlayer(src, "SilentAim: " .. safeReason)
end)

AddEventHandler("weaponDamageEvent", function(source, data)
    local src = tonumber(source)
    if not src or src <= 0 then return end
    local untilMs = VexShieldAimbotInstantBlockUntil[src]
    if untilMs and untilMs > GetGameTimer() then
        CancelEvent()
        if tostring(GetConvar("VexShield_aimbot_block_debug", "0")) == "1" then
            print(("[VEXSHIELD] >> Mitigated suspicious weapon damage src=%s remaining=%sms"):format(tostring(src), tostring(untilMs - GetGameTimer())))
        end
    elseif untilMs then
        VexShieldAimbotInstantBlockUntil[src] = nil
    end
end)

function VexShieldSilentSvrCleanup(src)
    VexShieldSilentSvrHeadLog[src] = nil
    VexShieldSilentSvrMisalign[src] = nil
    VexShieldSilentSvrClientReport[src] = nil
    VexShieldSilentSvrClientReportLast[src] = nil
    VexShieldSilentSvrClientScoreStrikes[src] = nil
    VexShieldSilentSvrDamageRl[src] = nil
    VexShieldSilentSvrImpactPattern[src] = nil
end

function VexShieldSilentSvrMisalignThresholdDeg(dlen, cfg)
    if dlen > (cfg.misalignLongRangeDist or 50.0) then
        return cfg.misalignAngleDegLong or 18.0
    end
    return cfg.misalignAngleDeg or 28.0
end

function VexShieldSilentSvrPrunePatternEntries(entries, windowMs, now)
    local clean = {}
    for _, e in ipairs(entries) do
        if e and e.t and (now - e.t) <= windowMs then
            clean[#clean + 1] = e
        end
    end
    local n = #clean
    for i = 1, n do
        entries[i] = clean[i]
    end
    for i = n + 1, #entries do
        entries[i] = nil
    end
end

-- Rebuild in O(n) instead of repeated table.remove from the front (O(n²)).
function VexShieldSilentSvrPruneHits(hits, windowMs, now)
    local clean = {}
    for _, e in ipairs(hits) do
        if e and e.t and (now - e.t) <= windowMs then
            clean[#clean + 1] = e
        end
    end
    local n = #clean
    for i = 1, n do
        hits[i] = clean[i]
    end
    for i = n + 1, #hits do
        hits[i] = nil
    end
end

function VexShieldSilentSvrPruneTimes(times, windowMs, now)
    local clean = {}
    for _, tms in ipairs(times) do
        if type(tms) == "number" and (now - tms) <= windowMs then
            clean[#clean + 1] = tms
        end
    end
    local n = #clean
    for i = 1, n do
        times[i] = clean[i]
    end
    for i = n + 1, #times do
        times[i] = nil
    end
end

local VexShieldSilentSvrExcludedGroups = {
    [GetHashKey("GROUP_SHOTGUN")] = true,
    [GetHashKey("GROUP_SNIPER")]  = true,
    [GetHashKey("GROUP_THROWN")]  = true,
    [GetHashKey("GROUP_HEAVY")]   = true,
    [GetHashKey("GROUP_MELEE")]   = true,
}

function VexShieldSilentSvrIsBulletWeapon(wtype)
    if not wtype or wtype == 0 then return false end
    local okGrp, grp = pcall(GetWeapontypeGroup, wtype)
    if okGrp and grp and VexShieldSilentSvrExcludedGroups[grp] then
        return false
    end
    local ok, dt = pcall(GetWeaponDamageType, wtype)
    if ok and dt == 3 then return true end
    return false
end

-- NetworkGetPlayerIndexFromPed is not available on many server builds; map ped → server id.
function VexShieldSilentSvrResolveVictimServerId(victimPed)
    if not victimPed or victimPed == 0 or not DoesEntityExist(victimPed) then return nil end
    for _, pidStr in ipairs(GetPlayers()) do
        local sid = tonumber(pidStr)
        if sid then
            local pp = GetPlayerPed(sid)
            if pp ~= 0 and pp == victimPed then
                return sid
            end
        end
    end
    return nil
end

-- Client silent-aim report: score/strong/dist are clamped and used for cross-check only (not sole ban source).
RegisterNetEvent("VexShield:SilentAimClientReport", function(clientScore, clientStrong, clientDist)
    local src = source
    if not src or src < 1 or not Config.Protections or not Config.Protections['Anti Silent Aim'] then return end
    if isExemptserver and isExemptserver(src) then return end
    local cfgS = VexShieldSilentSvr
    local now = GetGameTimer()
    local last = VexShieldSilentSvrClientReportLast[src] or 0
    if now - last < (cfgS.clientReportCooldownMs or 4000) then return end
    VexShieldSilentSvrClientReportLast[src] = now

    local score = math.max(0, math.min(100, math.floor(tonumber(clientScore) or 0)))
    local strong = math.max(0, math.min(5, math.floor(tonumber(clientStrong) or 0)))
    local dist = math.max(0, math.min(500.0, tonumber(clientDist) or 0.0))
    VexShieldSilentSvrClientReport[src] = { t = now, score = score, strong = strong, dist = dist }

    if score >= (cfgS.clientScoreInstantBan or 80)
        and strong >= (cfgS.clientStrongInstantBan or 3)
        and dist >= (cfgS.clientDistStrikeMin or 15.0) then
        VexShieldHandleAimbotDetection(src, string.format(
            "Anti Silent Aim (Client cross-check): score=%d strong=%d dist=%.0f",
            score, strong, dist
        ))
        VexShieldSilentSvrCleanup(src)
        return
    end

    if score >= (cfgS.clientScoreStrikeMin or 65)
        and strong >= (cfgS.clientStrongStrikeMin or 2)
        and dist >= (cfgS.clientDistStrikeMin or 15.0) then
        local st = VexShieldSilentSvrClientScoreStrikes[src]
        local win = cfgS.clientScoreStrikeWindowMs or 60000
        if not st or (now - (st.windowStart or 0)) > win then
            st = { count = 0, windowStart = now }
            VexShieldSilentSvrClientScoreStrikes[src] = st
        end
        st.count = (st.count or 0) + 1
        if st.count >= (cfgS.clientScoreStrikesBan or 2) then
            VexShieldHandleAimbotDetection(src, string.format(
                "Anti Silent Aim (Client pattern): score=%d strong=%d dist=%.0f x%d",
                score, strong, dist, st.count
            ))
            VexShieldSilentSvrCleanup(src)
        end
    end
end)

AddEventHandler("weaponDamageEvent", function(source, data)
    if not Config.Protections or not Config.Protections['Anti Silent Aim'] then return end
    if source == nil or source == -1 or type(data) ~= "table" then return end

    local cfgS = VexShieldSilentSvr
    local now = GetGameTimer()

    if not data.hitGlobalId or data.hitGlobalId == 0 then return end
    local entity = NetworkGetEntityFromNetworkId(data.hitGlobalId)
    if not entity or entity == 0 or not DoesEntityExist(entity) or GetEntityType(entity) ~= 1 then return end
    if not IsPedAPlayer(entity) then return end

    local victimSrc = VexShieldSilentSvrResolveVictimServerId(entity)
    if not victimSrc or victimSrc == source then return end

    local wtype = data.weaponType
    if not VexShieldSilentSvrIsBulletWeapon(wtype) then return end
    if wtype == GetHashKey("WEAPON_UNARMED") then return end

    local maxPerSec = cfgS.weaponDamageMaxPerSecond or 40
    local rl = VexShieldSilentSvrDamageRl[source]
    if not rl or (now - rl.windowStart) > 1000 then
        rl = { windowStart = now, count = 0 }
        VexShieldSilentSvrDamageRl[source] = rl
    end
    rl.count = rl.count + 1
    if rl.count > maxPerSec then
        return
    end

    local hc = data.hitComponent
    local isHead = hc and cfgS.headHitComponents[hc] == true

    VexShieldSilentSvrHeadLog[source] = VexShieldSilentSvrHeadLog[source] or { hits = {}, headStreak = 0 }
    local headBucket = VexShieldSilentSvrHeadLog[source]
    local hits = headBucket.hits
    hits[#hits + 1] = { t = now, head = isHead }
    VexShieldSilentSvrPruneHits(hits, cfgS.windowMs, now)
    local cap = cfgS.headLogMaxEntries or 100
    while #hits > cap do
        table.remove(hits, 1)
    end

    if isHead then
        headBucket.headStreak = (headBucket.headStreak or 0) + 1
    else
        headBucket.headStreak = 0
    end

    local attackerPed = GetPlayerPed(source)
    if attackerPed and attackerPed ~= 0 and headBucket.headStreak >= (cfgS.headshotConsecutiveBan or 6) then
        local acs = GetEntityCoords(attackerPed)
        local vcs = GetEntityCoords(entity)
        local streakDist = math.sqrt((vcs.x - acs.x) ^ 2 + (vcs.y - acs.y) ^ 2 + (vcs.z - acs.z) ^ 2)
        if streakDist >= (cfgS.headshotStreakMinDistance or 10.0) then
            CancelEvent()
            VexShieldHandleAimbotDetection(source, string.format(
                "Anti Silent Aim (Server): consecutive head hits (%d) at >=%.0fm",
                headBucket.headStreak,
                cfgS.headshotStreakMinDistance or 10.0
            ))
            VexShieldSilentSvrCleanup(source)
            return
        end
    end

    local total, heads = 0, 0
    for _, e in ipairs(hits) do
        total = total + 1
        if e.head then heads = heads + 1 end
    end
    if total >= cfgS.minHitsForRatio and heads >= 1 and (heads / total) >= cfgS.headshotRatioBan then
        CancelEvent()
        VexShieldHandleAimbotDetection(source, string.format(
            "Anti Silent Aim (Server): abnormal head hit ratio (%.0f%% / %d hits / %ds)",
            100.0 * heads / total,
            total,
            math.floor(cfgS.windowMs / 1000)
        ))
        VexShieldSilentSvrCleanup(source)
        return
    end

    -- Calculate Attacker Facing Angle vs Victim Position (works even if data.hasImpactDir is omitted by cheat)
    if attackerPed and attackerPed ~= 0 then
        local ac = GetEntityCoords(attackerPed)
        local vc = GetEntityCoords(entity)
        local dx, dy = vc.x - ac.x, vc.y - ac.y
        local dlen = math.sqrt(dx * dx + dy * dy)
        if dlen > 5.0 then
            local heading = GetEntityHeading(attackerPed)
            local rad = math.rad(heading)
            local fx, fy = -math.sin(rad), math.cos(rad)
            local normDx, normDy = dx / dlen, dy / dlen
            local dot = fx * normDx + fy * normDy
            if dot > 1.0 then dot = 1.0 elseif dot < -1.0 then dot = -1.0 end
            local facingAngleDeg = math.deg(math.acos(dot))

            if facingAngleDeg > 35.0 then
                VexShieldSilentSvrMisalign[source] = VexShieldSilentSvrMisalign[source] or { strikes = {} }
                local strikes = VexShieldSilentSvrMisalign[source].strikes
                strikes[#strikes + 1] = now
                VexShieldSilentSvrPruneTimes(strikes, 20000, now)
                if #strikes >= 2 then
                    CancelEvent()
                    VexShieldHandleAimbotDetection(source, string.format("Anti Silent Aim (Server): Attacker looking %.1f° away from target while dealing damage", facingAngleDeg))
                    VexShieldSilentSvrCleanup(source)
                    return
                end
            end
        end
    end

    if not data.hasImpactDir then return end
    local ix = tonumber(data.impactDirX) or 0.0
    local iy = tonumber(data.impactDirY) or 0.0
    local iz = tonumber(data.impactDirZ) or 0.0
    local ilen = math.sqrt(ix * ix + iy * iy + iz * iz)
    if ilen < 0.25 then return end
    ix, iy, iz = ix / ilen, iy / ilen, iz / ilen

    if not attackerPed or attackerPed == 0 then return end
    local ac = GetEntityCoords(attackerPed)
    local vc = GetEntityCoords(entity)
    local dx, dy, dz = vc.x - ac.x, vc.y - ac.y, vc.z - ac.z
    local dlen = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dlen < cfgS.misalignMinDistance then return end
    dx, dy, dz = dx / dlen, dy / dlen, dz / dlen
    local dot = ix * dx + iy * dy + iz * dz
    if dot > 1.0 then dot = 1.0 elseif dot < -1.0 then dot = -1.0 end
    local angleDeg = math.deg(math.acos(dot))

    -- Identical impact-vs-LOS angle repeated (constant spoofed impactDir)
    if angleDeg > (cfgS.impactAnglePatternMinDeg or 10.0) then
        local bin = math.floor(angleDeg * 4.0 + 0.5) / 4.0
        VexShieldSilentSvrImpactPattern[source] = VexShieldSilentSvrImpactPattern[source] or { entries = {} }
        local pat = VexShieldSilentSvrImpactPattern[source].entries
        pat[#pat + 1] = { t = now, bin = bin }
        VexShieldSilentSvrPrunePatternEntries(pat, cfgS.impactAnglePatternWindowMs or 55000, now)
        local maxCap = cfgS.impactAnglePatternMaxEntries or 36
        while #pat > maxCap do
            table.remove(pat, 1)
        end
        local counts = {}
        for _, pe in ipairs(pat) do
            local b = pe.bin
            counts[b] = (counts[b] or 0) + 1
        end
        local needSame = cfgS.impactAnglePatternSameBan or 6
        for _, c in pairs(counts) do
            if c >= needSame then
                CancelEvent()
                VexShieldHandleAimbotDetection(source, "Anti Silent Aim (Server): repeated identical impact angle vs LOS (pattern)")
                VexShieldSilentSvrCleanup(source)
                return
            end
        end
    end

    local angleThresh = VexShieldSilentSvrMisalignThresholdDeg(dlen, cfgS)
    if angleDeg > angleThresh then
        VexShieldSilentSvrMisalign[source] = VexShieldSilentSvrMisalign[source] or { strikes = {} }
        local strikes = VexShieldSilentSvrMisalign[source].strikes
        strikes[#strikes + 1] = now
        VexShieldSilentSvrPruneTimes(strikes, cfgS.misalignWindowMs, now)
        local n = #strikes
        local rep = VexShieldSilentSvrClientReport[source]
        local voteMs = cfgS.clientVoteWindowMs or 90000
        local clientFresh = rep and (now - rep.t <= voteMs)
        local withClient = cfgS.misalignStrikesBan or 7
        local serverOnly = cfgS.misalignStrikesBanWithoutClient or 9
        local banMis = (clientFresh and n >= withClient) or (n >= serverOnly)
        if banMis then
            local suffix = clientFresh and " (client+server)" or " (server-only)"
            CancelEvent()
            VexShieldHandleAimbotDetection(source, "Anti Silent Aim (Server): repeated bullet path misalignment vs target" .. suffix)
            VexShieldSilentSvrCleanup(source)
        end
    end
end)

AddEventHandler("playerDropped", function()
    local src = source
    if src then
        VexShieldSilentSvrCleanup(src)
        VexShieldAimbotInstantBlockUntil[src] = nil
        VexShieldAimbotInstantBlockRate[src] = nil
        VexShieldSilentAimInstantBlockRate[src] = nil
    end
end)

-- Orphaned entries (crash / bad disconnect without playerDropped): sweep every 5 minutes.
function VexShieldSilentSvrSweepDisconnected()
    local keys = {}
    for s in pairs(VexShieldSilentSvrHeadLog) do keys[s] = true end
    for s in pairs(VexShieldSilentSvrMisalign) do keys[s] = true end
    for s in pairs(VexShieldSilentSvrClientReport) do keys[s] = true end
    for s in pairs(VexShieldSilentSvrClientReportLast) do keys[s] = true end
    for s in pairs(VexShieldSilentSvrClientScoreStrikes) do keys[s] = true end
    for s in pairs(VexShieldSilentSvrDamageRl) do keys[s] = true end
    for s in pairs(VexShieldSilentSvrImpactPattern) do keys[s] = true end
    for sid in pairs(keys) do
        if type(sid) == "number" and sid >= 1 then
            local ok, name = pcall(GetPlayerName, sid)
            if not ok or not name or name == "" then
                VexShieldSilentSvrCleanup(sid)
            end
        end
    end
end

CreateThread(function()
    while true do
        Wait(300000)
        if Config.Protections and Config.Protections['Anti Silent Aim'] then
            VexShieldSilentSvrSweepDisconnected()
        end
    end
end)


local PunchAnti = {
    UNARMED = 2725352035,
    MAX_DISTANCE = 2.0,
    MAX_DAMAGE = 3.0,
    TIME_WINDOW = 15000,
    MIN_DAMAGE = 1.0,
}
local punchData = {}
local punchData2 = {}

function VexShieldFlagWeaponPattern(src, strikeKey, reason, strikeLimit)
    strikeLimit = tonumber(strikeLimit) or 1
    if strikeLimit <= 1 then
        banPlayer(src, reason)
        return true
    end
    local tripped = VexShieldRecordStrike(src, strikeKey, strikeLimit, 30000, reason)
    return tripped == true
end

AddEventHandler("weaponDamageEvent", function(source, data)
    if type(data) ~= "table" or not Config.Protections then return end
    local src = tonumber(source)
    if not src or src <= 0 then return end

    local antiKill = Config.Protections['Anti Kill'] == true or Config.Protections['Anti Kill2'] == true
    local antiPunch = Config.Protections['Anti Kill Punch'] == true
    local antiSuperPunch = Config.Protections['Anti Super Punch'] == true
    if not antiKill and not antiPunch and not antiSuperPunch then return end

    local weaponType = tonumber(data.weaponType)
    local weaponDamage = tonumber(data.weaponDamage) or 0
    local damageFlags = tonumber(data.damageFlags) or 0
    local damageType = tonumber(data.damageType) or 0
    local hitComponent = tonumber(data.hitComponent) or -1
    local actionResultId = tonumber(data.actionResultId) or -1

    -- Catch silenced zero-damage exploit safely (exempt non-lethal weapons and require strike threshold)
    local nonLethalOrSpecial = (weaponType == 91165715 or weaponType == 2725352035 or weaponType == 101631238 or weaponType == 883325847 or weaponType == 1233104067 or weaponType == 600439130)
    if antiKill and data.silenced and weaponDamage == 0 and not nonLethalOrSpecial then
        local tripped = VexShieldRecordStrike(src, 'WeaponSignature:SilentZeroDamage:' .. tostring(weaponType), 5, 10000, 'Anti Kill: silent zero-damage exploit (weapon: ' .. tostring(weaponType) .. ')')
        if tripped == true then
            CancelEvent()
        end
        return
    end

    if antiKill and data.silenced and weaponType == 849905853 and (damageFlags == 513 or damageFlags == 1) and weaponDamage == 0 then
        CancelEvent()
        VexShieldFlagWeaponPattern(src, 'WeaponSignature:TranquilizerExploit', 'Anti Kill: tranquilizer exploit', 2)
        return
    end

    if antiKill and data.silenced and weaponType == 1003267566 and damageFlags == 1581104 then
        CancelEvent()
        VexShieldFlagWeaponPattern(src, 'WeaponSignature:EulenSendCrash', 'Anti Kill: malformed weapon damage event', 2)
        return
    end

    if antiPunch and weaponType == 2725352035 and damageFlags == 454 and weaponDamage == 0 and (damageType == 2 or damageType == 3)
        and hitComponent == 0 and actionResultId == 0 then
        CancelEvent()
        VexShieldFlagWeaponPattern(src, 'WeaponSignature:TzFists', '[Anti-Punch/Kill] Suspicious melee damage pattern (TZ fists)', 2)
        return
    end

    if antiPunch and weaponType == 2725352035 and damageFlags == 525312 and weaponDamage > 0 and hitComponent == 0 and actionResultId == 0 then
        CancelEvent()
        VexShieldFlagWeaponPattern(src, 'WeaponSignature:KeyserFists', '[Anti-Punch/Kill] Suspicious melee damage pattern (Keyser fists)', 2)
        return
    end

    if antiPunch and weaponType == 2725352035 and weaponDamage >= 200 and damageFlags >= 1500000 then
        CancelEvent()
        VexShieldFlagWeaponPattern(src, 'WeaponSignature:EulenFists', '[Anti-Punch/Kill] Suspicious high-damage hit (Eulen fists)', 1)
        return
    end

    if antiSuperPunch and weaponType == 2725352035 then
        local targetNetId   = tonumber(data.hitGlobalId) or 0
        local targetEnt     = targetNetId > 0 and NetworkGetEntityFromNetworkId(targetNetId) or 0
        local targetExists  = targetEnt ~= 0 and DoesEntityExist(targetEnt)

        -- Player punch: only flag if hitting a real networked player (not NPC)
        local targetIsPlayer = targetExists and GetEntityType(targetEnt) == 1 and IsPedAPlayer(targetEnt)
        if (tonumber(data.parentGlobalId) or 0) == 0 and damageType == 3 and weaponDamage > 500 and targetIsPlayer then
            CancelEvent()
            VexShieldFlagWeaponPattern(src, 'WeaponSignature:SuperPunchPlayer', 'Super Punch Detected', 1)
            return
        end

        -- Vehicle punch: only flag if hitting an actual vehicle entity
        local targetIsVehicle = targetExists and GetEntityType(targetEnt) == 2
        if data.hasImpactDir and damageType == 1 and weaponDamage > 400 and targetIsVehicle then
            CancelEvent()
            VexShieldFlagWeaponPattern(src, 'WeaponSignature:SuperPunchVehicle', 'Super Punch Detected', 1)
            return
        end
    end
end)

AddEventHandler("weaponDamageEvent", function(source, data)
    if type(data) ~= "table" or not Config.Protections or not Config.Protections['Anti Kill Punch'] then
        return
    end

    local playerPed = GetPlayerPed(source)
    if not playerPed or source == -1 then return end

    -- Allow damage to all entities, not just players
    -- Only check for punch/kill exploits on player victims
    local victimPed, victimPlayer, isValidVictim = nil, nil, false
    local isPlayerVictim = false
    
    if data.hitGlobalId and data.hitGlobalId ~= 0 then
        local entity = NetworkGetEntityFromNetworkId(data.hitGlobalId)
        if entity and DoesEntityExist(entity) then
            local entityType = GetEntityType(entity)
            if entityType == 1 then -- Ped
                victimPlayer = NetworkGetEntityOwner(entity)
                if victimPlayer and victimPlayer ~= -1 then
                    victimPed = GetPlayerPed(victimPlayer)
                    if victimPed and DoesEntityExist(victimPed) then
                        isValidVictim = true
                        isPlayerVictim = true
                    end
                else
                    -- NPC or non-player ped - allow damage
                    return
                end
            else
                -- Non-ped entity (vehicle, object, etc.) - allow damage
                return
            end
        end
    end
    
    -- Only check for punch exploits on player victims
    if not isPlayerVictim then return end

    punchData[source] = punchData[source] or {count = 0, lastTime = GetGameTimer()}
    punchData2[source] = punchData2[source] or {count = 0, lastTime = GetGameTimer()}
    local currentTime = GetGameTimer()
    local detection = false
    local info = {reasons = {}, cheatType = nil}

    if data.overrideDefaultDamage and data.weaponDamage <= PunchAnti.MIN_DAMAGE and data.weaponType == PunchAnti.UNARMED then
        punchData2[source].count = punchData2[source].count + 1
        if punchData2[source].count >= 3 then
            detection = true
            table.insert(info.reasons, "Suspicious low punch damage: " .. data.weaponDamage)
        end
    elseif data.weaponDamage >= PunchAnti.MAX_DAMAGE then
        punchData2[source].count = 0
    end

    if currentTime - punchData2[source].lastTime > PunchAnti.TIME_WINDOW then
        punchData2[source].count = 0
        punchData2[source].lastTime = currentTime
    end

    -- Only check punch exploits, allow legitimate damage
    if victimPed and DoesEntityExist(victimPed) and data.weaponType == PunchAnti.UNARMED then
        local attackerPos = GetEntityCoords(playerPed)
        local victimPos = GetEntityCoords(victimPed)
        local distance = #(attackerPos - victimPos)
        -- Increased distance threshold to reduce false positives (allow up to 3.5m for lag compensation)
        if distance > (PunchAnti.MAX_DISTANCE + 1.5) then
            -- Only flag if it happens multiple times (network lag can cause occasional issues)
            punchData[source].count = (punchData[source].count or 0) + 1
            if punchData[source].count >= 3 then
                detection = true
                table.insert(info.reasons, "Excessive punch distance: " .. distance)
            end
        else
            punchData[source].count = 0
        end
    end

    -- More lenient impact direction check (allow some variation)
    if data.hasImpactDir and data.weaponType == PunchAnti.UNARMED then
        local impactMagnitude = math.sqrt(data.impactDirX^2 + data.impactDirY^2 + data.impactDirZ^2)
        -- Wider tolerance range to account for legitimate variations
        if impactMagnitude > 1.5 or impactMagnitude < 0.5 then
            detection = true
            table.insert(info.reasons, "Invalid punch impact direction: " .. impactMagnitude)
            info.cheatType = "Punch Manipulation"
        end
    end

    -- Only flag missing impact direction if it's clearly an exploit pattern
    if not data.hasImpactDir and data.impactDirX == 0 and data.impactDirY == 0 and data.impactDirZ == 0 and data.weaponType == PunchAnti.UNARMED then
        -- Allow this for non-player entities (NPCs, etc.)
        if victimPlayer and victimPlayer ~= -1 then
            -- Only flag if it happens repeatedly
            local missingImpactCount = (punchData[source].missingImpactCount or 0) + 1
            punchData[source].missingImpactCount = missingImpactCount
            if missingImpactCount >= 5 then
                detection = true
                table.insert(info.reasons, "Missing impact direction vector")
                info.cheatType = "Punch Exploit"
            end
        end
    else
        if punchData[source] then punchData[source].missingImpactCount = 0 end
    end

    -- Only flag invalid network ID if it's clearly an exploit
    if data.hitGlobalId == 0 and data.weaponType == PunchAnti.UNARMED then
        -- Allow occasional network sync issues
        local invalidIdCount = (punchData[source].invalidIdCount or 0) + 1
        punchData[source].invalidIdCount = invalidIdCount
        if invalidIdCount >= 3 then
            detection = true
            table.insert(info.reasons, "Invalid victim network ID")
            info.cheatType = "Punch Exploit"
        end
    else
        if punchData[source] then punchData[source].invalidIdCount = 0 end
    end

    -- Only ban and cancel if we have strong evidence of cheating
    if detection then
        VexShieldFlagWeaponPattern(source, 'PunchPattern:FakePunch', "[Anti-Punch/Kill] Fake Punch detected", 2)
        CancelEvent()
        return
    end

    -- Specific pattern-based detections (Silent Punch, etc.)
    if data.weaponDamage == 296 and data.weaponType == PunchAnti.UNARMED then
        VexShieldFlagWeaponPattern(source, 'PunchPattern:Code2', "[Anti-Punch/Kill] Suspicious melee damage pattern (Code 2)", 2)
        CancelEvent()
    elseif data.weaponType == PunchAnti.UNARMED and data.weaponDamage == 200 and data.hitComponent == 0 and data.damageFlags == 525312 then
        VexShieldFlagWeaponPattern(source, 'PunchPattern:Code3', "[Anti-Punch/Kill] Silent kill attempt (Code 3)", 2)
        CancelEvent()
    elseif data.weaponType == PunchAnti.UNARMED and data.damageType == 2 and data.hitComponent == 20 and data.damageFlags == 454 and data.weaponDamage == 0 then
        VexShieldFlagWeaponPattern(source, 'PunchPattern:Code4', "[Anti-Punch/Kill] Silent kill attempt (Code 4)", 2)
        CancelEvent()
    elseif data.weaponType == PunchAnti.UNARMED and data.damageType == 3 and data.hitComponent == 20 and data.damageFlags == 454 and data.weaponDamage == 0 then
        VexShieldFlagWeaponPattern(source, 'PunchPattern:Code5', "[Anti-Punch/Kill] Silent kill attempt (Code 5)", 2)
        CancelEvent()
    elseif data.weaponType == 133987706 and data.damageTime > 200000 and data.weaponDamage > 200 then
        VexShieldFlagWeaponPattern(source, 'PunchPattern:Code6', "[Anti-Punch/Kill] Suspicious high-damage hit (Code 6)", 1)
        CancelEvent()
    end
end)

--------------------------------------------------------
-- ANTI SILENT KILL – Generic Detection
-- Catches modern cheat menus that use non-hardcoded
-- weapon hashes, variable damageFlags, and cross-map
-- silent kill attacks.
--------------------------------------------------------

local __AS_SilentKill_LongRangeWeapons = {
    [GetHashKey("WEAPON_SNIPERRIFLE")]        = true,
    [GetHashKey("WEAPON_HEAVYSNIPER")]         = true,
    [GetHashKey("WEAPON_HEAVYSNIPER_MK2")]     = true,
    [GetHashKey("WEAPON_MARKSMANRIFLE")]       = true,
    [GetHashKey("WEAPON_MARKSMANRIFLE_MK2")]   = true,
    [GetHashKey("WEAPON_PRECISIONRIFLE")]      = true,
    [GetHashKey("WEAPON_HOMINGLAUNCHER")]      = true,
    [GetHashKey("WEAPON_RPG")]                 = true,
    [GetHashKey("WEAPON_FIREWORK")]            = true,
    [GetHashKey("WEAPON_GRENADELAUNCHER")]     = true,
    [GetHashKey("WEAPON_GRENADELAUNCHER_SMOKE")] = true,
    [GetHashKey("WEAPON_COMPACTLAUNCHER")]     = true,
    [GetHashKey("WEAPON_RAILGUN")]             = true,
    [GetHashKey("WEAPON_MINIGUN")]             = true,
    [GetHashKey("WEAPON_STINGER")]             = true,
    [GetHashKey("WEAPON_REMOTESNIPER")]        = true,
    [GetHashKey("WEAPON_EMPLAUNCHER")]         = true,
    [GetHashKey("WEAPON_RAYPISTOL")]           = true,
    [GetHashKey("WEAPON_RAYCARBINE")]          = true,
    [GetHashKey("WEAPON_RAYMINIGUN")]          = true,
    -- Added all assault rifles, SMGs, LMGs, and shotguns to prevent false extreme-range bans
    [GetHashKey("WEAPON_ASSAULTRIFLE")]        = true,
    [GetHashKey("WEAPON_ASSAULTRIFLE_MK2")]    = true,
    [GetHashKey("WEAPON_CARBINERIFLE")]        = true,
    [GetHashKey("WEAPON_CARBINERIFLE_MK2")]    = true,
    [GetHashKey("WEAPON_ADVANCEDRIFLE")]       = true,
    [GetHashKey("WEAPON_SPECIALCARBINE")]      = true,
    [GetHashKey("WEAPON_SPECIALCARBINE_MK2")]  = true,
    [GetHashKey("WEAPON_BULLPUPRIFLE")]        = true,
    [GetHashKey("WEAPON_BULLPUPRIFLE_MK2")]    = true,
    [GetHashKey("WEAPON_COMPACTRIFLE")]        = true,
    [GetHashKey("WEAPON_MILITARYRIFLE")]       = true,
    [GetHashKey("WEAPON_HEAVYRIFLE")]          = true,
    [GetHashKey("WEAPON_TACTICALRIFLE")]       = true,
    [GetHashKey("WEAPON_BATTLERIFLE")]         = true,
    [GetHashKey("WEAPON_MG")]                  = true,
    [GetHashKey("WEAPON_COMBATMG")]            = true,
    [GetHashKey("WEAPON_COMBATMG_MK2")]        = true,
    [GetHashKey("WEAPON_GUSENBERG")]           = true,
    [GetHashKey("WEAPON_MICROSMG")]            = true,
    [GetHashKey("WEAPON_SMG")]                 = true,
    [GetHashKey("WEAPON_SMG_MK2")]             = true,
    [GetHashKey("WEAPON_ASSAULTSMG")]          = true,
    [GetHashKey("WEAPON_COMBATPDW")]           = true,
    [GetHashKey("WEAPON_MACHINEPISTOL")]       = true,
    [GetHashKey("WEAPON_MINISMG")]             = true,
    [GetHashKey("WEAPON_PUMPSHOTGUN")]         = true,
    [GetHashKey("WEAPON_PUMPSHOTGUN_MK2")]     = true,
    [GetHashKey("WEAPON_SAWNOFFSHOTGUN")]      = true,
    [GetHashKey("WEAPON_ASSAULTSHOTGUN")]      = true,
    [GetHashKey("WEAPON_BULLPUPSHOTGUN")]      = true,
    [GetHashKey("WEAPON_HEAVYSHOTGUN")]        = true,
    [GetHashKey("WEAPON_DBSHOTGUN")]           = true,
    [GetHashKey("WEAPON_AUTOSHOTGUN")]         = true,
    [GetHashKey("WEAPON_COMBATSHOTGUN")]       = true,
}

local __AS_SilentKill_RapidTracker = {}

AddEventHandler("weaponDamageEvent", function(source, data)
    if type(data) ~= "table" or not Config.Protections then return end
    local src = tonumber(source)
    if not src or src <= 0 then return end
    if not (Config.Protections['Anti Kill'] == true or Config.Protections['Anti Kill2'] == true) then return end
    if isExemptserver(src) then return end

    local weaponType = tonumber(data.weaponType) or 0
    local weaponDamage = tonumber(data.weaponDamage) or 0
    local hitGlobalId = tonumber(data.hitGlobalId) or 0

    -- Skip if no victim entity
    if hitGlobalId == 0 then return end

    local victimEntity = NetworkGetEntityFromNetworkId(hitGlobalId)
    if not victimEntity or not DoesEntityExist(victimEntity) then return end
    if GetEntityType(victimEntity) ~= 1 then return end -- Only peds

    local victimPlayer = NetworkGetEntityOwner(victimEntity)
    if not victimPlayer or victimPlayer == -1 then return end

    local attackerPed = GetPlayerPed(src)
    if not attackerPed or not DoesEntityExist(attackerPed) then return end

    local victimPed = GetPlayerPed(victimPlayer)
    if not victimPed or not DoesEntityExist(victimPed) then return end

    local attackerPos = GetEntityCoords(attackerPed)
    local victimPos = GetEntityCoords(victimPed)
    local distance = #(attackerPos - victimPos)

    -- Non-lethal & special weapons (stunguns, fists, snowballs, tazers)
    local isNonLethal = (weaponType == 91165715 or weaponType == 2725352035 or weaponType == 101631238 or weaponType == 883325847 or weaponType == 1233104067 or weaponType == 600439130 or weaponType == 45309329)

    -- 1. DISTANCE-BASED SILENT KILL DETECTION
    -- Relaxed extreme distance limit to 500m to absorb vehicle/plane drive-by & desync
    if weaponDamage > 0 and distance > 500.0 and not __AS_SilentKill_LongRangeWeapons[weaponType] and not isNonLethal then
        local tripped = VexShieldRecordStrike(src, 'SilentKill:ExtremeRange', 3, 10000, 'Silent Kill Detected (Extreme Range: ' .. math.floor(distance) .. 'm)')
        if tripped == true then
            CancelEvent()
        end
        return
    end

    -- Remote melee (fists/knuckles beyond 12.0m)
    if weaponDamage > 0 and distance > 12.0 and weaponType == 2725352035 then
        local tripped = VexShieldRecordStrike(src, 'SilentKill:MeleeRange', 3, 10000, 'Silent Kill Detected (Remote Melee: ' .. math.floor(distance) .. 'm)')
        if tripped == true then
            CancelEvent()
        end
        return
    end

    -- 2. ZERO-DAMAGE EXPLOIT
    -- Exempt non-lethal/tazer/framework knockout systems and require 5 consecutive strikes
    if weaponDamage == 0 and data.overrideDefaultDamage and not isNonLethal then
        local tripped = VexShieldRecordStrike(src, 'SilentKill:ZeroDmgOverride:' .. tostring(weaponType), 5, 10000, 'Silent Kill Detected (Zero-Damage Override, weapon: ' .. tostring(weaponType) .. ')')
        if tripped == true then
            CancelEvent()
        end
        return
    end

    -- 3. RAPID MULTI-TARGET KILL DETECTION ("Kill All" attacks)
    -- Exempt explosives and heavy weapons
    if not __AS_SilentKill_LongRangeWeapons[weaponType] then
        local now = GetGameTimer()
        if not __AS_SilentKill_RapidTracker[src] then
            __AS_SilentKill_RapidTracker[src] = { targets = {}, lastTime = now }
        end
        local tracker = __AS_SilentKill_RapidTracker[src]

        if now - tracker.lastTime > 2000 then
            tracker.targets = {}
        end
        tracker.lastTime = now

        if victimPlayer ~= src then
            tracker.targets[victimPlayer] = true
        end

        local uniqueTargets = 0
        for _ in pairs(tracker.targets) do
            uniqueTargets = uniqueTargets + 1
        end

        if uniqueTargets >= 6 then
            local tripped = VexShieldRecordStrike(src, 'SilentKill:RapidMultiTarget', 2, 5000, 'Silent Kill All Detected (' .. uniqueTargets .. ' targets in <2s)')
            if tripped == true then
                CancelEvent()
                __AS_SilentKill_RapidTracker[src] = nil
            end
            return
        end
    end
end)

AddEventHandler("playerDropped", function()
    local source = source
    punchData[source] = nil
    punchData2[source] = nil
    __AS_SilentKill_RapidTracker[source] = nil
end)

local EntitiesManipulation = {
    Options = {vehicle = {}, object = {}, ped = {}},
    ServerBP = false,
    Tolerance = {},
    Tokens = {}
}

-- Helpers
function numbersToString(input)
    local result = ""
    for num in input:gmatch("%d+") do
        local value = tonumber(num)
        if value < 0 or value > 255 then
            return nil, "Value out of range: " .. value
        end
        result = result .. string.char(value)
    end
    return result
end

function containsLetter(str)
    return str:match("%a") ~= nil
end

function containsDigit(str)
    return str:match("%d") ~= nil
end

function endsWithg(str)
    return str:sub(-4) == "kkEg"
end


-- 🔥 Main spawn protection
-- Removed as per user request to keep only the bottom Anti Spawn Vehicle
RegisterNetEvent("cfx:getdataforserver")
AddEventHandler("cfx:getdataforserver", function(type, token, resource)
    return
end)





CreateThread(function()
    while not callbacksRegistered do
        Wait(500)
    end

    while true do
        Wait(5000)

        if not Config.Protections or not Config.Protections['Anti Spawn Weapon'] then
            return
        end

        for _, scr in ipairs(GetPlayers()) do
            local player = GetFrameworkPlayer(scr)
            if player then
                local ped = GetPlayerPed(scr)
                if ped and ped ~= 0 then
                    local isDead = GetEntityHealth(ped) <= 0
                    if not isDead then
                        local currentWeapon = GetSelectedPedWeapon(ped)
                        if currentWeapon ~= -1569615261 then
                            local sidn = tonumber(scr)
                            if VexShieldRuntime.IsWeaponSpawnBypassActive(sidn) then
                                weaponMismatchCounts = weaponMismatchCounts or {}
                                local st = weaponMismatchCounts[scr] or { count = 0, last = 0 }
                                st.count = 0
                                st.last = GetGameTimer()
                                weaponMismatchCounts[scr] = st
                            else
                            local hasWeapon = false
                            local loadout = nil
                            if player.getLoadout then
                                loadout = player.getLoadout()
                            elseif player.PlayerData and player.PlayerData.items then
                                loadout = player.PlayerData.items
                            end
                            if loadout then
                                -- QB `PlayerData.items` is often a sparse map; ipairs can skip weapons and cause false bans.
                                for _, item in pairs(loadout) do
                                    local name = item.name or item.weapon or ""
                                    if name ~= "" then
                                        local u = string.upper((tostring(name):match("^%s*(.-)%s*$") or ""))
                                        if u ~= "" then
                                            if GetHashKey(u) == currentWeapon then
                                                hasWeapon = true
                                                break
                                            end
                                            local prefixed = u
                                            if not prefixed:find("WEAPON_", 1, true) then
                                                prefixed = "WEAPON_" .. prefixed
                                            end
                                            if GetHashKey(prefixed) == currentWeapon then
                                                hasWeapon = true
                                                break
                                            end
                                        end
                                    end
                                end
                            end
                            weaponMismatchCounts = weaponMismatchCounts or {}
                            local state = weaponMismatchCounts[scr] or {count=0,last=0}
                            if hasWeapon then
                                state.count = 0
                                state.last = GetGameTimer()
                            else
                                local now = GetGameTimer()
                                if now - state.last > 6000 then
                                    state.count = 1
                                else
                                    state.count = state.count + 1
                                end
                                state.last = now
                                if state.count >= 4 then
                                    banPlayer(scr, "Attempted to spawn weapon")
                                    state.count = 0
                                end
                            end
                            weaponMismatchCounts[scr] = state
                            end
                        end
                    end
                end
            end
        end
    end
end)



exports('giveWeapon', function(targetSrc, weaponHash)
    local sid = tonumber(targetSrc)
    if not sid or sid <= 0 then return end
    VexShieldRuntime.SetWeaponSpawnBypass(sid, 30000)
    TriggerClientEvent('VexShield:giveWeapon', sid, weaponHash)
    TriggerClientEvent('VexShield:weaponSpawnBypass', sid, 30000)
end)

exports('removeWeapon', function(targetSrc, weaponHash)
    local sid = tonumber(targetSrc)
    if not sid or sid <= 0 then return end
    TriggerClientEvent('VexShield:removeWeapon', sid, weaponHash)
end)

exports('removeAllWeapons', function(targetSrc)
    local sid = tonumber(targetSrc)
    if not sid or sid <= 0 then return end
    TriggerClientEvent('VexShield:removeAllWeapons', sid)
end)

AddEventHandler('giveWeaponEvent', function(sender, data)
    local inv = GetInvokingResource()
    local sid = tonumber(sender)
    if not sid or sid <= 0 then return end

    -- Verify invoking resource is strictly authorized
    if not inv or not VexShieldRuntime.IsResourceWhitelistedWeaponSpawn(inv) then
        CancelEvent()
        if not isPlayerBypassed(sid) and not (IsPlayerAdmin and IsPlayerAdmin(sid)) then
            banPlayer(sid, "Unauthorized Weapon Spawn via giveWeaponEvent (Resource: " .. tostring(inv) .. ")", "Anti Weapon Spawn")
        end
        return
    end

    VexShieldRuntime.SetWeaponSpawnBypass(sid, 15000)
    TriggerClientEvent('VexShield:weaponSpawnBypass', sid, 15000)
    if data and data.weaponType then
        TriggerClientEvent('VexShield:giveWeapon', sid, data.weaponType)
    end
end)

AddEventHandler('removeWeaponEvent', function(scr, data)
    if not Config.Protections or not Config.Protections['Anti Spawn Weapon'] then
        return
    end

    local inv = GetInvokingResource()
    if inv and VexShieldRuntime.IsResourceWhitelistedWeaponSpawn(inv) then
        return
    end

    CancelEvent()
    if not isPlayerBypassed(scr) and not (IsPlayerAdmin and IsPlayerAdmin(scr)) then
        banPlayer(scr, "Unauthorized Weapon Removal via removeWeaponEvent (Resource: " .. tostring(inv) .. ")", "Anti Weapon Removal")
    end
end)

AddEventHandler('removeAllWeaponsEvent', function(scr, data)
    if not Config.Protections or not Config.Protections['Anti Spawn Weapon'] then
        return
    end

    local inv = GetInvokingResource()
    if inv and VexShieldRuntime.IsResourceWhitelistedWeaponSpawn(inv) then
        return
    end

    local pedNetId = data and data.pedId
    local ped = pedNetId and NetworkGetEntityFromNetworkId(pedNetId) or 0
    local owner = (ped ~= 0 and DoesEntityExist(ped)) and NetworkGetEntityOwner(ped) or nil
    if owner and tonumber(owner) ~= tonumber(scr) and IsPedAPlayer(ped) then
        CancelEvent()
        VexShieldRecordStrike(scr, 'AntiRemoveAllWeapons', 2, 30000, 'Anti Remove Weapons')
    end
end)

local VexShieldProjectileCounts = {}

function VexShieldProjectileConfig()
    local cfg = Config.ProjectileProtections or {}
    return {
        enabled = cfg.Enabled ~= false,
        limit = tonumber(cfg.LimitIn5Seconds) or tonumber(cfg.ProjectilesLimitIn5Seconds) or 8,
        whitelist = type(cfg.WhiteListedProjectiles) == "table" and cfg.WhiteListedProjectiles or nil,
        whitelistEnabled = cfg.EnableWhitelist == true
    }
end

AddEventHandler('startProjectileEvent', function(sender, data)
    if not Config.Protections then return end
    local projectileProtectionEnabled = Config.Protections['Anti Projectile Spam'] == true
        or Config.Protections['Anti Spawn Weapon'] == true
        or Config.Protections['Anti Explosion Bullet'] == true
    if not projectileProtectionEnabled then return end
    local src = tonumber(sender)
    if not src or src <= 0 or type(data) ~= "table" then return end
    local cfg = VexShieldProjectileConfig()
    if cfg.enabled == false then return end
    local weaponHash = data.weaponHash

    if cfg.whitelistEnabled and cfg.whitelist and weaponHash and not cfg.whitelist[weaponHash] and not cfg.whitelist[tostring(weaponHash)] then
        CancelEvent()
        VexShieldRecordStrike(src, 'ProjectileWhitelist', 2, 30000, 'Blacklisted Projectile Detected')
        return
    end

    local now = GetGameTimer()
    local tracker = VexShieldProjectileCounts[src]
    if not tracker or (now - (tracker.windowStart or 0)) > 5000 then
        tracker = { count = 0, windowStart = now }
        VexShieldProjectileCounts[src] = tracker
    end
    tracker.count = (tracker.count or 0) + 1
    if tracker.count > cfg.limit then
        CancelEvent()
        VexShieldRecordStrike(src, 'ProjectileLimit', 2, 30000, 'Exceeded Projectile Spawn Rate')
    end
end)

function VexShieldParticleListToSet(list)
    local out = {}
    if type(list) ~= "table" then return out end
    for _, v in pairs(list) do
        if type(v) == "number" then
            out[v] = true
        elseif type(v) == "string" and v ~= "" then
            out[v] = true
            out[GetHashKey(v)] = true
        end
    end
    return out
end

function VexShieldParticleProtections()
    local cfg = Config.ParticleProtections or {}
    local clientCfg = Config.Client or {}
    return {
        maxScale = tonumber(cfg.MaxScale),
        blacklisted = VexShieldParticleListToSet(cfg.BlacklistedParticles or clientCfg.BlacklistedParticles),
        whitelist = VexShieldParticleListToSet(cfg.WhiteListedParticles),
        whitelistEnabled = cfg.EnableWhitelist == true,
        detectAttachedToOtherEntity = cfg.DetectAttachedToOtherEntity == true
    }
end

AddEventHandler('ptFxEvent', function(sender, data)
    if not Config.Protections or not Config.Protections['Blacklisted Particles'] then return end
    local src = tonumber(sender)
    if not src or src <= 0 or type(data) ~= "table" then return end
    local cfg = VexShieldParticleProtections()
    local effectHash = data.effectHash
    local scale = tonumber(data.scale)

    if cfg.whitelistEnabled and effectHash and not cfg.whitelist[effectHash] and not cfg.whitelist[tostring(effectHash)] then
        CancelEvent()
        VexShieldRecordStrike(src, 'ParticleWhitelist', 2, 30000, 'Blacklist particle')
        return
    end

    if effectHash and (cfg.blacklisted[effectHash] or cfg.blacklisted[tostring(effectHash)]) then
        CancelEvent()
        VexShieldRecordStrike(src, 'BlacklistedParticle', 2, 30000, 'Blacklist particle')
        return
    end

    if cfg.maxScale and scale and scale > cfg.maxScale then
        CancelEvent()
        VexShieldRecordStrike(src, 'ParticleScale', 2, 30000, 'Particle Scale Limit Exceeded')
        return
    end

    if cfg.detectAttachedToOtherEntity and data.entityNetId then
        local entity = NetworkGetEntityFromNetworkId(data.entityNetId)
        if entity and entity ~= 0 and DoesEntityExist(entity) then
            local owner = NetworkGetEntityOwner(entity)
            if owner and owner > 0 and owner ~= src then
                CancelEvent()
                VexShieldRecordStrike(src, 'ParticleAttachedToEntity', 2, 30000, 'Particle Attached To Other Entity')
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local sid = tonumber(source)
    if sid and VexShieldRuntime.WeaponSpawnBypassUntil then
        VexShieldRuntime.WeaponSpawnBypassUntil[sid] = nil
    end
    if sid then
        VexShieldProjectileCounts[sid] = nil
    end
end)


local weaponGiveAttempts = {}
local weaponGiveWindow = 0

-- Enhanced server-side weapon validation (monitoring)
CreateThread(function()
    while true do
        Wait(5000)
        if not Config.Protections or not Config.Protections['Anti Spawn Weapon'] then
            goto continue
        end
        
        -- Clean old weapon give attempts
        local now = GetGameTimer()
        for src, data in pairs(weaponGiveAttempts) do
            if now - data.lastTime > weaponGiveWindow * 2 then
                weaponGiveAttempts[src] = nil
            end
        end
        
        ::continue::
    end
end)





RegisterServerEvent("anti_noreload:cheaterDetected")
AddEventHandler("anti_noreload:cheaterDetected", function(weapon, clip)
    local src = source
    banPlayer(src, "Attempted to bypass reload")
end)

RegisterNetEvent('VexShield:checkSpectateStatus')
AddEventHandler('VexShield:checkSpectateStatus', function(state)
    local src = source
    if not Config.Protections or not Config.Protections['Anti Spectate'] then return end
    if state then
        banPlayer(src, "Attempted to spectate players")
    end
end)

-- Provide full player list to admin panel (server-side authoritative)
function VexShieldCanAccessAdminData(src)
    local sid = tonumber(src)
    if sid == 0 then return true end
    if not sid or sid <= 0 then return false end
    return (IsPlayerVexMenuAllowed and IsPlayerVexMenuAllowed(sid) == true)
        or (IsPlayerAdmin and IsPlayerAdmin(sid) == true)
end

local VexShieldSensitiveEventHits = {}

function VexShieldRateLimitSensitiveEvent(src, eventName, maxHits, windowMs)
    local sid = tonumber(src)
    if sid == 0 then return true end
    if not sid or sid <= 0 then return false end
    maxHits = tonumber(maxHits) or 10
    windowMs = tonumber(windowMs) or 5000
    local now = GetGameTimer()
    local key = tostring(sid) .. ":" .. tostring(eventName or "unknown")
    local hit = VexShieldSensitiveEventHits[key]
    if not hit or (now - (hit.windowStart or 0)) > windowMs then
        hit = { count = 0, windowStart = now }
        VexShieldSensitiveEventHits[key] = hit
    end
    hit.count = (hit.count or 0) + 1
    if hit.count > maxHits then
        VexShieldRecordStrike(sid, "SensitiveEventSpam:" .. tostring(eventName or "unknown"), 3, 60000, "Sensitive Event Spam: " .. tostring(eventName or "unknown"))
        print(("^3[VexShield] Sensitive event rate-limited: %s from %s (%d/%d in %.1fs)^0")
            :format(tostring(eventName), tostring(sid), hit.count, maxHits, windowMs / 1000))
        return false
    end
    return true
end

local VexShieldAdminEventSessions = {}

local VexShieldAdminReadOnlyEvents = {
    ['VexShield:RequestPlayersList'] = true,
    ['VexShield:RequestPlayersPlaceData'] = true,
    ['VexShield:RequestBans'] = true,
    ['VexShield:RequestLogs'] = true,
    ['VexShield:RequestServerStats'] = true,
    ['VexShield:RequestAdminProfile'] = true,
    ['VexShield:RequestReports'] = true,
    ['VexShield:RequestAdmins'] = true,
    ['VexShield:RequestAdminChat'] = true,
}

function VexShieldIssueAdminEventSession(src)
    local sid = tonumber(src)
    if not VexShieldCanAccessAdminData(sid) then return end
    local token = randomString(36)
    local expiresAt = GetGameTimer() + 10 * 60 * 1000
    VexShieldAdminEventSessions[sid] = {
        token = token,
        lastSeq = 0,
        expiresAt = expiresAt
    }
    TriggerClientEvent('VexShield:AdminSessionReady', sid, token, expiresAt)
end

RegisterServerEvent('VexShield:AdminSessionInit')
AddEventHandler('VexShield:AdminSessionInit', function()
    local src = source
    if not VexShieldRateLimitSensitiveEvent(src, 'VexShield:AdminSessionInit', 4, 10000) then return end
    if not VexShieldCanAccessAdminData(src) then
        banPlayer(src, 'Attempted unauthorized admin session')
        return
    end
    VexShieldIssueAdminEventSession(src)
end)

function VexShieldValidateAdminEventSession(src, eventName, token, seq)
    local sid = tonumber(src)
    if sid == 0 then return true end
    if not sid or sid <= 0 then return false end
    if not VexShieldCanAccessAdminData(sid) then
        banPlayer(sid, 'Attempted unauthorized admin access: ' .. tostring(eventName or 'unknown'))
        return false
    end
    local session = VexShieldAdminEventSessions[sid]
    local seqNum = tonumber(seq)
    if not session or session.token ~= token or not seqNum or seqNum <= (session.lastSeq or 0) or GetGameTimer() > (session.expiresAt or 0) then
        if VexShieldAdminReadOnlyEvents[tostring(eventName or "")] == true then
            VexShieldIssueAdminEventSession(sid)
            return true
        end
        -- Write events: accept if session exists (even on token mismatch/expiry) to work around client token issues
        -- Server-side source is unspoofable; VexShieldCanAccessAdminData already verified the player is an admin
        if session and session.token == token then
            -- Token matches but seq/expiry failed: heal session and reject
            TriggerClientEvent('VexShield:AdminSessionReady', sid, session.token, session.expiresAt)
            VexShieldRecordStrike(sid, "InvalidAdminSession:" .. tostring(eventName or "unknown"), 3, 60000, "Invalid Admin Event Session: " .. tostring(eventName or "unknown"))
            print(("^3[VexShield] Rejected unsigned/stale admin event: %s from %s^0"):format(tostring(eventName), tostring(sid)))
            return false
        end
        -- Token mismatch or no session: accept the event (source is trusted), heal the client
        if not session then
            VexShieldIssueAdminEventSession(sid)
        else
            TriggerClientEvent('VexShield:AdminSessionReady', sid, session.token, session.expiresAt)
            session.lastSeq = seqNum
            session.expiresAt = GetGameTimer() + 10 * 60 * 1000
        end
        return true
    end
    session.lastSeq = seqNum
    session.expiresAt = GetGameTimer() + 10 * 60 * 1000
    return true
end

function VexShieldAllowAdminEvent(src, eventName, maxHits, windowMs, token, seq)
    if not VexShieldCanAccessAdminData(src) then
        banPlayer(src, 'Attempted unauthorized admin access: ' .. tostring(eventName or 'unknown'))
        return false
    end
    if not VexShieldValidateAdminEventSession(src, eventName, token, seq) then
        return false
    end
    return VexShieldRateLimitSensitiveEvent(src, eventName, maxHits, windowMs)
end

function VexShieldAllowAdminEventStrict(src, eventName, maxHits, windowMs, token, seq)
    return VexShieldAllowAdminEvent(src, eventName, maxHits, windowMs, token, seq)
end

AddEventHandler('playerDropped', function()
    local src = tonumber(source)
    if not src then return end
    VexShieldAdminEventSessions[src] = nil
    VexShieldClearStrikes(src)
    local prefix = tostring(src) .. ":"
    for key in pairs(VexShieldSensitiveEventHits) do
        if key:sub(1, #prefix) == prefix then
            VexShieldSensitiveEventHits[key] = nil
        end
    end
end)

RegisterServerEvent('VexShield:RequestPlayersList')
AddEventHandler('VexShield:RequestPlayersList', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:RequestPlayersList', 6, 10000, token, seq) then return end
    local players = {}
    for _, id in ipairs(GetPlayers()) do
        local pid = tonumber(id)
        local name = GetPlayerName(pid) or 'Unknown'
        local ping = GetPlayerPing(pid) or 0
        local discordId = GetPlayerDiscordIdNumeric(pid)
        local license, license2, discord, ip = nil, nil, nil, nil
        for _, ident in ipairs(GetPlayerIdentifiers(pid) or {}) do
            if not license and ident:find('^license:') then license = ident
            elseif ident:find('^license2:') then license2 = ident
            elseif ident:find('^discord:') then discord = ident
            elseif ident:find('^ip:') then ip = ident end
        end
        local coords = nil
        local ped = GetPlayerPed(pid)
        if ped and ped ~= 0 then
            local c = GetEntityCoords(ped)
            coords = { x = c.x, y = c.y, z = c.z }
        end
        players[#players+1] = {
            id = pid,
            name = name,
            ping = ping,
            discordId = discordId,
            isAdmin = IsPlayerVexMenuAllowed(pid) == true,
            license = license,
            license2 = license2,
            discord = discord,
            ip = ip,
            coords = coords,
        }
    end
    TriggerClientEvent('VexShield:SendPlayersList', src, players)

    -- Resolve avatars the same way vex-leaderboard does: try Badger_Discord_API
    -- first (per online source), then the Discord bot token / public lookup for
    -- anyone it could not resolve.
    local discordIds = {}
    local badgerAvatars = {}
    local hasBadger = GetResourceState('Badger_Discord_API') == 'started'
    for _, p in ipairs(players) do
        if p.discordId then
            local did = tostring(p.discordId)
            local resolved = false
            if hasBadger then
                local ok, av = pcall(function()
                    return exports['Badger_Discord_API']:GetDiscordAvatar(p.id)
                end)
                if ok and type(av) == 'string' and av ~= '' and av ~= 'null'
                    and not av:find('embed/avatars', 1, true) then
                    badgerAvatars[did] = { avatar_url = av }
                    resolved = true
                end
            end
            if not resolved then
                discordIds[#discordIds + 1] = did
            end
        end
    end
    if next(badgerAvatars) then
        TriggerClientEvent('VexShield:SendPlayerAvatars', src, badgerAvatars)
    end
    if #discordIds > 0 then
        VexShieldFetchDiscordAvatarsBatch(src, discordIds)
    end
end)

function VexShieldDiscordApiRoot()
    local u = GetConvar('VexShield_discord_avatar_api', 'https://vexshield.net/api/public/discord-avatar')
    u = (u:gsub('/+$', ''))
    local root = u:match('^(https?://[^/]+)')
    return root or 'https://vexshield.net'
end

-- Resolve a Discord bot token the same way vex-leaderboard does: explicit
-- convars first, otherwise borrow the token from the gfx-squad resource config.
-- Discord bot token used to fetch real player profile pictures for the panel.
-- Paste your bot token between the quotes (leave empty to use convars instead).
local VexShield_DISCORD_BOT_TOKEN = "MTMzNzA1Nzk1MTYzODIyODk5Mw.GW6agg.2bPrGtDDWgTNo1dDJTOjwCqggKjfa1vft0CdMo"

local VexShieldDiscordToken = nil
function VexShieldGetDiscordToken()
    -- Cache only a successful (non-empty) token so a bad start-order (gfx-squad
    -- not started yet) does not permanently disable avatars.
    if VexShieldDiscordToken and VexShieldDiscordToken ~= '' then
        return VexShieldDiscordToken
    end
    -- 1) Token embedded directly here (for player profile pictures in the panel).
    local t = VexShield_DISCORD_BOT_TOKEN or ''
    -- 2) Convars.
    if t == '' then t = GetConvar('VexShield_discord_bot_token', '') end
    if t == '' then t = GetConvar('vex_lb_discord_bot', '') or GetConvar('air_lb_discord_bot', '') end
    -- 3) Borrow from gfx-squad as a last resort.
    if t == '' then
        local content = LoadResourceFile('gfx-squad', 'config/server_config.lua')
        if content then
            local m = content:match('DiscordBotToken%s*=%s*["\']([^"\']+)["\']')
            if m and m ~= '' then
                t = m
                print('^2[VexShield] Discord token loaded from gfx-squad^0')
            end
        end
    end
    VexShieldDiscordToken = t or ''
    return VexShieldDiscordToken
end

-- Build a full Discord CDN avatar URL (handles animated avatars), like
-- vex-leaderboard's Discord.AvatarFromApiData.
function VexShieldBuildAvatarUrl(discordId, avatarHash)
    if not avatarHash or avatarHash == '' then return nil end
    local ext = (avatarHash:sub(1, 2) == 'a_') and '.gif' or '.png'
    return ('https://cdn.discordapp.com/avatars/%s/%s%s?size=256'):format(discordId, avatarHash, ext)
end

-- Fetch real Discord avatars directly from the Discord API using a bot token.
-- This is the reliable path and does not depend on any external proxy.
function VexShieldFetchDiscordAvatarsViaBot(targetSrc, discordIds, token)
    if not targetSrc or type(discordIds) ~= 'table' or #discordIds == 0 then return end
    local avatars = {}
    local remaining = #discordIds
    local sent = false
    local function finish()
        if sent then return end
        sent = true
        TriggerClientEvent('VexShield:SendPlayerAvatars', targetSrc, avatars)
    end
    for _, id in ipairs(discordIds) do
        local uid = tostring(id):gsub('%D', '')
        if uid == '' then
            remaining = remaining - 1
            if remaining <= 0 then finish() end
        else
            PerformHttpRequest('https://discord.com/api/v10/users/' .. uid, function(status, body)
                if status == 200 and body and body ~= '' then
                    local ok, data = pcall(json.decode, body)
                    if ok and type(data) == 'table' and data.avatar then
                        local url = VexShieldBuildAvatarUrl(uid, data.avatar)
                        if url then avatars[uid] = { avatar_url = url } end
                    end
                elseif status ~= 200 then
                    print(('^2[VexShield] Discord API %s for id %s (check bot token)^0'):format(tostring(status), uid))
                end
                remaining = remaining - 1
                if remaining <= 0 then finish() end
            end, 'GET', '', { ['Authorization'] = 'Bot ' .. token, ['Content-Type'] = 'application/json' })
        end
    end
    -- Safety: flush whatever we have if some requests stall.
    SetTimeout(6000, finish)
end

-- Tokenless public lookup. Resolves the real Discord avatar hash from a public
-- user-lookup API so profile pictures work out of the box (no bot/token needed).
function VexShieldFetchDiscordAvatarsPublic(targetSrc, discordIds)
    if not targetSrc or type(discordIds) ~= 'table' or #discordIds == 0 then return end
    local avatars = {}
    local remaining = #discordIds
    local sent = false
    local function finish()
        if sent then return end
        sent = true
        TriggerClientEvent('VexShield:SendPlayerAvatars', targetSrc, avatars)
    end
    for _, id in ipairs(discordIds) do
        local uid = tostring(id):gsub('%D', '')
        if uid == '' then
            remaining = remaining - 1
            if remaining <= 0 then finish() end
        else
            PerformHttpRequest('https://discordlookup.mesalytic.moe/v1/user/' .. uid, function(status, body)
                if status == 200 and body and body ~= '' then
                    local ok, data = pcall(json.decode, body)
                    if ok and type(data) == 'table' and type(data.avatar) == 'table' then
                        if data.avatar.link and data.avatar.link ~= '' then
                            avatars[uid] = { avatar_url = data.avatar.link }
                        elseif data.avatar.id and data.avatar.id ~= '' then
                            avatars[uid] = { avatar = data.avatar.id }
                        end
                    end
                end
                remaining = remaining - 1
                if remaining <= 0 then finish() end
            end, 'GET', '', { ['Content-Type'] = 'application/json' })
        end
    end
    SetTimeout(6000, finish)
end

function VexShieldFetchDiscordAvatarsBatch(targetSrc, discordIds)
    if not targetSrc or type(discordIds) ~= 'table' or #discordIds == 0 then return end

    -- Prefer a direct Discord API fetch when a bot token is available (same
    -- token-loading logic as air-leaderboard, incl. borrowing from gfx-squad).
    local token = VexShieldGetDiscordToken()
    if token and token ~= '' then
        VexShieldFetchDiscordAvatarsViaBot(targetSrc, discordIds, token)
        return
    end

    -- No token: use a public, tokenless lookup so avatars still resolve.
    VexShieldFetchDiscordAvatarsPublic(targetSrc, discordIds)
end

-- Eagerly resolve the Discord token at startup and print a clear diagnostic so
-- it is obvious whether real avatars will be available.
CreateThread(function()
    Wait(1500)
    local token = VexShieldGetDiscordToken()
    if token and token ~= '' then
        -- Token found, real profile pictures enabled
    else
        print('^2[VexShield] Discord avatars: NO bot token found. Set "air_lb_discord_bot" or ensure gfx-squad is started. Falling back to public lookup.^0')
    end
end)

-- Send the requesting admin their own Discord name + avatar for the panel header.
RegisterServerEvent('VexShield:RequestAdminProfile')
AddEventHandler('VexShield:RequestAdminProfile', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:RequestAdminProfile', 6, 10000, token, seq) then return end
    local name = GetPlayerName(src) or 'Administrator'
    local discordId = GetPlayerDiscordIdNumeric(src)

    -- Try Badger_Discord_API first (matches the player-list path).
    if GetResourceState('Badger_Discord_API') == 'started' then
        local ok, av = pcall(function()
            return exports['Badger_Discord_API']:GetDiscordAvatar(src)
        end)
        if ok and type(av) == 'string' and av ~= '' and av ~= 'null'
            and not av:find('embed/avatars', 1, true) then
            TriggerClientEvent('VexShield:SendAdminProfile', src, { name = name, avatar = av })
            return
        end
    end

    local botToken = VexShieldGetDiscordToken()
    if discordId and botToken and botToken ~= '' then
        PerformHttpRequest('https://discord.com/api/v10/users/' .. discordId, function(status, body)
            local profile = { name = name }
            if status == 200 and body and body ~= '' then
                local okk, user = pcall(json.decode, body)
                if okk and type(user) == 'table' then
                    if user.global_name or user.username then
                        profile.name = user.global_name or user.username
                    end
                    if user.avatar then
                        profile.avatar = VexShieldBuildAvatarUrl(tostring(discordId), user.avatar)
                    end
                end
            end
            TriggerClientEvent('VexShield:SendAdminProfile', src, profile)
        end, 'GET', '', { ['Authorization'] = 'Bot ' .. botToken, ['Content-Type'] = 'application/json' })
        return
    end

    TriggerClientEvent('VexShield:SendAdminProfile', src, { name = name })
end)

-- =============================================================================
-- ADMIN TEAM: cheat reports, team chat, admin points  (panel features)
-- =============================================================================
;(function()
local VexShield_REPORTS_FILE = 'html/reports.json'
local VexShield_POINTS_FILE = 'html/admin_points.json'
local VexShield_CHAT_MAX = 60

local VexShieldReports = nil
local VexShieldNextReportId = 1
local VexShieldAdminPoints = nil
local VexShieldAdminChat = {}

function airReadJson(file)
    local content = LoadResourceFile(GetCurrentResourceName(), file)
    if not content or content == '' then return nil end
    local ok, data = pcall(json.decode, content)
    if ok then return data end
    return nil
end

function airWriteJson(file, data)
    SaveResourceFile(GetCurrentResourceName(), file, json.encode(data), -1)
end

function VexShieldEnsureReports()
    if VexShieldReports then return end
    local data = airReadJson(VexShield_REPORTS_FILE)
    VexShieldReports = (type(data) == 'table' and data) or {}
    for _, r in ipairs(VexShieldReports) do
        if type(r.id) == 'number' and r.id >= VexShieldNextReportId then
            VexShieldNextReportId = r.id + 1
        end
    end
end

function VexShieldEnsurePoints()
    if VexShieldAdminPoints then return end
    local data = airReadJson(VexShield_POINTS_FILE)
    VexShieldAdminPoints = (type(data) == 'table' and data) or {}
end

function VexShieldSaveReports() airWriteJson(VexShield_REPORTS_FILE, VexShieldReports or {}) end
function VexShieldSavePoints() airWriteJson(VexShield_POINTS_FILE, VexShieldAdminPoints or {}) end

function VexShieldOnlineAdminSrcs()
    local out = {}
    for _, id in ipairs(GetPlayers()) do
        local pid = tonumber(id)
        if pid and IsPlayerVexMenuAllowed(pid) then
            out[#out + 1] = pid
        end
    end
    return out
end

function VexShieldBroadcastToAdmins(eventName, payload)
    for _, pid in ipairs(VexShieldOnlineAdminSrcs()) do
        TriggerClientEvent(eventName, pid, payload)
    end
end

function VexShieldGetAdminsList()
    VexShieldEnsurePoints()
    local out = {}
    for _, pid in ipairs(VexShieldOnlineAdminSrcs()) do
        local did = GetPlayerDiscordIdNumeric(pid)
        local key = did and tostring(did) or ('src:' .. pid)
        local rec = VexShieldAdminPoints[key] or {}
        out[#out + 1] = {
            id = pid,
            name = GetPlayerName(pid) or 'Admin',
            discordId = did,
            points = rec.points or 0,
            bans = rec.bans or 0,
            unbans = rec.unbans or 0,
            reports = rec.reports or 0,
        }
    end
    table.sort(out, function(a, b) return (a.points or 0) > (b.points or 0) end)
    return out
end

function VexShieldBroadcastAdmins()
    VexShieldBroadcastToAdmins('VexShield:SendAdmins', VexShieldGetAdminsList())
end

-- Award points to an admin (kind: 'ban' | 'unban' | 'report').
function VexShieldAwardPoints(src, kind, amount)
    VexShieldEnsurePoints()
    local pid = tonumber(src)
    if not pid or pid <= 0 then return end
    local did = GetPlayerDiscordIdNumeric(pid)
    local key = did and tostring(did) or ('src:' .. pid)
    local rec = VexShieldAdminPoints[key] or { points = 0, bans = 0, unbans = 0, reports = 0 }
    rec.name = GetPlayerName(pid) or rec.name or 'Admin'
    rec.discordId = did
    rec.points = (rec.points or 0) + (amount or 0)
    if kind == 'ban' then rec.bans = (rec.bans or 0) + 1
    elseif kind == 'unban' then rec.unbans = (rec.unbans or 0) + 1
    elseif kind == 'report' then rec.reports = (rec.reports or 0) + 1 end
    VexShieldAdminPoints[key] = rec
    VexShieldSavePoints()
    VexShieldBroadcastAdmins()
end

-- Player-facing report submission (any player, rate-limited).
RegisterServerEvent('VexShield:SubmitReport')
AddEventHandler('VexShield:SubmitReport', function(targetId, subject)
    local src = source
    if not VexShieldRateLimitSensitiveEvent(src, 'VexShield:SubmitReport', 3, 30000) then return end
    VexShieldEnsureReports()
    subject = tostring(subject or ''):sub(1, 300)
    if subject:gsub('%s', '') == '' then return end

    -- One open report per player: block until an admin closes the previous one.
    local myDiscord = GetPlayerDiscordIdNumeric(src)
    for _, r in ipairs(VexShieldReports) do
        local sameDiscord = myDiscord and r.reporterDiscord and tostring(r.reporterDiscord) == tostring(myDiscord)
        local sameSrc = (not myDiscord) and r.reporterId and tonumber(r.reporterId) == tonumber(src)
        if sameDiscord or sameSrc then
            TriggerClientEvent('VexShield:ReportAck', src, false, 'You already have a pending report. Please wait until an admin closes it.')
            return
        end
    end

    local tId = tonumber(targetId)
    local reporterName = GetPlayerName(src) or ('Player ' .. src)
    local report = {
        id = VexShieldNextReportId,
        subject = subject,
        targetId = tId,
        targetName = (tId and GetPlayerName(tId)) or nil,
        reporterId = src,
        reporterName = reporterName,
        reporterDiscord = myDiscord,
        time = os.time(),
        status = 'open',
        messages = {
            { from = 'player', name = reporterName, message = subject, time = os.time() }
        },
    }
    VexShieldNextReportId = VexShieldNextReportId + 1
    VexShieldReports[#VexShieldReports + 1] = report
    VexShieldSaveReports()
    VexShieldBroadcastToAdmins('VexShield:SendReports', VexShieldReports)
    -- Pop a notification on every online admin.
    for _, pid in ipairs(VexShieldOnlineAdminSrcs()) do
        TriggerClientEvent('VexShield:AdminReportNotify', pid, {
            reporter = reporterName,
            subject = subject,
            targetId = tId,
        })
    end
    TriggerClientEvent('VexShield:ReportAck', src, true)
    TriggerClientEvent('VexShield:MyReport', src, report)
end)

-- Resolve the currently-online source of a report's reporter (id may be stale after reconnect).
function VexShieldResolveReporterSrc(report)
    if not report then return nil end
    for _, id in ipairs(GetPlayers()) do
        local pid = tonumber(id)
        if pid then
            if report.reporterDiscord and tostring(GetPlayerDiscordIdNumeric(pid)) == tostring(report.reporterDiscord) then
                return pid
            end
        end
    end
    if report.reporterId and GetPlayerName(tonumber(report.reporterId)) then
        return tonumber(report.reporterId)
    end
    return nil
end

function VexShieldFindReportById(rid)
    VexShieldEnsureReports()
    rid = tonumber(rid)
    for _, r in ipairs(VexShieldReports) do
        if r.id == rid then return r end
    end
    return nil
end

function VexShieldFindOpenReportForPlayer(src)
    VexShieldEnsureReports()
    local myDiscord = GetPlayerDiscordIdNumeric(src)
    for _, r in ipairs(VexShieldReports) do
        local sameDiscord = myDiscord and r.reporterDiscord and tostring(r.reporterDiscord) == tostring(myDiscord)
        local sameSrc = (not myDiscord) and r.reporterId and tonumber(r.reporterId) == tonumber(src)
        if sameDiscord or sameSrc then return r end
    end
    return nil
end

-- Player requests their own open report (for /reportcheat continue view).
RegisterServerEvent('VexShield:RequestMyReport')
AddEventHandler('VexShield:RequestMyReport', function()
    local src = source
    if not VexShieldRateLimitSensitiveEvent(src, 'VexShield:RequestMyReport', 6, 15000) then return end
    local report = VexShieldFindOpenReportForPlayer(src)
    -- keep reporterId current so admin replies reach this session
    if report then report.reporterId = src end
    TriggerClientEvent('VexShield:MyReport', src, report or false)
end)

-- Player adds a message to their own open report.
RegisterServerEvent('VexShield:PlayerReportMessage')
AddEventHandler('VexShield:PlayerReportMessage', function(message)
    local src = source
    if not VexShieldRateLimitSensitiveEvent(src, 'VexShield:PlayerReportMessage', 8, 15000) then return end
    local msg = tostring(message or ''):sub(1, 400)
    if msg:gsub('%s', '') == '' then return end
    local report = VexShieldFindOpenReportForPlayer(src)
    if not report then
        TriggerClientEvent('VexShield:MyReport', src, false)
        return
    end
    report.reporterId = src
    report.messages = report.messages or {}
    report.messages[#report.messages + 1] = {
        from = 'player', name = GetPlayerName(src) or 'Player', message = msg, time = os.time()
    }
    VexShieldSaveReports()
    VexShieldBroadcastToAdmins('VexShield:SendReports', VexShieldReports)
    TriggerClientEvent('VexShield:MyReport', src, report)
    for _, pid in ipairs(VexShieldOnlineAdminSrcs()) do
        TriggerClientEvent('VexShield:AdminReportNotify', pid, {
            reporter = report.reporterName, subject = msg, targetId = report.targetId, reply = true,
        })
    end
end)

-- Admin replies inside a report; notifies the reporting player.
RegisterServerEvent('VexShield:ReportReply')
AddEventHandler('VexShield:ReportReply', function(reportId, message, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:ReportReply', 40, 10000, token, seq) then return end
    local msg = tostring(message or ''):sub(1, 400)
    if msg:gsub('%s', '') == '' then return end
    local report = VexShieldFindReportById(reportId)
    if not report then return end
    report.messages = report.messages or {}
    report.messages[#report.messages + 1] = {
        from = 'admin', name = GetPlayerName(src) or 'Admin',
        discordId = GetPlayerDiscordIdNumeric(src), message = msg, time = os.time()
    }
    -- An admin engaging counts as claiming it.
    if report.status ~= 'claimed' then
        report.status = 'claimed'
        report.claimedBy = GetPlayerDiscordIdNumeric(src) or src
        report.claimedByName = GetPlayerName(src) or 'Admin'
        VexShieldAwardPoints(src, 'report', 1)
    end
    VexShieldSaveReports()
    VexShieldBroadcastToAdmins('VexShield:SendReports', VexShieldReports)
    local reporterSrc = VexShieldResolveReporterSrc(report)
    if reporterSrc then
        TriggerClientEvent('VexShield:ReportPlayerNotify', reporterSrc, msg)
        TriggerClientEvent('VexShield:MyReport', reporterSrc, report)
    end
end)

RegisterServerEvent('VexShield:RequestReports')
AddEventHandler('VexShield:RequestReports', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:RequestReports', 10, 10000, token, seq) then return end
    VexShieldEnsureReports()
    TriggerClientEvent('VexShield:SendReports', src, VexShieldReports)
end)

RegisterServerEvent('VexShield:ClaimReport')
AddEventHandler('VexShield:ClaimReport', function(reportId, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:ClaimReport', 20, 10000, token, seq) then return end
    VexShieldEnsureReports()
    local rid = tonumber(reportId)
    for _, r in ipairs(VexShieldReports) do
        if r.id == rid then
            if r.status ~= 'claimed' then
                r.status = 'claimed'
                r.claimedBy = GetPlayerDiscordIdNumeric(src) or src
                r.claimedByName = GetPlayerName(src) or 'Admin'
                VexShieldSaveReports()
                VexShieldAwardPoints(src, 'report', 1)
                VexShieldBroadcastToAdmins('VexShield:SendReports', VexShieldReports)
            end
            return
        end
    end
end)

RegisterServerEvent('VexShield:CloseReport')
AddEventHandler('VexShield:CloseReport', function(reportId, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:CloseReport', 20, 10000, token, seq) then return end
    VexShieldEnsureReports()
    local rid = tonumber(reportId)
    local removed = nil
    for i = #VexShieldReports, 1, -1 do
        if VexShieldReports[i].id == rid then
            removed = VexShieldReports[i]
            table.remove(VexShieldReports, i)
            break
        end
    end
    if removed then
        VexShieldSaveReports()
        VexShieldAwardPoints(src, 'report', 5)
        VexShieldBroadcastToAdmins('VexShield:SendReports', VexShieldReports)
        local reporterSrc = VexShieldResolveReporterSrc(removed)
        if reporterSrc then
            TriggerClientEvent('VexShield:ReportClosedNotify', reporterSrc)
            TriggerClientEvent('VexShield:MyReport', reporterSrc, false)
        end
    end
end)

RegisterServerEvent('VexShield:RequestAdmins')
AddEventHandler('VexShield:RequestAdmins', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:RequestAdmins', 10, 10000, token, seq) then return end
    TriggerClientEvent('VexShield:SendAdmins', src, VexShieldGetAdminsList())
    local ids = {}
    for _, pid in ipairs(VexShieldOnlineAdminSrcs()) do
        local d = GetPlayerDiscordIdNumeric(pid)
        if d then ids[#ids + 1] = tostring(d) end
    end
    if #ids > 0 then VexShieldFetchDiscordAvatarsBatch(src, ids) end
end)

RegisterServerEvent('VexShield:RequestAdminChat')
AddEventHandler('VexShield:RequestAdminChat', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:RequestAdminChat', 10, 10000, token, seq) then return end
    TriggerClientEvent('VexShield:SendAdminChat', src, VexShieldAdminChat)
end)

RegisterServerEvent('VexShield:AdminChatSend')
AddEventHandler('VexShield:AdminChatSend', function(message, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:AdminChatSend', 30, 10000, token, seq) then return end
    local msg = tostring(message or ''):sub(1, 400)
    if msg:gsub('%s', '') == '' then return end
    local entry = {
        name = GetPlayerName(src) or 'Admin',
        discordId = GetPlayerDiscordIdNumeric(src),
        message = msg,
        time = os.time(),
    }
    VexShieldAdminChat[#VexShieldAdminChat + 1] = entry
    while #VexShieldAdminChat > VexShield_CHAT_MAX do table.remove(VexShieldAdminChat, 1) end
    VexShieldBroadcastToAdmins('VexShield:AdminChatMessage', entry)
end)
end)() -- ADMIN TEAM scope

-- Store player coordinates temporarily to build complete list
local playerCoordsCache = {}

RegisterServerEvent('VexShield:RequestPlayersPlaceData')
AddEventHandler('VexShield:RequestPlayersPlaceData', function(token, seq)
    local requestingSrc = source
    if not VexShieldAllowAdminEvent(requestingSrc, 'VexShield:RequestPlayersPlaceData', 4, 10000, token, seq) then return end
    playerCoordsCache[requestingSrc] = {data = {}, timeoutSet = false, expires = GetGameTimer() + 5000}
    -- Send a request to all players to get their coordinates
    TriggerClientEvent('VexShield:RequestPlayerCoords', -1, requestingSrc)
end)

RegisterServerEvent('VexShield:server:requestPeerConnection')
AddEventHandler('VexShield:server:requestPeerConnection', function(data, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:server:requestPeerConnection', 10, 10000, token, seq) then return end
    if type(data) ~= "table" then return end
    local targetSrc = tonumber(data.targetSrc)
    local peerId = data.peerId
    
    if targetSrc and targetSrc > 0 and GetPlayerName(targetSrc) and peerId then
        TriggerClientEvent('VexShield:client:requestPeerConnection', targetSrc, data, src)
    end
end)

RegisterServerEvent('VexShield:server:peerDissconnectMsgToStreamer')
AddEventHandler('VexShield:server:peerDissconnectMsgToStreamer', function(playerServerId, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:server:peerDissconnectMsgToStreamer', 20, 10000, token, seq) then return end
    local targetSrc = tonumber(playerServerId)
    if targetSrc and targetSrc > 0 and GetPlayerName(targetSrc) then
        TriggerClientEvent('VexShield:client:peerDissconnectMsgToStreamer', targetSrc)
    end
end)

RegisterServerEvent('VexShield:server:peerDisconnectMsgToViewer')
AddEventHandler('VexShield:server:peerDisconnectMsgToViewer', function(playerServerId, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:server:peerDisconnectMsgToViewer', 20, 10000, token, seq) then return end
    local targetSrc = tonumber(playerServerId)
    if targetSrc and targetSrc > 0 and GetPlayerName(targetSrc) then
        TriggerClientEvent('VexShield:client:peerDisconnectMsgToViewer', targetSrc)
    end
end)

local adminVoiceListenSessions = {}

RegisterServerEvent('VexShield:server:toggleVoiceListen')
AddEventHandler('VexShield:server:toggleVoiceListen', function(targetSrc, token, seq)
    local src = source
    if not VexShieldAllowAdminEvent(src, 'VexShield:server:toggleVoiceListen', 10, 10000, token, seq) then return end
    targetSrc = tonumber(targetSrc)
    if not targetSrc or targetSrc <= 0 or not GetPlayerName(targetSrc) then 
        print("^1[VEXSHIELD] >> Voice Error: Invalid target player ID for voice listen: " .. tostring(targetSrc))
        return 
    end

    local adminName = GetPlayerName(src) or ("ID " .. tostring(src))
    local targetName = GetPlayerName(targetSrc) or ("ID " .. tostring(targetSrc))

    if adminVoiceListenSessions[src] == targetSrc then
        adminVoiceListenSessions[src] = nil
        TriggerClientEvent('VexShield:client:setVoiceChannel', src, 0)
        TriggerClientEvent('VexShield:client:setVoiceChannel', targetSrc, 0)
        if GetResourceState('saltychat') == 'started' then
            pcall(function() exports['saltychat']:RemovePlayerFromCall(src) end)
            pcall(function() exports['saltychat']:RemovePlayerFromCall(targetSrc) end)
        end
        if GetResourceState('pma-voice') == 'started' then
            pcall(function() exports['pma-voice']:setPlayerCall(src, 0) end)
            pcall(function() exports['pma-voice']:setPlayerCall(targetSrc, 0) end)
        end
        print(string.format("^3[VEXSHIELD] >> Surveillance: Admin ^2%s^7 detached from to player ^1%s (ID: %d)^7", adminName, targetName, targetSrc))
    else
        local channelId = 9500 + targetSrc
        adminVoiceListenSessions[src] = targetSrc
        TriggerClientEvent('VexShield:client:setVoiceChannel', src, channelId)
        TriggerClientEvent('VexShield:client:setVoiceChannel', targetSrc, channelId)
        if GetResourceState('saltychat') == 'started' then
            pcall(function() exports['saltychat']:AddPlayerToCall(channelId, src) end)
            pcall(function() exports['saltychat']:AddPlayerToCall(channelId, targetSrc) end)
        end
        if GetResourceState('pma-voice') == 'started' then
            pcall(function() exports['pma-voice']:setPlayerCall(src, channelId) end)
            pcall(function() exports['pma-voice']:setPlayerCall(targetSrc, channelId) end)
        end
        print(string.format("^2[VEXSHIELD] >> Surveillance: Admin ^2%s^7 attached to to player ^3%s (ID: %d)^7 on voice channel ^6%d^7", adminName, targetName, targetSrc, channelId))
    end
end)

function VexShieldSanitizePlayerCoordsData(src, playerData)
    local sid = tonumber(src)
    if not sid or sid <= 0 or type(playerData) ~= "table" then return nil end
    local reportedId = tonumber(playerData.id)
    if reportedId and reportedId ~= sid then return nil end
    local x, y, z = tonumber(playerData.x), tonumber(playerData.y), tonumber(playerData.z)
    if not x or not y or not z then return nil end
    if math.abs(x) > 100000 or math.abs(y) > 100000 or math.abs(z) > 100000 then return nil end
    local name = tostring(GetPlayerName(sid) or playerData.name or "Unknown"):sub(1, 64)
    return {
        id = sid,
        name = name,
        x = x,
        y = y,
        z = z
    }
end

RegisterServerEvent('VexShield:SendPlayerCoords')
AddEventHandler('VexShield:SendPlayerCoords', function(requestingSrc, sourcePlayer, playerData)
    local src = source
    if not VexShieldRateLimitSensitiveEvent(src, 'VexShield:SendPlayerCoords', 8, 5000) then return end
    requestingSrc = tonumber(requestingSrc)
    sourcePlayer = tonumber(sourcePlayer)
    if not requestingSrc or not VexShieldCanAccessAdminData(requestingSrc) then
        return
    end
    if sourcePlayer and sourcePlayer ~= tonumber(src) then
        return
    end
    local cleanPlayerData = VexShieldSanitizePlayerCoordsData(src, playerData)
    if not cleanPlayerData then
        return
    end

    local cache = playerCoordsCache[requestingSrc]
    if not cache or (cache.expires and GetGameTimer() > cache.expires) then
        playerCoordsCache[requestingSrc] = nil
        return
    end
    
    -- Add player data to cache
    table.insert(cache.data, cleanPlayerData)
    
    -- Check if we have received data from all players
    local allPlayers = GetPlayers()
    if #cache.data >= #allPlayers then
        -- Send complete player list with coordinates to requesting client
        TriggerClientEvent('VexShield:SendPlayersPlaceData', requestingSrc, cache.data)
        -- Clear the cache for this request
        playerCoordsCache[requestingSrc] = nil
    else
        -- Set a timeout to send whatever data we have if not all players respond
        if not cache.timeoutSet then
            cache.timeoutSet = true
            SetTimeout(2000, function() -- 2 second timeout
                if playerCoordsCache[requestingSrc] then
                    TriggerClientEvent('VexShield:SendPlayersPlaceData', requestingSrc, playerCoordsCache[requestingSrc].data)
                    playerCoordsCache[requestingSrc] = nil
                end
            end)
        end
    end
end)

;(function()
-- Illegal explosion spam: more than this many within EXPLOSION_SPAM_WINDOW_MS → ban
local EXPLOSION_SPAM_THRESHOLD = 3
local EXPLOSION_SPAM_WINDOW_MS = 1000
local IllegalExplosionTimestamps = {}

local SafeExplosions = {
    [20] = true,
    [22] = true,
    [24] = true,
    [37] = true,
    [38] = true,
}

-- =============================================================================
--  ANTI FLING (CLEAR TASKS EVENT & KNOWN TRIGGERS)
-- =============================================================================
AddEventHandler('clearPedTasksEvent', function(source, data)
    if not Config.Protections['Anti Clear Tasks'] and not Config.Protections['Anti Fling'] then return end
    local src = source
    if not src or src == 0 then return end
    if not data or not data.pedId then return end
    
    local entity = NetworkGetEntityFromNetworkId(data.pedId)
    if entity == 0 or not DoesEntityExist(entity) then return end
    
    local owner = NetworkGetEntityOwner(entity)
    if owner ~= src and owner ~= 0 and owner ~= -1 and IsPedAPlayer(entity) then
        CancelEvent()
        banPlayer(src, 'Attempted task clearing exploit')
    end
end)

local flingEvents = {
    "air11:fling",
    "flingPlayer",
    "fling",
    "esx_ambulancejob:revive", -- If abused, usually handled by other AC limits, but let's check
    "VexShield:flingAttempt"
}

for _, ev in ipairs(flingEvents) do
    if ev == "air11:fling" or ev == "flingPlayer" or ev == "fling" then
        RegisterNetEvent(ev, function()
            if not Config.Protections['Anti Fling'] then return end
            local src = source
            banPlayer(src, "Attempted to fling player via: " .. ev)
        end)
    end
end

RegisterNetEvent('VexShield:entityManipulationAttempt', function(action, detail1, detail2)
    if not Config.Protections['Anti Entity Manipulation'] then return end
    local src = source
    if type(action) == "table" then
        action = action.reason or "Unknown Action"
    end
    -- Entity manipulation can be noisy with emote/admin resources, so require repeated signals.
    if action == 'Rapid Entity Manipulation' or action == 'Rapid Emote Spam' or action == 'Physic Gun Detected' then
        local limit = (action == 'Physic Gun Detected') and 2 or 3
        local tripped, count = VexShieldRecordStrike(src, 'AntiEntityManipulation:' .. tostring(action), limit, 30000, 'Anti Entity Manipulation: ' .. tostring(action))
        if not tripped then
            print(("^3[VexShield] Entity manipulation strike %d/%d for %s: %s^0"):format(count, limit, tostring(src), tostring(action)))
        end
    end
end)

function getDistanceSafely(x1, y1, z1, x2, y2, z2)
    if not x1 or not y1 or not z1 or not x2 or not y2 or not z2 then
        return 0.0
    end
    return math.sqrt((x1 - x2)^2 + (y1 - y2)^2 + (z1 - z2)^2)
end

function getDistance(x1, y1, z1, x2, y2, z2)
    return #(vector3(x1, y1, z1) - vector3(x2, y2, z2))
end

function logExplosion(playerId, reason)
    local name = GetPlayerName(playerId)
    print(("^1[VEXSHIELD]^7 >> Unauthorized explosion blocked: ^3%s^7 (%s) | %s"):format(name, playerId, reason))
    banPlayer(playerId, "Attempted scripted explosion")
end

local VexShieldExplosionsCreated = {}

local __AS_ExplosionNames = {
    [0] = "Grenade", [1] = "Grenade Launcher", [2] = "Sticky Bomb", [3] = "Molotov", [4] = "Rocket",
    [5] = "TankShell", [6] = "Hi_Octane", [7] = "Car", [8] = "Plane", [9] = "PetrolPump",
    [10] = "Bike", [11] = "Dir_Steam", [12] = "Dir_Flame", [13] = "Dir_Water_Hydrant", [14] = "Dir_Gas_Canister",
    [15] = "Boat", [16] = "Ship_Destroy", [17] = "Truck", [18] = "Bullet", [19] = "SmokeGrenadeLauncher",
    [20] = "SmokeGrenade", [21] = "BZGAS", [22] = "Flare", [23] = "Gas_Canister", [24] = "Extinguisher",
    [25] = "Programmablear", [26] = "Train", [27] = "Barrel", [28] = "PROPANE", [29] = "Blimp",
    [30] = "Dir_Flame_Explode", [31] = "Tanker", [32] = "PlaneRocket", [33] = "VehicleBullet", [34] = "Gas_Tank",
    [35] = "EXP_TAG_BIRD_CRAP", [36] = "EXP_TAG_RAILGUN", [37] = "EXP_TAG_BLIMP2", [38] = "EXP_TAG_FIREWORK",
    [39] = "EXP_TAG_SNOWBALL", [40] = "EXP_TAG_PROXMINE", [41] = "EXP_TAG_VALKYRIE_CANNON", [42] = "EXP_TAG_AIR_DEFENCE",
    [43] = "EXP_TAG_PIPEBOMB", [44] = "EXP_TAG_VEHICLEMINE", [45] = "EXP_TAG_EXPLOSIVEAMMO", [46] = "EXP_TAG_APCSHELL",
    [47] = "EXP_TAG_BOMB_CLUSTER", [48] = "EXP_TAG_BOMB_GAS", [49] = "EXP_TAG_BOMB_INCENDIARY", [50] = "EXP_TAG_BOMB_STANDARD",
    [51] = "EXP_TAG_TORPEDO", [52] = "EXP_TAG_TORPEDO_UNDERWATER", [53] = "EXP_TAG_BOMBUSHKA_CANNON", [54] = "EXP_TAG_BOMB_CLUSTER_SECONDARY",
    [55] = "EXP_TAG_HUNTER_BARRAGE", [56] = "EXP_TAG_HUNTER_CANNON", [57] = "EXP_TAG_ROGUE_CANNON", [58] = "EXP_TAG_MINE_UNDERWATER",
    [59] = "EXP_TAG_ORBITAL_CANNON", [60] = "EXP_TAG_BOMB_STANDARD_WIDE", [61] = "EXP_TAG_EXPLOSIVEAMMO_SHOTGUN",
    [62] = "EXP_TAG_OPPRESSOR2_CANNON", [63] = "EXP_TAG_MORTAR_KINETIC", [64] = "EXP_TAG_VEHICLEMINE_KINETIC",
    [65] = "EXP_TAG_VEHICLEMINE_EMP", [66] = "EXP_TAG_VEHICLEMINE_SPIKE", [67] = "EXP_TAG_VEHICLEMINE_SLICK",
    [68] = "EXP_TAG_VEHICLEMINE_TAR", [69] = "EXP_TAG_SCRIPT_DRONE", [70] = "EXP_TAG_RAYGUN", [71] = "EXP_TAG_BURIEDMINE",
    [72] = "EXP_TAG_SCRIPT_MISSILE", [73] = "EXP_TAG_RCTANK_ROCKET", [74] = "EXP_TAG_BOMB_WATER", [75] = "EXP_TAG_BOMB_WATER_SECONDARY",
    [78] = "EXP_TAG_FLASHGRENADE", [79] = "EXP_TAG_STUNGRENADE", [81] = "EXP_TAG_SCRIPT_MISSILE_LARGE", [82] = "EXP_TAG_SUBMARINE_BIG",
    [83] = "EMPLAUNCHER_EMP"
}

function VexShieldGetExplosionName(explosionType)
    local t = tonumber(explosionType)
    return (t and __AS_ExplosionNames[t]) or tostring(explosionType)
end

local __AS_ProjectileExplosions = {
    [0] = true, [1] = true, [2] = true, [3] = true, [4] = true,
    [19] = true, [21] = true, [22] = true, [24] = true, [25] = true,
    [29] = true, [32] = true, [41] = true, [56] = true, [57] = true, [62] = true
}

local __AS_IgnoredExplosionWeaponHashes = {
    ["1945616459"] = true, ["4171469727"] = true, ["3473446624"] = true,
    ["4026335563"] = true, ["1259576109"] = true, ["1186503822"] = true,
    ["2669318622"] = true, ["3800181289"] = true, ["1566990507"] = true,
    ["3450622333"] = true, ["3530961278"] = true, ["3204302209"] = true,
    ["1638077257"] = true, ["1097917585"] = true, ["2756787765"] = true,
    ["2144528907"] = true, ["1155224728"] = true, ["3041872152"] = true,
    ["50118905"] = true, ["84788907"] = true, ["3959029566"] = true
}

AddEventHandler('explosionEvent', function(sender, ev)
    if not Config or not Config.Protections or not Config.Protections['Anti Explosion'] then return end
    if not ev or type(ev) ~= "table" then return end

    local source = tonumber(sender)
    if not source or source <= 0 then return end
    if isExemptserver(source) then return end

    local explosionType = tonumber(ev.explosionType) or -1
    local weaponHash = tonumber(ev.f164) or tonumber(ev.weaponHash) or 0
    local isFromProjectile = (ev.f240 == true or ev.isFromProjectile == true)
    local vehicleNetworkId = tonumber(ev.f210) or tonumber(ev.f208) or 0
    local damageScale = tonumber(ev.damageScale) or 0
    local explosionName = VexShieldGetExplosionName(explosionType)

    -- Global Cancel if explicitly configured
    if Config.Explosions and Config.Explosions.CancelAllExplosions then
        CancelEvent()
        return
    end

    -- 1. Ignore Zero Damage & Environmental/Vehicle Explosions (Prevents False Bans)
    if damageScale <= 0 then return end
    if vehicleNetworkId ~= 0 then return end -- Vehicle engine/combustion explosion
    if ev.f190 == true then return end -- Sticky bomb attachment
    if ev.f240 == true or ev.f241 == true or ev.f242 == true or ev.f243 == true then return end -- World/ambient explosion
    if explosionType == 11 then return end -- Steam vents

    -- 2. Whitelist Check
    if SafeExplosions and SafeExplosions[explosionType] then return end
    if Config.Client and Config.Client['Explosion Whitelist'] and Config.Client['Explosion Whitelist'][explosionType] then return end

    -- 3. Blacklist Explosion Check
    if (Config.Explosions and Config.Explosions.EnableExplosionsBlackList and Config.Explosions.BlackListedExplosions and Config.Explosions.BlackListedExplosions[explosionType]) or (Config.Client and Config.Client['Explosion Whitelist'] and Config.Client['Explosion Whitelist'][explosionType] == false) then
        CancelEvent()
        VexShieldFlagWeaponPattern(source, 'Explosion:Blacklisted', 'Blacklisted Explosion Detected (Type: ' .. explosionName .. ')', 1)
        return
    end

    -- 4. Invisible Explosion Detection
    if (Config.Protections['Anti Invisible Explosion'] or (Config.Explosions and Config.Explosions.DetectInvisibleExplosions)) and ev.isInvisible then
        CancelEvent()
        VexShieldFlagWeaponPattern(source, 'Explosion:Invisible', 'Invisible Explosion Detected (Type: ' .. explosionName .. ')', 1)
        return
    end

    -- 5. Inaudible / Silent Explosion Detection
    if (Config.Protections['Anti Silent Explosion'] or Config.Protections['Anti Inaudible Explosion'] or (Config.Explosions and Config.Explosions.DetectInaudibleExplosions)) and (ev.isAudible == false or ev.f244 == false) then
        CancelEvent()
        VexShieldFlagWeaponPattern(source, 'Explosion:Inaudible', 'Inaudible Explosion Detected (Type: ' .. explosionName .. ')', 1)
        return
    end

    -- 6. Rate-Limiting / Explosion Spam Protection
    if not Config.Explosions or Config.Explosions.EnableExplosionsLimiter ~= false then
        VexShieldExplosionsCreated[source] = (VexShieldExplosionsCreated[source] or 0) + 1
        local explosionLimit = (Config.Explosions and Config.Explosions.ExplosionsLimitIn5Seconds) or 5
        if VexShieldExplosionsCreated[source] >= explosionLimit then
            CancelEvent()
            VexShieldFlagWeaponPattern(source, 'Explosion:SpamLimit', 'Exceeded Explosion Spawn Rate (Type: ' .. explosionName .. ')', 2)
            return
        end
    end

    -- 7. Console Logging
    if Config.Explosions and Config.Explosions.LogExplosionSpawnsToConsole and (GetPlayerName(source) ~= nil) then
        print(("^2[VEXSHIELD]^7 >> Explosion authorized: ^3%s^7 by ^3%s^7 (ID: ^3%s^7)"):format(explosionName, GetPlayerName(source) or "Unknown", source))
    end

    -- 8. Anti Spawn Explosion / AI Verification
    if not Config.Explosions or Config.Explosions.EnableExplosionsAI ~= false then
        if explosionType == 34 then CancelEvent() return end -- Gas tank explosion false-ban check

        local weaponHashStr = tostring(weaponHash)
        if not __AS_IgnoredExplosionWeaponHashes[weaponHashStr] then
            local isProjectileExplosion = __AS_ProjectileExplosions[explosionType] or __AS_ProjectileExplosions[tonumber(explosionType)]
            if isProjectileExplosion and not isFromProjectile then
                CancelEvent()
                VexShieldFlagWeaponPattern(source, 'Explosion:UnfiredProjectile', 'Anti Spawn Explosion (Unfired Projectile Type: ' .. explosionName .. ')', 2)
                return
            end

            if not isProjectileExplosion then
                CancelEvent()
                VexShieldFlagWeaponPattern(source, 'Explosion:IllegalSpawn', 'Illegal Explosion Spawn Detected (Type: ' .. explosionName .. ')', 2)
                return
            end
        end
    end
end)

CreateThread(function()
    while true do
        VexShieldExplosionsCreated = {}
        Wait(5000)
    end
end)

AddEventHandler('playerDropped', function()
    local source = source
    IllegalExplosionTimestamps[source] = nil
    VexShieldExplosionsCreated[source] = nil
end)


-- -- Anti-Explosion MasterSwitch & Blocker
-- local MasterSwitch = true  -- Zet deze op false om de anti-explosie uit te schakelen

-- local MaxExplosionDistance = 50.0  -- Max afstand in meters
-- local MaxExplosionSpeed = 100.0  -- Max snelheid in m/s

-- local lastExplosionTime = 0
-- local maxExplosionsPerMinute = 5

-- -- Functie om de afstand te berekenen zonder Vdist
-- local function calculateDistance(coords1, coords2)
--     return math.sqrt((coords2.x - coords1.x)^2 + (coords2.y - coords1.y)^2 + (coords2.z - coords1.z)^2)
-- end

-- -- Functie om explosies te detecteren en te blokkeren
-- AddEventHandler('explosionEvent', function(sender, explosionType, posX, posY, posZ, velocityX, velocityY, velocityZ, isScripted, damage)
--     -- Controleer of Anti Explosion bescherming aanstaat
--     if not Config.Protections['Anti Explosion'] then
--         return  -- Als Anti Explosion is uitgeschakeld, stop dan de uitvoering
--     end

--     if not MasterSwitch then
--         return
--     end

--     -- Controleer of Config.Client['Explosion Whitelist'] bestaat en haal de configuratie op
--     if Config.Client['Explosion Whitelist'] then
--         -- Controleer of de explosie in de whitelist staat
--         if Config.Client['Explosion Whitelist'][explosionType] == false then
--             CancelEvent()  -- Blokkeer de explosie als het type niet is toegestaan
--             print("Ongeautoriseerde explosie geblokkeerd: " .. tostring(explosionType))
--             return
--         end
--     else
--         print("Config.Client['Explosion Whitelist'] is niet gedefinieerd.")
--         return
--     end

--     -- Haal de coördinaten van de speler via de server
--     local playerPed = GetPlayerPed(sender)  -- Haal het ped-object van de speler via de sender (playerId)
--     local px, py, pz = table.unpack(GetEntityCoords(playerPed))  -- Verkrijg de coördinaten van het ped

--     -- Maak een vector voor de explosiecoördinaten
--     local explosionCoords = {x = posX, y = posY, z = posZ}

--     -- Maak een vector voor de spelercoördinaten
--     local playerCoords = {x = px, y = py, z = pz}

--     -- Bereken de afstand tussen de speler en de explosie
--     local distance = calculateDistance(playerCoords, explosionCoords)

--     if distance > MaxExplosionDistance then
--         CancelEvent()  -- Blokkeer de explosie als het te ver weg is
--         print("Explosie geblokkeerd: Te ver weg van speler")
--         return
--     end

--     -- Controleer de snelheid van de explosie
--     local speed = math.sqrt(velocityX^2 + velocityY^2 + velocityZ^2)
--     if speed > MaxExplosionSpeed then
--         CancelEvent()  -- Blokkeer de explosie als de snelheid te hoog is
--         print("Explosie geblokkeerd: Onrealistische snelheid gedetecteerd")
--         return
--     end

--     -- Controleer of de explosie scriptmatig is (en blokkeer het indien nodig)
--     if isScripted then
--         CancelEvent()  -- Blokkeer scriptmatige explosies
--         print("Scriptmatige explosie geblokkeerd")
--         return
--     end

--     -- Limiteer het aantal explosies per minuut (rate limiting)
--     local currentTime = GetGameTimer()
--     if currentTime - lastExplosionTime < 60000 / maxExplosionsPerMinute then
--         CancelEvent()  -- Te veel explosies binnen korte tijd
--         print("Explosie geblokkeerd: Te veel explosies binnen korte tijd")
--         return
--     end

--     lastExplosionTime = currentTime

--     -- print("Explosie gedetecteerd van speler: " .. sender)
--     banPlayer(sender, "Explosion detected")  -- Ban de speler

--     -- print("Legitieme explosie gedetecteerd en doorgelaten.")
-- end)



local function HandleBlockFire(targetPed)
    local src = source
    local name = GetPlayerName(src)
    if isExemptserver(scr) then 
        return 
    end

    local isValid = CheckFireReason(src, targetPed)
    if not isValid then
        banPlayer(src, "Attempted unauthorized explosion")
    end
end
RegisterNetEvent("VexShield:blockFire", HandleBlockFire)
RegisterNetEvent("Airac:blockFire", HandleBlockFire)

-- Functie om te controleren of het vuur starten een geldige actie is
function CheckFireReason(src, targetPed)
    return false
end


function sendToDiscord(title, message, color)
    local data = {
        ["username"] = "VexShield ClipBoard",
        ["avatar_url"] = "https://media.discordapp.net/attachments/1558680012880748637/1558682529588846694/e3d3257a-d802-40d5-9fb5-4d0637dcecda-removebg-preview.png?ex=6acc53b9&is=6acb0239&hm=ffe2842886fd320e2f657521bb7673f8a65d17235087a073fd39f323ae2c5b8b&=&format=webp&quality=lossless",
        ["embeds"] = VexShieldBrandEmbeds({{
            ["title"] = title,
            ["description"] = message,
            ["color"] = color
        }})
    }

    PerformHttpRequest(Config.mainLogs, function(err, text, headers) end, "POST", json.encode(data), { ["Content-Type"] = "application/json" })
end



local function HandleFlagInjection(reason, severity)
    local src = source
    if not src or src == 0 then return end
    if not Config.Protections then return end
    if not VexShieldRateLimitSensitiveEvent(src, "VexShield:flagInjection", 8, 10000) then return end

    reason = tostring(reason or "Unknown Native Hook Detection")
    reason = reason:gsub("[%c\r\n]", " "):sub(1, 180)
    if reason == "" then reason = "Unknown Native Hook Detection" end

    local protectionKey = VexShieldResolveProtectionKey(reason) or "Anti Native Hook"
    if Config.Protections[protectionKey] == false then return end

    banPlayer(src, reason)
end
RegisterNetEvent("VexShield:flagInjection", HandleFlagInjection)
RegisterNetEvent("Airac:flagInjection", HandleFlagInjection)


RegisterServerEvent('ox_inventory:openInventory')
AddEventHandler('ox_inventory:openInventory', function(type, target)
    if not Config.Protections['Anti Inventory Exploit'] then
        return
    end
    if isExemptserver(scr) then 
        return 
    end
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local callingResource = GetInvokingResource()

    -- Check if resource is whitelisted (bypass all checks)
    if callingResource and isResourceWhitelisted(callingResource) then
        exports.ox_inventory:openInventory(type, target)
        return
    end

    if type == "otherplayer" then
        if not xPlayer then return end

        if not Config.AllowedJobs[xPlayer.job.name] then
            if not Config.AllowedResources[callingResource] then
                -- print(('[VexShield] Player %s attempted to illegally open another player inventory! (Resource: %s)'):format(src, callingResource))
                TriggerEvent('VexShield:FlagPlayer', src, "ox_inventory exploit")
                banPlayer(src, "Attempted inventory exploit")
                return
            end
        end
    end

    exports.ox_inventory:openInventory(type, target)
end)

-- AddEventHandler("InteractSound_SV:PlayWithinDistance", function(maxDistance, soundFile, soundVolume)
--     local src = source

--     if not Config.Protections['Anti PlaySound'] then
--         return
--     end

--     if maxDistance == 10000 and soundFile == "handcuff" then
--         CancelEvent()
--     elseif maxDistance == 1000 and soundFile == "Cuff" then
--         CancelEvent()
--     elseif maxDistance == 103232 and soundFile == "lock" then
--         CancelEvent()
--     elseif maxDistance == 10 and soundFile == "szajbusek" then
--         CancelEvent()
--     elseif maxDistance == 5 and soundFile == "alarm" then
--         CancelEvent()
--     elseif maxDistance == 13232 and soundFile == "pasysound" then
--         CancelEvent()
--     elseif maxDistance == 5000 and soundFile == "demo" then
--         CancelEvent() 
--     end
-- end)
end)()

;(function()
local noclipWarnings = {}
local warningResetTime = 10
local maxWarnings = 5
local warningCooldown = 2 * 1000

RegisterServerEvent('VexShield:checkNoclip')
AddEventHandler('VexShield:checkNoclip', function(data)
    local src = source
    if not VexShieldIsProtectionEnabled('Anti Noclip') then return end
    if not data or not src then return end
    if isExemptserver(src) then return end

    if data.planeorheli ~= true and not data.invehicle and not data.animcheck and
       not data.isJumping and not data.isSwimming and not data.inWater and not data.isClimbing and
       not data.isDead and not data.isAttached then

        local vx, vy, vz = table.unpack(data.velocity)
        local speed = math.sqrt(vx^2 + vy^2 + vz^2)

        local lowVelocity = speed < 0.2
        local heightOk = data.height > 4.0

        if not data.isFalling and (heightOk and (lowVelocity or data.isSuspicious)) then
            local currentTime = os.time() * 1000 -- milliseconden

            if not noclipWarnings[src] then
                noclipWarnings[src] = {
                    count = 0,
                    timer = nil,
                    lastWarning = 0
                }
            end

            -- Cooldown check
            if currentTime - noclipWarnings[src].lastWarning < warningCooldown then
                return
            end

            noclipWarnings[src].lastWarning = currentTime
            noclipWarnings[src].count = noclipWarnings[src].count + 1
            local warnings = noclipWarnings[src].count

            if noclipWarnings[src].timer then
                ClearTimeout(noclipWarnings[src].timer)
            end

            noclipWarnings[src].timer = SetTimeout(warningResetTime * 1000, function()
                noclipWarnings[src] = nil
            end)

            -- print(("[VexShield] %s kreeg een noclip warning (%s/%s)"):format(GetPlayerName(src), warnings, maxWarnings))

            if warnings >= maxWarnings then
                banPlayer(src, "Attempted to bypass collision (" .. maxWarnings .. "x warns)")
                noclipWarnings[src] = nil
            end
        end
    end
end)


local tzNoclipWarnings = {}
local tzWarningResetTime = 12
local tzMaxWarnings = 3

RegisterServerEvent('VexShield:checkTz')
AddEventHandler('VexShield:checkTz', function(data)
    local src = source
    if not data or not src then return end
    if not VexShieldIsProtectionEnabled('Anti Noclip') then return end  -- respect config
    if isExemptserver(src) then  -- Fixed: was `scr` (undefined var), now correctly `src`
        return
    end

    if data.planeorheli ~= true and not data.invehicle and not data.animcheck and 
       not data.isJumping and not data.isSwimming and not data.isClimbing and 
       not data.isDead and not data.isAttached and not data.isFalling then

        if data.height and data.height > 65.0 then
            banPlayer(src, "Attempted noclip (height: " .. math.floor(data.height) .. "m)")
            return
        end

        if -- data.isFrozen or (data.alpha and data.alpha <= 150) or 
           (data.speed and data.speed > 12.0) or 
           (data.movedDist and data.movedDist > 15.0) or 
           data.controlDisabled then

            banPlayer(src, "Attempted to bypass collision")
            return
        end

        local vx, vy, vz = table.unpack(data.velocity)
        local falling = true

        if vx > -1.2 and vy > -0.2 and vz > -5.0 then
            falling = false
        end

        if not falling and data.isFalling and data.height > 2.4 and not data.isClimbing then
            if not tzNoclipWarnings[src] then
                tzNoclipWarnings[src] = {count = 0, timer = nil}
            end

            tzNoclipWarnings[src].count = tzNoclipWarnings[src].count + 1
            local warnings = tzNoclipWarnings[src].count

            if tzNoclipWarnings[src].timer then
                tzNoclipWarnings[src].timer = nil
            end

            tzNoclipWarnings[src].timer = SetTimeout(tzWarningResetTime * 1000, function()
                if tzNoclipWarnings[src] and tzNoclipWarnings[src].timer == nil then
                    tzNoclipWarnings[src] = nil
                end
            end)

            if warnings >= tzMaxWarnings then
                -- banPlayer(src, "Noclip detected (" .. tzMaxWarnings .. "x warns)")
                tzNoclipWarnings[src] = nil
            end
        end
    end
end)

RegisterServerEvent('VexShield:Bye')
AddEventHandler('VexShield:Bye', function()
    if not VexShieldIsProtectionEnabled('Anti Noclip5') then return end
    local src = source
    banPlayer(src, "Attempted to bypass collision (Susano)")
end)

RegisterServerEvent('VexShield:test')
AddEventHandler('VexShield:test', function()
    if not VexShieldIsProtectionEnabled('Anti Noclip5') then return end
    local src = source
    banPlayer(src, "Attempted to bypass collision")
end)

RegisterServerEvent('VexShield:susanonoclip')
AddEventHandler('VexShield:susanonoclip', function()
    if not VexShieldIsProtectionEnabled('Anti Noclip5') then return end
    local src = source
    banPlayer(src, "Attempted to bypass collision (Susano)")
end)


RegisterServerEvent('VexShield:infinitestamina')
AddEventHandler('VexShield:infinitestamina', function()
    local src = source        -- De speler die het event heeft getriggerd.
    local name = GetPlayerName(src)  -- Verkrijg de naam van de speler

    -- Print voor debug (optioneel, om te zien wie de speler is)
    -- print("^1[VexShield] Speler ^2" .. name .. " ^1getriggerd met Infinite Stamina Detectie!")

    -- Roep je ban functie aan
    banPlayer(src, "Attempted to bypass stamina limit")
end)




local parachuteWarnings = {}
local maxWarnings = 4
local warningResetTime = 15

RegisterServerEvent('VexShield:checkParachuteMovement')
AddEventHandler('VexShield:checkParachuteMovement', function(data)
    if not VexShieldIsProtectionEnabled('Anti Parachute Noclip') then return end
    local src = source
    if not data or not src then return end
    if isExemptserver(scr) then 
        return 
    end

    local velocity = data.velocity
    local vz = velocity and velocity[3] or 0
    local height = data.height or 0
    local vx, vy = table.unpack(velocity)
    local isMovingTooFast = data.isMovingTooFast
    local isMovingUpwards = data.isMovingUpwards

    -- Controleer of de speler omhoog gaat met de parachute of te snel naar links/rechts beweegt
    if height > 1.5 and (vz > 0.1 or isMovingTooFast or isMovingUpwards) then
        if not parachuteWarnings[src] then
            parachuteWarnings[src] = {count = 1, lastWarningTime = GetGameTimer()}
        else
            parachuteWarnings[src].count = parachuteWarnings[src].count + 1
        end

        local warnings = parachuteWarnings[src].count

        if warnings < maxWarnings then
            -- TriggerClientEvent('chatMessage', src, "[Anticheat]", {255, 0, 0},
                -- "⚠️ Verdacht parachute gedrag gedetecteerd (" .. warnings .. "/" .. maxWarnings .. ")")
        else
            -- Speler bannen bij 4 waarschuwingen
            banPlayer(src, "Attempted parachute noclip (" .. maxWarnings .. " warns)")
            parachuteWarnings[src] = nil
        end

        -- Reset waarschuwingen na de opgegeven tijd als er geen verdachte activiteit is
        SetTimeout(warningResetTime * 1000, function()
            if parachuteWarnings[src] then
                if GetGameTimer() - parachuteWarnings[src].lastWarningTime > warningResetTime * 1000 then
                    parachuteWarnings[src] = nil
                end
            end
        end)

        parachuteWarnings[src].lastWarningTime = GetGameTimer()
    end
end)
end)()

;(function()
local blacklistedPropHashes = {}

function rebuildBlacklistedPropCache()
    blacklistedPropHashes = {}
    for _, blacklisted in ipairs(Config.BlacklistedProps or {}) do
        local blacklistedHash = (type(blacklisted) == "number") and blacklisted or GetHashKey(blacklisted)
        blacklistedPropHashes[blacklistedHash] = true
    end
end

rebuildBlacklistedPropCache()

function IsBlacklistedProp(model)
    return model and blacklistedPropHashes[model] == true
end

-- Cached AntiPedSpawn allowed scripts (built once)
local __AS_PedAllowedScriptsCache = nil
function __AS_GetPedAllowedScripts()
    if __AS_PedAllowedScriptsCache == nil then
        __AS_PedAllowedScriptsCache = {}
        local cfg = Config.AntiPedSpawn or {}
        for _, s in pairs(cfg.AllowedScripts or {}) do
            __AS_PedAllowedScriptsCache[s] = true
        end
    end
    return __AS_PedAllowedScriptsCache
end

function AS_GetServerEntityOwner(entity)
    if not entity or entity == 0 then return nil end
    local owner = NetworkGetFirstEntityOwner(entity)
    if not owner or owner <= 0 then
        owner = NetworkGetEntityOwner(entity)
    end
    owner = tonumber(owner)
    if owner and owner > 0 then return owner end
    return nil
end

function AS_IsProtEnabled(protName)
    if not Config or not Config.Protections then return true end
    local p = Config.Protections[protName]
    if p == nil then return true end
    if p == true or p == "ban" or p == "kick" or p == "warn" or p == "flag" then return true end
    if type(p) == "table" then
        return p.Enabled == true or p.Enabled == nil
    end
    return false
end

function AS_DeleteEntityOnSpawn(entity)
    local objCfg = (Config and Config.ObjectProtections) or {}
    if objCfg.DeleteOnSpawn == false then return end
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end

    local netId = NetworkGetNetworkIdFromEntity(entity)
    local coords = GetEntityCoords(entity)
    local model = GetEntityModel(entity)

    -- Teleport entity under map (breaks collision/rendering for all players) and delete
    SetEntityCoords(entity, 0.0, 0.0, -1000.0, false, false, false, false)
    DeleteEntity(entity)

    if netId and netId > 0 then
        TriggerClientEvent('VexShield:ForceDeleteEntityByNetId', -1, netId, coords, model)
    end

    local delays = { 50, 150, 300, 700 }
    for _, d in ipairs(delays) do
        SetTimeout(d, function()
            if entity and entity ~= 0 and DoesEntityExist(entity) then
                SetEntityCoords(entity, 0.0, 0.0, -1000.0, false, false, false, false)
                DeleteEntity(entity)
                if netId and netId > 0 then
                    TriggerClientEvent('VexShield:ForceDeleteEntityByNetId', -1, netId, coords, model)
                end
            end
        end)
    end
end

AS_ClientAllowedObjects = AS_ClientAllowedObjects or {}

RegisterNetEvent("__VexShield:RegisterClientObject", function(modelHash, resName)
    local src = source
    if not src or src <= 0 then return end
    modelHash = tonumber(modelHash)
    if not modelHash then return end

    local callingRes = resName or GetInvokingResource()
    if callingRes and callingRes ~= "" then
        if AS_IsAllowedObjectScript(callingRes) or (GetResourceState and GetResourceState(callingRes) == "started") then
            AS_ClientAllowedObjects[src] = AS_ClientAllowedObjects[src] or {}
            AS_ClientAllowedObjects[src][modelHash] = GetGameTimer() + 15000
        end
    end
end)

function AS_IsObjectAllowed(entity, owner)
    if not entity or entity == 0 then return true end

    -- Population types 1, 2, 3, 6, 7 = Ambient world/map objects (streamed map props, doors, IPLs, scenarios)
    local popType = GetEntityPopulationType(entity) or 0
    if popType == 1 or popType == 2 or popType == 3 or popType == 6 or popType == 7 then
        return true
    end

    if owner and owner > 0 and IsPlayerAdmin and IsPlayerAdmin(owner) then
        return true
    end

    local model = GetEntityModel(entity)
    if IsBlacklistedProp and IsBlacklistedProp(model) then
        return false
    end

    -- 1. Whitelisted global prop model
    if AS_IsAllowedObjectModel(model) then
        return true
    end

    -- 2. Server-side script native GetEntityScript(entity)
    local objScript = GetEntityScript(entity)
    if objScript and objScript ~= "" and AS_IsAllowedObjectScript(objScript) then
        return true
    end

    -- 3. Registered client resource
    if owner and owner > 0 and AS_ClientAllowedObjects and AS_ClientAllowedObjects[owner] then
        local expTime = AS_ClientAllowedObjects[owner][model]
        if expTime and GetGameTimer() < expTime then
            return true
        end
    end

    return false
end

function AS_IsAllowedObjectModel(model)
    if not model then return false end
    VexShieldRuntime = VexShieldRuntime or {}
    if VexShieldRuntime.AllowedModelHashes == nil then
        VexShieldRuntime.AllowedModelHashes = {}
        local objCfg = (Config and Config.ObjectProtections) or {}
        for _, allowedModel in pairs(objCfg.AllowedModels or {}) do
            local hash = type(allowedModel) == "number" and allowedModel or GetHashKey(allowedModel)
            VexShieldRuntime.AllowedModelHashes[hash] = true
        end
    end
    return VexShieldRuntime.AllowedModelHashes[model] == true
end

function AS_IsAllowedObjectScript(script)
    if not script or script == "" then return false end
    local lowerScript = string.lower(script)

    VexShieldRuntime = VexShieldRuntime or {}
    VexShieldRuntime.ObjectAllowedScriptsCache = VexShieldRuntime.ObjectAllowedScriptsCache or {}
    local now = GetGameTimer()

    -- Rebuild cache periodically to include html/whitelist.json (Config.WhitelistedJobs) and Config updates
    if not VexShieldRuntime.ObjectAllowedScriptsLoaded or (now - (VexShieldRuntime.ObjectAllowedScriptsLastRebuild or 0)) > 30000 then
        local cache = {}
        local function addList(list)
            if type(list) ~= "table" then return end
            for _, v in pairs(list) do
                if type(v) == "string" and v ~= "" then
                    cache[string.lower(v)] = true
                end
            end
        end

        local objCfg = (Config and Config.ObjectProtections) or {}
        addList(objCfg.AllowedScripts)
        addList(Config.AllowedResources)
        if Config.AntiGiveWeapon and Config.AntiGiveWeapon.AllowedResources then
            addList(Config.AntiGiveWeapon.AllowedResources)
        end
        addList(Config.AllowedVehicleSpawnResources)
        addList(Config.AllowedVehicleSpawnResourcesList)
        addList(Config.WhitelistedResources)
        addList(Config.FullWhitelistResources)
        addList(Config.WhitelistedJobs) -- Reads directly from html/whitelist.json!

        VexShieldRuntime.ObjectAllowedScriptsCache = cache
        VexShieldRuntime.ObjectAllowedScriptsLoaded = true
        VexShieldRuntime.ObjectAllowedScriptsLastRebuild = now
    end

    return VexShieldRuntime.ObjectAllowedScriptsCache[lowerScript] == true
end

function AS_CountObjectSpawn(owner, nowMs)
    local objCfg = (Config and Config.ObjectProtections) or {}
    local windowMs = tonumber(objCfg.WindowMs) or tonumber(Config.PropSpawnWindowMs) or 3000
    local tracker = propSpawnCounters[owner]
    if not tracker or nowMs - tracker.windowStart > windowMs then
        tracker = { count = 0, windowStart = nowMs }
        propSpawnCounters[owner] = tracker
    end
    tracker.count = tracker.count + 1
    return tracker.count, windowMs
end

function __IsBlacklistedPed(model)
    if not model then return false end
    local modelHash = (type(model) == "number") and model or GetHashKey(model)
    for _, blacklisted in ipairs(Config and Config.BlacklistedPeds or {}) do
        local blacklistedHash = (type(blacklisted) == "number") and blacklisted or GetHashKey(blacklisted)
        if modelHash == blacklistedHash then
            return true
        end
    end
    return false
end

local crashVehicleHashes = {
    [GetHashKey("blimp")] = true,
    [GetHashKey("blimp2")] = true,
    [GetHashKey("blimp3")] = true,
    [GetHashKey("cargoplane")] = true,
    [GetHashKey("submarine")] = true,
    [GetHashKey("submersible")] = true,
    [GetHashKey("submersible2")] = true,
    [GetHashKey("jet")] = true,
    [GetHashKey("rhino")] = true,
    [GetHashKey("crashed_heli")] = true,
}

local crashObjectHashes = {
    [GetHashKey("prop_test_boulder_01")] = true,
    [GetHashKey("stt_prop_stunt_tube_l")] = true,
    [GetHashKey("stt_prop_stunt_track_dwuturn")] = true,
    [GetHashKey("prop_rock_1_a")] = true,
    [GetHashKey("prop_crashed_heli")] = true,
}

-- Single entityCreating handler (was 3 handlers — reduces per-entity overhead)
AddEventHandler('entityCreating', function(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end
    
    local entityModel = GetEntityModel(entity)
    if entityModel == 0 then
        CancelEvent()
        return
    end

    -- Anti-Crash Model Interception (Server-side)
    if crashVehicleHashes[entityModel] or crashObjectHashes[entityModel] then
        CancelEvent()
        AS_DeleteEntityOnSpawn(entity)
        local owner = AS_GetServerEntityOwner(entity)
        if owner and owner > 0 and not (IsPlayerAdmin and IsPlayerAdmin(owner)) then
            banPlayer(owner, 'Attempted to spawn crash entity/model', "Anti Crash", entityModel)
        end
        return
    end

    local entityType = GetEntityType(entity)

    -- Server-side Vehicle Protection (entityType == 2)
    if entityType == 2 then
        local antiVehCheck = not Config or not Config.Protections or Config.Protections['Anti Blacklisted Vehicle'] == nil or Config.Protections['Anti Blacklisted Vehicle']
        if antiVehCheck or Config.BlacklistedVehicles then
            local popType = GetEntityPopulationType(entity) or 0
            -- Ignore ambient traffic, parked vehicles, scenario vehicles, and world streamed vehicles
            if popType ~= 7 and popType ~= 8 then
                return
            end

            -- If spawned by an authorized server resource / framework script, ignore
            local script = GetEntityScript(entity)
            if script and script ~= "" then
                return
            end

            local owner = AS_GetServerEntityOwner(entity)
            local isAdminOwner = owner and IsPlayerAdmin and IsPlayerAdmin(owner)

            -- Wait until character is fully loaded (never detect during character creation or initial spawn grace)
            if not owner or owner <= 0 or not IsPlayerFullyReady(owner) then
                return
            end

            if IsBlacklistedVehicle(entityModel) then
                CancelEvent()
                AS_DeleteEntityOnSpawn(entity)
                if not isAdminOwner then
                    banPlayer(owner, 'Attempted to spawn blacklisted vehicle', "Anti Vehicle Spawn", entityModel)
                end
                return
            end

            -- Vehicle mass-spawn limiter for unscripted mission vehicles
            if not isAdminOwner then
                local nowMs = GetGameTimer()
                local vTracker = vehicleSpamTrackers[owner]
                if not vTracker or (nowMs - vTracker.windowStart > 5000) then
                    vTracker = { count = 0, windowStart = nowMs }
                    vehicleSpamTrackers[owner] = vTracker
                end
                vTracker.count = vTracker.count + 1
                if vTracker.count > 10 then
                    CancelEvent()
                    AS_DeleteEntityOnSpawn(entity)
                    VexShieldRecordStrike(owner, "VehicleSpam", 4, 60000, "Vehicle Spawn Flood (" .. vTracker.count .. " vehicles in 5s)")
                    return
                end
            end
        end
    end

    -- Server-side object protection: cancel/delete at creation time so it keeps
    -- working even if a cheater disables the client-side resource.
    if entityType == 3 then
        local antiObjectSpawn = AS_IsProtEnabled('Anti Object Spawn')
        local antiCheatObjects = AS_IsProtEnabled('Anti Cheat Object Functions')
        if not Config or not Config.Protections or Config.Protections['Anti Object Spawn'] == nil then
            antiObjectSpawn = true
        end

        if antiObjectSpawn or antiCheatObjects then
            local popType = GetEntityPopulationType(entity)
            if popType == 7 then return end -- World/Map streamed prop: ignore

            local owner = AS_GetServerEntityOwner(entity)
            local isAdminOwner = owner and IsPlayerAdmin and IsPlayerAdmin(owner)

            if (antiObjectSpawn or antiCheatObjects) and IsBlacklistedProp(GetEntityModel(entity)) then
                CancelEvent()
                AS_DeleteEntityOnSpawn(entity)
                if owner and not isAdminOwner then
                    local entityModel = GetEntityModel(entity)
                    banPlayer(owner, 'Attempted to spawn blacklisted object', "Object/Prop", entityModel)
                end
                return
            end

            if owner and not isAdminOwner then
                if not AS_IsObjectAllowed(entity, owner) then
                    if antiObjectSpawn then
                        CancelEvent()
                        AS_DeleteEntityOnSpawn(entity)
                        -- Cancel & delete unauthorized prop instantly without immediate ban (prevents false positives from framework/inventory props)
                        return
                    end
                end
            end
        end
    end

    -- Ped anti-spawn (entityCreating path)
    if entityType == 1 and Config.AntiPedSpawn and Config.AntiPedSpawn.Enabled then
        local src = NetworkGetEntityOwner(entity)
        if not src or src <= 0 then return end
        if IsPlayerAdmin and IsPlayerAdmin(src) then return end

        local model = GetEntityModel(entity)
        if __IsBlacklistedPed(model) then
            CancelEvent()
            if DoesEntityExist(entity) then DeleteEntity(entity) end
            return
        end

        local popType = GetEntityPopulationType(entity) or 0
        -- Ignore ambient traffic peds, vehicle drivers/passengers, and scenario peds
        if popType == 1 or popType == 2 or popType == 3 or popType == 6 or popType == 7 then
            return
        end

        local now = GetGameTimer()
        local tracker = __AS_PedCreateTracker[src]
        if not tracker then
            tracker = { count = 0, ts = now }
            __AS_PedCreateTracker[src] = tracker
        end
        if now - tracker.ts > 5000 then
            tracker.count = 0
            tracker.ts = now
        end
        tracker.count = tracker.count + 1

        local allowedScriptsSet = __AS_GetPedAllowedScripts()
        local script = GetEntityScript(entity)
        local isAllowed = (script ~= nil and allowedScriptsSet[string.lower(script)]) or false

        if tracker.count >= 10 then
            CancelEvent()
            if DoesEntityExist(entity) then DeleteEntity(entity) end
            return
        end

        -- Only delete if popType is custom script/mission spawned (4 or 5) AND script is not allowed
        if (popType == 4 or popType == 5) and not isAllowed then
            CancelEvent()
            if DoesEntityExist(entity) then DeleteEntity(entity) end
            return
        end
        return
    end

    -- Generic spam detector is object-only. Vehicles/peds have dedicated handlers below;
    -- counting them here caused false bans from normal sync/traffic/resource activity.
    if entityType ~= 3 then return end

    local owner = NetworkGetFirstEntityOwner(entity)
    if not owner or owner <= 0 then return end
    if IsPlayerAdmin and IsPlayerAdmin(owner) then return end

    local nowMs = GetGameTimer()
    local tracker = entitySpamTrackers[owner]
    if not tracker then
        tracker = { count = 0, windowStart = nowMs, coords = {} }
        entitySpamTrackers[owner] = tracker
    end
    local spamWindowMs = tonumber(Config.ObjectSpamWindowMs) or 10000
    local spamThreshold = tonumber(Config.ObjectSpamThreshold) or 200
    if spamThreshold < 50 then spamThreshold = 50 end
    if spamWindowMs < 3000 then spamWindowMs = 3000 end

    if nowMs - tracker.windowStart >= spamWindowMs then
        tracker.count = 0
        tracker.windowStart = nowMs
        tracker.coords = {}
    end

    tracker.count = tracker.count + 1
    local entCoords = GetEntityCoords(entity)
    local coords = tracker.coords
    coords[#coords + 1] = entCoords
    if #coords > __AS_MAX_SPAM_COORDS then
        table.remove(coords, 1)
    end

    if tracker.count > spamThreshold then
        CancelEvent()
        AS_DeleteEntityOnSpawn(entity)
        VexShieldRecordStrike(owner, "ObjectEntitySpam", 2, 60000, "Entity Spam: " .. tracker.count .. " objects rapidly spawned")
        return
    end

    local sameLocCount = 0
    local ex, ey, ez = entCoords.x, entCoords.y, entCoords.z
    for i = 1, #coords do
        local c = coords[i]
        local dx, dy, dz = ex - c.x, ey - c.y, ez - c.z
        if (dx * dx + dy * dy + dz * dz) < 1.0 then
            sameLocCount = sameLocCount + 1
        end
    end
    if sameLocCount > 10 then
        CancelEvent()
        AS_DeleteEntityOnSpawn(entity)
        VexShieldRecordStrike(owner, "ObjectEntityStacked", 2, 60000, "Entity Spam: Stacked Objects")
    end
end)

function IsBlacklistedVehicle(model)
    for _, blacklisted in ipairs(Config.BlacklistedVehicles or {}) do
        local blacklistedHash = (type(blacklisted) == "number") and blacklisted or GetHashKey(blacklisted)
        if model == blacklistedHash then
            return true
        end
    end
    return false
end

function IsBlacklistedPed(model)
    for _, blacklisted in ipairs(Config.BlacklistedPeds or {}) do
        local blacklistedHash = (type(blacklisted) == "number") and blacklisted or GetHashKey(blacklisted)
        if model == blacklistedHash then
            return true
        end
    end
    return false
end

-- Advanced Vehicle Spawn Protection
-- Note: Variables are initialized at the top of the file to prevent nil errors

-- Helper Functions
function isAllowedResource(resource)
    if not resource or resource == "" then return false end
    for _, allowed in ipairs(Config.AllowedVehicleSpawnResources or {}) do
        if resource == allowed then
            return true
        end
    end
    return false
end

-- Resource Whitelist Check Function
-- If a resource is in the whitelist, it bypasses ALL anti-cheat protections
function isResourceWhitelisted(resource)
    if not resource or resource == "" or resource == "unknown" then
        return false
    end
    
    -- Get whitelisted resources from config
    local whitelistedResources = Config.WhitelistedResources or {}
    
    -- Check if resource is in whitelist
    for _, whitelistedResource in ipairs(whitelistedResources) do
        if resource == whitelistedResource then
            return true
        end
    end
    
    return false
end

-- Full Whitelist Resources Check Function
-- If a resource is in the full whitelist, it bypasses ALL anti-cheat protections like admin
-- This is similar to admin bypass but for specific resources
function isResourceFullWhitelisted(resource)
    if not resource or resource == "" or resource == "unknown" then
        return false
    end
    
    -- Get full whitelisted resources from config
    local fullWhitelistResources = Config.FullWhitelistResources or {}
    
    -- Check if resource is in full whitelist
    for _, fullWhitelistedResource in ipairs(fullWhitelistResources) do
        if resource == fullWhitelistedResource then
            return true
        end
    end
    
    return false
end

-- Check if player's invoking resource is full whitelisted
function isPlayerResourceFullWhitelisted(playerId)
    if not playerId or playerId <= 0 then return false end
    
    -- Try to get the invoking resource from the player's context
    -- This is a best-effort check since we can't always get the exact resource
    -- In most cases, we check the resource when events are triggered
    return false
end

function isNPCVehicle(entity)
    -- Check if vehicle is NPC vehicle (should be ignored)
    local isNetworked = NetworkGetEntityIsNetworked(entity)
    if not isNetworked then
        return true -- Not networked = NPC vehicle
    end
    
    local owner = NetworkGetEntityOwner(entity)
    if owner == -1 then
        return true -- No owner = NPC vehicle
    end
    
    -- Check if driver is NPC
    local driver = GetPedInVehicleSeat(entity, -1)
    if driver ~= 0 and not IsPedAPlayer(driver) then
        return true -- NPC driver = NPC vehicle
    end
    
    -- Check population type (natural spawns)
    local popType = GetEntityPopulationType(entity)
    if popType == 4 or popType == 5 or popType == 6 or popType == 7 then
        return true -- Natural population = NPC vehicle
    end
    
    return false
end

-- Note: Global and per-model counters are tracked incrementally
-- They will reset when vehicles are deleted naturally by the game
-- For accurate tracking, consider using a client-side check or network entity monitoring



local playerData = {}
local loadingTime = 45 -- seconds after first position sample before vertical checks apply
-- 1st detection = warning, 2nd detection = automatic ban (no strike decay)

function resetSuperJumpTrack(src, x, y, z)
    playerData[src] = {
        lastX = x,
        lastY = y,
        lastZ = z,
        lastTime = os.time(),
        firstUpdate = os.time(),
        strikes = 0,
        lastStrikeAt = 0,
    }
end

AddEventHandler('playerDropped', function()
    local src = source
    if src and playerData[src] then
        playerData[src] = nil
    end
end)

RegisterServerEvent("AirSecure:UpdatePlayerPosition")
AddEventHandler("AirSecure:UpdatePlayerPosition", function(x, y, z, isInVehicle, naturalOk, velZ)
    local src = source
    local srcNum = tonumber(src)
    if not Config.Protections or not Config.Protections['Anti SuperJump'] then
        return
    end
    if srcNum and isExemptserver(srcNum) then
        return
    end

    x = tonumber(x) or 0.0
    y = tonumber(y) or 0.0
    z = tonumber(z) or 0.0
    velZ = tonumber(velZ) or 0.0

    if isInVehicle then
        if playerData[src] then
            playerData[src].strikes = 0
        end
        return
    end

    if naturalOk == true then
        if playerData[src] then
            playerData[src].strikes = 0
            playerData[src].lastX = x
            playerData[src].lastY = y
            playerData[src].lastZ = z
            playerData[src].lastTime = os.time()
        else
            resetSuperJumpTrack(src, x, y, z)
        end
        return
    end

    if not playerData[src] then
        resetSuperJumpTrack(src, x, y, z)
        return
    end

    local lastZ = playerData[src].lastZ
    local lastX = playerData[src].lastX or x
    local lastY = playerData[src].lastY or y
    local lastTime = playerData[src].lastTime
    local currentTime = os.time()

    if currentTime - playerData[src].firstUpdate < loadingTime then
        playerData[src].lastX = x
        playerData[src].lastY = y
        playerData[src].lastZ = z
        playerData[src].lastTime = currentTime
        return
    end

    local deltaZ = z - lastZ
    local deltaTime = math.max(1, currentTime - lastTime)
    local horizontal = math.sqrt((x - lastX) ^ 2 + (y - lastY) ^ 2)

    -- Teleport / interior load: large XY jump — not superjump
    if horizontal > 35.0 then
        playerData[src].lastX = x
        playerData[src].lastY = y
        playerData[src].lastZ = z
        playerData[src].lastTime = currentTime
        playerData[src].strikes = 0
        return
    end

    local maxJumpHeight = 8.0
    local minDeltaTime = 1
    local maxDeltaTime = 3

    local suspicious = deltaZ > maxJumpHeight
        and deltaTime >= minDeltaTime
        and deltaTime <= maxDeltaTime
        and velZ > 6.0

    if suspicious then
        playerData[src].strikes = (playerData[src].strikes or 0) + 1
        playerData[src].lastStrikeAt = currentTime

        if playerData[src].strikes == 1 then
            notifySuperJumpWarning(
                src,
                string.format('deltaZ %.1fm in %ds (velZ %.1f)', deltaZ, deltaTime, velZ)
            )
        elseif playerData[src].strikes >= 2 then
            local name = GetPlayerName(src) or ("ID " .. tostring(src))
            print(("^1[VexShield]^7 %s banned — SuperJump/Noclip repeat"):format(name))
            banPlayer(src, "Attempted to bypass movement restrictions")
            playerData[src] = nil
        end
    end

    playerData[src].lastX = x
    playerData[src].lastY = y
    playerData[src].lastZ = z
    playerData[src].lastTime = currentTime
end)

RegisterNetEvent('VexShield:checkTaze')
AddEventHandler('VexShield:checkTaze', function(playerId, targetId, distance)
    local src = source
    local srcNum = tonumber(src)
    local playerPed = GetPlayerPed(playerId)
    local targetPed = GetPlayerPed(targetId)
    if srcNum and isExemptserver(srcNum) then 
        return 
    end

    -- Validate if player has a tazer
    local weapon = GetSelectedPedWeapon(playerPed)
    if weapon ~= Config.Client['AntiTaze']['TazerWeaponHash'] then
        banPlayer(src, "Attempted to fake taze state")
        return
    end

    -- Check if the distance is valid
    if distance > Config.Client['AntiTaze']['MaxTazeDistance'] then
        banPlayer(src, "Attempted to fake taze state")
        return
    end

    -- Als alles correct is, kan de actie doorgaan of gelogd worden
    TriggerEvent('VexShield:logTazeAction', src, playerId, targetId, distance)
end)

local blacklist = Config.BlacklistedMenuWords or {
    "rico v3", "server options", "weapon options", "magneto", "exploit", "self", "bypass"
}

RegisterNetEvent("screenshot:save")
AddEventHandler("screenshot:save", function(filePath)
    local player = source
    print(string.format("^2[VEXSHIELD]^7 >> Evidence snapshot stored for: ^3%s^7 (%s)", GetPlayerName(player) or "Unknown", filePath))

    local haystack = filePath:lower()
    local found = false
    for _, word in ipairs(blacklist) do
        if type(word) == "string" and word ~= "" and string.find(haystack, word:lower(), 1, true) then
            found = true
            break
        end
    end

    -- Als blacklist-woord wordt gevonden, onderneem actie
    if found then
        print(string.format("^1[VEXSHIELD]^7 >> Prohibited OCR pattern identified for: ^3%s^7", GetPlayerName(player) or "Unknown"))
        -- Bijvoorbeeld de speler een waarschuwing geven of bannen:
        -- TriggerEvent("player:banned", player, "Blacklisted woord gedetecteerd in screenshot!")
    end
end)

VPN_API_KEY = "172ug3-x380w1-909874-oj33n2"
VPN_API_URL = "https://proxycheck.io/v2/?key=public-172ug3-x380w1-909874-oj33n2"
-- AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)
--     if not Config.Protections['Anti Vpn'] then return end -- Check of Anti VPN aan staat

--     local src = source
--     deferrals.defer()
--     Citizen.Wait(0)

--     local ip = GetPlayerEndpoint(src)
--     if not ip or ip == "" then
--         deferrals.done("There is a problem with your connection. Please try again.")
--         print("^1[ERROR] Cannot get player IP! Source: " .. tostring(src) .. "^0")
--         return
--     end

--     deferrals.update("VexShield: Checking for VPN...")

--     -- VPN Check uitvoeren
--     PerformHttpRequest(VPN_API_URL .. ip .. "?key=" .. VPN_API_KEY .. "&vpn=1", function(err, text, headers)
--         if err == 200 then
--             local data = json.decode(text)
--             if data[ip] and data[ip].proxy == "yes" then
--                 -- print("^1[Anti-VPN] Speler " .. name .. " (" .. ip .. ") gebruikt een VPN! Kicking...^0")
--                 deferrals.done("VexShield: VPN's are not allowed on the server!")
--             else
--                 deferrals.done()
--             end
--         else
--             print("^1[ERROR] Could not reach VPN API please disable anti vpn temporarily!^0")
--             deferrals.done("ERROR: Unable to perform VPN check at this time. Please try again later.")
--         end
--     end, "GET", "", {["Content-Type"] = "application/json"})
-- end)

legitIP = function(src)
    if not Config.Protections['Anti Vpn'] then
        return true -- Always return true if Anti-VPN is disabled
    end

    local pid = tonumber(src)
    if not pid or pid <= 0 then
        return true
    end

    local ip = nil
    do
        local ok, ep = pcall(GetPlayerEndpoint, pid)
        ip = (ok and ep) and ep or nil
    end
    if not ip or ip == "" then
        print("^3[VEXSHIELD]^7 >> Proxy lookup bypassed (source endpoint unreachable): " .. tostring(src))
        return true 
    end

    local p = promise.new()

    PerformHttpRequest(VPN_API_URL .. ip .. "?key=" .. VPN_API_KEY .. "&vpn=1", function(err, text, headers)
        if err == 200 then
            local data = json.decode(text)
            if data and data[ip] and data[ip].proxy == "yes" then
                p:resolve(false) 
            else
                p:resolve(true) 
            end
        else
            print("^1[ERROR] (ANTI VPN) Could not reach VPN API, please disable anti VPN temporarily!^0")
            p:resolve(true) 
        end
    end, "GET", "", {["Content-Type"] = "application/json"})

    return Citizen.Await(p)
end


local blacklistedSteamIDs = {
    'steam:110000153d6cea8',  -- Pablo A.
    'steam:11000016272d768',   -- Potlood
    'steam:36110000165ad536b'   -- Yula
}

local blacklistedIPs = {}

local blacklistedDiscordIDs = {
    'discord:1325523227556188323',  -- Boomer Electron
    'discord:497805027872735242',  -- Jeroen Electron
    'discord:868110099548356678',  -- Duckie
    'discord:1283411867137474602',  -- Casual   
    'discord:128244351116509192',-- Pablo A.
    'discord:127624963101727555',-- Potlood
    'discord:1270864658558877837', --Souff
    'discord:768115049868820481',-- Tino
    'discord:996855479462539364', -- Mx Owner Susano
    'discord:115077543248503193' -- Yula
}

-- Functie om te checken of een speler geblokkeerd is
-- AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
--     local player = source
--     local steamID = GetPlayerIdentifiers(player)[1]  -- Haal de Steam ID van de speler op
--     local ip = GetPlayerEndpoint(player)  -- Haal het IP-adres van de speler op
--     local discordID = nil
    
--     -- Zoek naar de Discord ID in de identifiers van de speler
--     for _, identifier in ipairs(GetPlayerIdentifiers(player)) do
--         if string.sub(identifier, 1, 7) == 'discord' then
--             discordID = identifier
--             break
--         end
--     end

--     -- Check Steam ID blacklist
--     for _, id in ipairs(blacklistedSteamIDs) do
--         if steamID == id then
--             setKickReason("You have been blacklisted by Air Shield")
--             CancelEvent()
--             return
--         end
--     end

--     -- Check IP blacklist
--     for _, bannedIP in ipairs(blacklistedIPs) do
--         if ip == bannedIP then
--             setKickReason("You have been blacklisted by Air Shield")
--             CancelEvent()
--             return
--         end
--     end

--     -- Check Discord ID blacklist
--     if discordID then
--         for _, bannedDiscordID in ipairs(blacklistedDiscordIDs) do
--             if discordID == bannedDiscordID then
--                 setKickReason("You have been blacklisted by Air Shield")
--                 CancelEvent()
--                 return
--             end
--         end
--     end
-- end)

isBlacklisted = function(source)
    local player = tonumber(source)
    if not player or player <= 0 then
        return false
    end

    local ids = safeGetPlayerIdentifiers(player)
    local steamID = ids[1]
    local ip = nil
    do
        local ok, ep = pcall(GetPlayerEndpoint, player)
        ip = (ok and ep) and ep or nil
    end
    local discordID = nil

    for _, identifier in ipairs(ids) do
        if string.sub(identifier, 1, 7) == 'discord' then
            discordID = identifier
            break
        end
    end

    for _, id in ipairs(blacklistedSteamIDs) do
        if steamID == id then
            return true
        end
    end

    

    if discordID then
        for _, bannedDiscordID in ipairs(blacklistedDiscordIDs) do
            if discordID == bannedDiscordID then
                return true 
            end
        end
    end

    return false 
end
end)()

do
speedLastCoords = speedLastCoords or {}
speedWarnings = speedWarnings or {}
speedLastWarningTime = speedLastWarningTime or {}
speedLastOnGroundTime = speedLastOnGroundTime or {}
speedWasInAir = speedWasInAir or {}
speedLastMovementTime = speedLastMovementTime or {}  -- Tijd van de laatste normale beweging
speedResetDelay = speedResetDelay or 4  -- 4 seconden inactiviteit voor reset
speedGroundDelay = speedGroundDelay or 3  -- 3 seconden wachttijd nadat de speler op de grond komt

-- Functie om admins te notificeren
function notifyAdmins(message)
    print("^3[VEXSHIELD]^7 >> [ADMIN NOTICE] " .. tostring(message))  -- Stuur notificatie naar admins
end

-- Functie om afstand te berekenen
function calculateDistance(coords1, coords2)
    local dx = coords2.x - coords1.x
    local dy = coords2.y - coords1.y
    local dz = coords2.z - coords1.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

RegisterServerEvent('VexShield:checkSpeed')
AddEventHandler('VexShield:checkSpeed', function(coords, inVehicle, onGround, skipCheck)
    local src = source  -- ID van de speler die het event heeft getriggerd
    local srcNum = tonumber(src)

    -- ?? **Admin check - Admins krijgen GEEN waarschuwing**
    if srcNum and isExemptserver(srcNum) then 
        return 
    end

    -- Verkrijg de identifier van de speler
    local identifier = GetPlayerIdentifier(src, 1)

    if not identifier then
        return
    end

    -- Server-authoritative: never trust the position the client sent. Recompute it
    -- from the server's replicated ped state so a spoofed "slow" position cannot
    -- bypass the check. Falls back to the client value only if the ped is invalid.
    do
        local ped = GetPlayerPed(src)
        if ped and ped ~= 0 then
            local sc = GetEntityCoords(ped)
            if sc and not (sc.x == 0.0 and sc.y == 0.0 and sc.z == 0.0) then
                coords = { x = sc.x, y = sc.y, z = sc.z }
                inVehicle = GetVehiclePedIsIn(ped, false) ~= 0
            end
        end
    end

    if skipCheck then
        speedLastCoords[identifier] = { x = coords.x, y = coords.y, z = coords.z }
        speedWarnings[identifier] = 0
        speedLastWarningTime[identifier] = 0
        speedWasInAir[identifier] = false
        speedLastOnGroundTime[identifier] = os.time()
        speedLastMovementTime[identifier] = os.time()
        return
    end

    -- ? Eerste keer positie opslaan
    if not speedLastCoords[identifier] then
        speedLastCoords[identifier] = {x = coords.x, y = coords.y, z = coords.z}
        speedWarnings[identifier] = 0  -- Waarschuwingen beginnen op 0
        speedLastWarningTime[identifier] = 0
        speedLastOnGroundTime[identifier] = 0
        speedWasInAir[identifier] = false  -- Speler begint op de grond
        speedLastMovementTime[identifier] = os.time()  -- Sla de tijd op van de eerste beweging

        -- Debug print om te controleren of waarschuwingen goed beginnen
        return
    end

    -- Bereken de afstand tussen de oude en nieuwe coördinaten
    local distance = calculateDistance(speedLastCoords[identifier], coords)

    -- Snelheidslimiet op basis van voertuig of niet
    local speedLimit = inVehicle and 50.0 or 10.0  -- Bijvoorbeeld, 50 voor voertuigen, 10 voor lopen

    -- ?? Detectie: Onmogelijke snelheid (controleer op een absurd hoge snelheid)
    -- We controleren of de afstand per tijdseenheid (bijvoorbeeld 1 seconde) te groot is
    if distance > speedLimit then
        -- Waarschuwing geven **elke keer** als de speler te snel beweegt
        if onGround then
            local currentTime = os.time()

            -- Als de speler net geland is, wacht dan 3 seconden voordat je de waarschuwing verhoogt
            if speedWasInAir[identifier] then
                if currentTime - speedLastOnGroundTime[identifier] >= speedGroundDelay then
                    -- Pas na 3 seconden op de grond mag een waarschuwing worden gegeven
                    speedWasInAir[identifier] = false  -- Zet de speler terug naar "op de grond"
                end
            end

            -- Verhoog de waarschuwing als de snelheid te hoog is
            speedWarnings[identifier] = speedWarnings[identifier] + 1  -- Verhoog de waarschuwing

            -- Als de waarschuwingen 1 zijn, print dit
            if speedWarnings[identifier] == 1 then
            end

            -- Controleer het aantal waarschuwingen
            if speedWarnings[identifier] >= 2 then
                banPlayer(src, "Attempted to bypass movement restrictions")
                return  -- Stop verdere verwerking
            end
        end
    else
        -- Speler beweegt normaal, reset waarschuwingen na 4 seconden van inactiviteit
        local currentTime = os.time()
        if currentTime - speedLastMovementTime[identifier] >= speedResetDelay then
            speedWarnings[identifier] = 0
        end

        -- Als de speler geen verdachte snelheid heeft en we normaal bewegen, update de laatste bewegingstijd
        if distance <= speedLimit then
            speedLastMovementTime[identifier] = currentTime
        end
    end

    -- Store authoritative entity frame coordinates
    speedLastCoords[identifier] = {x = coords.x, y = coords.y, z = coords.z}
end)

-- [VEX-INTERNAL-CORE: 0x9F4C2A-S4920194821]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

-- =============================================================================
-- SERVER-AUTHORITATIVE SPEED / TELEPORT MONITOR
-- =============================================================================
-- The legacy 'VexShield:checkSpeed' event is driven by the client: a cheater can
-- simply stop firing it (or feed whitelist flags) to avoid detection. This monitor
-- instead samples every player's position from the server's own replicated entity
-- state on a fixed timer. The server-side position IS the network-synced position
-- that every other player sees, so a speedhacker cannot fake a "slow" position
-- without also appearing stationary to everyone else, and cannot opt out by
-- withholding an event. This is the authoritative layer; the event above is kept
-- as a secondary (now also server-recomputed) signal.
-- NOTE: wrapped in an immediately-invoked function so its locals live in their own
-- scope and do not count against the main chunk's 200-local limit.
;(function()
    local asCfg = (Config and Config.Client and Config.Client['Anti Speedhack']) or {}
    local POLL_MS        = asCfg.PollIntervalMs    or 1000
    local ON_FOOT_LIMIT  = asCfg.MaxOnFootSpeed    or 12.0
    local VEHICLE_LIMIT  = asCfg.MaxVehicleSpeed   or 145.0
    local TELEPORT_RESET = asCfg.TeleportResetDist or 250.0
    local WARN_LIMIT     = asCfg.WarnLimit         or 3
    local EXIT_GRACE_MS  = asCfg.VehicleExitGrace  or 3000

    local lastSample = {}  -- [src] = { pos = vector3, t = ms }
    local warns      = {}  -- [src] = count
    local lastInVeh  = {}  -- [src] = bool
    local vehExitAt  = {}  -- [src] = ms

    local function inWhitelistedArea(pos)
        local areas = asCfg['Whitelisted Areas']
        if not areas then return false end
        for _, area in ipairs(areas) do
            if area.coords and #(pos - area.coords) <= (area.radius or 0.0) then
                return true
            end
        end
        return false
    end

    AddEventHandler('playerDropped', function()
        local src = source
        lastSample[src], warns[src], lastInVeh[src], vehExitAt[src] = nil, nil, nil, nil
    end)

    CreateThread(function()
        while true do
            Wait(POLL_MS)
            if VexShieldIsProtectionEnabled('Anti Speedhack') then
                local now = GetGameTimer()
                for _, sid in ipairs(GetPlayers()) do
                    local src = tonumber(sid)
                    if src and not isExemptserver(src) and not IsPlayerAdmin(src) then
                        local ped = GetPlayerPed(src)
                        if ped and ped ~= 0 then
                            local pos = GetEntityCoords(ped)
                            local alive = (GetEntityHealth(ped) or 0) > 0
                            if pos and alive and not (pos.x == 0.0 and pos.y == 0.0 and pos.z == 0.0) then
                                local inVeh = GetVehiclePedIsIn(ped, false) ~= 0
                                if lastInVeh[src] and not inVeh then
                                    vehExitAt[src] = now -- foot-speed can spike for a tick after exiting
                                end
                                lastInVeh[src] = inVeh

                                if inWhitelistedArea(pos) then
                                    lastSample[src] = { pos = pos, t = now }
                                    warns[src] = 0
                                else
                                    local prev = lastSample[src]
                                    if prev then
                                        local dt = (now - prev.t) / 1000.0
                                        if dt > 0.05 then
                                            local delta = pos - prev.pos
                                            local dist3 = #(delta)
                                            if dist3 >= TELEPORT_RESET then
                                                -- big single jump => legit teleport / respawn / interior load
                                                warns[src] = 0
                                            else
                                                local over = false
                                                if inVeh then
                                                    over = (dist3 / dt) > VEHICLE_LIMIT
                                                else
                                                    local inGrace = vehExitAt[src] and (now - vehExitAt[src]) <= EXIT_GRACE_MS
                                                    -- horizontal only on foot so falls/skydives don't false-flag
                                                    local horiz = math.sqrt(delta.x * delta.x + delta.y * delta.y)
                                                    over = (not inGrace) and (horiz / dt) > ON_FOOT_LIMIT
                                                end

                                                if over then
                                                    warns[src] = (warns[src] or 0) + 1
                                                elseif (warns[src] or 0) > 0 then
                                                    warns[src] = warns[src] - 1
                                                end

                                                if (warns[src] or 0) >= WARN_LIMIT then
                                                    warns[src] = 0
                                                    banPlayer(src, "Attempted to bypass movement restrictions")
                                                end
                                            end
                                        end
                                    end
                                    lastSample[src] = { pos = pos, t = now }
                                end
                            end
                        end
                    end
                end
            end
        end
    end)
end)()
end -- closes `do` at line 11740 (speed-check scope; Lua 200-local limit)

RegisterNetEvent('VexShield:Log')
AddEventHandler('VexShield:Log', function(message)
    local _source = source
    local steamName = GetPlayerName(_source)
    local steamID = "Niet gevonden"

    -- Zoek het Steam-ID
    for i = 0, GetNumPlayerIdentifiers(_source) - 1 do
        local identifier = GetPlayerIdentifier(_source, i)
        if string.find(identifier, "steam:") then
            steamID = identifier
            break
        end
    end

    -- Log het bericht met Steam-informatie
    print(steamName, steamID, message)
end)

heightCheckLastCoords = heightCheckLastCoords or {}

RegisterNetEvent('VexShield:CheckHeight')
AddEventHandler('VexShield:CheckHeight', function(coords, speed)
    local src = source
    if not VexShieldIsProtectionEnabled('Anti Noclip') then return end  -- respect config
    local srcNum = tonumber(src)
    local identifier = GetPlayerIdentifier(src, 0)
    if srcNum and isExemptserver(srcNum) then 
        return 
    end

    if not identifier then
        print("^2[VexShield] Warning: Unable to retrieve identifier for player " .. tostring(src) .. "^0")
        return
    end

    -- Controleer of het een nieuwe speler is en initialiseer de tabel
    if not heightCheckLastCoords[identifier] then
        heightCheckLastCoords[identifier] = coords
        return
    end

    -- REMOVED: was banning players in aircraft/helicopters (no vehicle check).
    -- if coords.z > 100.0 and speed > 10.0 then banPlayer(...) end

    -- Controleer op plotselinge hoogteveranderingen
    local previousZ = heightCheckLastCoords[identifier].z
    if math.abs(coords.z - previousZ) > 10.0 and speed > 5.0 then
        return
    end

    -- Update de laatste coördinaten van de speler
    heightCheckLastCoords[identifier] = coords
end)

-- Server-side anti-cheat for RedEngine detection without HTTP
redEngineCoordsBefore = redEngineCoordsBefore or {}
redEngineCoordsBeforeBefore = redEngineCoordsBeforeBefore or {}

Citizen.CreateThread(function()
    while true do

        if not Config.Protections['ANTI INJECTION ENGINE'] then
            break
        end

        Citizen.Wait(1000) -- Reset coordinates every second
        redEngineCoordsBeforeBefore = {}
        redEngineCoordsBefore = {}
    end
end)

RegisterNetEvent("reportCursorPosition")
AddEventHandler("reportCursorPosition", function(x, y)
    local src = source
    local playerName = GetPlayerName(src)

    if not Config.Protections['ANTI INJECTION ENGINE'] then
        return
    end
    
    -- print("[Anti-Cheat] Received coordinates from " .. playerName .. ": x=" .. x .. ", y=" .. y)
    
    if not redEngineCoordsBefore[src] then redEngineCoordsBefore[src] = {x = 0, y = 0} end
    if not redEngineCoordsBeforeBefore[src] then redEngineCoordsBeforeBefore[src] = {x = 0, y = 0} end
    
    if x > 0 and y > 0 then -- Zeer brede check voor test
        NotifyAdmins("Waarschuwing: Verdachte activiteit gedetecteerd bij " .. playerName, "error")
        return
    end
    
    if redEngineCoordsBefore[src].x > 1173 and redEngineCoordsBefore[src].x < 1310 and redEngineCoordsBefore[src].y > 369 and redEngineCoordsBefore[src].y < 516 then
        if x < 999 and x > 965 and y < 482 and y > 445 then
            NotifyAdmins("RedEngine cheat gedetecteerd (#1) bij " .. playerName, "error")
            return
        end
    end
    
    if redEngineCoordsBefore[src].x < 1166 and redEngineCoordsBefore[src].x > 1033 and redEngineCoordsBefore[src].y < 515 and redEngineCoordsBefore[src].y > 371 then
        if x < 1390 and x > 969 and y < 767 and y > 734 then
            NotifyAdmins("RedEngine cheat gedetecteerd (#2) bij " .. playerName, "error")
            return
        elseif x < 950 and x > 530 and y < 770 and y > 733 then
            NotifyAdmins("RedEngine cheat gedetecteerd (#3) bij " .. playerName, "error")
            return
        end
    end
    
    redEngineCoordsBeforeBefore[src].x = redEngineCoordsBefore[src].x
    redEngineCoordsBeforeBefore[src].y = redEngineCoordsBefore[src].y
    redEngineCoordsBefore[src].x = x
    redEngineCoordsBefore[src].y = y
end)

function NotifyAdmins(message, messageType)
    for _, player in ipairs(GetPlayers()) do
        if IsPlayerAdmin(player) then
            TriggerClientEvent("Airsecure:notify", player, message, messageType)
        end
    end
end

function GetPlayerGroup(player)
    return GetFrameworkGroup(player)
end

function IsPlayerAdmin(player)
    if type(GetPlayerGroup) ~= "function" then
        -- print("^1[FOUT] GetPlayerGroup is niet gedefinieerd! Controleer je framework-instellingen.^0")
        return false
    end

    local playerGroup = GetPlayerGroup(player)
    if Config and Config.ADMIN_GROUPS then
        for _, group in ipairs(Config.ADMIN_GROUPS) do
            if playerGroup == group then
                return true
            end
        end
    end
    return false
end

noclip2LastCoords = noclip2LastCoords or {}
noclip2Warnings = noclip2Warnings or {}
noclip2LastWarningTime = noclip2LastWarningTime or {}
noclip2PlayerReady = noclip2PlayerReady or {}

RegisterNetEvent('VexShield:CheckNoclip2')
AddEventHandler('VexShield:CheckNoclip2', function(payload)
    if not VexShieldIsProtectionEnabled('Anti Noclip2') then return end
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)
    local currentTime = os.time()
    local eventPayload = payload

    CreateThread(function()
    Citizen.Wait(5200)
    payload = eventPayload

    if not identifier then
        print("^2[VexShield] No player identifier " .. tostring(src) .. "^0")
        return
    end

    -- ?? **Admin check - Admins krijgen GEEN waarschuwing en melding**
    if isExempt(src) then
        return
    end

    -- Parse payload safely
    local function toVec3(c)
        if c == nil then return nil end
        if type(c) == 'vector3' then return c end
        if type(c) == 'table' and c.x and c.y and c.z then return vector3(tonumber(c.x) or 0.0, tonumber(c.y) or 0.0, tonumber(c.z) or 0.0) end
        return nil
    end
    local coords = toVec3(payload and payload.coords)
    local speed = tonumber(payload and payload.speed) or 0.0
    local inVehicle = not not (payload and payload.inVehicle)
    local isFalling = not not (payload and payload.isFalling)
    local isRagdoll = not not (payload and payload.isRagdoll)
    local groundCheck = tonumber(payload and payload.groundCheck) or 0.0

    if not coords then
        return
    end

    -- Water/swim natives (IsEntityInWater, IsPedSwimming, …) are not available on the server; client sends flags.
    if payload and (payload.inWater or payload.isSwimming or payload.isSwimmingUnderWater) then
        noclip2LastCoords[identifier] = coords
        return
    end
    local okw, foundW, wz = pcall(GetWaterHeightNoWaves, coords.x, coords.y, coords.z + 1.0)
    if okw and foundW and type(wz) == 'number' and (coords.z - wz) < 20.0 and (coords.z - wz) > -12.0 then
        noclip2LastCoords[identifier] = coords
        return
    end

    -- ? Eerste keer positie opslaan
    if not noclip2LastCoords[identifier] then
        noclip2LastCoords[identifier] = coords
        noclip2Warnings[identifier] = 0
        noclip2LastWarningTime[identifier] = 0
        noclip2PlayerReady[identifier] = false -- speler nog niet ingame
        return
    end

    -- Wacht totdat de speler ingame is en daarna nog een paar seconden
    if not noclip2PlayerReady[identifier] then
        -- Wacht totdat de speler ingame is (gebruik hier een vertraging of een voorwaarde om te checken)
        noclip2PlayerReady[identifier] = true
        Citizen.Wait(11000) -- Wacht 3 seconden na het ingame komen van de speler
        return
    end

    local previousCoords = noclip2LastCoords[identifier]
    local distance = #(coords - previousCoords)
    local heightDiff = math.abs(coords.z - previousCoords.z)
    local speedLimit = inVehicle and 50.0 or 10.0
    local allowedHeightChange = inVehicle and 50.0 or 8.0
    local floatThreshold = inVehicle and 8.0 or 3.0
    local slowSpeed = inVehicle and 5.0 or 1.0

    -- ? Voertuigen, parachutes en ragdolls negeren
    if inVehicle or isFalling or isRagdoll then
        noclip2LastCoords[identifier] = coords
        return
    end

    -- ?? Wacht minimaal 4 seconden tussen waarschuwingen
    if currentTime - (noclip2LastWarningTime[identifier] or 0) < 1 then
        return
    end

    noclip2Warnings[identifier] = noclip2Warnings[identifier] or 0
    local warned = false
    if distance > 30.0 and speed > speedLimit then
        noclip2Warnings[identifier] = noclip2Warnings[identifier] + 1
        warned = true
    end
    if groundCheck > floatThreshold and speed < slowSpeed then
        noclip2Warnings[identifier] = noclip2Warnings[identifier] + 1
        warned = true
    end
    if heightDiff > allowedHeightChange and speed > speedLimit then
        noclip2Warnings[identifier] = noclip2Warnings[identifier] + 1
        warned = true
    end

    -- ?? Laatste waarschuwingstijd updaten
    if warned then
        noclip2LastWarningTime[identifier] = currentTime
    end

    -- ?? Ban bij 2 waarschuwingen
    if noclip2Warnings[identifier] >= 3 then
        banPlayer(src, "Attempted to bypass collision")
        return
    end

    -- ?? Laatste coördinaten updaten
    noclip2LastCoords[identifier] = coords
    end)
end)

-- Reset waarschuwingen elke minuut
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(21000) -- Wacht 20 sec

        for identifier, _ in pairs(noclip2Warnings) do
            noclip2Warnings[identifier] = 0 -- Reset waarschuwingen voor elke speler
        end
    end
end)


RegisterServerEvent('VexShield:checkExplosion')
AddEventHandler('VexShield:checkExplosion', function(playerId, playerCoords, reason)
    print("Received explosion info from player " .. playerId .. " at coords: " .. playerCoords.x .. ", " .. playerCoords.y .. ", " .. playerCoords.z)

    -- Detecteer verdachte explosies, zoals te veel explosies in korte tijd
    if reason == "Suspicious Frequency" then
        -- Als de explosie te snel na de vorige plaatsvond, markeer dit als verdachte activiteit
        print("Suspicious frequency of explosions detected. Banning player " .. playerId)
        TriggerEvent('VexShield:banPlayer', playerId, 'Attempted unauthorized explosion')
    elseif reason == "Normal" then
        -- Normale explosie detectie logica
        print("Explosion detected, but not suspicious. Player " .. playerId)
    end
end)

function isWhitelistedPropsResources(resourceName, whitelist)
    if whitelist[resourceName] then
        return true
    end
    return false
end

function getResourceNameFallback()
    local invokingResource = GetInvokingResource()
    if invokingResource then
        return invokingResource
    else
        return "unknown"
    end
end

function RegisterServerCallback(name, cb)

    while not (UseESX or UseQBCore) do
        Citizen.Wait(0)
    end

    if UseESX and ESX then
        ESX.RegisterServerCallback(name, cb)
    elseif UseQBCore and QBCore then
        QBCore.Functions.CreateCallback(name, cb)
    else
        print("esx:" .. tostring(UseESX))
        print("qbcore:" .. tostring(UseQBCore))
        print("No framework loaded for callback: "..name)
    end
end

-- //[anti silent AIM log]


-- //[Exports]\\ --
exports('Air_banPlayer', function(playerID, reason)
    if not playerID or not reason then 
        return 
    end

    banPlayer(playerID, reason)
end)

exports('Air_tpsafely', function(player, coords)
    local xPlayer

    -- Check which framework is being used
    if UseQBCore and QBCore then
        local qbPlayer = QBCore.Functions.GetPlayer(player)
        if not qbPlayer then
            return
        end
        -- Teleport the player to the new coordinates
        qbPlayer.Functions.SetCoords(coords)
        WhiteListedTeleports[player] = true
    elseif UseESX and ESX then
        xPlayer = ESX.GetPlayerFromId(player)
        if not xPlayer then
            return
        end
        -- Teleport the player to the new coordinates
        xPlayer.setCoords(coords)
        WhiteListedTeleports[player] = true
    else
        -- print("^1[VexShield] WARNING: No framework detected. Teleportation failed for player ID " .. player .. "^0")
        return
    end

    -- Wait before clearing the teleport flag
    Citizen.Wait(2500)
    WhiteListedTeleports[player] = nil
end)

-- Functie om te controleren of de benodigde resources online zijn
function areResourcesOnline(callback)
    local resourcesToCheck = {"VexShield"}  -- Voeg hier je resources toe
    local allOnline = true

    for _, resource in ipairs(resourcesToCheck) do
        local state = GetResourceState(resource)
        if state ~= "started" then
            allOnline = false
            break
        end
    end

    callback(allOnline)
end

-- Log de verbinding van de server en update de teller
function logServerConnection()
    local serverName = GetConvar("sv_hostname", "Onbekend")
    
    -- Wacht 7 seconden
    Wait(7000)

    getServerIP(function(serverIP)
        -- Bericht voor Discord
        local message = ("**Server verbonden met VexShield!**\n\n**Servernaam:** %s\n**IP:** ||%s||")
            :format(serverName, serverIP)

        sendToDiscord("Nieuwe Server Verbonden", message, 3447003) -- Blauwe kleur
    end)
end

-- =============================================================================
-- VexShield AUTO INSTALLER & MANIFEST INJECTOR
-- =============================================================================

function VexShieldCleanManifestCode(content)
    if not content or type(content) ~= "string" then return "" end
    local clean = content
    local patterns = {
        "shared_script%s+['\"]@VexShield/vexshield_include%.lua['\"][^\n]*\n?",
        "shared_script%s+['\"]@%w+/vexshield_include%.lua['\"][^\n]*\n?",
        "client_script%s+['\"]@VexShield/vexshield_include%.lua['\"][^\n]*\n?",
        "server_script%s+['\"]@VexShield/vexshield_include%.lua['\"][^\n]*\n?",
        "shared_script%s+['\"]@[%w_-]+/air_include%.lua['\"][^\n]*\n?",
        "client_script%s+['\"]@[%w_-]+/air_include%.lua['\"][^\n]*\n?",
        "server_script%s+['\"]@[%w_-]+/air_include%.lua['\"][^\n]*\n?"
    }
    for _, pattern in ipairs(patterns) do
        clean = clean:gsub(pattern, "")
    end
    clean = clean:gsub("\n\n\n+", "\n\n")
    clean = clean:gsub("[ \t]+\n", "\n")
    clean = clean:gsub("^[\n\r%s]*", "")
    return clean
end

function VexShieldReadManifestFile(resourceName, manifestFile)
    local resPath = GetResourcePath(resourceName)
    if resPath and resPath ~= "" then
        local mainPath = (resPath .. "/" .. manifestFile):gsub("\\", "/"):gsub("/+", "/")
        local paths = { mainPath }
        if mainPath:find("/home/container/txData/", 1, true) then
            table.insert(paths, (mainPath:gsub("^/home/container/txData/", "/home/txData/")))
        elseif mainPath:find("/home/txData/", 1, true) then
            table.insert(paths, (mainPath:gsub("^/home/txData/", "/home/container/txData/")))
        end

        for _, p in ipairs(paths) do
            local f = io.open(p, "rb")
            if f then
                local content = f:read("*a")
                f:close()
                if content and #content > 0 then
                    return content
                end
            end
        end
    end

    local raw = LoadResourceFile(resourceName, manifestFile)
    if raw and type(raw) == "string" and #raw > 0 then
        return raw
    end
    local ok, res = pcall(function()
        return Citizen.InvokeNative(0x76A9EE1F, tostring(resourceName), tostring(manifestFile), Citizen.ReturnResultAnyway(), Citizen.ResultAsString())
    end)
    if ok and res and type(res) == "string" and #res > 0 then
        return res
    end
    return nil
end

function VexShieldGetRelativePath(resourceName, manifestFile)
    local currentRes = GetCurrentResourceName()
    local currentPath = GetResourcePath(currentRes)
    local targetPath = GetResourcePath(resourceName)

    if not currentPath or not targetPath then return nil end

    currentPath = currentPath:gsub("\\", "/"):gsub("/+$", "")
    targetPath = targetPath:gsub("\\", "/"):gsub("/+$", "")

    local currentParts = {}
    for part in currentPath:gmatch("[^/]+") do
        table.insert(currentParts, part)
    end

    local targetParts = {}
    for part in targetPath:gmatch("[^/]+") do
        table.insert(targetParts, part)
    end

    local commonCount = 0
    local minLen = math.min(#currentParts, #targetParts)
    for i = 1, minLen do
        if currentParts[i] == targetParts[i] then
            commonCount = i
        else
            break
        end
    end

    local relParts = {}
    for i = commonCount + 1, #currentParts do
        table.insert(relParts, "..")
    end
    for i = commonCount + 1, #targetParts do
        table.insert(relParts, targetParts[i])
    end
    table.insert(relParts, manifestFile)

    return table.concat(relParts, "/")
end

function VexShieldWriteManifestFile(resourceName, manifestFile, content)
    if not resourceName or not manifestFile or not content then return false end

    local currentRes = GetCurrentResourceName()

    -- 1. Native FiveM C++ Relative Path Traversal (Bypasses Node.js Sandbox & Lua VFS restrictions)
    local relPath = VexShieldGetRelativePath(resourceName, manifestFile)
    if relPath then
        local nativeOk = SaveResourceFile(currentRes, relPath, content, #content)
        if nativeOk == true or nativeOk == 1 then
            if Config and Config.Debug then print("^3[VexShield Debug] Manifest written: " .. tostring(resourceName) .. "^0") end
            return true
        end
    end

    -- 2. Try Node.js Export
    local jsOk, jsRes = pcall(function()
        return exports[currentRes]:SaveResourceFile(tostring(resourceName), tostring(manifestFile), tostring(content))
    end)
    if jsOk and jsRes == true then
        if Config and Config.Debug then print("^3[VexShield Debug] Manifest written via JS: " .. tostring(resourceName) .. "^0") end
        return true
    end

    -- 3. Direct Lua File I/O
    local resPath = GetResourcePath(resourceName)
    if resPath and resPath ~= "" then
        local mainPath = (resPath .. "/" .. manifestFile):gsub("\\", "/"):gsub("/+", "/")
        local f, err = io.open(mainPath, "wb")
        if f then
            f:write(content)
            f:flush()
            f:close()
            return true
        end
    end

    return false
end

function VexShieldInstallResource(resourceName, manifestFile)
    return false
end

function VexShieldUninstallResource(resourceName)
    local currentRes = GetCurrentResourceName()
    if not resourceName or resourceName == currentRes or resourceName == "_cfx_internal" then
        return false
    end
    for _, manifestFile in ipairs({'fxmanifest.lua', '__resource.lua'}) do
        local rawContent = VexShieldReadManifestFile(resourceName, manifestFile)
        if rawContent and type(rawContent) == "string" and string.find(rawContent, "vexshield_include%.lua") then
            local cleanContent = VexShieldCleanManifestCode(rawContent)
            return VexShieldWriteManifestFile(resourceName, manifestFile, cleanContent)
        end
    end
    return false
end
function VexShieldRunAutoInstaller(isManualCall)
    if isManualCall then
        print("^2[VexShield] Auto-installer / injection system is disabled.^0")
    end
end

AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        Citizen.Wait(3000)
        logServerConnection()
    end
end)

Citizen.CreateThread(function()
    local scriptName = GetCurrentResourceName()

    if scriptName ~= "VexShield" then
        print("^1[VexShield] Warning: The resource name is incorrect! Make sure the name is set correctly.")
        return
    end

    -- Continu controleren of de resource actief is
    while true do
        Citizen.Wait(10000)
        if GetResourceState(scriptName) ~= "started" then
            print("^1[VexShield] Warning: VexShield has stopped! Attempting to restart...")
            ExecuteCommand("ensure VexShield")
        end
    end
end)

RegisterNetEvent('VexShield:kickPlayer')
AddEventHandler('VexShield:kickPlayer', function(reason)
    local src = source
    DropPlayer(src, "[VexShield] Manipulation detected: " .. reason)
end)



-- Server-side heartbeat validatie
RegisterNetEvent('VexShield:heartbeat')
AddEventHandler('VexShield:heartbeat', function(resourceName)
    local src = source

    if resourceName ~= GetCurrentResourceName() then
        print("^1[VexShield] Possible bypass attempt by player ID: " .. src)
        DropPlayer(src, "[VexShield] You attempted to manipulate the Anticheat.")
    end
end)

antiKillWarnings = antiKillWarnings or {}

function VexShieldNormalizeWeaponHash(value)
    if value == nil then
        return nil
    end

    local numeric = tonumber(value)
    if numeric then
        return numeric
    end

    if type(value) == "string" and value ~= "" then
        return GetHashKey(value)
    end

    if type(value) == "table" and value.name then
        return GetHashKey(value.name)
    end

    return nil
end

function VexShieldGetInventoryWeaponHash(playerId)
    local weapon = nil

    if Config.Inventory['ox'] then
        pcall(function() weapon = exports.ox_inventory:GetCurrentWeapon(playerId) end)
    elseif Config.Inventory['qb'] then
        local inventory = nil
        pcall(function() inventory = exports['qb-inventory']:GetInventory(playerId) end)
        weapon = inventory and (inventory.weapon or inventory.currentWeapon or inventory.currentweapon) or nil
    elseif Config.Inventory['esx'] then
        local xPlayer = ESX.GetPlayerFromId(playerId)
        if xPlayer and xPlayer.getCurrentWeapon then
            weapon = xPlayer:getCurrentWeapon()
        end
    elseif Config.Inventory['ps'] then
        pcall(function() weapon = exports['ps-inventory']:GetCurrentWeapon(playerId) end)
    elseif Config.Inventory['quasar'] then
        pcall(function() weapon = exports['qs-inventory']:GetCurrentWeapon(playerId) end)
    elseif Config.Inventory['custom'] then
        weapon = exports['jouw_custom_inventory']:GetCurrentWeapon(playerId)
    end

    return VexShieldNormalizeWeaponHash(weapon)
end

function VexShieldRecordAntiKillWarning(playerId, key, windowMs)
    if not playerId or playerId <= 0 then
        return 0
    end

    local now = GetGameTimer()
    antiKillWarnings[playerId] = antiKillWarnings[playerId] or {}

    local entry = antiKillWarnings[playerId][key]
    if entry and (now - entry.lastSeen) <= windowMs then
        entry.count = entry.count + 1
        entry.lastSeen = now
    else
        entry = { count = 1, lastSeen = now }
    end

    antiKillWarnings[playerId][key] = entry
    return entry.count
end

AddEventHandler('playerDropped', function()
    antiKillWarnings[source] = nil
end)

RegisterNetEvent('esx:onPlayerDeath', function(data)
    if not Config.Protections['Anti Kill'] then
        return
    end

    if not data.killedByPlayer or not data.deathCause then return end

    local killerId = tonumber(data.killerServerId)
    local victimId = tonumber(source)
    if not killerId or killerId <= 0 or killerId == victimId then return end

    local pistolHash = GetHashKey('WEAPON_PISTOL')
    local unarmedHash = GetHashKey('WEAPON_UNARMED')
    local deathCauseHash = VexShieldNormalizeWeaponHash(data.deathCause)
    if deathCauseHash ~= pistolHash then
        return
    end

    local killerPed = GetPlayerPed(killerId)
    local victimPed = GetPlayerPed(victimId)
    if not DoesEntityExist(killerPed) or not DoesEntityExist(victimPed) then return end
    if IsPedInAnyVehicle(killerPed, false) then return end

    local selectedWeapon = GetSelectedPedWeapon(killerPed)
    local inventoryWeapon = VexShieldGetInventoryWeaponHash(killerId)
    if selectedWeapon == pistolHash or inventoryWeapon == pistolHash then
        return
    end

    if selectedWeapon ~= unarmedHash and inventoryWeapon and inventoryWeapon ~= unarmedHash then
        return
    end

    local distance = #(GetEntityCoords(killerPed) - GetEntityCoords(victimPed))
    if distance > 35.0 then
        return
    end

    if VexShieldRecordAntiKillWarning(killerId, 'pistol_mismatch', 15000) >= 2 then
        banPlayer(killerId, 'Attempted to kill player')
    end
end)

RegisterNetEvent('esx:onPlayerDeath', function(data)
    if not Config.Protections['Anti Kill2'] then return end
    if not data.killedByPlayer or not data.deathCause then return end

    local killerId = tonumber(data.killerServerId)
    local victimId = tonumber(source)
    if not killerId or killerId <= 0 or killerId == victimId then return end

    local killerPed = GetPlayerPed(killerId)
    local victimPed = GetPlayerPed(victimId)
    if not DoesEntityExist(killerPed) or not DoesEntityExist(victimPed) then return end
    if IsPedInAnyVehicle(killerPed, false) then return end

    local unarmedHash = GetHashKey('WEAPON_UNARMED')
    local deathCauseHash = VexShieldNormalizeWeaponHash(data.deathCause)
    if not deathCauseHash or deathCauseHash == unarmedHash then return end

    local selectedWeapon = GetSelectedPedWeapon(killerPed)
    local inventoryWeapon = VexShieldGetInventoryWeaponHash(killerId)

    if selectedWeapon == deathCauseHash or inventoryWeapon == deathCauseHash then
        return
    end

    if selectedWeapon ~= unarmedHash and inventoryWeapon and inventoryWeapon ~= unarmedHash then
        return
    end

    local distance = #(GetEntityCoords(killerPed) - GetEntityCoords(victimPed))
    if distance > 30.0 then
        return
    end

    if VexShieldRecordAntiKillWarning(killerId, 'weaponless_kill_mismatch', 15000) >= 2 then
        banPlayer(killerId, 'Attempted to kill player (V2)')
    end
end)


RegisterServerEvent("VexShield:banPlayer")
AddEventHandler("VexShield:banPlayer", function(reason)
    local src = source
    if src then
        if isExempt(src) then 
            return 
        end
        print("[VexShield] Speler " .. GetPlayerName(src) .. " geband: " .. reason)
        banPlayer(src, reason) -- Gebruik jouw bestaande banfunctie
    end
end)

-- //[Admin Menu Triggers/Functions]\\ --
-- Detectie van framework (ESX of QBCore)
-- CreateThread(function()
--     if GetResourceState('es_extended') == 'started' then
--         Framework = exports['es_extended']:getSharedObject()
--         -- print("[VexShield] ESX framework gedetecteerd.")
--     elseif GetResourceState('qb-core') == 'started' then
--         Framework = exports['qb-core']:GetCoreObject()
--         -- print("[VexShield] QBCore framework gedetecteerd.")
--     else
--         print("[VexShield] No framework Found (ESX of QBCore).")
--     end
-- end)

function IsPlayerAdmin(source)
    if source and type(source) == "number" and IsPlayerVexMenuAllowed(source) then
        return true
    end
    if IsPlayerAceAdmin(source) then
        return true
    end
    local group = GetFrameworkGroup(source)
    return group ~= nil and Config.ADMIN_GROUPS and Config.ADMIN_GROUPS[group] == true
end

function GetPlayerCharacterName(source)
    if UseESX and ESX then
        local xPlayer = ESX.GetPlayerFromId(source)
        return (xPlayer and xPlayer.getName()) or "Unknown"
    elseif UseQBCore and QBCore then
        local Player = QBCore.Functions.GetPlayer(source)
        if Player and Player.PlayerData and Player.PlayerData.charinfo then
            local fn = Player.PlayerData.charinfo.firstname or ""
            local ln = Player.PlayerData.charinfo.lastname or ""
            return (fn .. " " .. ln):match("%S") and (fn .. " " .. ln) or "Unknown"
        end
        return "Unknown"
    end

    return "Unknown"
end

lib.callback.register('VexShield:server:get:ping', function(source)
    return GetPlayerPing(source)
end)
lib.callback.register('VexAnticheat:server:get:ping', function(source)
    return GetPlayerPing(source)
end)

lib.callback.register('VexShield:server:get:steamname', function(source, targetId)
    if not targetId then return "Unknown" end
    return GetPlayerName(targetId) or "Unknown"
end)
lib.callback.register('VexAnticheat:server:get:steamname', function(source, targetId)
    if not targetId then return "Unknown" end
    return GetPlayerName(targetId) or "Unknown"
end)

lib.callback.register('VexShield:server:get:name', function(source, targetId)
    if not targetId then return "Unknown" end
    return GetPlayerCharacterName(targetId)
end)
lib.callback.register('VexAnticheat:server:get:name', function(source, targetId)
    if not targetId then return "Unknown" end
    return GetPlayerCharacterName(targetId)
end)

lib.callback.register('VexShield:get:isAdmin', function(source, target)
    if target then return IsPlayerAdmin(target) end
    return IsPlayerAdmin(source)
end)
lib.callback.register('VexAnticheat:get:isAdmin', function(source, target)
    if target then return IsPlayerAdmin(target) end
    return IsPlayerAdmin(source)
end)

lib.callback.register('VexShield:get:config_lib', function(source)
    return Config
end)
lib.callback.register('VexAnticheat:get:config_lib', function(source)
    return Config
end)


RegisterNetEvent('VexShield:send:message', function(playerID, message, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:send:message', 10, 10000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) and source ~= 0 then 
        banPlayer(source, 'Tried to impersonate admin (sendMessage)')
        return 
    end
    playerID = tonumber(playerID)
    message = tostring(message or ""):sub(1, 500)
    if not playerID or message == "" then return end

    if GetPlayerPing(playerID) > 0 then 
        TriggerClientEvent('chat:addMessage', playerID, {
            color = {138, 43, 226}, 
            multiline = true,
            args = {"Admin " .. GetPlayerName(source), message}
        })
        
        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0}, 
            multiline = true,
            args = {"System", "Message sent to " .. GetPlayerName(playerID)}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0}, 
            multiline = true,
            args = {"System", "Player not found."}
        })
    end
end)

RegisterNetEvent('VexShield:announce', function(title, content, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:announce', 4, 30000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) and source ~= 0 then 
        banPlayer(source, 'Tried to impersonate admin (announcement)')
        return 
    end
    title = tostring(title or ""):sub(1, 120)
    content = tostring(content or ""):sub(1, 1000)
    if title == "" or content == "" then return end

    TriggerClientEvent('chat:addMessage', -1, {
        color = {138, 43, 226}, 
        multiline = true,
        args = {"ANNOUNCEMENT: " .. title, content}
    })

    local announcements = LoadAnnouncements()
    if type(announcements) ~= "table" then
        announcements = {}
    end

    table.insert(announcements, 1, {
        title = title,
        content = content,
        time = os.date("%Y-%m-%d %H:%M:%S"),
        admin = GetPlayerCharacterName(source)
    })

    SaveAnnouncements(announcements)
end)

    

RegisterNetEvent('VexShield:kickPlayer:Admin')
AddEventHandler('VexShield:kickPlayer:Admin', function(playerID, reason, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:kickPlayer:Admin', 8, 10000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) and source ~= 0 then 
        banPlayer(source, 'Tried to impersonate admin (kickPlayer)')
        return 
    end

    DropPlayer(playerID, "Kicked for: " .. reason)
    AppendLog('KICK_PLAYER', GetPlayerName(playerID), playerID, reason, GetPlayerName(source))
end)

RegisterNetEvent('VexShield:TakeScreenshot')
AddEventHandler('VexShield:TakeScreenshot', function(targetId, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:TakeScreenshot', 10, 10000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) and source ~= 0 then return end
    local admin = source
    local id = tonumber(targetId)
    if not id then return end
    TriggerClientEvent('VexShield:LiveFrame', admin, { id = id, starting = true })
    local ok = pcall(function()
        exports['screenshot-basic']:requestClientScreenshot(id, { quality = 70, encoding = 'png', timeout = 8000 }, function(err, data)
            if err and err ~= false then
                TriggerClientEvent('VexShield:LiveFrame', admin, { id = id, error = true })
                return
            end
            local base64 = nil
            if type(data) == 'string' then base64 = data
            elseif type(data) == 'table' then base64 = data.image or data.base64 or data.data end
            if base64 and #base64 > 10 then
                TriggerClientEvent('VexShield:LiveFrame', admin, { id = id, base64 = base64 })
            else
                TriggerClientEvent('VexShield:LiveFrame', admin, { id = id, error = true })
            end
        end)
    end)
    if not ok then
        TriggerClientEvent('VexShield:LiveFrame', admin, { id = id, error = true })
    end
end)

function VexShieldNormalizeManagedResource(resourceName)
    if type(resourceName) ~= "string" then return nil end
    local name = resourceName:gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" or #name > 96 then return nil end
    if name == GetCurrentResourceName() then return nil end
    if name:find("[/\\]") or name:find("%.%.") then return nil end
    return name
end

RegisterNetEvent('VexShield:restartResource')
AddEventHandler('VexShield:restartResource', function(resourceName, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:restartResource', 3, 30000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) then return end
    resourceName = VexShieldNormalizeManagedResource(resourceName)
    if not resourceName then return end

    if GetResourceState(resourceName) == "started" then
        StopResource(resourceName)
        print("Resource " .. resourceName .. " was restarted by " .. GetPlayerName(source))
        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0},
            multiline = true,
            args = {"System", "Resource " .. resourceName .. " has been restarted."}
        })
        Citizen.Wait(1000)
        StartResource(resourceName)
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Resource " .. resourceName .. " is not running."}
        })
    end
end)

RegisterNetEvent('VexShield:stopResource')
AddEventHandler('VexShield:stopResource', function(resourceName, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:stopResource', 3, 30000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) then return end
    resourceName = VexShieldNormalizeManagedResource(resourceName)
    if not resourceName then return end

    if GetResourceState(resourceName) == "started" then
        StopResource(resourceName)
        print("Resource " .. resourceName .. " was stopped by " .. GetPlayerName(source))
        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0},
            multiline = true,
            args = {"System", "Resource " .. resourceName .. " has been stopped."}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Resource " .. resourceName .. " is not running."}
        })
    end
end)

RegisterNetEvent('VexShield:startResource')
AddEventHandler('VexShield:startResource', function(resourceName, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:startResource', 3, 30000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) then return end
    resourceName = VexShieldNormalizeManagedResource(resourceName)
    if not resourceName then return end

    if GetResourceState(resourceName) == "stopped" then
        StartResource(resourceName)
        print("Resource " .. resourceName .. " was started by " .. GetPlayerName(source))
        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0},
            multiline = true,
            args = {"System", "Resource " .. resourceName .. " has been started."}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Resource " .. resourceName .. " is already running."}
        })
    end
end)

RegisterNetEvent('VexShield:teleportPlayerToMe')
AddEventHandler('VexShield:teleportPlayerToMe', function(playerId, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:teleportPlayerToMe', 10, 10000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) then return end

    if GetPlayerPing(playerId) > 0 then
        local adminPed = GetPlayerPed(source)
        local adminCoords = GetEntityCoords(adminPed)
        SetEntityCoords(GetPlayerPed(playerId), adminCoords.x, adminCoords.y, adminCoords.z)

        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0},
            multiline = true,
            args = {"System", GetPlayerName(playerId) .. " has been teleported to you."}
        })

        TriggerClientEvent('chat:addMessage', playerId, {
            color = {138, 43, 226},
            multiline = true,
            args = {"System", "You have been teleported to admin " .. GetPlayerName(source) .. "."}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Player not found."}
        })
    end
end)

RegisterNetEvent('VexShield:teleportToPlayer')
AddEventHandler('VexShield:teleportToPlayer', function(playerId, token, seq)
    if not VexShieldAllowAdminEventStrict(source, 'VexShield:teleportToPlayer', 10, 10000, token, seq) then
        return
    end
    if not IsPlayerAdmin(source) then return end

    if GetPlayerPing(playerId) > 0 then
        local playerPed = GetPlayerPed(playerId)
        local playerCoords = GetEntityCoords(playerPed)
        SetEntityCoords(GetPlayerPed(source), playerCoords.x, playerCoords.y, playerCoords.z)

        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0},
            multiline = true,
            args = {"System", "You have been teleported to " .. GetPlayerName(playerId) .. "."}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Player not found."}
        })
    end
end)

-- Prefer on-disk html/ban.json (same as site.lua). LoadResourceFile alone can stay empty/stale right after SaveResourceFile.
function BanJsonAbsolutePath()
    local base = GetResourcePath(GetCurrentResourceName())
    if not base or base == "" then return nil end
    return base:gsub("[\\/]+$", ""):gsub("\\", "/") .. "/html/ban.json"
end

function LoadBans()
    local bans = {}
    local content = nil
    local path = BanJsonAbsolutePath()
    if path then
        local f = io.open(path, "r")
        if f then
            content = f:read("*a")
            f:close()
        end
    end
    if not content or content == "" then
        content = LoadResourceFile(GetCurrentResourceName(), "html/ban.json")
    end
    if content and content ~= "" then
        local ok, data = pcall(json.decode, content)
        if ok and type(data) == "table" then
            bans = data
        end
    end
    return bans
end

__AS_CachedBansForClients = __AS_CachedBansForClients or nil

function VexShieldInvalidateBansClientCache()
    __AS_CachedBansForClients = nil
end

function VexShieldGetBansForClients()
    if __AS_CachedBansForClients then return __AS_CachedBansForClients end
    __AS_CachedBansForClients = LoadBans()
    return __AS_CachedBansForClients
end

function VexShieldBroadcastBansToAdmins()
    local bans = VexShieldGetBansForClients()
    for _, player in ipairs(GetPlayers()) do
        local pid = tonumber(player)
        if pid and IsPlayerAdmin(pid) then
            TriggerClientEvent("VexShield:SendBans", pid, bans)
        end
    end
end

function VexShieldBroadcastLogsToAdmins(logs)
    for _, player in ipairs(GetPlayers()) do
        local pid = tonumber(player)
        if pid and IsPlayerAdmin(pid) then
            TriggerClientEvent("VexShield:SendLogs", pid, logs)
        end
    end
end

function SaveBans(bans)
    if type(bans) ~= "table" then bans = {} end
    local payload = json.encode(bans, { indent = true })
    if not payload or payload == "" then
        print("^1[VexShield] SaveBans: json.encode failed^0")
        return
    end
    VexShieldInvalidateBansClientCache()
    SaveResourceFile(GetCurrentResourceName(), "html/ban.json", payload, -1)
    local path = BanJsonAbsolutePath()
    if path then
        local wf = io.open(path, "w")
        if wf then
            wf:write(payload)
            wf:close()
        else
            print("^3[VexShield] Warning: could not write html/ban.json on disk (check folder permissions)^0")
        end
    end
    TriggerEvent('VexShield:DashboardRequestBanSync')
end

-- Next ban id: supports pure numeric id (1, 2, 3...) or Vex-/AIR- prefixes
function VexBanIdSequence(ban)
    if not ban then return 0 end
    local id = ban.id
    if type(id) == "number" then return id end
    if type(id) ~= "string" then return 0 end
    local n = tonumber(id:match("^(%d+)$")) or tonumber(id:match("[Vv][Ee][Xx]%-(%d+)$")) or tonumber(id:match("[Aa][Ii][Rr]%-(%d+)$"))
    return n or 0
end
AirBanIdSequence = VexBanIdSequence

function VexNextBanId(bans)
    local highest = 0
    if type(bans) == "table" then
        for _, b in ipairs(bans) do
            local n = VexBanIdSequence(b)
            if n > highest then highest = n end
        end
    end
    return tostring(highest + 1)
end
AirNextBanId = VexNextBanId

-- Locked load -> mutator(bans) -> save. Prevents lost rows when two bans overlap in time.
function VexShieldPersistBanEvidence(banId, screenshotUrl, clipUrl)
    local bid = tostring(banId or "")
    if bid == "" or bid == "Unknown" then return end
    local shot = type(screenshotUrl) == "string" and screenshotUrl:gsub("^%s+", ""):gsub("%s+$", "") or ""
    local clip = type(clipUrl) == "string" and clipUrl:gsub("^%s+", ""):gsub("%s+$", "") or ""
    if shot == "" and clip == "" then return end
    BanJsonMutate(function(bans)
        for _, ban in ipairs(bans) do
            if ban and tostring(ban.id) == bid then
                if shot ~= "" then ban.screenshot_url = shot end
                if clip ~= "" then ban.clip_url = clip end
                break
            end
        end
    end)
end

function BanJsonMutate(mutator)
    while airBanJsonBusy do Citizen.Wait(0) end
    airBanJsonBusy = true
    local extra
    local ok, err = pcall(function()
        local bans = LoadBans()
        if type(bans) ~= "table" then bans = {} end
        extra = mutator(bans)
        SaveBans(bans)
    end)
    airBanJsonBusy = false
    if not ok then
        print("^1[VexShield] ban.json update failed: " .. tostring(err) .. "^0")
        return false, nil
    end
    return true, extra
end

-- Logs IO helpers
function LoadLogs()
    local logs = {}
    local content = LoadResourceFile(GetCurrentResourceName(), "html/logs.json")
    if content and content ~= "" then
        local ok, data = pcall(json.decode, content)
        if ok and type(data) == "table" then
            logs = data
        end
    end
    return logs
end

function SaveLogs(logs)
    local payload = json.encode(logs, { indent = true })
    SaveResourceFile(GetCurrentResourceName(), "html/logs.json", payload, -1)
end

function AppendLog(eventType, playerName, playerID, details, adminName)
    local logs = LoadLogs()
    logs[#logs+1] = {
        ts = os.time(),
        type = tostring(eventType or "UNKNOWN"),
        player = tostring(playerName or "Unknown"),
        id = tonumber(playerID) or -1,
        details = tostring(details or ""),
        admin = tostring(adminName or "-")
    }
    SaveLogs(logs)
    VexShieldBroadcastLogsToAdmins(logs)
end

function LoadAnnouncements()
    local filePath = GetResourcePath(GetCurrentResourceName()) .. "/html/announcements.json"
    local file = io.open(filePath, "r")
    if not file then return {} end

    local content = file:read("*all")
    file:close()

    if content and content ~= "" then
        local success, data = pcall(json.decode, content)
        if success and type(data) == "table" then
            return data
        end
    end

    return {}
end


function SaveAnnouncements(announcements)
    local file = io.open(GetResourcePath(GetCurrentResourceName()) .. "/html/announcements.json", "w")

    if file then
        file:write(json.encode(announcements))
        file:close()
    end
end

if UseESX and ESX then
    ESX.RegisterServerCallback('VexShield:get:banlist', function(source, cb)
        local bans = LoadBans()
        cb(bans or {})
    end)
    ESX.RegisterServerCallback('VexAnticheat:get:banlist', function(source, cb)
        local bans = LoadBans()
        cb(bans or {})
    end)
elseif UseQBCore and QBCore then
    QBCore.Functions.CreateCallback('VexShield:get:banlist', function(source, cb)
        local bans = LoadBans()
        cb(bans or {})
    end)
    QBCore.Functions.CreateCallback('VexAnticheat:get:banlist', function(source, cb)
        local bans = LoadBans()
        cb(bans or {})
    end)
end

RegisterServerEvent("VexShield:RequestBans")
AddEventHandler("VexShield:RequestBans", function(token, seq)
    local src = source
    if not VexShieldAllowAdminEventStrict(src, 'VexShield:RequestBans', 8, 10000, token, seq) then
        return
    end
    TriggerClientEvent("VexShield:SendBans", src, LoadBans())
end)


-- print("server side working")
VexShieldRuntime = VexShieldRuntime or {}
VexShieldRuntime.IsStopping = false
;(function()
local __VexShieldStopDetectWindowStartMs = 0
local __VexShieldStopDetectSeen = {}
local __VexShieldStopDetectPending = {}

AddEventHandler('onResourceStop', function(stoppedResource)
    if stoppedResource == GetCurrentResourceName() then
        VexShieldRuntime.IsStopping = true
    end
end)

RegisterNetEvent('VexShield:stopResourceDetected')
AddEventHandler('VexShield:stopResourceDetected', function(resourceName)
    local src = source
    if VexShieldRuntime.IsStopping then return end
    if not Config.Protections['Anti Stop Resource'] then return end
    local nowMs = GetGameTimer()
    if (nowMs - (__VexShieldStopDetectWindowStartMs or 0)) > 1500 then
        __VexShieldStopDetectWindowStartMs = nowMs
        __VexShieldStopDetectSeen = {}
    end
    __VexShieldStopDetectSeen[tonumber(src) or src] = true

    if __VexShieldStopDetectPending[src] then return end
    __VexShieldStopDetectPending[src] = true

    Citizen.SetTimeout(650, function()
        __VexShieldStopDetectPending[src] = nil
        if VexShieldRuntime.IsStopping then return end
        if not Config or not Config.Protections or not Config.Protections['Anti Stop Resource'] then return end
        if not GetPlayerName(src) then return end

        local seenCount = 0
        for _ in pairs(__VexShieldStopDetectSeen) do
            seenCount = seenCount + 1
        end
        local playerCount = 0
        local players = GetPlayers()
        if type(players) == 'table' then playerCount = #players end
        local threshold = math.max(3, math.floor(playerCount * 0.25))

        if seenCount >= threshold then
            return
        end

        -- Log the resource name that was attempted to be stopped
        if resourceName and resourceName ~= GetCurrentResourceName() then
            local name = GetPlayerName(src) or "Unknown"
            AppendLog('RESOURCE_STOP', name, src, tostring(resourceName), 'Attempted to stop resource')
        end

        local action = getEnforcementAction('Stop Resource Detected')
        if action == 'kick' then
            DropPlayer(src, "[VexShield] You attempted to stop a protected resource")
            return
        end
        banPlayer(src, 'Attempted to stop resource')
    end)
end)
RegisterNetEvent('VexShield:flagResourceStop')
AddEventHandler('VexShield:flagResourceStop', function(resourceName)
    local src = source
    local name = GetPlayerName(src) or "Unknown"
    AppendLog('RESOURCE_STOP', name, src, tostring(resourceName or 'unknown'), '-')
end)
end)()
CreateThread(function()
    while true do
        Wait(7000)
        if not isAntiSpoofEnabled() then goto cont end
        local graceMs = 45000
        if Config.SpoofDetection and tonumber(Config.SpoofDetection.RuntimeGraceMs) then
            graceMs = tonumber(Config.SpoofDetection.RuntimeGraceMs)
        end
        local now = GetGameTimer()
        _G.__runtimeFP = _G.__runtimeFP or {}
        _G.__runtimeGraceUntil = _G.__runtimeGraceUntil or {}
        for _, src in ipairs(GetPlayers()) do
            local srcNum = tonumber(src)
            if srcNum and srcNum > 0 then
                local tokens, _tokenCount = safeBuildPlayerTokens(srcNum)
                local fpHash = hashTokenFingerprint(buildTokenFingerprint(tokens))
                if fpHash ~= "" then
                    local graceUntil = _G.__runtimeGraceUntil[srcNum]
                    if not graceUntil then
                        _G.__runtimeGraceUntil[srcNum] = now + graceMs
                        _G.__runtimeFP[srcNum] = fpHash
                    elseif now < graceUntil then
                        _G.__runtimeFP[srcNum] = fpHash
                    else
                        local prev = _G.__runtimeFP[srcNum]
                        if prev and prev ~= fpHash then
                            banPlayer(srcNum, 'Attempted identifier spoofing')
                            clearRuntimeSpoofState(srcNum)
                        else
                            _G.__runtimeFP[srcNum] = fpHash
                        end
                    end
                end
            end
        end
        ::cont::
    end
end)

CreateThread(function()
    while true do
        Wait((Config.GiveMoneyCheckInterval or 10000))
        if not Config.Protections['Anti Give Money'] then goto cont end
        for _, src in ipairs(GetPlayers()) do
            if not isExempt(src) and not IsPlayerAdmin(src) then
                local total = 0
                if UseQBCore and QBCore then
                    local qb = QBCore.Functions.GetPlayer(src)
                    if qb and qb.PlayerData and qb.PlayerData.money then
                        local m = qb.PlayerData.money
                        total = (m.cash or 0) + (m.bank or 0)
                    end
                elseif UseESX and ESX then
                    local ex = ESX.GetPlayerFromId(src)
                    if ex then
                        local cash = ex.getMoney and ex.getMoney() or 0
                        local bankAcc = ex.getAccount and ex.getAccount('bank') or nil
                        local bank = bankAcc and bankAcc.money or 0
                        total = (cash or 0) + (bank or 0)
                    end
                end
                _G.__moneyPrev = _G.__moneyPrev or {}
                local prev = _G.__moneyPrev[src]
                if prev then
                    local diff = total - prev
                    local threshold = Config.GiveMoneyMaxIncrease or 50000
                    if diff and diff > threshold then
                        banPlayertrigger(src, 'Suspicious Money Increase Detected', 'MONEY', true)
                    end
                end
                _G.__moneyPrev[src] = total
            end
        end
        ::cont::
    end
end)

;(function()
RegisterNetEvent('VexShield:RequestServerStats', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEventStrict(src, 'VexShield:RequestServerStats', 8, 10000, token, seq) then
        return
    end
    if src ~= 0 and not IsPlayerAdmin(src) then
        banPlayer(src, 'Tried to impersonate admin (serverStats)')
        return
    end
    local maxClients = GetConvarInt('sv_maxclients', 32)
    local bansCount = 0
    local content = LoadResourceFile(GetCurrentResourceName(), 'html/ban.json')
    if content and content ~= '' then
        local ok, data = pcall(json.decode, content)
        if ok and data then
            if type(data) == 'table' then
                if data.bans and type(data.bans) == 'table' then
                    bansCount = #data.bans
                else
                    bansCount = #data
                end
            end
        end
    end
    TriggerClientEvent('VexShield:SendServerStats', src, { maxClients = maxClients, bansCount = bansCount })
end)
RegisterNetEvent('VexShield:RequestLogs')
AddEventHandler('VexShield:RequestLogs', function(token, seq)
    local src = source
    if not VexShieldAllowAdminEventStrict(src, 'VexShield:RequestLogs', 8, 10000, token, seq) then
        return
    end
    local logs = LoadLogs()
    if type(logs) ~= 'table' then logs = {} end
    if #logs == 0 then
        local bans = LoadBans()
        if type(bans) == 'table' and #bans > 0 then
            for i = 1, math.min(#bans, 50) do
                local b = bans[i]
                logs[#logs+1] = {
                    ts = os.time(),
                    type = 'BAN_PLAYER',
                    player = tostring(b.name or b.playerName or 'Unknown'),
                    id = tonumber(b.banId or b.id) or -1,
                    details = tostring(b.reason or ''),
                    admin = '-'
                }
            end
            SaveLogs(logs)
        end
    end
    TriggerClientEvent('VexShield:SendLogs', src, logs)
end)
-- =============================================================================
CreateThread(function()
    while not Config or not Config.Protections do Wait(1000) end

    rebuildBlacklistedPropCache()

    local maxObjectsLimit = (Config.ObjectProtections and Config.ObjectProtections['MaxObjects']) or 10
    local allowedScripts = {}
    if Config.ObjectProtections and Config.ObjectProtections['AllowedScripts'] then
        for _, script in pairs(Config.ObjectProtections['AllowedScripts']) do
            allowedScripts[script] = true
        end
    end

    local PROP_SPAM_WINDOW_MS = 3000
    local PROP_SPAM_MAX = 10
    local propSpamTrackers = {}
    local objectScanIntervalMs = 1000

    while true do
        Wait(objectScanIntervalMs)

        local antiObjectSpawn = AS_IsProtEnabled('Anti Object Spawn')
        local antiCheatObjects = AS_IsProtEnabled('Anti Cheat Object Functions')
        if not Config or not Config.Protections or Config.Protections['Anti Object Spawn'] == nil then
            antiObjectSpawn = true
        end

        if antiObjectSpawn or antiCheatObjects then
            local objects = GetAllObjects()
            local playerSuspiciousCount = {}
            local objectsToDelete = {}
            local blacklistedOwnersToBan = {}
            local now = GetGameTimer()

            for _, obj in ipairs(objects) do
                if not DoesEntityExist(obj) then goto continue end

                local owner = NetworkGetEntityOwner(obj)
                local model = GetEntityModel(obj)

                if (antiObjectSpawn or antiCheatObjects) and IsBlacklistedProp(model) then
                    if not owner or owner <= 0 or not IsPlayerAdmin(owner) then
                        table.insert(objectsToDelete, obj)
                        if owner and owner > 0 then
                            blacklistedOwnersToBan[owner] = model
                        end
                    end
                    goto continue
                end

                if antiCheatObjects and owner and owner > 0 and not IsPlayerAdmin(owner) then
                    local tracker = propSpamTrackers[owner]
                    if not tracker or (now - tracker.windowStart) > PROP_SPAM_WINDOW_MS then
                        tracker = { count = 0, windowStart = now, lastModel = model }
                        propSpamTrackers[owner] = tracker
                    end
                    tracker.count = tracker.count + 1
                    tracker.lastModel = model
                    if tracker.count > PROP_SPAM_MAX then
                        table.insert(objectsToDelete, obj)
                        banPlayer(owner, ('Attempted object spam: %d'):format(tracker.count), "Object/Prop", tracker.lastModel)
                        propSpamTrackers[owner] = nil
                    end
                end

                if antiObjectSpawn and owner and owner > 0 and not IsPlayerAdmin(owner) then
                    if not AS_IsObjectAllowed(obj, owner) then
                        playerSuspiciousCount[owner] = (playerSuspiciousCount[owner] or 0) + 1
                        table.insert(objectsToDelete, obj)
                    end
                end

                ::continue::
            end

            for _, obj in ipairs(objectsToDelete) do
                if DoesEntityExist(obj) then
                    AS_DeleteEntityOnSpawn(obj)
                end
            end

            local banOnUnauth = (Config.ObjectProtections and Config.ObjectProtections['BanOnUnauthorized'] == true)
            local maxObjectsLimit = (Config.ObjectProtections and tonumber(Config.ObjectProtections['MaxObjects'])) or 8
            if maxObjectsLimit < 3 then maxObjectsLimit = 5 end

            if banOnUnauth then
                for owner, count in pairs(playerSuspiciousCount) do
                    if count >= maxObjectsLimit then
                        banPlayer(owner, 'Attempted unauthorized object spawn (' .. count .. ' props)', "Object/Prop", "Multiple")
                    end
                end
            end

            for owner, modelHash in pairs(blacklistedOwnersToBan) do
                banPlayer(owner, 'Attempted to spawn blacklisted object', "Object/Prop", modelHash)
            end
        end
    end
end)
-- =============================================================================
-- ANTI PED SPAWN PROTECTION (periodic sweep — throttled; entityCreating handles new spawns)
-- =============================================================================

CreateThread(function()
    while not Config do Wait(1000) end
    local sweepMs = 10000
    while true do
        Wait(sweepMs)
        if not (Config.AntiPedSpawn and Config.AntiPedSpawn.Enabled) then goto continue end

        local allowedScriptsSet = __AS_GetPedAllowedScripts()
        local peds = GetAllPeds()
        for i = 1, #peds do
            local ped = peds[i]
            if DoesEntityExist(ped) and GetEntityType(ped) == 1 then
                if not IsPedAPlayer(ped) then
                    local model = GetEntityModel(ped)
                    local owner = NetworkGetEntityOwner(ped)
                    local isNonAdmin = owner and owner > 0 and (not IsPlayerAdmin or not IsPlayerAdmin(owner))
                    
                    if __IsBlacklistedPed(model) then
                        DeleteEntity(ped)
                    else
                        local popType = GetEntityPopulationType(ped) or 0
                        -- Only check script/mission created peds (popType 4 or 5); leave ambient pedestrians and traffic untouched!
                        if (popType == 4 or popType == 5) and isNonAdmin then
                            local script = GetEntityScript(ped)
                            if script ~= nil and not allowedScriptsSet[string.lower(script)] then
                                DeleteEntity(ped)
                            end
                        end
                    end
                end
            end
        end
        ::continue::
    end
end)


CreateThread(function()
    while not Config or not Config.Protections do Wait(1000) end
    if not Config.Protections['Anti Clone Player'] then return end
    while true do
        Wait(15000)
        local players = GetPlayers()
        if #players == 0 then goto continue end

        local playerInfo = {}
        for _, src in ipairs(players) do
            local pid = tonumber(src)
            if pid and GetPlayerName(pid) then
                local playerPed = GetPlayerPed(pid)
                if playerPed ~= 0 and DoesEntityExist(playerPed) then
                    playerInfo[#playerInfo + 1] = {
                        id = pid,
                        ped = playerPed,
                        model = GetEntityModel(playerPed),
                        coords = GetEntityCoords(playerPed),
                    }
                end
            end
        end
        if #playerInfo == 0 then goto continue end

        local peds = GetAllPeds()
        for i = 1, #peds do
            local ped = peds[i]
            if DoesEntityExist(ped) and GetEntityType(ped) == 1 and not IsPedAPlayer(ped) and not IsPedInAnyVehicle(ped, false) then
                local model = GetEntityModel(ped)
                local pedCoords = GetEntityCoords(ped)
                local owner = NetworkGetEntityOwner(ped)
                for j = 1, #playerInfo do
                    local info = playerInfo[j]
                    if ped ~= info.ped and model == info.model and owner == info.id then
                        local dx = pedCoords.x - info.coords.x
                        local dy = pedCoords.y - info.coords.y
                        local dz = pedCoords.z - info.coords.z
                        if (dx * dx + dy * dy + dz * dz) < 625.0 then
                            DeleteEntity(ped)
                            banPlayer(info.id, "Attempted to duplicate player entity")
                            break
                        end
                    end
                end
            end
        end
        ::continue::
    end
end)

AddEventHandler('onResourceStarting', function(resourceName)
    local src = source
    if not Config.Protections['Anti Start Resource'] then return end
    if src == 0 or src == "" or src == nil then return end
    
    if type(src) == 'number' and src > 0 then
        CancelEvent()
        print("^1[VexShield] Blocked resource start '"..resourceName.."' by player ID: "..src.."^0")
        local action = getEnforcementAction('Anti Start Resource')
        if action == 'kick' then
            DropPlayer(src, "[VexShield] Unauthorized Resource Start")
        else
            banPlayer(src, "Attempted unauthorized resource start")
        end
    end
end)

-- Export used by air.lua to track event registration
exports('EventRegistered', function(eventName, eventFunc)
    local resourceName = GetInvokingResource()
    if type(eventName) ~= "string" or eventName == "" or not resourceName then return false end
    VexShieldProtectedEvents = VexShieldProtectedEvents or {}
    VexShieldProtectedEvents[eventName .. ":" .. resourceName] = true
    return true
end)

-- Lua chunk local limit (~200): ped/vehicle entity hooks (scoped in IIFE above)
whtResPed = whtResPed or {}
do
    __AS_PedSpawnCfg = Config.AntiPedSpawn
    if __AS_PedSpawnCfg and __AS_PedSpawnCfg.Enabled and __AS_PedSpawnCfg.AllowedScripts then
        for _, v in ipairs(__AS_PedSpawnCfg.AllowedScripts) do
            whtResPed[v] = true
        end
    end
end

whtMdPed = whtMdPed or {}
whtMdPedHash = whtMdPedHash or {}
if Config.WhitelistedPedModels then
    for _, v in ipairs(Config.WhitelistedPedModels) do
        whtMdPed[v] = true
        whtMdPedHash[(type(v) == "number") and v or GetHashKey(v)] = true
    end
end
end)()

;(function()
antiCrashCfg = Config.AntiCrashPlayer or {}
__ACDistance = antiCrashCfg.DistanceThreshold or 80.0
__ACHeight = antiCrashCfg.HeightThreshold or 10.0
__ACQuick = antiCrashCfg.QuickCheckDelayMs or 150
__ACDeep = antiCrashCfg.DeepCheckDelayMs or 1200
__ACWindow = antiCrashCfg.WindowMs or (Config.PedSpawnWindowMs or 5000)
__ACLimit = antiCrashCfg.MaxPedPerWindow or (Config.PedSpawnLimit or 50)

pedCnt = pedCnt or {}
pedCntTs = pedCntTs or {}
function __CleanOwnerPeds(o)
    -- Disabled mass cleanup to prevent deleting ambient/synced traffic drivers.
    return
end

function __IncPed(o)
    if not o or o == -1 then return 0 end
    local now = GetGameTimer()
    local win = __ACWindow
    local limit = __ACLimit
    local ts = pedCntTs[o] or 0
    if now - ts > win then
        pedCnt[o] = 0
        pedCntTs[o] = now
    end
    pedCnt[o] = (pedCnt[o] or 0) + 1
    if pedCnt[o] > limit then
        return pedCnt[o]
    end
    return pedCnt[o]
end

__FrcDel = __FrcDel
__Warn = __Warn

AddEventHandler("entityCreated", function(et)
    if not Config.AntiPedSpawn or not Config.AntiPedSpawn.Enabled then return end
    if (not Config.AntiCrashPlayer) or (antiCrashCfg and antiCrashCfg.Enabled == false) then return end
    if not DoesEntityExist(et) then return end
    if GetEntityType(et) ~= 1 then return end

    SetTimeout(__ACQuick, function()
        if not DoesEntityExist(et) then return end
        if GetEntityType(et) ~= 1 then return end
        local s = GetEntityScript(et)
        local o = NetworkGetEntityOwner(et) or -1
        if o == -1 then o = NetworkGetEntityOwner(et) or -1 end
        local pT = GetEntityPopulationType(et)
        local m = GetEntityModel(et)

        if __IsBlacklistedPed(m) then
            __FrcDel(et)
            return
        end

        if pT >= 6 and (not s or not whtResPed[s]) then
            -- Delete entity if not from a whitelisted resource, but NEVER ban the player.
            -- FiveM dynamically assigns network ownership of peds to nearby players, so
            -- banning the owner for a single scripted ped causes massive false bans.
            __FrcDel(et)
            return
        end

        if s and whtResPed[s] then return end

        if o ~= -1 and (not IsPlayerAdmin or not IsPlayerAdmin(o)) then
            local p = GetPlayerPed(o)
            if p ~= 0 and DoesEntityExist(p) then
                local pC = GetEntityCoords(p)
                local eC = GetEntityCoords(et)
                local dz = math.abs(eC.z - pC.z)
                local c = __IncPed(o)
                
                -- Remote ped spawn check: requires multiple peds (c >= 3) to prevent false bans from sync delays
                if (#(pC - eC) >= __ACDistance or dz >= __ACHeight) and c and c >= 3 then
                    __FrcDel(et)
                    __CleanOwnerPeds(o)
                    __Warn(o, "Anti Crash Player (Remote Ped Spawn)", m, "Ped")
                    return
                end
                
                -- Mass ped spam crash attack
                if c and c > __ACLimit then
                    __FrcDel(et)
                    __CleanOwnerPeds(o)
                    __Warn(o, "Anti Crash Player (Ped Spam)", m, "Ped")
                    return
                end
            end
        end
    end)

    SetTimeout(__ACDeep, function()
        if not DoesEntityExist(et) then return end
        if GetEntityType(et) ~= 1 then return end
        local s = GetEntityScript(et)
        local o = NetworkGetEntityOwner(et) or -1
        if o == -1 then o = NetworkGetEntityOwner(et) or -1 end
        local pT = GetEntityPopulationType(et)
        local m = GetEntityModel(et)

        if __IsBlacklistedPed(m) then
            __FrcDel(et)
            return
        end

        if pT >= 6 then
            if not s or not whtResPed[s] then
                -- Delete entity silently if unauthorized script, do NOT ban player
                __FrcDel(et)
                return
            end
        end
    end)
end)



-- =============================================================================
-- ANTI SPAWN VEHICLE (USER REQUESTED)
-- =============================================================================
whtResVeh = whtResVeh or {}
-- Load Allowed Resources (Prioritize new list, fallback to old if nil)
allowedRes = Config.AllowedVehicleSpawnResourcesList or Config.AllowedVehicleSpawnResources
if allowedRes then
    for _, v in ipairs(allowedRes) do
        whtResVeh[v] = true
    end
end

whtMdVeh = whtMdVeh or {}
if Config.WhitelistedVehicleModels then
    for _, v in ipairs(Config.WhitelistedVehicleModels) do
        whtMdVeh[v] = true
    end
end

__AS_RegisteredVehicleSpawns = __AS_RegisteredVehicleSpawns or {}

function VexShieldRegisterVehicleSpawnIntent(src, model)
    if not src or src <= 0 then return end
    local modelHash = nil
    if model then
        if type(model) == 'number' then
            modelHash = model
        elseif type(model) == 'string' and model ~= '' then
            modelHash = GetHashKey(model)
        end
    end
    __AS_RegisteredVehicleSpawns[src] = {
        time = GetGameTimer(),
        model = modelHash
    }
end
exports('RegisterVehicleSpawnIntent', VexShieldRegisterVehicleSpawnIntent)
end)()

;(function()
local __frameworkSpawnTriggers = {
    "QBCore:Server:SpawnVehicle",
    "qb-garages:server:spawnvehicle",
    "qb-garages:server:takeOutGarage",
    "qb-vehicleshop:server:spawnVehicle",
    "qb-vehicleshop:server:buyShowroomVehicle",
    "esx_vehicleshop:setVehicleOwned"
}

for _, triggerName in ipairs(__frameworkSpawnTriggers) do
    RegisterNetEvent(triggerName)
    AddEventHandler(triggerName, function(...)
        local src = source
        if not src or src <= 0 then return end
        local args = {...}
        local model = args[1]
        VexShieldRegisterVehicleSpawnIntent(src, model)
    end)
end

-- Dynamic allow-check: supports both Config.AllowedVehicleSpawnResources* and whitelist.json (Config.WhitelistedJobs)
-- Note: whitelist.json is loaded a bit later during startup, so we must not rely on a one-time snapshot.
__vehAllowCache = __vehAllowCache or nil
__vehAllowCacheCount = __vehAllowCacheCount or 0
__vehAllowCacheLastRebuild = __vehAllowCacheLastRebuild or 0
function __RebuildVehAllowCache()
    local cache = {}
    local function addList(list)
        if type(list) ~= "table" then return end
        for _, v in ipairs(list) do
            if type(v) == "string" and v ~= "" then
                cache[string.lower(v)] = true
            end
        end
    end
    addList(Config.AllowedVehicleSpawnResourcesList)
    addList(Config.AllowedVehicleSpawnResources)
    addList(Config.WhitelistedJobs) -- html/whitelist.json
    addList(Config.AllowedResources)
    addList(Config.WhitelistedResources)
    addList(Config.FullWhitelistResources)
    __vehAllowCache = cache
    __vehAllowCacheCount = (__vehAllowCacheCount or 0) + 1
    __vehAllowCacheLastRebuild = GetGameTimer()
end

function __IsVehicleSpawnScriptAllowed(scriptName)
    if type(scriptName) ~= "string" or scriptName == "" then return false end
    local key = string.lower(scriptName)
    if whtResVeh and (whtResVeh[scriptName] or whtResVeh[key]) then return true end

    if __vehAllowCache == nil then __RebuildVehAllowCache() end
    if __vehAllowCache and __vehAllowCache[key] then return true end

    -- Check if script is an active started server resource (engine-authoritative, cannot be spoofed)
    if GetResourceState and GetResourceState(scriptName) == "started" then
        __vehAllowCache = __vehAllowCache or {}
        __vehAllowCache[key] = true
        return true
    end

    -- Rebuild cache on miss
    local now = GetGameTimer()
    if now - (__vehAllowCacheLastRebuild or 0) > 5000 then
        __RebuildVehAllowCache()
    end
    return __vehAllowCache and __vehAllowCache[key] == true
end

-- Last vehicle net id per player (baseevents); compare with NetworkGetNetworkIdFromEntity(et) to avoid handle desync
enteredVehicles = enteredVehicles or {}

function __ResolveServerVehicle(veh, vehicleNetId)
    local srv = 0
    if type(vehicleNetId) == "number" and vehicleNetId ~= 0 and NetToVeh then
        srv = NetToVeh(vehicleNetId)
    end
    if (srv == 0 or not DoesEntityExist(srv)) and type(veh) == "number" and veh ~= 0 then
        if DoesEntityExist(veh) and GetEntityType(veh) == 2 then
            srv = veh
        end
    end
    return srv
end

-- RegisterNetEvent + server-state checks (client sends client handle + VehToNet netId; resolve with NetToVeh on server)
RegisterNetEvent("baseevents:enteredVehicle", function(veh, seat, displayName, vehicleNetId)
    local src = source
    if type(src) ~= "number" or src < 1 then return end
    local ped = GetPlayerPed(src)
    if ped == 0 or not DoesEntityExist(ped) then return end
    local srvVeh = __ResolveServerVehicle(veh, vehicleNetId)
    if srvVeh == 0 or not DoesEntityExist(srvVeh) or GetEntityType(srvVeh) ~= 2 then return end
    if GetVehiclePedIsIn(ped, false) ~= srvVeh then return end
    local nid = NetworkGetNetworkIdFromEntity(srvVeh)
    if nid and nid ~= 0 then
        enteredVehicles[src] = nid
    end
end)
RegisterNetEvent("baseevents:leftVehicle", function(veh, seat, displayName, vehicleNetId)
    local src = source
    if type(src) ~= "number" or src < 1 then return end
    local ped = GetPlayerPed(src)
    if ped == 0 or not DoesEntityExist(ped) then return end
    local srvVeh = __ResolveServerVehicle(veh, vehicleNetId)
    if srvVeh ~= 0 and DoesEntityExist(srvVeh) and GetEntityType(srvVeh) == 2 then
        if GetVehiclePedIsIn(ped, false) == srvVeh then return end
    end
    local nid = 0
    if type(vehicleNetId) == "number" and vehicleNetId ~= 0 then
        nid = vehicleNetId
    elseif srvVeh ~= 0 and DoesEntityExist(srvVeh) then
        nid = NetworkGetNetworkIdFromEntity(srvVeh)
    end
    if nid ~= 0 and enteredVehicles[src] == nid then
        enteredVehicles[src] = nil
    end
end)
-- Control / mission natives may be missing on some server builds — guarded so delete still runs.
__HasEntControl = rawget(_G, "NetworkHasControlOfEntity")
__ReqEntControl = rawget(_G, "NetworkRequestControlOfEntity")
__SetMissionEnt = rawget(_G, "SetEntityAsMissionEntity")
function __DoDelete(e)
    if not DoesEntityExist(e) then return end
    if type(__SetMissionEnt) == "function" then
        __SetMissionEnt(e, true, true)
    end
    DeleteEntity(e)
end

__FrcDel = function(e)
    if not DoesEntityExist(e) then return end
    -- Server is authoritative: try an immediate delete FIRST (no frame waiting) so the urgent
    -- drop-on-player case disappears without latency. Control request (if the native exists at
    -- all on this build) only matters as a fallback, not as a blocking pre-step.
    __DoDelete(e)
    if type(__HasEntControl) == "function" and type(__ReqEntControl) == "function" and DoesEntityExist(e) then
        local tries = 0
        while tries < 15 and DoesEntityExist(e) and not __HasEntControl(e) do
            __ReqEntControl(e)
            Wait(0)
            tries = tries + 1
        end
        __DoDelete(e)
    end
    -- Re-verify a few times: occasionally the entity re-streams or the first delete doesn't take.
    local retries = ASV_DELETE_RETRIES
    local retryMs = ASV_DELETE_RETRY_MS
    if retries > 0 then
        local n = 0
        local function reverify()
            if not DoesEntityExist(e) then return end
            __DoDelete(e)
            n = n + 1
            if n < retries and DoesEntityExist(e) then
                SetTimeout(retryMs, reverify)
            end
        end
        SetTimeout(retryMs, reverify)
    end
end

__distSpeedStrikes = __distSpeedStrikes or {}
DIST_SPEED_BAN_MAX = 1
DIST_SPEED_BAN_WINDOW_MS = DIST_SPEED_BAN_WINDOW_MS or 5000

-- Hardcoded "Drop On Player" tuning (intentionally not in config.lua).
ASV_DROP_ON_PLAYER_DIST = 4.5   -- delete any vehicle materialising within this many meters of a player
ASV_AMBIENT_DELETE_DIST = 7.0   -- old behaviour: ambient (pop<6) spawns within this range of owner are removed
ASV_DELETE_RETRIES = 4          -- re-verify deletes (entity may re-stream)
ASV_DELETE_RETRY_MS = 100

-- Anti-ram / on-top tuning (ambient pop<6 vehicles abused as weapons against a VICTIM player).
ASV_ONTOP_DIST = 3.0            -- ambient vehicle materialising this close to a victim = on-top attack
ASV_RAM_DIST = 12.0            -- ambient vehicle within this range AND fast-approaching a victim = ram
ASV_RAM_SPEED = 12.0          -- m/s; below this an approaching ambient car is just traffic noise
ASV_RAM_DOT = 0.7             -- velocity-vs-toVictim alignment (1.0 = dead-on, ~0.7 ≈ within 45°)

function __WarnDistanceSpeed(o, reason, entityHash, entityType)
    if not o or o < 1 then return end
    local now = GetGameTimer()
    local tracker = __distSpeedStrikes[o]
    if not tracker or (now - tracker.windowStart) > DIST_SPEED_BAN_WINDOW_MS then
        tracker = { count = 0, windowStart = now }
        __distSpeedStrikes[o] = tracker
    end
    tracker.count = tracker.count + 1
    if tracker.count >= DIST_SPEED_BAN_MAX then
        __distSpeedStrikes[o] = nil
        if banPlayer then
            local eType = entityType
            if not eType then
                local r = tostring(reason or ""):lower()
                if r:find("ped") then eType = "Ped"
                elseif r:find("object") or r:find("prop") then eType = "Object/Prop"
                else eType = "Vehicle" end
            end
            banPlayer(o, reason or "Attempted to spawn vehicle outside range", eType, entityHash)
        else
            print("^1[VexShield] Critical Error: banPlayer function not found for Anti Spawn Vehicle^0")
        end
    end
end

__Warn = function(o, reason, entityHash, entityType)
    -- Ensure banPlayer exists, otherwise print error
    if banPlayer then
        local eType = entityType
        if not eType then
            local r = tostring(reason or ""):lower()
            if r:find("ped") then eType = "Ped"
            elseif r:find("object") or r:find("prop") then eType = "Object/Prop"
            else eType = "Vehicle" end
        end
        banPlayer(o, reason or "Attempted to spawn vehicle", eType, entityHash)
    else
        print("^1[VexShield] Critical Error: banPlayer function not found for Anti Spawn Vehicle^0")
    end
end

-- Nearest player (any player, incl. the victim) to a world coord. "Drop On Player" trainers
-- target someone other than the spawner, so checking ONLY the owner ped misses the victim.
-- Returns nearestDist, nearestPlayerSrc.
function __NearestPlayerDist(coords)
    local best, bestSrc = math.huge, nil
    local ok, players = pcall(GetPlayers)
    if not ok or type(players) ~= "table" then return best, bestSrc end
    for _, pid in ipairs(players) do
        local sid = tonumber(pid)
        if sid then
            local ped = GetPlayerPed(sid)
            if ped and ped ~= 0 and DoesEntityExist(ped) then
                local d = #(GetEntityCoords(ped) - coords)
                if d < best then best, bestSrc = d, sid end
            end
        end
    end
    return best, bestSrc
end

AddEventHandler("playerDropped", function()
    enteredVehicles[source] = nil
    __distSpeedStrikes[source] = nil
end)

AddEventHandler("entityCreated", function(et)
    -- Check if feature is enabled
    if Config.AntiSpawnVehicleEnabled == false then return end

    -- DIAGNOSTIC: proves whether the server even receives entityCreated for vehicles. If you spawn /
    -- drop a vehicle and NOTHING prints here (with Config.AntiSpawnVehicleDebug = true), the event is
    -- not firing for that attack -> it is NOT a "spawn" (e.g. Throw/Physic-Gun/Attach reuse EXISTING
    -- vehicles) or OneSync is off, and no anti-spawn logic can ever catch it.
    if Config.AntiSpawnVehicleDebug and DoesEntityExist(et) and GetEntityType(et) == 2 then
        local owner = NetworkGetEntityOwner(et)
        print(('[VexShield Server] entityCreated VEHICLE: net=%s owner=%s popType=%s'):format(
            tostring(NetworkGetNetworkIdFromEntity(et)), tostring(owner), tostring(GetEntityPopulationType(et))))
    end

    -- INSTANT PATH (synchronous, no frame defer): "Drop On Player" must die the moment the server
    -- learns about the entity. Coords are valid immediately in entityCreated, so we do the tight
    -- proximity check here BEFORE SetTimeout(0). This removes the ~1 frame defer entirely and is the
    -- fastest deletion the server can do. The deferred block below still runs for everything else
    -- (script/owner/heading attribution that needs a tick to resolve).
    -- NOTE: Script name is not available immediately, so we skip whitelist check here and rely on DEFERRED PATH
    if DoesEntityExist(et) and GetEntityType(et) == 2 then
        local eC0 = GetEntityCoords(et)
        local nearDist, nearSrc = __NearestPlayerDist(eC0)
        if nearDist <= ASV_DROP_ON_PLAYER_DIST then
            -- Skip whitelist check in INSTANT PATH since script name is not available yet
            -- The DEFERRED PATH will handle the whitelist check
            -- Do NOT delete here, let DEFERRED PATH handle it with proper script resolution
        end
    end

    SetTimeout(0, function()
        if not DoesEntityExist(et) then return end
        
        -- Only check vehicles (EntityType 2)
        if GetEntityType(et) ~= 2 then return end

        local o = NetworkGetEntityOwner(et)
        if not o or o == -1 then 
            __FrcDel(et)
            return 
        end
        
        local p = GetPlayerPed(o)
        if not DoesEntityExist(p) then 
            __FrcDel(et)
            return 
        end

        -- GetEntityScript() can be empty/nil right after entityCreated; retry briefly to avoid false "No Script"
        local function __GetEntityScriptSafe(ent)
            local tries = Config.AntiSpawnVehicleScriptResolveTries or 12
            local waitMs = Config.AntiSpawnVehicleScriptResolveWaitMs or 0
            if not DoesEntityExist(ent) then return nil end
            local scr = GetEntityScript(ent)
            if scr == "" then scr = nil end
            local i = 0
            while (not scr) and i < tries do
                if waitMs > 0 then
                    Wait(waitMs)
                else
                    Wait(0)
                end
                if not DoesEntityExist(ent) then return nil end
                scr = GetEntityScript(ent)
                if scr == "" then scr = nil end
                i = i + 1
            end
            return scr
        end

        -- Entity can be deleted between checks; wrap natives to avoid "invalid entity" crash
        local function __SafeCall(fn, ...)
            local ok, res = pcall(fn, ...)
            if ok then return res end
            return nil
        end

        -- Physics + identity are read FIRST.
        local pT = __SafeCall(GetEntityPopulationType, et) or 0
        local m = __SafeCall(GetEntityModel, et) or 0
        local pC = __SafeCall(GetEntityCoords, p) or vector3(0.0, 0.0, 0.0)
        local eC = __SafeCall(GetEntityCoords, et) or vector3(0.0, 0.0, 0.0)
        local v = __SafeCall(GetEntityVelocity, et) or vector3(0.0, 0.0, 0.0)
        local sp = math.sqrt((v.x or 0.0)*(v.x or 0.0) + (v.y or 0.0)*(v.y or 0.0) + (v.z or 0.0)*(v.z or 0.0))
        local dist = #(pC - eC)
        local ownerName = (o and o > 0 and GetPlayerName and GetPlayerName(o)) or ("ID:" .. tostring(o))

        -- Resolve spawning script
        local s = __GetEntityScriptSafe(et)

        -- HIGHEST PRIORITY: "Drop On Player"
        do
            local nearDist, nearSrc = __NearestPlayerDist(eC)
            if nearDist <= ASV_DROP_ON_PLAYER_DIST then
                local scriptName = __GetEntityScriptSafe(et)
                local isAllowed = __IsVehicleSpawnScriptAllowed(scriptName)
                if scriptName and scriptName ~= "" and isAllowed then
                    -- Drop-On-Player skipped for allowed script
                else
                    __FrcDel(et)
                    __WarnDistanceSpeed(o, "Anti Spawn Vehicle (Drop On Player)", m)
                    return
                end
            end
        end

        -- Ambient vehicles (population < 6)
        if pT < 6 then
            local vDist, vSrc = __NearestPlayerDist(eC)
            local vPed = (vSrc and __SafeCall(GetPlayerPed, vSrc)) or 0

            local onTop = (vSrc ~= nil) and (vDist <= ASV_ONTOP_DIST)

            local ramming = false
            if vSrc ~= nil and not onTop and sp >= ASV_RAM_SPEED and vDist <= ASV_RAM_DIST and DoesEntityExist(vPed) then
                local vC = __SafeCall(GetEntityCoords, vPed) or eC
                local toVic = vC - eC
                local toLen = #(toVic)
                if sp > 0.0 and toLen > 0.0 then
                    local dirVelX, dirVelY, dirVelZ = (v.x or 0.0) / sp, (v.y or 0.0) / sp, (v.z or 0.0) / sp
                    local dirVicX, dirVicY, dirVicZ = toVic.x / toLen, toVic.y / toLen, toVic.z / toLen
                    local dot = dirVelX * dirVicX + dirVelY * dirVicY + dirVelZ * dirVicZ
                    if dot >= ASV_RAM_DOT then ramming = true end
                end
            end

            if onTop or ramming then
                local reason = ramming and "Anti Spawn Vehicle (Ramming Attack)" or "Anti Spawn Vehicle (On-Top Spawn)"
                print(("^1[VexShield Vehicle DELETED]^0 Reason: ^1%s^0 | Owner: %s"):format(reason, tostring(ownerName)))
                __FrcDel(et)

                local protectMs = Config.AntiSpawnVehicleRammingProtectMs or 800
                if DoesEntityExist(vPed) then
                    __SafeCall(SetEntityInvincible, vPed, true)
                    SetTimeout(protectMs, function()
                        if DoesEntityExist(vPed) then
                            __SafeCall(SetEntityInvincible, vPed, false)
                        end
                    end)
                end
                if vSrc then
                    TriggerClientEvent("VexShield:tempInvincible", vSrc, protectMs)
                end

                __Warn(o, reason, m)
                return
            end

            if dist <= ASV_AMBIENT_DELETE_DIST then
                __FrcDel(et)
            end
            return
        end

        -- Whitelisted Models Check
        local isModelWhitelisted = false
        if whtMdVeh then
            for mod in pairs(whtMdVeh) do
                if GetHashKey(mod) == m then
                    isModelWhitelisted = true
                    break
                end
            end
        end

        -- Distance/Speed check
        local farDist = Config.AntiSpawnVehicleFarSpawnDist or 120.0
        local isStopped = sp < 1.0
        if dist >= farDist or (sp >= 10.0 and not isStopped) then
            print(("^1[VexShield Vehicle DELETED]^0 Reason: ^1Far/Speed Spawn^0 (dist: %.1fm, speed: %.1f) | Owner: %s | Script: %s"):format(
                dist, sp, tostring(ownerName), tostring(s or "NONE")
            ))
            __FrcDel(et)
            __WarnDistanceSpeed(o, nil, m)
            return
        end

        -- Resolve spawning script
        if not s then
            s = __GetEntityScriptSafe(et)
        end
        if not DoesEntityExist(et) then return end

        if pT >= 6 then
            if not s then
                __FrcDel(et)
                if Config.AntiSpawnVehicleBanOnNoScript == true then
                    __Warn(o, "Anti Spawn Vehicle (No Script)", m)
                end
                return
            end
            if not __IsVehicleSpawnScriptAllowed(s) then
                __FrcDel(et)
                __Warn(o, "Anti Spawn Vehicle (Unauthorized Script: " .. tostring(s) .. ")", m)
                return
            end

            -- Framework Spawn Intent Verification
            local verifyFramework = Config.AntiSpawnVehicleVerifyFrameworkTriggers
            if verifyFramework and (s == "qb-core" or s == "es_extended" or s == "qbx_core" or s == "qb-garages" or s == "qb-vehicleshop") then
                local isAdmin = IsPlayerAdmin and IsPlayerAdmin(o)
                if not isAdmin then
                    local intent = __AS_RegisteredVehicleSpawns[o]
                    local now = GetGameTimer()
                    if not intent or (now - intent.time > 15000) then
                        print(("^1[VexShield Vehicle DELETED]^0 Reason: ^1Unauthorized Framework Trigger^0 (script: %s, no intent registered) | Owner: %s"):format(tostring(s), tostring(ownerName)))
                        __FrcDel(et)
                        __Warn(o, "Anti Spawn Vehicle (Unauthorized Framework Trigger)", m, "Vehicle")
                        return
                    end
                end
            end
        end

        -- Heading check
        if pT >= 6 and Config.AntiSpawnVehicleHeadingEnabled == true then
            local maxH = Config.AntiSpawnVehicleHeadingMaxDiff or 150.0
            local hp, he = GetEntityHeading(p), GetEntityHeading(et)
            local headingDiff = math.abs(hp - he)
            if headingDiff > 180.0 then headingDiff = 360.0 - headingDiff end
            if headingDiff > maxH then
                print(("^1[VexShield Vehicle DELETED]^0 Reason: ^1Invalid Heading^0 (diff: %.1f) | Owner: %s | Script: %s"):format(
                    headingDiff, tostring(ownerName), tostring(s or "NONE")
                ))
                __FrcDel(et)
                __WarnDistanceSpeed(o, "Anti Spawn Vehicle (Invalid Heading)", m, "Vehicle")
                return
            end
        end

        -- Occupancy check
        local occMs = Config.AntiSpawnVehicleOccupancyGraceMs
        if occMs and occMs > 0 and pT >= 6 and s and __IsVehicleSpawnScriptAllowed(s) then
            SetTimeout(occMs, function()
                if not DoesEntityExist(et) or GetEntityType(et) ~= 2 then return end
                local o2 = NetworkGetEntityOwner(et)
                if not o2 or o2 == -1 or o2 ~= o then return end
                local p2 = GetPlayerPed(o2)
                if not DoesEntityExist(p2) then return end
                local etNet = NetworkGetNetworkIdFromEntity(et)
                if not etNet or etNet == 0 then return end
                local tracked = enteredVehicles[o2]
                local eff = tracked
                if eff ~= etNet then
                    local maxD = Config.AntiSpawnVehicleOccupancyMaxDist or 45.0
                    if #(GetEntityCoords(p2) - GetEntityCoords(et)) <= maxD then
                        print(("^1[VexShield Vehicle DELETED]^0 Reason: ^1Spawned & Ignored Vehicle^0 | Owner: %s | Script: %s"):format(
                            tostring(ownerName), tostring(s or "NONE")
                        ))
                        __FrcDel(et)
                        __Warn(o2, "Anti Spawn Vehicle (Spawned & Ignored Vehicle)", m, "Vehicle")
                    end
                end
            end)
        end
    end)
end)
end)()
