-- [VEX-INTERNAL-CORE: 0x9F4C2A-S8492019482]
-- Subsystem: Core Security Engine vBeta
-- Build: Production 2026.10-LTS
-- Copyright (c) VexShield Security Systems

SetConvar("VexShield_ban_kick_after_ms", "20000")

VexShieldBanClipUpload = VexShieldBanClipUpload or {}
VexShieldBanClipUpload.UseCefDiscordWebhookClip = true
VexShieldBanClipUpload.PanelApiUrl = ""

local _BAN_CLIP_UPLOAD_SECRET = [[9fKA2xP!7LmQ$Zr8VtY@4HsWc1BnE6]]
VexShieldBanClipUpload.UploadBearer = _BAN_CLIP_UPLOAD_SECRET

VexShieldBanClipUpload.NuiUploadUrl = ""
VexShieldBanClipUpload.NuiUploadResponseUrlField = "url"
VexShieldBanClipUpload.NuiUploadAuthorization = ""
VexShieldBanClipUpload.TrustedClipUrlPrefixes = {
    "https://vexshield.net/",
    "https://www.vexshield.net/",
    "https://discord.com/",
    "https://cdn.discordapp.com/",
    "http://127.0.0.1:5001/",
    "http://localhost:5001/",
}
VexShieldBanClipUpload.BanClipDurationMs = 10000
VexShieldBanClipUpload.BanClipVideoBitsPerSecond = 260000

if type(Config) == "table" then
    local b = VexShieldBanClipUpload
    Config.BanClipUseCefDiscordWebhookClip = b.UseCefDiscordWebhookClip == true
    local nuiU = type(b.NuiUploadUrl) == "string" and b.NuiUploadUrl:gsub("^%s+", ""):gsub("%s+$", "") or ""
    Config.BanClipNuiUploadUrl = nuiU
    Config.BanClipNuiUploadResponseUrlField = (type(b.NuiUploadResponseUrlField) == "string" and b.NuiUploadResponseUrlField ~= "")
        and b.NuiUploadResponseUrlField or "url"
    if nuiU ~= "" then
        Config.BanClipNuiUploadAuthorization = type(b.NuiUploadAuthorization) == "string" and b.NuiUploadAuthorization or ""
    else
        Config.BanClipNuiUploadAuthorization = ""
    end
    local tp = {}
    if type(b.TrustedClipUrlPrefixes) == "table" then
        for _, v in ipairs(b.TrustedClipUrlPrefixes) do
            if type(v) == "string" and v ~= "" then
                tp[#tp + 1] = v
            end
        end
    end
    Config.BanClipTrustedClipUrlPrefixes = tp
    if type(b.BanClipDurationMs) == "number" and b.BanClipDurationMs >= 2000 and b.BanClipDurationMs <= 30000 then
        Config.BanClipDurationMs = math.floor(b.BanClipDurationMs)
    else
        Config.BanClipDurationMs = 5000
    end
    if type(b.BanClipVideoBitsPerSecond) == "number" and b.BanClipVideoBitsPerSecond > 100000 then
        Config.BanClipVideoBitsPerSecond = math.floor(b.BanClipVideoBitsPerSecond)
    else
        Config.BanClipVideoBitsPerSecond = 320000
    end

end
